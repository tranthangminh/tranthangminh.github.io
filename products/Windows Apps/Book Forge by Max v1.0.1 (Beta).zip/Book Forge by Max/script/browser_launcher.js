const fs = require('fs');
const path = require('path');
const os = require('os');

/**
 * Robust Puppeteer Browser Launcher for Windows
 * - Creates an isolated temporary user-data-dir per session to avoid profile locking
 * - Disables Microsoft Edge Startup Boost (msEdgeStartupBoost) which causes immediate exit code 0
 * - Adds anti-sandbox, disable-extensions, and headless flags
 * - Automatically falls back to default bundled Chrome if a specified executablePath fails
 * - Automatically purges temporary user-data-dir on browser close
 */
async function launchRobustBrowser(puppeteerMod, options = {}) {
    // A killed run (Stop, closing the app) cannot clean up after itself, so the next launch does.
    for (const name of fs.readdirSync(os.tmpdir())) {
        if (name.startsWith('bf-pup-')) {
            try { fs.rmSync(path.join(os.tmpdir(), name), { recursive: true, force: true }); } catch (e) {}
        }
    }

    const tempProfile = fs.mkdtempSync(path.join(os.tmpdir(), 'bf-pup-'));

    const defaultArgs = [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-web-security',
        '--disable-features=msEdgeStartupBoost,Translate,BackForwardCache',
        '--disable-extensions',
        '--disable-component-update',
        '--disable-background-networking',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--no-first-run',
        '--no-default-browser-check',
        '--user-data-dir=' + tempProfile
    ];

    const launchOpts = {
        headless: 'new',
        args: defaultArgs,
        ...options
    };

    if (options.args) {
        const mergedArgs = [...defaultArgs];
        for (const arg of options.args) {
            if (!mergedArgs.includes(arg) && !arg.startsWith('--user-data-dir=')) {
                mergedArgs.push(arg);
            }
        }
        launchOpts.args = mergedArgs;
    }

    if (!launchOpts.executablePath) {
        const envPath = process.env.PUPPETEER_EXECUTABLE_PATH || process.env.CHROME_PATH;
        if (envPath && fs.existsSync(envPath)) {
            launchOpts.executablePath = envPath;
        }
    }

    let browser = null;
    try {
        browser = await puppeteerMod.launch(launchOpts);
    } catch (err) {
        if (launchOpts.executablePath) {
            console.warn('[BrowserLauncher] Warning: Launching with ' + launchOpts.executablePath + ' failed: ' + err.message + '. Retrying with default browser...');
            const savedPupPath = process.env.PUPPETEER_EXECUTABLE_PATH;
            const savedChromePath = process.env.CHROME_PATH;
            delete process.env.PUPPETEER_EXECUTABLE_PATH;
            delete process.env.CHROME_PATH;
            const fallbackOpts = { ...launchOpts };
            delete fallbackOpts.executablePath;
            try {
                browser = await puppeteerMod.launch(fallbackOpts);
            } catch (fallbackErr) {
                try { fs.rmSync(tempProfile, { recursive: true, force: true }); } catch (e) {}
                throw fallbackErr;
            } finally {
                if (savedPupPath) process.env.PUPPETEER_EXECUTABLE_PATH = savedPupPath;
                if (savedChromePath) process.env.CHROME_PATH = savedChromePath;
            }
        } else {
            try { fs.rmSync(tempProfile, { recursive: true, force: true }); } catch (e) {}
            throw err;
        }
    }

    const originalClose = browser.close.bind(browser);
    browser.close = async () => {
        try {
            await originalClose();
        } finally {
            try {
                fs.rmSync(tempProfile, { recursive: true, force: true });
            } catch (e) {}
        }
    };

    const browserProcess = browser.process ? browser.process() : null;
    if (browserProcess && browserProcess.pid) {
        const killBrowserSync = () => {
            try {
                if (process.platform === 'win32') {
                    require('child_process').execSync(`taskkill /F /T /PID ${browserProcess.pid}`, { stdio: 'ignore' });
                } else {
                    browserProcess.kill('SIGKILL');
                }
            } catch (e) {}
            try {
                fs.rmSync(tempProfile, { recursive: true, force: true });
            } catch (e) {}
        };

        process.once('exit', killBrowserSync);
        process.once('SIGINT', () => { killBrowserSync(); process.exit(1); });
        process.once('SIGTERM', () => { killBrowserSync(); process.exit(1); });
        process.once('SIGHUP', () => { killBrowserSync(); process.exit(1); });
    }

    return browser;
}

module.exports = { launchRobustBrowser };
