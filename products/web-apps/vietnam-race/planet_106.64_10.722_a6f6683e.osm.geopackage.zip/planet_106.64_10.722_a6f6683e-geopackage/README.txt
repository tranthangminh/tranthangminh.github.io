Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
geopackage by https://gdal.org

Please read the OSM wiki on how to use GeoPackage files:

  https://wiki.openstreetmap.org/wiki/GeoPackage


This GeoPackage file was created on: Sat 24 Oct 16:31:16 UTC 2026
GPS rectangle coordinates (lng,lat): 106.543,10.722 x 106.846,10.94
Script URL: https://extract.bbbike.org/?sw_lng=106.543&sw_lat=10.722&ne_lng=106.846&ne_lat=10.94&format=geopackage.zip&coords=106.64%2C10.722%7C106.765%2C10.726%7C106.846%2C10.843%7C106.769%2C10.919%7C106.662%2C10.94%7C106.543%2C10.905&city=HoChiMinh&lang=en
Name of area: HoChiMinh


We welcome your feedback and suggestions. If you find the service useful,
please consider a donation via PayPal or bank transfer:

  https://extract.bbbike.org/community.html

Any amount helps, whether 10, 20 or 50 euros: whatever the service is
worth to you, or whatever you can afford. We need to raise 20 euros a day,
or 600 euros a month, to cover the server costs. Many thanks!

Thanks, Wolfram Schneider

--
Donate to BBBike: https://extract.bbbike.org/community.html
Upgrade to BBBike Pro: https://extract.bbbike.org/support.html
