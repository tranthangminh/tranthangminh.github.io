import maya.cmds as cmds
import maya.mel as mel
import math
import os

#-------------------------------------------Support Function----------------------------------------------------
LOCAL_PATH = os.path.expanduser("~").replace("\\", "/") + "/maya/" + str(cmds.about(version=True)) + "/scripts"
if int(cmds.about(version=True)) >= 2023:
	LOCAL_PATH = os.path.expanduser("~").replace("\\", "/") + "/Documents/maya/" + str(cmds.about(version=True)) + "/scripts"

highpoly_define_name = "HSTool_High"

def combine_object(selected_objects):
	cmds.select(selected_objects)
	if len(selected_objects) > 1:
		mel.eval("source \"" + LOCAL_PATH + "/Model_Tools/Scripts/Mel/Combine.mel\"")
	return cmds.ls(sl=True)

def check_highpoly_name(name):
	split_list = name.rsplit("|", 1)[-1].rsplit("_", 1)
	if split_list[0] == highpoly_define_name and split_list[-1].isnumeric():
		return True
	else:
		return False

def export_fbx_for_baking(object_name, fbx_path):
	if cmds.checkBox('bakeset_lock_normal_cb', q=True, v=True):
		mel.eval('FBXProperty Export|IncludeGrp|Geometry|TangentsandBinormals -v true')
	else:
		mel.eval('FBXProperty Export|IncludeGrp|Geometry|TangentsandBinormals -v false')	
	mel.eval('FBXProperty Export|IncludeGrp|Geometry|SmoothingGroups -v true')
	mel.eval('FBXProperty Export|IncludeGrp|Geometry|expHardEdges -v false')
	mel.eval('FBXProperty Export|IncludeGrp|Geometry|SmoothMesh -v true')
	mel.eval('FBXProperty Export|IncludeGrp|Geometry|SelectionSet -v false')
	mel.eval('FBXProperty Export|IncludeGrp|Geometry|Instances -v false')
	mel.eval('FBXExportReferencedAssetsContent -v false')
	mel.eval('FBXExportTriangulate -v true')
	mel.eval('FBXExportInAscii -v true')

	if "high" in object_name.rsplit('_', 1)[-1].lower():
		print(1)
		mel.eval('FBXExportInAscii -v false')
		mel.eval('FBXProperty Export|IncludeGrp|Geometry|SmoothingGroups -v false')
		mel.eval('FBXProperty Export|IncludeGrp|Geometry|SmoothMesh -v false')
		mel.eval('FBXExportTriangulate -v false')
		
	mel.eval('FBXExport -f "' + fbx_path + '/' + object_name + '.fbx' + '" -s')

def get_distance(a_pos, b_pos):
	distance = math.sqrt(pow((a_pos[0]-b_pos[0]),2) + pow((a_pos[1]-b_pos[1]),2) + pow((a_pos[2]-b_pos[2]),2))
	return distance

def check_intersection(object_a, object_b):
	obj_a = cmds.duplicate(object_a)
	obj_b = cmds.duplicate(object_b)
	results = cmds.polyCBoolOp(obj_a[0], obj_b[0], useThresholds=True, op=3)
	num_intersect_vertex = cmds.polyEvaluate(results[0], v=True)
	
	cmds.delete(results)
	cmds.delete(obj_a[0])
	cmds.delete(obj_b[0])

	if num_intersect_vertex != 0:
		return True
	else:
		return False

def check_overlap(object_a, object_b):
	bb_a = cmds.exactWorldBoundingBox(object_a)
	a_min = [bb_a[0], bb_a[1], bb_a[2]]
	a_max = [bb_a[3], bb_a[4], bb_a[5]]

	bb_b = cmds.exactWorldBoundingBox(object_b)
	b_min = [bb_b[0], bb_b[1], bb_b[2]]
	b_max = [bb_b[3], bb_b[4], bb_b[5]]

	diagonal_line_length = get_distance(b_min, b_max)
	min_distance = diagonal_line_length * cmds.floatField('bakeset_auto_threshold_ff', q=True, v=True)
	if get_distance(a_min, b_min) >= min_distance or get_distance(a_max, b_max) >= min_distance:
		return False
	else:
		return True
#----------------------------------------------------Function----------------------------------------------------
def get_material_from_objects(*arg):
	shapes_sel = cmds.ls(dagObjects=True, objectsOnly=True, shapes=True, selection=True) # get shapes of selection
	shaders_list = []
	if shapes_sel == []:
		cmds.warning('Nothing selected!')
	if shapes_sel != []:
		shading_group = cmds.listConnections(shapes_sel, type='shadingEngine') # get shading groups from shapes
		shaders_list = set(cmds.ls(cmds.listConnections(shading_group), materials=True)) # get the shaders  
	return list(shaders_list)


def apply_normal_map(mode):
	normal_path = cmds.textField('normal_map_path_tf', q=True, tx=True)

	obj_list = cmds.ls(sl=True, l = True)

	shader_name = "HSTool_Normal_MTL"

	if mode == 0:
		materials = get_material_from_objects()
		if len(materials) == 0:
			cmds.warning('Object has 0 materials!')
			return False
		else:
			shader_name = materials[0]
		for m in materials:
			cmds.delete(m)
	elif mode == 1:
		old_name = shader_name
		i = 1
		while shader_name in [m for m in cmds.ls(mat = True)]:
			shader_name = old_name + "_" + str(i)
			i += 1

	cmds.shadingNode('blinn', name=shader_name, asShader=True)
	cur_shader_SG = cmds.sets(name='%sSG' % shader_name, empty=True, renderable=True, noSurfaceShader=True)
	cmds.connectAttr(shader_name + '.outColor' , cur_shader_SG + '.surfaceShader' )
	
	# Create bump2d node
	bumpNode = cmds.shadingNode('bump2d', asUtility=True)
	cmds.setAttr(bumpNode + '.bumpInterp', 1)
	cmds.connectAttr(bumpNode + '.outNormal', shader_name + '.normalCamera')

	# Create file node
	fileNode = cmds.shadingNode( "file", asTexture=True, isColorManaged=True )
	textureName = cmds.shadingNode( "place2dTexture", asUtility=True )
	cmds.connectAttr(textureName + ".coverage", fileNode + ".coverage", force=True )
	cmds.connectAttr(textureName + ".translateFrame", fileNode + ".translateFrame", force=True )
	cmds.connectAttr(textureName + ".rotateFrame", fileNode + ".rotateFrame", force=True )
	cmds.connectAttr(textureName + ".mirrorU", fileNode + ".mirrorU", force=True )
	cmds.connectAttr(textureName + ".mirrorV", fileNode + ".mirrorV", force=True )
	cmds.connectAttr(textureName + ".stagger", fileNode + ".stagger", force=True )
	cmds.connectAttr(textureName + ".wrapU", fileNode + ".wrapU", force=True )
	cmds.connectAttr(textureName + ".wrapV", fileNode + ".wrapV", force=True )
	cmds.connectAttr(textureName + ".repeatUV", fileNode + ".repeatUV", force=True )
	cmds.connectAttr(textureName + ".offset", fileNode + ".offset", force=True )
	cmds.connectAttr(textureName + ".rotateUV", fileNode + ".rotateUV", force=True )
	cmds.connectAttr(textureName + ".noiseUV", fileNode + ".noiseUV", force=True )
	cmds.connectAttr(textureName + ".vertexUvOne", fileNode + ".vertexUvOne", force=True )
	cmds.connectAttr(textureName + ".vertexUvTwo", fileNode + ".vertexUvTwo", force=True )
	cmds.connectAttr(textureName + ".vertexUvThree", fileNode + ".vertexUvThree", force=True )
	cmds.connectAttr(textureName + ".vertexCameraOne", fileNode + ".vertexCameraOne", force=True )
	cmds.connectAttr(textureName + ".outUV", fileNode + ".uv", force=True )
	cmds.connectAttr(textureName + ".outUvFilterSize", fileNode + ".uvFilterSize", force=True )

	# Set path for file node
	cmds.setAttr(fileNode + ".fileTextureName", normal_path, type="string" )
	cmds.setAttr(fileNode + ".colorSpace", "Raw", type="string")

	# Connect file node to bump2d node
	cmds.connectAttr(fileNode + '.outAlpha', bumpNode+'.bumpValue')

	for obj in obj_list:
		cmds.sets(obj, e=True, forceElement=cur_shader_SG)

def auto_fill_normal_path(*arg):
	current_file_path = cmds.file(q= True, loc = True)
	if current_file_path != "unknown":
		current_file_name = current_file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
		current_folder_path = current_file_path.rsplit("/", 1)[0]
		file_path_list = [f for f in os.listdir(current_folder_path) if os.path.isfile(os.path.join(current_folder_path, f))]
		for f in file_path_list:
			file_name = f.rsplit(".", 1)[0].lower()
			if file_name == current_file_name + "_n" or file_name == current_file_name + "_nml" or file_name == current_file_name + "_normal" or "normal" in file_name:
				return f
	return ""

def auto_fill_export_path(*arg):
	current_file_path = cmds.file(q= True, loc = True)
	if current_file_path != "unknown":
		current_folder_path = current_file_path.rsplit("/", 1)[0] + "/FBX_" + current_file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0]
		return current_folder_path
	return ""

def get_normal_map_path(*arg):
	multipleFilters = "Texture Files (*.psd *.tga *.png);;All Files (*.*)"
	current_file_path = cmds.file(q= True, loc = True)
	if current_file_path != "unknown":
		default_path = current_file_path.rsplit("/", 1)[0]
		new_dir = cmds.fileDialog2(dir = default_path, cap = 'Choose Normal Map Path!', fm=1, ff=multipleFilters)
	else:
		new_dir = cmds.fileDialog2(cap = 'Choose Normal Map Path!', fm=1, ff=multipleFilters)
	cmds.textField('normal_map_path_tf', e=True, tx= new_dir[0])
	return True

def get_export_fbx_path(*arg):
	current_file_path = cmds.file(q= True, loc = True)
	if current_file_path != "unknown":
		default_path = current_file_path.rsplit("/", 1)[0]
		new_dir = cmds.fileDialog2(dir = default_path, cap = 'Choose Export FBX Path!', fm=3)
	else:
		new_dir = cmds.fileDialog2(dir = default_path, cap = 'Choose Export FBX Path!', fm=3)
	cmds.textField('export_fbx_path_tf', e=True, tx= new_dir[0])
	return True

def set_right_handed(*arg):
	obj = cmds.ls(sl=True, l=True)
	for s in obj:
		cmds.setAttr(s+'.tangentSpace', 0)

def set_left_handed(*arg):
	obj = cmds.ls(sl=True, l=True)
	for s in obj:
		cmds.setAttr(s+'.tangentSpace', 2)

def rename_highpoly(*arg):
	selected_transform_list = cmds.listRelatives(cmds.ls(sl=True, type = 'mesh', dag=True, ni=True, l=True), parent=True, f=True)
	if len(selected_transform_list) == 0:
		cmds.warning('Please select mesh for rename!')
		return False
	
	i = 1
	new_name = highpoly_define_name + '_1'
	for transform in selected_transform_list:
		# if check_highpoly_name(transform):
		# 	continue
		transform_list = [str(tr.rsplit("|", 1)[-1]) for tr in cmds.listRelatives(cmds.ls(sl=True, type = 'mesh', dag=True, ni=True, l=True), parent=True, f=True)]
		while new_name in transform_list:
			i += 1
			new_name = highpoly_define_name + '_' + str(i)
		cmds.rename(transform, new_name) 

	cmds.warning('Rename Highpoly: Done!')
	return True

def create_bakeset_group_auto_v2(*arg):
	# Unparent mesh list
	cmds.Unparent(cmds.ls(sl=True, type = 'mesh', dag=True, ni=True), s=True, w = True)
	# Delete empty group
	mel.eval('source cleanUpScene;')
	mel.eval('deleteEmptyGroups;')
	
	selected_transform_list = cmds.listRelatives(cmds.ls(sl=True, type = 'mesh', dag=True, ni=True, l=True), parent=True, f=True)

	# Get highpoly+lowpoly list
	highpoly_list = []
	lowpoly_list = []
	for obj in selected_transform_list:
		if check_highpoly_name(obj):
			highpoly_list.append(obj)
		else:
			lowpoly_list.append(obj)

	# Get bakeset group list
	bakeset_group_list = []
	## Get highpoly bakeset group list
	checked_highpoly_list = []
	for i in range(0, len(highpoly_list)):
		bakeset_highpoly_list = []
		if highpoly_list[i] not in checked_highpoly_list:
			checked_highpoly_list.append(highpoly_list[i])
			bakeset_highpoly_list.append(highpoly_list[i])
			for j in range(i+1, len(highpoly_list)):
				if highpoly_list[j] not in checked_highpoly_list:
					for k in range(0, len(bakeset_highpoly_list)):
						if check_intersection(bakeset_highpoly_list[k], highpoly_list[j]):
							break
						elif k == len(bakeset_highpoly_list) - 1:
							checked_highpoly_list.append(highpoly_list[j])
							bakeset_highpoly_list.append(highpoly_list[j])
			bakeset_group_list.append([bakeset_highpoly_list])

	# for i in bakeset_group_list:
	# 	for j in i:
	# 		print(j)

	# Get low bakeset group list
	checked_lowpoly_list = []

	for i in range(0, len(bakeset_group_list)):
		bakeset_lowpoly_list = []
		for j in range(0, len(bakeset_group_list[i][0])):
			for k in range(0, len(lowpoly_list)):
				if (lowpoly_list[k] not in checked_lowpoly_list) and check_overlap(bakeset_group_list[i][0][j], lowpoly_list[k]):
					checked_lowpoly_list.append(lowpoly_list[k])
					bakeset_lowpoly_list.append(lowpoly_list[k])
		bakeset_group_list[i].append(bakeset_lowpoly_list)

	for i in range(0, len(bakeset_group_list)):
		bakeset_name = cmds.textField('bakeset_name_tf', q=True, tx=True) + str(i+1)
		high_group = cmds.group(bakeset_group_list[i][0], n="High", w=True)
		if bakeset_group_list[i][1]:
			low_group = cmds.group(bakeset_group_list[i][1], n="Low", w=True)
		else:
			low_group = cmds.group(n="Low", w=True, em=True)
		cmds.group(high_group, low_group, n=bakeset_name, w=True)
		cmds.hide(bakeset_name)
	
	# Delete empty group
	mel.eval('source cleanUpScene;')
	mel.eval('deleteEmptyGroups;')

def create_bakeset_group_auto(*arg):
	# Unparent mesh list
	cmds.Unparent(cmds.ls(sl=True, type = 'mesh', dag=True, ni=True), s=True, w = True)
	# Delete empty group
	mel.eval('source cleanUpScene;')
	mel.eval('deleteEmptyGroups;')

	#Create BakeSet Group
	object_pair_list = []
	checked_object_list = []
	selected_mesh_list = cmds.ls(sl=True, type = 'mesh', dag=True, ni=True, l=True)
	for i in range(0, len(selected_mesh_list)):
		for j in range(i+1, len(selected_mesh_list)):
			if i not in checked_object_list:
				if check_overlap(selected_mesh_list[i], selected_mesh_list[j]):
					object_pair_list.append([selected_mesh_list[i], selected_mesh_list[j]])
					checked_object_list.append(j)
					break
	for obj_pair in object_pair_list:
		transform_list = cmds.listRelatives(obj_pair, parent=True, f=True)
		if check_highpoly_name(transform_list[0]):
			highpoly_mesh = transform_list[0]
			lowpoly_mesh = transform_list[1]
		elif check_highpoly_name(transform_list[1]):
			highpoly_mesh = transform_list[1]
			lowpoly_mesh = transform_list[0]

		bakeset_name = cmds.textField('bakeset_name_tf', q=True, tx=True) + "1"
		high_group = cmds.group(highpoly_mesh, n="High")
		low_group = cmds.group(lowpoly_mesh, n="Low")
		bakeset_name = cmds.group(high_group, low_group, n=bakeset_name, w=True)

		new_highpoly_mesh_name = '|' + bakeset_name + '|High|' + highpoly_mesh.rsplit('|', 1)[-1]
		new_lowpoly_mesh_name = '|' + bakeset_name + '|Low|' + lowpoly_mesh.rsplit('|', 1)[-1]

		highpoly_mesh = cmds.rename(new_highpoly_mesh_name, bakeset_name + "_High")
		lowpoly_mesh = cmds.rename(new_lowpoly_mesh_name, bakeset_name + "_Low")
		cmds.hide(bakeset_name)
		
	# Delete empty group
	mel.eval('source cleanUpScene;')
	mel.eval('deleteEmptyGroups;')

def create_bakeset_group_manual(*arg):
	# Unparent mesh list
	cmds.Unparent(cmds.ls(sl=True, type = 'mesh', dag=True, ni=True), s=True, w = True)
	# Delete empty group
	mel.eval('source cleanUpScene;')
	mel.eval('deleteEmptyGroups;')

	# Create BakeSet Group
	transform_list = cmds.listRelatives(cmds.ls(sl=True, type = 'mesh', dag=True, ni=True, l=True), parent=True, f=True)

	# Get lowpoly & highpoly mesh
	highpoly_mesh_list = []
	lowpoly_mesh_list = []
	for i in range(0, len(transform_list)):
		if check_highpoly_name(transform_list[i]):
			highpoly_mesh_list.append(transform_list[i])
		else:
			lowpoly_mesh_list.append(transform_list[i])


	highpoly_mesh = combine_object(highpoly_mesh_list)[0]

	lowpoly_mesh = combine_object(lowpoly_mesh_list)[0]

	bakeset_name = cmds.textField('bakeset_name_tf', q=True, tx=True) + "1"
	high_group = cmds.group(highpoly_mesh, n="High")
	low_group = cmds.group(lowpoly_mesh, n="Low")
	bakeset_name = cmds.group(high_group, low_group, n=bakeset_name, w=True)

	new_highpoly_mesh_name = '|' + bakeset_name + '|High|' + highpoly_mesh.rsplit('|', 1)[-1]
	new_lowpoly_mesh_name = '|' + bakeset_name + '|Low|' + lowpoly_mesh.rsplit('|', 1)[-1]

	highpoly_mesh = cmds.rename(new_highpoly_mesh_name, bakeset_name + "_High")
	lowpoly_mesh = cmds.rename(new_lowpoly_mesh_name, bakeset_name + "_Low")
	cmds.hide(bakeset_name)

	mel.eval('source cleanUpScene;')
	mel.eval('deleteEmptyGroups;')

def create_highlow_layer(*arg):
	high_group = []
	low_group = []

	mesh_list = cmds.listRelatives(cmds.ls(type="mesh"), parent=True)

	for mesh in mesh_list:
		if "high" in mesh.rsplit("|", 1)[-1].rsplit('_', 1)[-1].lower():
			high_group.append(mesh)
		elif "low" in mesh.rsplit("|", 1)[-1].rsplit('_', 1)[-1].lower():
			low_group.append(mesh)
	
	bakeset_name = cmds.textField('bakeset_name_tf', q=True, tx=True)
	bakeset_list = cmds.ls(bakeset_name + '*', type="transform")
	cmds.showHidden(bakeset_list)
	# Create Highpoly Layer
	cmds.select(high_group)
	try:
		cmds.createDisplayLayer(noRecurse=True, name='_High')
	except:
		pass
	cmds.editDisplayLayerMembers('_High', high_group)

	# Create Lowpoly Layer
	cmds.select(low_group)
	try:
		cmds.createDisplayLayer(noRecurse=True, name='_Low')
	except:
		pass
	cmds.editDisplayLayerMembers('_Low', low_group)

	cmds.select(d=True)

def export_bakeset(*arg):
	file_name = cmds.file(q=True, loc=True)

	# Check open maya file
	if file_name == "unknown":
		cmds.warning('Please open maya file!')
		return False
	else:
		fbx_path = cmds.textField('export_fbx_path_tf', q=True, tx=True)
	
	# Create FBX folder
	if not os.path.exists(fbx_path):
		os.makedirs(fbx_path)
	
	# FBX Export
	cmds.select(d=True)
	bakeset_name = cmds.textField('bakeset_name_tf', q=True, tx=True)
	mesh_list = cmds.listRelatives(cmds.ls(bakeset_name + '*', type="mesh"), parent=True)
	export_mode = cmds.radioButtonGrp('export_bakeset_mode_rbg', q=True, sl=True)

	if export_mode == 2:
		# Multiple Files
		for mesh in mesh_list:
			cmds.select(mesh, r=True)
			export_fbx_for_baking(mesh, fbx_path)
	else:
		# Single Files
		low_mesh = [m for m in mesh_list if m.rsplit("_", 1)[-1].lower() == "low"]
		high_mesh = [m for m in mesh_list if m.rsplit("_", 1)[-1].lower() == "high"]
		cmds.select(low_mesh)
		export_fbx_for_baking('Object_Low', fbx_path)
		cmds.select(high_mesh)
		export_fbx_for_baking('Object_High', fbx_path)

	cmds.select(d=True)	

def export_selected_objects(*arg):
	file_name = cmds.file(q=True, loc=True)

	# Check open maya file
	if file_name == "unknown":
		cmds.warning('Please open maya file!')
		return False
	else:
		fbx_path = cmds.textField('export_fbx_path_tf', q=True, tx=True)
	
	# Create FBX folder
	if not os.path.exists(fbx_path):
		os.makedirs(fbx_path)
	
	# FBX Export
	mesh_list = cmds.ls(sl=True, type="transform")

	export_mode = cmds.radioButtonGrp('export_bakeset_mode_rbg', q=True, sl=True)

	if export_mode == 2:
		# Multiple Files
		cmds.select(d=True)
		for mesh in mesh_list:
			cmds.select(mesh, r=True)
			export_fbx_for_baking(mesh, fbx_path)
		cmds.select(d=True)
	else:
		# Single Files
		if "low" in mesh_list[0].rsplit('_', 1)[-1].lower():
			export_fbx_for_baking('Object_Low', fbx_path)
		else:
			export_fbx_for_baking('Object_High', fbx_path)
		cmds.select(d=True)	

#-------------------------------------------------------UI--------------------------------------------------------
