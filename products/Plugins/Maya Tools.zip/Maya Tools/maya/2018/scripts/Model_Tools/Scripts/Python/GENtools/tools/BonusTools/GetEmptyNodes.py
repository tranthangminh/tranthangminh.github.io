#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.mel as mel
import maya.cmds as cmds
from functools import partial
from collections import OrderedDict

# for python 3 compatibility
import six
from six.moves import filter

from ...core.gui.options import OptionsWindow, helpCmd

def lsType(*args, **kwargs):
	"""
	List objects based on their type, supports multiple type at once.
	
	:param object: Objects to filter.
	:param exactType: List all objects of the specified type.
	:return: Returns a list of objects.
	"""
	objects = []
	exactType = []
	
	for i, arg in enumerate(args):
		if i == 0:
			object = arg
	
	for key, value in list(kwargs.items()):
		if key == "exactType" or key == "et":
			exactType = value
			del kwargs["exactType"]
	
	if not isinstance(exactType, (list, tuple)):
		exactType = [exactType]
	
	for t in exactType:
		if "object" in locals():
			objects.extend(cmds.ls(object, exactType=t, **kwargs))
		else:
			objects.extend(cmds.ls(exactType=t, **kwargs))
	
	return objects

def getEmptyNodes(*args, **kwargs):	
	"""
	Find empty nodes. (Nodes without children)
	
	:param objects: Find the empty nodes within these objects.
	:param selection: Find the empty nodes inside the active list. Ignored if objects param is not empty.
	:param nodeType: Find the empty nodes of the specified type. 
	:param recursive: Find the empty nodes recursively.
	:param deleteNodes: Delete the empty nodes. (The objects in the returned list will no longer exists)
	:return: Returns a list of the empty nodes.
	"""
	
	# Create default args
	objects = None
	selection = True
	nodeType = "transform"
	recursive = True
	deleteNodes = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "nodeType" or key == "nt":
			nodeType = value
		elif key == "deleteNodes" or key == "dn":
			deleteNodes = value
	
	# Load SelectSimilar optionVars
	if deleteNodes:
		if cmds.optionVar(exists="CEG_SearchScope") is True:
			searchScope = cmds.optionVar(query="CEG_SearchScope")
			if searchScope == 2:
				selection = False
		if cmds.optionVar(exists="CEG_Recursive") is True:
			recursive = cmds.optionVar(query="CEG_Recursive")
	else:
		if cmds.optionVar(exists="SEG_SearchScope") is True:
			searchScope = cmds.optionVar(query="SEG_SearchScope")
			if searchScope == 2:
				selection = False
		if cmds.optionVar(exists="SEG_Recursive") is True:
			recursive = cmds.optionVar(query="SEG_Recursive")
	
	# Load keyworded arguments (override optionsVars)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "recursive" or key == "rsv":
			recursive = value
	
	emptyNodes = []
	
	# Find empty nodes in objects param
	if objects:
		transforms = lsType(objects, long=True, exactType=nodeType)
	
	# Find empty nodes in active list
	elif selection is True:
		transforms = lsType(long=True, exactType=nodeType, selection=True)
		transformsRelatives = lsType(cmds.listRelatives(lsType(long=True, exactType=nodeType, selection=True), fullPath=True, allDescendents=True), long=True, exactType=nodeType)
		
		transforms.extend(transformsRelatives)		
		transforms = list(OrderedDict.fromkeys(transforms)) # Remove duplicates objects
	
	# Find empty nodes in the whole scene
	else:
		transforms = lsType(long=True, exactType=nodeType)
	
	if transforms:
		try:
			# Start progress bar
			gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
			cmds.progressBar(gMainProgressBar, edit=True, beginProgress=True, status="Operation in progress...", maxValue=len(transforms))
			
			undoOperations = False

			# If undo queue is turned off, turn it on temporarily
			undoState = cmds.undoInfo(query=True, state=True)
			if not undoState:
				cmds.undoInfo(state=True)

			try:
				# Open undo chunk
				cmds.undoInfo(openChunk=True)
				
				for transform in transforms:
					if cmds.objExists(transform) is True:
						childrens = cmds.listRelatives(transform, fullPath=True, children=True)
						if childrens is not None:
							if len(cmds.ls(childrens, noIntermediate=True, long=True)) <= 0 and cmds.listHistory(childrens, pruneDagObjects=True) is None:
								childrens = None
						if childrens is None:
							parent = lsType(cmds.listRelatives(transform, fullPath=True, parent=True, noIntermediate=True), long=True, exactType=nodeType) or None
							if parent is not None:
								transforms.extend(parent)
								pb_max = cmds.progressBar(gMainProgressBar, query=True, maxValue=True)
								cmds.progressBar(gMainProgressBar, edit=True, maxValue=(pb_max+1))
							emptyNodes.append(transform)
							if recursive:
								cmds.delete(transform)
								undoOperations = True
							#print ("{0} has no children").format(transform)
					cmds.progressBar(gMainProgressBar, edit=True, step=1)
			finally:
				# Close undo chunk
				cmds.undoInfo(closeChunk=True)
			
				# If undo queue is not empty
				if undoOperations is True and cmds.undoInfo(query=True, undoQueueEmpty=True) is False and deleteNodes is False:
					# Undo last chunk
					cmds.undo()
				
				# Restore undo queue state
				if not undoState:
					cmds.undoInfo(state=False)
		
		finally:
			# End progress bar
			cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)
	
	if deleteNodes and recursive:
		return emptyNodes
	
	# Make sure nodes exists
	emptyNodes = list(filter(cmds.objExists, emptyNodes))
	#print ("Found {0} empty nodes").format(len(emptyNodes))
	
	if deleteNodes and not recursive:
		cmds.delete(emptyNodes)
	
	return emptyNodes

class CleanEmptyGroupsOptions(OptionsWindow):
	def __init__(self):
		self.windowName = "CleanEmptyGroupsOptionsWin"
		self.pfx = "CEG_"
		kwargs = {"windowSize": [360, 150], 
		          "windowTitle": "Clean Empty Groups Options", 
		          "runLabel": "Cleanup", 
		          "minWindowSize": 180, 
		          "rowOffset": 143, 
				  "preview": False}
		
		super(CleanEmptyGroupsOptions, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		getEmptyNodes(deleteNodes=True)
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/bonustools-mesh/#clean-empty-groups")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Clean Empty Groups Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Selection / Whole Scene
		cmds.rowLayout(self.pfx+"SearchScopeRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Search Scope:")
		cmds.radioButtonGrp(self.pfx+"SearchScope", dtg=self.pfx+"SearchScope", l="", nrb=2, la2=("Selection", "Whole Scene"), sl=1, cw3=(0, 80, 80), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Recursive
		cmds.rowLayout(self.pfx+"RecursiveRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"Recursive", dtg=self.pfx+"Recursive", l="", l1="Recursive", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))

class SelectEmptyGroupsOptions(OptionsWindow):
	def __init__(self):
		self.windowName = "SelectEmptyGroupsOptionsWin"
		self.pfx = "SEG_"
		kwargs = {"windowSize": [360, 150], 
		          "windowTitle": "Select Empty Groups Options", 
		          "runLabel": "Select", 
		          "minWindowSize": 180, 
		          "rowOffset": 143, 
				  "preview": False}
		
		super(SelectEmptyGroupsOptions, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		cmds.select(getEmptyNodes())
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/bonustools-select/#select-empty-groups")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Select Empty Groups Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Selection / Whole Scene
		cmds.rowLayout(self.pfx+"SearchScopeRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Search Scope:")
		cmds.radioButtonGrp(self.pfx+"SearchScope", dtg=self.pfx+"SearchScope", l="", nrb=2, la2=("Selection", "Whole Scene"), sl=1, cw3=(0, 80, 80), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Recursive
		cmds.rowLayout(self.pfx+"RecursiveRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"Recursive", dtg=self.pfx+"Recursive", l="", l1="Recursive", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))