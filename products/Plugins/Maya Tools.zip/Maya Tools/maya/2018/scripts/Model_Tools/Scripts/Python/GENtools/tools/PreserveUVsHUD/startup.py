#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Preserve UVs HUD")
		self.scriptLoader.setToolDocumentation("/docs/preserve-uvs-hud/")
		self.scriptLoader.setStartupFile("PreserveUVsHUD.mel")
		self.scriptLoader.setStartupFunc("PUVH_Startup")
		self.scriptLoader.setMenuCategory("View")
		self.scriptLoader.setMenuCheckBoxDict({"optionVarName": "PreserveUVsHUD", "checkBoxFunc": "PUVH_MenuItems"})
		self.scriptLoader.setMenuItemDict({"image": "menuIconDisplay.png", "sourceType": "mel", "command": "PreserveUVsHUD", "checkBox": False})
		return self.scriptLoader