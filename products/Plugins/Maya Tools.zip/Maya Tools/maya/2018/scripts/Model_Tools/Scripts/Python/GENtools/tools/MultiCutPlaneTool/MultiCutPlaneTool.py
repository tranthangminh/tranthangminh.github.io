#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya
from collections import OrderedDict

# for python 3 compatibility
import six

def SCPT_GetCurrentSel(*args):
	objects = None
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects

def SCPT_GetComponentType(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	selList = OpenMaya.MSelectionList()
	
	if selection is not None:
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
	else:
		OpenMaya.MGlobal_getActiveSelectionList(selList)
	
	filterDict = []
	#filterDict.append(("v", OpenMaya.MFn.kMeshVertComponent))
	#filterDict.append(("eg", OpenMaya.MFn.kMeshEdgeComponent))
	filterDict.append(("fc", OpenMaya.MFn.kMeshPolygonComponent))
	#filterDict.append(("puv", OpenMaya.MFn.kMeshMapComponent))
	#filterDict.append(("pvf", OpenMaya.MFn.kMeshVtxFaceComponent))
	#filterDict.append(("cv", OpenMaya.MFn.kCurveCVComponent))
	filterDict = OrderedDict(filterDict)
	
	for key, filter in six.iteritems(filterDict):
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		try:
			if sel_iter.hasComponents() is True:
				return key
		except:
			pass
	
	return None

def SCPT_CreateMultiPolyCutNode(objects=None, polyCutNode=None):
	if objects is None:
		objects = SCPT_GetCurrentSel()[1]
	if polyCutNode is None:
		polyCutNode = cmds.createNode("polyCut", n="polyCut1", ss=True)
	
	SCPT_multiPolyCutNode = cmds.createNode("polyTweak", n="multiPolyCut1", ss=True)
	cmds.addAttr(SCPT_multiPolyCutNode, m=True, im=False, at="typed", ln="dagSetMembers", k=False, h=True)
	
	# Connect objects to multiPolyCut
	for object in objects:
		cmds.connectAttr((object+".instObjGroups"), (SCPT_multiPolyCutNode+".dagSetMembers"), na=True, f=True)
	
	# Create multiPolyCut attribute controls
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="cutPlaneCenterX", dv=0, k=True, h=False, pxy=(polyCutNode+".cutPlaneCenterX"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="cutPlaneCenterY", dv=0, k=True, h=False, pxy=(polyCutNode+".cutPlaneCenterY"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="cutPlaneCenterZ", dv=0, k=True, h=False, pxy=(polyCutNode+".cutPlaneCenterZ"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="cutPlaneRotateX", dv=0, k=True, h=False)
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="cutPlaneRotateY", dv=0, k=True, h=False, pxy=(polyCutNode+".cutPlaneRotateY"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="cutPlaneRotateZ", dv=0, k=True, h=False, pxy=(polyCutNode+".cutPlaneRotateZ"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="long", ln="cutPlaneWidth", min=0, max=2, dv=1, k=True, h=False, pxy=(polyCutNode+".cutPlaneWidth"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="long", ln="cutPlaneHeight", min=0, max=2, dv=1, k=True, h=False, pxy=(polyCutNode+".cutPlaneHeight"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="bool", ln="extractFaces", dv=False, k=True, h=False, pxy=(polyCutNode+".extractFaces"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="extractOffsetX", dv=0, k=True, h=False, pxy=(polyCutNode+".extractOffsetX"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="extractOffsetY", dv=0, k=True, h=False, pxy=(polyCutNode+".extractOffsetY"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="double", ln="extractOffsetZ", dv=0, k=True, h=False, pxy=(polyCutNode+".extractOffsetZ"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="bool", ln="deleteFaces", dv=False, k=True, h=False, pxy=(polyCutNode+".extractFaces"))
	cmds.addAttr(SCPT_multiPolyCutNode, at="bool", ln="invert", dv=False, k=True, h=False)
	
	# Create invert expression
	SCPT_invertExpression = cmds.expression(s=polyCutNode+".cutPlaneRotateX = "+SCPT_multiPolyCutNode+".cutPlaneRotateX+("+SCPT_multiPolyCutNode+".invert*180);", n=(SCPT_multiPolyCutNode+"_expression1"))
	
	# Hide nodes from channel box / attribute editor
	cmds.setAttr((SCPT_invertExpression+".isHistoricallyInteresting"), 0)