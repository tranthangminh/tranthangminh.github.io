import maya.cmds as cmds
import maya.mel as mel


def _progressBarInit(title='Fix Corrupted Objects', status='Fixing', numJobs=100):
	if numJobs == 0:
		numJobs = 1
	cmds.progressWindow (title=title, st=status, progress=0, min=0, max=numJobs, isInterruptable=False)
	

def _doFixCorruptObject(theCube, theObjFullPath, queryTheObjUVSets):
    # get Object Parent
    theObjParent = cmds.listRelatives(theObjFullPath, parent= True, fullPath= True)[0]
    
    # duplicate cube to keep path, in the case of there is only 1 object in this path
    keepingPathCube = cmds.duplicate(theCube)[0]
    cmds.parent(keepingPathCube, theObjParent)
    
    # query object UVSets and create more if need, allUVSets will be in-ordered
    if queryTheObjUVSets:
        theObjAllUVSets = cmds.polyUVSet(theObjFullPath, query= True, allUVSets= True) or []
        moreValidUVSets = ('map2', 'map3', 'map4', 'map5')    
        for aUVSet in moreValidUVSets:
            if aUVSet in theObjAllUVSets:
                cmds.polyUVSet(theCube, create= True, uvSet= aUVSet)
            
    # combine
    newObj = cmds.polyUnite((theCube, theObjFullPath), ch= False)[0]
    
    # delete cube's faces
    cmds.delete(newObj + '.f[0:5]')
    cmds.delete(newObj, ch= True)
    
    # rename and link
    theObjFullPath_Tokens = theObjFullPath.split('|')
    newObj = cmds.rename(newObj, theObjFullPath_Tokens[len(theObjFullPath_Tokens) - 1])
    cmds.parent(newObj, theObjParent)
    
    # delete the keepingPath cube
    cmds.delete(keepingPathCube)
    

def fixCorruptedObjects():
    
    selection = cmds.ls(sl = True, long= True, dagObjects= True, type = 'transform') or []
    
    if len(selection) > 0:
        # delete history for this selection
        cmds.delete(selection, ch= True)
        
        # create temporary cube with map1 and colorSet1 ready
        theTempCube = cmds.polyCube(ch= False, w= 1, h= 1, d= 1, cuv= 4)[0]        
        cmds.polyColorSet(theTempCube, create= True, colorSet= 'colorSet1')
        cmds.polyColorPerVertex(theTempCube, r= 1, g= 1, b= 1, a= 1, cdo= True)
        cmds.delete(theTempCube, ch= True)
        
        # Progress Bar Window
        numJobs = len(selection)
        _progressBarInit(title='Fix Corrupted Objects', status='FCO...', numJobs=numJobs)
        progressBarIdx = 0
        
        # do fixing
        for anObj in selection:
            if cmds.objExists(anObj):
                childrenShapes = cmds.listRelatives(anObj, children= True, type= 'mesh') or []
                if childrenShapes != []:
                    cmds.progressWindow(edit=True, status= 'FCO on:    - ' + anObj)
                    _doFixCorruptObject(cmds.duplicate(theTempCube)[0], anObj, True)
                    
            # update progress bar
            progressBarIdx += 1
            cmds.progressWindow(edit=True, progress= progressBarIdx)
            
        #end progress bar
        cmds.progressWindow (endProgress=True)
                
        # delete theTempCube
        cmds.delete(theTempCube)
        
        #re-select
        cmds.select(selection)
    
def fixCorruptedObjects_ToMap5():
    selection = cmds.ls(sl = True, long= True, dagObjects= True, type = 'transform') or []
    
    if len(selection) > 0:
        # delete history for this selection
        cmds.delete(selection, ch= True)
        
        # create temporary cube with map1 and colorSet1 ready
        theTempCube = cmds.polyCube(ch= False, w= 1, h= 1, d= 1, cuv= 4)[0]
        moreValidUVSets = ('map2', 'map3', 'map4', 'map5')    
        for aUVSet in moreValidUVSets:
            cmds.polyUVSet(theTempCube, create= True, uvSet= aUVSet)            
        cmds.polyColorSet(theTempCube, create= True, colorSet= 'colorSet1')
        cmds.polyColorPerVertex(theTempCube, r= 1, g= 1, b= 1, a= 1, cdo= True)
        cmds.delete(theTempCube, ch= True)
        
        # Progress Bar Window
        numJobs = len(selection)
        _progressBarInit(title='Fix Corrupted Objects', status='FCO...', numJobs=numJobs)
        progressBarIdx = 0
        
        # do fixing
        for anObj in selection:
            if cmds.objExists(anObj):
                childrenShapes = cmds.listRelatives(anObj, children= True, type= 'mesh') or []
                if childrenShapes != []:
                    cmds.progressWindow(edit=True, status= 'FCO on:    - ' + anObj)
                    _doFixCorruptObject(cmds.duplicate(theTempCube)[0], anObj, False)
                    
            # update progress bar
            progressBarIdx += 1
            cmds.progressWindow(edit=True, progress= progressBarIdx)
            
        #end progress bar
        cmds.progressWindow (endProgress=True)
                
        # delete theTempCube
        cmds.delete(theTempCube)
        
        #re-select
        cmds.select(selection)
    
    