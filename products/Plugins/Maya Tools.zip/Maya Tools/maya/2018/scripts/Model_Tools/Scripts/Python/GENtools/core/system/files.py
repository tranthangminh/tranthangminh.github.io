#!/usr/bin/python
# -*- coding: utf-8 -*-
import os

def GetResource(ROOT_DIR, file_name):
	resource_file = os.path.join(ROOT_DIR, file_name.replace("/", os.sep))
	
	if not os.path.isfile(resource_file):
		resource_file = ":/{0}".format(file_name.replace(os.sep, "/"))
	
	return resource_file