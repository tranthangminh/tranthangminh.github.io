#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.mel as mel
import maya.cmds as cmds
from collections import defaultdict
from functools import partial
from webbrowser import open_new_tab
from maya.OpenMayaUI import MQtUtil
try:
	from PySide2 import QtWidgets
	from shiboken2 import wrapInstance
except ImportError:
	from PySide import QtGui as QtWidgets
	from shiboken import wrapInstance

# for python 3 compatibility
import six
from six.moves import range
try:
	from past.builtins import long
except:
	pass

from ..config.infos import GENtools_Domain

def helpCmd(*args, **kwargs):
	helpUrl = None
	addDomain = True

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			helpUrl = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "helpUrl" or key == "url":
			helpUrl = value
		elif key == "addDomain" or key == "ad":
			addDomain = value
	
	if helpUrl:
		if addDomain:
			helpUrl = GENtools_Domain+helpUrl
		open_new_tab(helpUrl)

class OptionsWindow(object):
	_OptionsWindowDict = {}

	def __init__(self, windowName, **kwargs):
		if hasattr(self, "_instanceInitDone"):
			return
		
		super(OptionsWindow, self).__init__()
		
		# Create default variables
		preview = False
		self.showWindow = True
		self.windowName = windowName
		self.windowTitle = "Window Title"
		self.toolbox = False
		self.runLabel = "Apply and Close"
		self.applyLabel = "Apply"
		self.windowSize = [540, 360]
		self.minWindowSize = None
		self.rowOffset = 143
		self.scrollLayout = None
		self.scrollForm = None
		self.windowForm = None
		self.sizeable = True
		self.parentWindow = mel.eval("$gMainWindow = $gMainWindow")
		
		# Load keyworded arguments
		for key, value in six.iteritems(kwargs):
			if key == "preview" or key == "p":
				preview = value
			elif key == "showWindow" or key == "sw":
				self.showWindow = value
			elif key == "windowTitle" or key == "wt":
				self.windowTitle = value
			elif key == "toolbox" or key == "tlb":
				self.toolbox = value
			elif key == "runLabel" or key == "rl":
				self.runLabel = value
			elif key == "applyLabel" or key == "al":
				self.applyLabel = value
			elif key == "windowSize" or key == "ws":
				self.windowSize = value
			elif key == "minWindowSize" or key == "mws":
				self.minWindowSize = value
			elif key == "rowOffset" or key == "ro":
				self.rowOffset = value
			elif key == "sizeable" or key == "s":
				self.sizeable = value
			elif key == "parentWindow" or key == "pw":
				if isinstance(value, six.string_types) and cmds.window(value, exists=True):
					self.parentWindow = value
		
		# Create UI
		self.createUI()
		
		if preview is True:
			self.UIDict = {}
			self.frameLayoutList = []
		else:
			# Create UI Dictionary
			self.createUIDict()
			
			# Create popupMenus
			self.createPopupMenus()
			
			# Setup UI controls
			self.windowSetup()

		# Show UI
		self.initUI()

		if self.showWindow is True:
			self.postInit()
		
		self._instanceInitDone = True
	
	def saveOptionVar(self, name, type, value, refresh=0, *args):
		# float array 3
		if type in ["colorSliderGrp"]:
			cmds.optionVar(remove=name)
			for i in range(3):
				try:
					cmds.optionVar(floatValueAppend=(name, value[i]))
				except:
					cmds.optionVar(floatValueAppend=(name, 0))
		# int array 4
		elif type in ["checkBoxGrp"]:
			cmds.optionVar(remove=name)
			for i in range(4):
				try:
					cmds.optionVar(intValueAppend=(name, value[i]))
				except:
					cmds.optionVar(intValueAppend=(name, 0))
		# float
		elif type in ["floatSliderGrp", "floatFieldGrp"]:
			cmds.optionVar(floatValue=(name, value))
		# int
		elif type in ["intSliderGrp", "intFieldGrp", "radioButtonGrp", "optionMenuGrp"]:
			cmds.optionVar(intValue=(name, value))
		# string
		elif type in ["textFieldGrp"]:
			cmds.optionVar(stringValue=(name, value))
		if refresh == 1:
			self.windowSetup()
	
	def saveSettings(self, save, *args):
		for ctl, ctl_dict in six.iteritems(self.UIDict):
			if "optionVar" in ctl_dict and "value" in ctl_dict:
				# Create non-existing optionVar / Reset
				if (cmds.optionVar(exists=ctl_dict["optionVar"]) is False or save == 2):					
					self.saveOptionVar(ctl_dict["optionVar"], ctl_dict["type"], ctl_dict["value"])
				# Save
				if save == 1:
					if ctl_dict["type"] == "checkBoxGrp":
						controlValue = cmds.checkBoxGrp(ctl, query=True, valueArray4=True)
					elif ctl_dict["type"] == "floatSliderGrp":
						controlValue = cmds.floatSliderGrp(ctl, query=True, value=True)
					elif ctl_dict["type"] == "intSliderGrp":
						controlValue = cmds.intSliderGrp(ctl, query=True, value=True)
					elif ctl_dict["type"] == "floatFieldGrp":
						controlValue = cmds.floatFieldGrp(ctl, query=True, value=True)	
					elif ctl_dict["type"] == "intFieldGrp":
						controlValue = cmds.intFieldGrp(ctl, query=True, value=True)
					elif ctl_dict["type"] == "radioButtonGrp":
						controlValue = cmds.radioButtonGrp(ctl, query=True, select=True)
					elif ctl_dict["type"] == "optionMenuGrp":
						controlValue = cmds.optionMenuGrp(ctl, query=True, select=True)
					elif ctl_dict["type"] == "textFieldGrp":
						controlValue = cmds.textFieldGrp(ctl, query=True, text=True)
					elif ctl_dict["type"] == "colorSliderGrp":
						controlValue = cmds.colorSliderGrp(ctl, query=True, rgbValue=True)
					if "controlValue" in locals():
						self.saveOptionVar(ctl_dict["optionVar"], ctl_dict["type"], controlValue)
	
	def querySettings(self):
		# Create non-existing optionVar
		self.saveSettings(0)
		queryDict = defaultdict()
		for ctl_dict in six.itervalues(self.UIDict):
			if "optionVar" in ctl_dict:
				queryDict[ctl_dict["optionVar"]] = cmds.optionVar(query=ctl_dict["optionVar"])
		return queryDict
	
	def windowSetup(self, ignoreCallback=False, *args):
		# Query optionVar
		settings = self.querySettings()
		for ctl, ctl_dict in six.iteritems(self.UIDict):
			if eval("cmds."+ctl_dict['type']+"(ctl, query=True, exists=True)") is True:
				if ctl_dict["type"] in ["checkBoxGrp"]:
					flag = "valueArray4"
				elif ctl_dict["type"] in ["floatSliderGrp", "intSliderGrp", "floatFieldGrp", "intFieldGrp"]:
					flag = "value"
				elif ctl_dict["type"] in ["radioButtonGrp", "optionMenuGrp"]:
					flag = "select"
				elif ctl_dict["type"] in ["textFieldGrp"]:
					flag = "text"
				elif ctl_dict["type"] in ["colorSliderGrp"]:
					flag = "rgbValue"
				try:
					eval("cmds."+ctl_dict['type']+"(ctl, edit=True, "+flag+"=settings[ctl_dict['optionVar']])")
				except Exception as e:
					pass
		if not ignoreCallback:
			# Update controls
			self.controlsCallback()
		# Set scrollLayout size
		if self.scrollLayout is not None and self.minWindowSize is not None:
			if self.minWindowSize > 0:
				cmds.scrollLayout(self.scrollLayout, edit=True, width=self.minWindowSize)
	
	def resetSettings(self, *args):
		# Reset settings
		self.saveSettings(2)
		# Update controls
		self.windowSetup()
	
	def buttonsCmd(self, runScript, closeWindow, *args):
		if(runScript is True):
			# Save settings
			if(cmds.window(self.windowName, exists=True) is True):
				self.saveSettings(1)
			# Run script
			self.runCmd()
		if(closeWindow is True):
			if(cmds.window(self.windowName, exists=True) is True):
				##cmds.deleteUI(self.windowName, window=True)
				# evalDeferred fixes rare occurence of a crash
				cmds.evalDeferred("import maya.cmds as cmds;cmds.deleteUI('"+self.windowName+"\', window=True)")
	
	def scrollResized(self, *args):
		if self.scrollLayout is not None and self.scrollForm is not None:
			scrollLayoutWidth = cmds.scrollLayout(self.scrollLayout, query=True, width=True)
			scrollFormWidth = cmds.formLayout(self.scrollForm, query=True, width=True)
			for fl in self.frameLayoutList:
				if (scrollLayoutWidth > scrollFormWidth+10):
					cmds.formLayout(self.scrollForm, edit=True, attachForm=(fl, "right", 2))
				else:
					cmds.formLayout(self.scrollForm, edit=True, attachForm=(fl, "right", 0))
	
	def separationRow(self, row1_h, row2_h, row3_h):
		cmds.rowLayout(height=row1_h)
		cmds.setParent("..")
		cmds.rowLayout(height=row2_h, backgroundColor=(0.266, 0.266, 0.266))
		cmds.setParent("..")
		cmds.rowLayout(height=row3_h)
		cmds.setParent("..")
	
	def createUIDict(self):
		default_factory = (lambda: defaultdict(dict))
		self.UIDict = defaultdict(default_factory)
		self.frameLayoutList = []
		UITypes = ["checkBox", "floatSlider", "intSlider", "floatField", "intField", "radioButton", "popupMenu", "textField"]
		mainLayoutChildrens = cmds.layout(self.windowForm, query=True, childArray=True)
		
		while len(mainLayoutChildrens)>0:
			for each in mainLayoutChildrens:
				mainLayoutChildrens.remove(each)
				# If layout exists
				if cmds.layout(each, query=True, exists=True) is True:
					# If layout has childrens
					layoutChildrens = cmds.layout(each, query=True, childArray=True)
					if layoutChildrens is not None:
						# Add childrens to list
						for ctl in layoutChildrens:
							mainLayoutChildrens.append(each + "|" + ctl)
				# If is a UI control, add to dictionary
				if cmds.objectTypeUI(each) in ["rowGroupLayout", "TcolorSlider"]:
					if cmds.layout(each, query=True, exists=True) is True:
						layoutChildrens = cmds.layout(each, query=True, childArray=True)
						for ctl in layoutChildrens:
							UIType = cmds.objectTypeUI(ctl)
							if UIType in UITypes:
								if cmds.checkBoxGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "checkBoxGrp"
									self.UIDict[each]["value"] = cmds.checkBoxGrp(each, query=True, valueArray4=True)
								elif cmds.colorSliderGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "colorSliderGrp"
									self.UIDict[each]["value"] = cmds.colorSliderGrp(each, query=True, rgbValue=True)
								elif cmds.floatSliderGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "floatSliderGrp"
									self.UIDict[each]["value"] = cmds.floatSliderGrp(each, query=True, value=True)
								elif cmds.intSliderGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "intSliderGrp"
									self.UIDict[each]["value"] = cmds.intSliderGrp(each, query=True, value=True)
								elif cmds.floatFieldGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "floatFieldGrp"
									self.UIDict[each]["value"] = cmds.floatFieldGrp(each, query=True, value=True)
								elif cmds.intFieldGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "intFieldGrp"
									self.UIDict[each]["value"] = cmds.intFieldGrp(each, query=True, value=True)
								elif cmds.radioButtonGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "radioButtonGrp"
									self.UIDict[each]["value"] = cmds.radioButtonGrp(each, query=True, select=True)
								elif cmds.optionMenuGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "optionMenuGrp"
									self.UIDict[each]["value"] = cmds.optionMenuGrp(each, query=True, select=True)
								elif cmds.textFieldGrp(each, query=True, exists=True) is True:
									self.UIDict[each]["type"] = "textFieldGrp"
									self.UIDict[each]["value"] = cmds.textFieldGrp(each, query=True, text=True)
								if each in self.UIDict:
									docTag = cmds.control(each, query=True, docTag=True)
									if docTag:
										self.UIDict[each]["optionVar"] = docTag
									break
								
				# If is a frameLayout, add to list
				elif cmds.objectTypeUI(each) == "frameLayout":
					if cmds.frameLayout(each, query=True, exists=True) is True:
						self.frameLayoutList.append(each)
	
	def createPopupMenus(self):
		for ctl, ctl_dict in six.iteritems(self.UIDict):
			if "optionVar" in ctl_dict and "type" in ctl_dict and "value" in ctl_dict:
				cmds.popupMenu(parent=ctl, button=3, postMenuCommand=partial(self.saveOptionVar, ctl_dict["optionVar"], ctl_dict["type"], ctl_dict["value"], 1))
				cmds.setParent("..")
	
	def resetWindowSize(self, *args):
		cmds.window(self.windowName, edit=True, widthHeight=self.windowSize, resizeToFitChildren=True, sizeable=self.sizeable)
	
	def sizeHint(self):
		windowControl = MQtUtil.findControl(self.windowName)
		windowWidget = wrapInstance(long(windowControl), QtWidgets.QWidget)
		if windowWidget:
			return windowWidget.sizeHint()

	def initUI(self):
		# Set window size from windowPrefs
		if self.sizeable and cmds.windowPref(self.windowName, exists=True):
			windowSize = cmds.windowPref(self.windowName, query=True, widthHeight=True)
			cmds.window(self.windowName, edit=True, widthHeight=windowSize, resizeToFitChildren=True)
		else:
			self.resetWindowSize()
		
		if not self.showWindow:
			return
		
		cmds.showWindow(self.windowName)
		cmds.window(self.windowName, edit=True, resizeToFitChildren=True, sizeable=self.sizeable, toolbox=self.toolbox)
		
		cmds.setFocus(self.windowName)
	
	def postInit(self):
		pass
	
	def runCmd(self, *args):
		return
	
	def controlsCallback(self, *args):
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		#settings = self.querySettings()
	
	def createUI(self):
		return
