#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Bonus Tools")
		self.scriptLoader.setStartupFile("BonusTools.mel")
		self.scriptLoader.setMenuItemDict({"subMenu": True, "tearOff": True})
		self.scriptLoader.setMenuItemFunc(self.createMenuItem)
		return self.scriptLoader
	
	def createMenuItem(self):
		menuTitle = cmds.menuItem(divider=True, dividerLabel="Bonus Tools")
		bonusToolsMenu = cmds.setParent(menuTitle, query=True, menu=True)
		
		# Display
		cmds.menuItem(label="Display", subMenu=True, tearOff=True, parent=bonusToolsMenu)
		cmds.menuItem(divider=True, dividerLabel="Display")
		cmds.menuItem(label="Toggle Visibility", image="polyToggleProxySubdiv.png", sourceType="mel", command="ToggleVisibility")
		cmds.menuItem(label="Show All", image="RS_visible.png", sourceType="mel", command="ShowAllCustom")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Toggle Isolate Selection", image="IsolateSelected.png", sourceType="mel", command="ToggleIsolateSelection")
		cmds.menuItem(label="Add Isolate Selection", image="uvIsolateSelectAdd.png", sourceType="mel", command="AddIsolateSelection")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Toggle Wireframe", image="WireFrame.png", sourceType="mel", command="ToggleWireframe")
		cmds.menuItem(label="Toggle Wireframe On Shaded", image="WireFrameOnShaded.png", sourceType="mel", command="ToggleWireframeOnShaded")
		cmds.menuItem(label="Toggle Soft Hard Edge Display", image="polySoftEdge.png", sourceType="mel", command="ToggleSoftHardEdgeDisplay")
		cmds.menuItem(label="Toggle Hard Edge Display", image="polyHardEdge.png", sourceType="mel", command="ToggleHardEdgeDisplay")
		cmds.menuItem(label="Toggle Textured", image="Textured.png", sourceType="mel", command="ToggleTextured")
		cmds.menuItem(label="Toggle Lights", image="Light.png", sourceType="mel", command="ToggleLights")
		cmds.menuItem(label="Toggle Renderer", image="render_phong.png", sourceType="mel", command="ToggleRenderer")
		
		# Edit Mesh
		cmds.menuItem(label="Edit Mesh", image="", subMenu=True, tearOff=True, parent=bonusToolsMenu)
		cmds.menuItem(divider=True, dividerLabel="Edit Mesh")
		cmds.menuItem(label="Poly Merge", image="polyMerge.png", sourceType="mel", command="PolyMergeCustom")
		
		# Mesh
		meshMenu = cmds.menuItem(label="Mesh", subMenu=True, tearOff=True, parent=bonusToolsMenu)
		cmds.menuItem(divider=True, dividerLabel="Mesh")
		# Cleanup
		cmds.menuItem(label="Cleanup", image="polyCleanup.png", subMenu=True, tearOff=True, parent=meshMenu)
		cmds.menuItem(divider=True, dividerLabel="Cleanup")
		cmds.menuItem(label="Clean Empty Groups", image="group.png", sourceType="mel", command="CleanEmptyGroups", dragDoubleClickCommand="CleanEmptyGroupsOptions")
		cmds.menuItem(image="group.png", optionBox=True, sourceType="mel", command="CleanEmptyGroupsOptions")
		cmds.menuItem(label="Clean Custom Attributes", image="attributes.png", sourceType="mel", command="CleanCustomAttributes", dragDoubleClickCommand="CleanCustomAttributesOptions")
		cmds.menuItem(image="attributes.png", optionBox=True, sourceType="mel", command="CleanCustomAttributesOptions")
		cmds.menuItem(label="Clean Intermediate Shapes", image="polyCube.png", sourceType="mel", command="CleanIntermediateShapes", dragDoubleClickCommand="CleanIntermediateShapesOptions")
		cmds.menuItem(image="polyCube.png", optionBox=True, sourceType="mel", command="CleanIntermediateShapesOptions")
		cmds.menuItem(label="Remove All Namespaces", image="publishNamedAttribute.png", sourceType="mel", command="RemoveAllNamespaces")
		# Clean Booleans
		cmds.menuItem(label="Clean Booleans", image="polyBooleansUnion.png", subMenu=True, tearOff=True, parent=meshMenu)
		cmds.menuItem(divider=True, dividerLabel="Clean Booleans")
		cmds.menuItem(label="Clean Boolean Union", image="polyBooleansUnion.png", sourceType="mel", command="CleanBooleanUnion")
		cmds.menuItem(label="Clean Boolean Difference", image="polyBooleansDifference.png", sourceType="mel", command="CleanBooleanDifference")
		cmds.menuItem(label="Clean Boolean Intersection", image="polyBooleansIntersection.png", sourceType="mel", command="CleanBooleanIntersection")
		# Mirror
		cmds.menuItem(label="Mirror", image="polyMirrorGeometry.png", subMenu=True, tearOff=True, parent=meshMenu)
		cmds.menuItem(divider=True, dividerLabel="Axis")
		cmds.menuItem(label="X", image="polyMirrorGeometry.png", sourceType="mel", command="MirrorAlongX", dragDoubleClickCommand="MirrorAlongXReverse")
		cmds.menuItem(label="Y", image="polyMirrorGeometry.png", sourceType="mel", command="MirrorAlongY", dragDoubleClickCommand="MirrorAlongYReverse")
		cmds.menuItem(label="Z", image="polyMirrorGeometry.png", sourceType="mel", command="MirrorAlongZ", dragDoubleClickCommand="MirrorAlongZReverse")
		
		# Mesh Display
		cmds.menuItem(label="Mesh Display", subMenu=True, tearOff=True, parent=bonusToolsMenu)
		cmds.menuItem(divider=True, dividerLabel="Mesh Display")
		cmds.menuItem(label="Toggle Display Colors", image="polyToggleDisplayColor.png", sourceType="mel", command="ToggleDisplayColors")
		cmds.menuItem(label="Force Display Colors On", image="polyToggleDisplayColor.png", sourceType="mel", command="ForceDisplayColorsOn")
		cmds.menuItem(label="Force Display Colors Off", image="polyToggleDisplayColor.png", sourceType="mel", command="ForceDisplayColorsOff")
		cmds.menuItem(label="Set Display Color Channel None", image="polyColorMaterialNone.png", sourceType="mel", command="SetDisplayColorChannelNone")
		cmds.menuItem(label="Set Display Color Channel Ambient", image="polyColorMaterialAmbient.png", sourceType="mel", command="SetDisplayColorChannelAmbient")
		cmds.menuItem(label="Set Display Color Channel Diffuse", image="polyColorMaterialDiffuse.png", sourceType="mel", command="SetDisplayColorChannelDiffuse")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Toggle Double Sided", image="", sourceType="mel", command="ToggleDoubleSided")
		cmds.menuItem(label="Force Double Sided On", image="", sourceType="mel", command="ForceDoubleSidedOn")
		cmds.menuItem(label="Force Double Sided Off", image="", sourceType="mel", command="ForceDoubleSidedOff")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Toggle Face Centers", image="polyConvertToVertexFaces.png", sourceType="mel", command="ToggleFaceCenters")
		
		# Select
		selectMenu = cmds.menuItem(label="Select", subMenu=True, tearOff=True, parent=bonusToolsMenu)
		cmds.menuItem(divider=True, dividerLabel="Select")
		cmds.menuItem(label="Select Empty Groups", image="group.png", sourceType="mel", command="SelectEmptyGroups", dragDoubleClickCommand="SelectEmptyGroupsOptions")
		cmds.menuItem(image="group.png", optionBox=True, sourceType="mel", command="SelectEmptyGroupsOptions")
		cmds.menuItem(label="Select Border Edges", image="polySelectEdgeBorder.png", sourceType="mel", command="SelectBorderEdges")
		cmds.menuItem(label="Select UV Border Edges", image="selectTextureBorders.png", sourceType="mel", command="SelectUVBorderEdges")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Select Every N-Edge", image="", sourceType="mel", command="SelectEveryNEdge")
		cmds.menuItem(label="Select Every N-Edge Ring", image="polySelectEdgeRing.png", sourceType="mel", command="SelectEveryNEdgeRing")
		cmds.menuItem(label="Select Every N-Edge Loop", image="polySelectEdgeLoop.png", sourceType="mel", command="SelectEveryNEdgeLoop")
		cmds.menuItem(divider=True, dividerLabel="Tool Settings")
		cmds.menuItem(label="Toggle Auto Camera-Based Selection", image="polySelectBoundary.png", sourceType="mel", command="ToggleAutoCameraBasedSelection")
		# Components
		cmds.menuItem(divider=True, dividerLabel="Polygons")
		cmds.menuItem(label="Components", image="", subMenu=True, tearOff=True, parent=selectMenu)
		cmds.menuItem(divider=True, dividerLabel="Components")
		cmds.menuItem(label="Toggle Select Mode", image="selectByComponent.png", sourceType="mel", command="ToggleSelectMode")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Toggle Vertex", image="polySelectVertex.png", sourceType="mel", command="ToggleVertex")
		cmds.menuItem(label="Toggle Edge", image="polySelectEdge.png", sourceType="mel", command="ToggleEdge")
		cmds.menuItem(label="Toggle Face", image="polySelectFace.png", sourceType="mel", command="ToggleFace")
		cmds.menuItem(label="Toggle UV", image="polySelectUV.png", sourceType="mel", command="ToggleUV")	
		cmds.menuItem(label="Toggle UV Shell", image="UVEditorShell.png", sourceType="mel", command="ToggleUVShell")
		cmds.menuItem(label="Toggle Multi-Component", image="", sourceType="mel", command="ToggleMultiComponent")
		# Convert Selection
		cmds.menuItem(label="Convert Selection", image="", subMenu=True, tearOff=True, parent=selectMenu)
		cmds.menuItem(divider=True, dividerLabel="Convert Selection")
		cmds.menuItem(label="Convert Selection To Vertices", image="polyConvertToVertices.png", sourceType="mel", command="ConvertSelectionToVerticesCustom")
		cmds.menuItem(label="Convert Selection To Vertex Perimeter", image="polyConvertToShellBorder.png", sourceType="mel", command="ConvertSelectionToVertexPerimeterCustom")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Convert Selection To Edges", image="polyConvertToEdge.png", sourceType="mel", command="ConvertSelectionToEdgesCustom")
		cmds.menuItem(label="Convert Selection To Contained Edges", image="polyConvertToContainedEdges.png", sourceType="mel", command="ConvertSelectionToContainedEdgesCustom")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Convert Selection To Faces", image="polyConvertToFace.png", sourceType="mel", command="ConvertSelectionToFacesCustom")
		cmds.menuItem(label="Convert Selection To Contained Faces", image="polyConvertToContainedFaces.png", sourceType="mel", command="ConvertSelectionToContainedFacesCustom")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Convert Selection To UVs", image="polyConvertToUVs.png", sourceType="mel", command="ConvertSelectionToUVsCustom")
		cmds.menuItem(label="Convert Selection To UV Perimeter", image="polyConvertToShellBorder.png", sourceType="mel", command="ConvertSelectionToUVPerimeterCustom")
		
		# UV
		cmds.menuItem(label="UV", subMenu=True, tearOff=True, parent=bonusToolsMenu)
		cmds.menuItem(divider=True, dividerLabel="UV")
		cmds.menuItem(label="UV Random Rotation", image="polyRandomizeShell.png", sourceType="mel", command="UVRandomRotation", dragDoubleClickCommand="UVRandomRotationOptions")
		cmds.menuItem(image="polyRandomizeShell.png", optionBox=True, sourceType="mel", command="UVRandomRotationOptions")
