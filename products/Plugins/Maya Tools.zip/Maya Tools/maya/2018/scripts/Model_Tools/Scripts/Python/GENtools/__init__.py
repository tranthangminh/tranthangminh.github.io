#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys

from .core.config.infos import GENtools_Root

sys.path.append(os.path.join(GENtools_Root, "lib"))