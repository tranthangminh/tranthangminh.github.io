#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import re
import time
import logging
#import inspect
import maya.mel as mel
import maya.cmds as cmds
from threading import Thread
from functools import partial
import maya.api.OpenMaya as om
import maya.OpenMaya as OpenMaya
from maya.OpenMayaUI import MQtUtil
from maya.utils import executeDeferred
from collections import defaultdict, OrderedDict
try:
	from PySide2 import QtWidgets
	from shiboken2 import wrapInstance
except ImportError:
	from PySide import QtGui as QtWidgets
	from shiboken import wrapInstance

# for python 3 compatibility
import six
from six.moves import range
from six.moves import zip
try:
	from past.builtins import long
except:
	pass

from ...core.gui.options import OptionsWindow, helpCmd
from ...core.general.selections import componentListIntersection, componentListDifference, getComponentCount, flattenList, getComponentIds, componentDictionary, getSortedVertexFaces
from ...core.general.polymesh import applySmoothMeshPreview, disablePolyBaseCache

ROOT_DIR = os.path.dirname(os.path.realpath(__file__))
#ROOT_DIR = os.path.dirname(os.path.realpath(inspect.getfile(lambda: None)))
PARTITION_NAME = "NormalToolkit_Partition"
SET_NAME = "NormalToolkit_SelectionSet"
FILLET_SET_NAME = "NormalToolkit_FilletSet"

def getPluginPath():
	pluginName = "NormalToolkit.py"
	pluginDirPath = os.path.join(ROOT_DIR, "plugins")
	pluginFilePath = os.path.join(pluginDirPath, pluginName)
	if os.path.isdir(pluginDirPath) and os.path.isfile(pluginFilePath):
		return (pluginName, pluginDirPath, pluginFilePath)
	
	return (None, None, None)

def loadPlugin():
	pluginDirPath, pluginFilePath = getPluginPath()[-2:]

	if pluginDirPath and pluginFilePath:
		# Add plugin directory to MAYA_PLUG_IN_PATH
		MAYA_PLUG_IN_PATH = os.getenv("MAYA_PLUG_IN_PATH", pluginDirPath)
		if MAYA_PLUG_IN_PATH:
			MAYA_PLUG_IN_PATH += ";"+pluginDirPath
		os.environ["MAYA_PLUG_IN_PATH"] = MAYA_PLUG_IN_PATH

		# Load plugin
		if not cmds.pluginInfo(pluginFilePath, query=True, loaded=True):
			#cmds.unloadPlugin(pluginFilePath, force=True)
			cmds.loadPlugin(pluginFilePath)

def unloadPlugin():
	pluginName, pluginDirPath, pluginFilePath = getPluginPath()
	if pluginDirPath and pluginFilePath:
		# Unload plugin
		if cmds.pluginInfo(pluginFilePath, query=True, loaded=True):
			cmds.unloadPlugin(pluginName, force=True)

def undoableFunction(func, *args, **kwargs):
	if callable(func):
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		try:
			func(*args, **kwargs)
		except:
			pass
		finally:
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)

def isclose(a, b, rt=0.000000001, at=0):
    return abs(a-b) <= max(rt * max(abs(a), abs(b)), at)

def CenterWindow(windowName):
    if cmds.window(windowName, ex=True) is True:
        gMainWindow = mel.eval("$gMainWindow = $gMainWindow")
        gMainWindowWidth = (cmds.window(gMainWindow, q=True, w=True)/2)
        gMainWindowHeight = (cmds.window(gMainWindow, q=True, h=True)/2)
        leftPosition = gMainWindowWidth-(cmds.window(windowName, q=True, w=True)/2)
        topPosition = gMainWindowHeight-(cmds.window(windowName, q=True, h=True)/2)
        cmds.window(windowName, e=True, le=leftPosition, te=topPosition)
        return [topPosition, leftPosition]

def ProgressBarWindow(**kwargs):
	title = "Progress Window"
	width = 300
	height = 25
	minValue = 0
	maxValue = 100
	centered = True
	for key, value in six.iteritems(kwargs):
		if key == "name" or key == "n":
			name = value
		elif key == "title" or key == "t":
			title = value
		elif key == "width" or key == "w":
			width = value
		elif key == "height" or key == "h":
			height = value
		elif key == "minValue" or key == "min":
			minValue = value
		elif key == "maxValue" or key == "max":
			maxValue = value
		elif key == "centered" or key == "c":
			centered = value
	
	if "name" in locals():
		if(cmds.window(name, ex=True) is True):
			cmds.deleteUI(name, wnd=True)
		progressWin = cmds.window(name, t=title, s=False, mxb=False, tlb=True)
	else:
		progressWin = cmds.window(t=title, s=False, mxb=False, tlb=True)
	cmds.formLayout("mainForm")
	progressBarName = cmds.progressBar(min=minValue, max=maxValue)
	cmds.setParent("..")
	
	cmds.formLayout("mainForm", e=True, af=[(progressBarName, "top", 0), (progressBarName, "left", 0), (progressBarName, "right", 0), (progressBarName, "bottom", 0)])
	
	cmds.showWindow(progressWin)
	cmds.window(progressWin, e=True, wh=(width, height), rtf=True)
	if centered is True:
		CenterWindow(progressWin)
	
	return progressWin, progressBarName

def DisconnectAllAttributes(node, source=True, destination=True):
	connectionPairs = []
	if source is True:
		connections = cmds.listConnections(node, p=True, c=True, d=False, s=True)
		if connections is not None:
			connectionPairs.extend(list(zip(connections[1::2], connections[::2])))
	if destination is True:
		connections = cmds.listConnections(node, p=True, c=True, d=True, s=False)
		if connections is not None:
			connectionPairs.extend(list(zip(connections[::2], connections[1::2])))
	for srcAttr, destAttr in connectionPairs:
		try:
			cmds.disconnectAttr(srcAttr, destAttr)
		except:
			pass

def GetIsolatedObjects():
	isolatedObjects = None
	activeModelPanel = cmds.getPanel(wf=True)
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is False:
		activeModelPanel = "modelPanel4"
	
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is True:
		if cmds.isolateSelect(activeModelPanel, q=True, s=True) is True:
			isolatedObjects = cmds.ls(cmds.sets(cmds.isolateSelect(activeModelPanel, q=True, vo=True), q=True), l=True)
	
	return isolatedObjects

def GetFacesArea(face):
	if isinstance(face, six.string_types) and cmds.objExists(face):
		faces = [face]
	elif isinstance(face, (list, tuple)):
		faces = cmds.ls(face, long=True, flatten=True)
	else:
		return None
	
	faces_area = 0
	if len(faces) > 0:
		selList = om.MSelectionList()
		for f in faces:
			selList.add(f)
		
		# Loop over objects
		for i in range(selList.length()):
			dagPath, component = selList.getComponent(i)
			
			# Remove shape from path
			if not dagPath.hasFn(om.MFn.kTransform):
				dagPath.pop()
			
			face_ids = om.MFnSingleIndexedComponent(component).getElements()
			face_iter = om.MItMeshPolygon(dagPath)
			
			# Loop over faces
			for face_id in face_ids:
				face_iter.setIndex(face_id)
				
				# Get current face area
				faces_area += face_iter.getArea(space=om.MSpace.kWorld)
	
	return faces_area

def PropagateVertexFaceNormal(vertexFaces=None, vertexFaceConstraint=None):
	if not isinstance(vertexFaceConstraint, (list, tuple)) or len(vertexFaceConstraint) < 0:
		vertexFaceConstraint = None
	if isinstance(vertexFaces, (list, tuple)) and len(vertexFaces) > 0:
		softEdges = NT_GetSoftEdges(cmds.polyListComponentConversion(cmds.polyListComponentConversion(vertexFaces, toVertex=True), toEdge=True))
		
		selList = om.MSelectionList()
		for vf in vertexFaces:
			selList.add(vf)
		
		# Loop over objects
		for i in range(selList.length()):
			dagPath, component = selList.getComponent(i)
			
			# Remove shape from path
			if not dagPath.hasFn(om.MFn.kTransform):
				dagPath.pop()
			
			objectName = dagPath.fullPathName()
			
			vertexFace_iter = om.MItMeshFaceVertex(dagPath, component)
			
			vertex_list = []
			while not vertexFace_iter.isDone():
				vertexId = vertexFace_iter.vertexId()
				
				if vertexId not in vertex_list:
					vertex_list.append(vertexId)
					
					vertex = "{0}.vtx[{1}]".format(objectName, vertexId)
					vtx_normal = vertexFace_iter.getNormal(space=om.MSpace.kWorld)
					
					if vertexFaceConstraint:
						vertex = cmds.ls(cmds.polyListComponentConversion(vertex, toVertexFace=True), long=True, flatten=True)
						vertex = [vf for vf in vertex if vf in vertexFaceConstraint]
					
					cmds.polyNormalPerVertex(vertex, normalXYZ=vtx_normal)					
				
				vertexFace_iter.next()
		
		cmds.polySoftEdge(softEdges, angle=180)

def PropagateVertexFaceNormalV2(vertexFaces=None, vertexFaceConstraint=None, softEdges=None):
	if not isinstance(vertexFaceConstraint, (list, tuple)) or len(vertexFaceConstraint) < 0:
		vertexFaceConstraint = None
	if isinstance(vertexFaces, (list, tuple)) and len(vertexFaces) > 0:
		if not isinstance(softEdges, (list, tuple)) or len(softEdges) < 0:
			softEdges = NT_GetSoftEdges(cmds.polyListComponentConversion(cmds.polyListComponentConversion(vertexFaces, toVertex=True), toEdge=True))
		
		softEdges = cmds.ls(softEdges, long=True, flatten=True)
		
		selList = om.MSelectionList()
		for vf in vertexFaces:
			selList.add(vf)
		
		# Loop over objects
		for i in range(selList.length()):
			dagPath, component = selList.getComponent(i)
			
			# Remove shape from path
			if not dagPath.hasFn(om.MFn.kTransform):
				dagPath.pop()
			
			objectName = dagPath.fullPathName()
			
			vertexFace_iter = om.MItMeshFaceVertex(dagPath, component)
			
			vertexFace_list = []
			while not vertexFace_iter.isDone():
				vertexId = vertexFace_iter.vertexId()
				faceId = vertexFace_iter.faceId()
				vertexFace = "{0}.vtxFace[{1}][{2}]".format(objectName, vertexId, faceId)
				
				if vertexFace not in vertexFace_list:
					vertexFace_list.append(vertexFace)
					
					# Get vertex face normal
					vtx_normal = vertexFace_iter.getNormal(space=om.MSpace.kObject)
					
					# Get all vertex faces
					vertex = "{0}.vtx[{1}]".format(objectName, vertexId)
					vertexFaces = cmds.ls(cmds.polyListComponentConversion(vertex, toVertexFace=True), long=True, flatten=True)
					connectedEdges = cmds.ls(cmds.polyListComponentConversion(vertex, toEdge=True), long=True, flatten=True)
					
					# Get vertex face connected by soft edges
					if len(connectedEdges) != len([vf for vf in connectedEdges if vf in softEdges]):
						connectedSoftEdges = [e for e in cmds.ls(cmds.polyListComponentConversion(vertexFace, toEdge=True, vertexFaceAllEdges=True), long=True, flatten=True) if e in softEdges]
						connectedVertexFaces = cmds.ls(cmds.polyListComponentConversion(connectedSoftEdges, toVertexFace=True), long=True, flatten=True)
						connectedVertexFaces = [vf for vf in connectedVertexFaces if vf in vertexFaces and vf != vertexFace]
						
						if vertexFaceConstraint:
							connectedVertexFaces = [vf for vf in connectedVertexFaces if vf in vertexFaceConstraint]
						
					else:
						connectedVertexFaces = [vf for vf in vertexFaces if vf != vertexFace]
					
					# Apply vertex face normal
					if len(connectedVertexFaces) > 0:
						cmds.polyNormalPerVertex(connectedVertexFaces, normalXYZ=vtx_normal)
						vertexFace_list.extend(connectedVertexFaces)
				
				vertexFace_iter.next()
		
		cmds.polySoftEdge(softEdges, angle=180)
	
def GetVerticesCenter(vertices):
	vertLocation = [0, 0, 0]
	
	for vert in vertices:
		vertLocation = [x + y for x, y in zip(vertLocation, cmds.xform(vert, query=True, worldSpace=True, translation=True))]
	
	vertLocation = [x / len(vertices) for x in vertLocation]
	
	return vertLocation

def GetBorderEdges(*args, **kwargs):
	# Create default args
	selection = None
	flatten = False
	borderEdges = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "flatten" or key == "fl":
			flatten = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(toEdge=True)
	
	if selection is not None:		
		selList = om.MSelectionList()
		for edge in selection:
			selList.add(edge)
		
		borderEdgesList = om.MSelectionList()
		
		# Iterate over selList
		for i in range(selList.length()):
			dagPath, component = selList.getComponent(i)
			if component.hasFn(om.MFn.kMeshEdgeComponent):
				dagPath.pop() # Remove shape
				node = dagPath.fullPathName()
				try:
					edge_itr = om.MItMeshEdge(dagPath, component)
				except:
					cmds.delete(cmds.ls(cmds.listConnections("{0}.inMesh".format(node), connections=False, destination=False, source=True)[0], type="transformGeometry"))
					edge_itr = om.MItMeshEdge(dagPath, component)
				while not edge_itr.isDone():
					edgeId = edge_itr.index()
					onBoundary = edge_itr.onBoundary()
					
					if onBoundary is True:
						borderEdgesList.add((dagPath, edge_itr.currentItem()))
					
					edge_itr.next()
		
		borderEdges = borderEdgesList.getSelectionStrings()
		# Return full path strings
		if flatten is False:
			borderEdges = cmds.ls(borderEdges, long=True)
		else:
			borderEdges = cmds.ls(borderEdges, long=True, flatten=True)
	return borderEdges

def GetShortName(objectSel):
	dagPath = []
	shortName = objectSel
	dagPath = shortName.split("|")
	#shortName = filter(None, shortName)
	if(len(dagPath)>0):
		shortName = dagPath[len(dagPath)-1]
	return shortName

def NormalizeVector(v1=[1, 0, 0]):
	if isinstance(v1, (list, tuple)) is True and len(v1) >= 3:
		v1 = om.MVector(v1[0], v1[1], v1[2])
		v1.normalize()
		v1 = [v1.x+0, v1.y+0, v1.z+0]
	return v1

def NT_init():
	# Create non-existing optionVar
	NT_SmartBevelWin(showWindow=False).saveSettings(0)
	NT_ProcessNormalsWin(showWindow=False).saveSettings(0)

def NT_GetComponents(*args, **kwargs):
	# Create default args
	selection = None
	filterDict = {"vertex": {"filter": False, "filterType": OpenMaya.MFn.kMeshVertComponent}, 
			      "edge": {"filter": False, "filterType": OpenMaya.MFn.kMeshEdgeComponent}, 
			      "face": {"filter": False, "filterType": OpenMaya.MFn.kMeshPolygonComponent}, 
			      "uv": {"filter": False, "filterType": OpenMaya.MFn.kMeshMapComponent}, 
			      "vertexFace": {"filter": False, "filterType": OpenMaya.MFn.kMeshFaceVertComponent}}
	componentsList = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "vertex" or key == "v":
			filterDict["vertex"]["filter"] = value
		elif key == "edge" or key == "e":
			filterDict["edge"]["filter"] = value
		elif key == "face" or key == "f":
			filterDict["face"]["filter"] = value
		elif key == "uv":
			filterDict["uv"]["filter"] = value
		elif key == "vertexFace" or key == "vf":
			filterDict["vertexFace"]["filter"] = value
	
	if selection is None:
		selection = cmds.ls(sl=True, l=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for each in selection:
			selList.add(each)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		compList = OpenMaya.MSelectionList()
		
		for dict in six.itervalues(filterDict):
			if dict["filter"] is True:
				sel_iter = OpenMaya.MItSelectionList(selList, dict["filterType"])
				while not sel_iter.isDone():
					sel_iter.getDagPath(dagPath, component)
					compList.add(dagPath, component)			
					sel_iter.next()
		
		# Create new list and merge elements (unflatten list)
		mergedList = OpenMaya.MSelectionList()
		if compList.isEmpty() is False:
			mergedList.merge(compList, OpenMaya.MSelectionList.kMergeNormal)
		# Get selection strings
		objComponents = []
		mergedList.getSelectionStrings(objComponents)
		# Return full path strings
		objComponents = cmds.ls(objComponents, l=True)
		
		# Add to list
		componentsList.extend(objComponents)
		
	return componentsList

def NT_GetCurrentSel(*args, **kwargs):
	objects = None
	allParents = False
	allDescendents = False

	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
		elif i == 1:
			allParents = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "allParents" or key == "ap":
			allParents = value
		elif key == "allDescendents" or key == "ad":
			allDescendents = True

	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	if not allDescendents:
		objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	else:
		objectShapes = cmds.ls(cmds.listRelatives(allDescendents=True, fullPath=True, typ="mesh"), long=True, noIntermediate=True)
	if not allParents:
		objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	else:
		objects = cmds.listRelatives(objectShapes, f=True, ap=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects
	
def NT_GetComponentType(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	selList = OpenMaya.MSelectionList()
	
	if selection is not None:
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
	else:
		OpenMaya.MGlobal_getActiveSelectionList(selList)
	
	filterDict = []
	filterDict.append(("v", OpenMaya.MFn.kMeshVertComponent))
	filterDict.append(("eg", OpenMaya.MFn.kMeshEdgeComponent))
	filterDict.append(("fc", OpenMaya.MFn.kMeshPolygonComponent))
	filterDict.append(("puv", OpenMaya.MFn.kMeshMapComponent))
	filterDict.append(("pvf", OpenMaya.MFn.kMeshVtxFaceComponent))
	#filterDict.append(("cv", OpenMaya.MFn.kCurveCVComponent))
	filterDict = OrderedDict(filterDict)
	
	for key, filter in six.iteritems(filterDict):
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		try:
			if sel_iter.hasComponents() is True:
				return key
		except:
			pass
	
	return None

def NT_ConvertInstanceComponents(*args, **kwargs):
	# Create default args
	selection = None
	rootList = om.MSelectionList()
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	if selection is not None:
		selList = om.MSelectionList()
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
		
		# Iterate over selList
		for i in range(selList.length()):
			# Make sure item is a DAG path
			mObj = selList.getDependNode(i)
			if not mObj.hasFn(om.MFn.kDagNode):
				continue
			
			dagPath, component = selList.getComponent(i)
			if not component.isNull():
				dagPath.pop() # Remove shape
				
				# if object is an instance
				if dagPath.isInstanced():
					dagNode = om.MFnDagNode(dagPath)
					dagPaths = dagNode.getAllPaths() # first dag path is the "original" object

					# loop through component list
					for selComp in selList.getSelectionStrings(i):
						try:
							# change instance dag path with first dag path
							rootList.add("{0}.{1}".format(dagPaths[0], selComp.split(".", 1)[-1]))
						except:
							pass
				
				else:
					for each in selList.getSelectionStrings(i):
						try:
							rootList.add(each)
						except:
							pass
	
	return rootList.getSelectionStrings()

def NT_CreateSelectionSet(*args, **kwargs):
	# Create default args
	setName = SET_NAME

	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "setName" or key == "sn":
			setName = value
	
	# Create NormalToolkit_SelectionSet
	if cmds.objExists(setName) and cmds.objectType(setName) != "objectSet":
		cmds.rename(setName, "object#")
	if not cmds.objExists(setName):
		cmds.sets(name=setName, empty=True, facets=True)
	# Merge NormalToolkit_SelectionSet
	NT_objectSets_filter = cmds.itemFilter(byType="objectSet")
	NT_selSets_filter = cmds.itemFilter(byName="*{0}*".format(setName))
	NT_selSets_filtered = cmds.itemFilter(intersect=(NT_objectSets_filter, NT_selSets_filter))			
	NT_selSets = cmds.lsThroughFilter(NT_selSets_filtered, nodeArray=True)
	NT_selSets.remove(setName)
	cmds.delete([NT_objectSets_filter, NT_selSets_filter, NT_selSets_filtered])
	if len(NT_selSets) > 0:
		NT_selSetsMembers = cmds.sets(NT_selSets, query=True)
		if NT_selSetsMembers is not None:
			for selSetMember in NT_selSetsMembers:
				try:
					cmds.sets(selSetMember, edit=True, forceElement=setName)
					#NT_AddToSelectionSet(selSetMember, setName=setName)
				except:
					pass
		cmds.delete(NT_selSets)

	# Make sure the partition name is unique
	if cmds.objExists(PARTITION_NAME) and cmds.objectType(PARTITION_NAME) != "partition":
		cmds.rename(PARTITION_NAME, "object#")

	# Create NormalToolkit_Partition
	if not cmds.objExists(PARTITION_NAME):
		cmds.partition(setName, name=PARTITION_NAME)
	# Add set to partition
	elif setName not in (cmds.partition(PARTITION_NAME, query=True) or []):
		try:
			cmds.partition(setName, addSet=PARTITION_NAME)
		except:
			partitionElements = set()
			# remove element from sets before adding to partition
			for s in cmds.partition(PARTITION_NAME, query=True):
				partitionElements.update(cmds.sets(s, query=True))
			
			if partitionElements:
				cmds.sets(list(partitionElements), remove=setName, noWarnings=True)

			cmds.partition(setName, addSet=PARTITION_NAME)

def NT_SelectionDictionary(*args, **kwargs):
	# Create default args
	selection = None
	objectSelDict = defaultdict(list)
	objectList = []
	faceSelList = []
	filter = OpenMaya.MFn.kMeshPolygonComponent
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			filter = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "filter" or key == "f":
			filter = value
		elif key == "progressBar" or key == "pb":
			progressBar = value
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		compList = OpenMaya.MSelectionList()
		
		if "progressBar" in locals() and progressBar is True:
			progressWinName, progressBarName = ProgressBarWindow(n="NT_ProgressWin", t="Building Selection Set Dictionary...", w=300, max=(selList.length()))
		
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		while not sel_iter.isDone():
			sel_iter.getDagPath(dagPath, component)
			dagPath.pop() # Remove shape
			node = dagPath.fullPathName()
			
			# Add current components to selectionList
			compList.clear()
			compList.add(dagPath, component)
			
			# Create new list and merge elements (unflatten list)
			##mergedList = OpenMaya.MSelectionList()
			##if compList.isEmpty() is False:
				##mergedList.merge(compList, OpenMaya.MSelectionList.kMergeNormal)
			# Get selection strings
			objComponents = []
			compList.getSelectionStrings(objComponents)
			# Return full path strings
			objComponents = cmds.ls(objComponents, l=True)
			
			# Add to dictionary
			objectSelDict[node].extend(objComponents)
			objectList.append(node)
			faceSelList.extend(objComponents)
			
			if "progressBarName" in locals():
				cmds.progressBar(progressBarName, e=True, s=1)
			
			sel_iter.next()
		
		if "progressWinName" in locals():
				cmds.deleteUI(progressWinName, wnd=True)
		
	return objectSelDict, objectList, faceSelList

def NT_ViewSelectionSet(*args, **kwargs):
	# Create default args
	objects = None
	returnSelection = False
	returnAsSets = False
	setName = SET_NAME
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
		elif i == 0:
			returnSelection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "returnSelection" or key == "rs":
			returnSelection = value
		elif key == "setName" or key == "sn":
			setName = value
		elif key == "returnAsSets" or key == "ras":
			returnAsSets = value
	
	currentSel, objects = NT_GetCurrentSel(objects, allParents=True)
	if objects is not None:
		# Make sure there is no cached polyBase
		disablePolyBaseCache(objects)

		NT_CreateSelectionSet(setName=setName)
		NT_selDict = NT_SelectionDictionary(cmds.sets(setName, q=True))[0]
		viewSelectionSet = []
		selectionSets = []
		for obj in objects:
			if obj in NT_selDict:
				viewSelectionSet.extend(NT_selDict[obj])
				if returnAsSets:
					selectionSets.append(cmds.sets(NT_selDict[obj], facets=True))
		
		if returnSelection and returnAsSets:
			return viewSelectionSet, selectionSets
		elif returnSelection:
			return viewSelectionSet
		elif returnAsSets:
			return selectionSets
		
		if len(viewSelectionSet) > 0 and NT_GetComponents(currentSel, f=True) == viewSelectionSet:
			cmds.selectMode(co=True)
			cmds.selectMode(o=True)
		elif len(viewSelectionSet) > 0:
			cmds.selectMode(co=True)
			cmds.selectType(fc=True)
			cmds.select(viewSelectionSet, r=True)
		else:
			##cmds.inViewMessage(amg="<span style=\"color:#ff5d5d;\"> INFO: </span> No Selection Sets found", fade=True, pos="midCenterTop", fontSize=9)
			cmds.warning("No Selection Sets found", noContext=True)
	
	elif returnSelection and returnAsSets:
		return [], []
	elif returnSelection or returnAsSets:
		return []

def NT_ClearFullSelectionSet(objects=[], setName=SET_NAME):
	if objects is None or len(objects) <= 0:
		objects = NT_GetCurrentSel()[1]
	
	if objects is not None and len(objects) > 0:
		NT_CreateSelectionSet(setName=setName)
		NT_selDict = NT_SelectionDictionary(cmds.sets(setName, query=True))[0]
		for obj in objects:
			if obj in NT_selDict:
				objFacesSet = (re.split("\.f\[([0-9:]*)\]", NT_selDict[obj][0])[1]).split(":")
				if int(objFacesSet[0]) == 0 and int(objFacesSet[len(objFacesSet)-1])+1 == cmds.polyEvaluate(obj, face=True):
					cmds.sets(NT_selDict[obj], edit=True, remove=setName)

def NT_AddToSelectionSet(selection, setName=SET_NAME):
	if selection:
		# Add to selection set
		if cmds.objExists(setName) and cmds.objectType(setName) == "objectSet":
			cmds.sets(selection, edit=True, forceElement=setName, noWarnings=True)

		# Make sure that the faces added to the set are exclusive
		if cmds.objExists(PARTITION_NAME) and cmds.objectType(PARTITION_NAME) == "partition":
			partitionSets = cmds.partition(PARTITION_NAME, query=True) or []
			if setName in partitionSets:
				partitionSets.remove(setName)
			for s in partitionSets:
				cmds.sets(selection, edit=True, remove=s, noWarnings=True)

def NT_ModifiySelectionSet(*args, **kwargs):
	# Create default args
	selection = cmds.ls(selection=True, long=True)
	add = False
	remove = False
	clear = False
	setName = SET_NAME
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "add" or key == "a":
			add = value
		elif key == "remove" or key == "r":
			remove = value
		elif key == "clear" or key == "c":
			clear = value
		elif key == "setName" or key == "sn":
			setName = value
	
	# Make sure there is no cached polyBase
	disablePolyBaseCache(selection)
	
	if len(NT_GetComponents(selection, f=True)) <= 0:
		selection = cmds.polyListComponentConversion(selection, toFace=True)
	
	# for instances selections, we must change path to their "original" object
	selection = NT_ConvertInstanceComponents(selection)

	objects, selection = NT_SelectionDictionary(selection)[1:3]
	
	NT_ClearFullSelectionSet(objects, setName=setName)
	
	if len(selection) > 0:
		NT_CreateSelectionSet(setName=setName)
		if add is True:
			#cmds.sets(selection, edit=True, forceElement=setName)
			NT_AddToSelectionSet(selection, setName=setName)
			##cmds.inViewMessage(amg="<span style=\"color:#bfff00;\"> INFO: </span> Selected faces added to Selection Set", fade=True, pos="midCenterTop", fontSize=9)
			print ("Selected faces added to Selection Set.")
		elif remove is True:
			cmds.sets(selection, edit=True, remove=setName, noWarnings=True)
			##cmds.inViewMessage(amg="<span style=\"color:#bfff00;\"> INFO: </span> Selected faces removed from Selection Set", fade=True, pos="midCenterTop", fontSize=9)
			print ("Selected faces removed from Selection Set.")
		elif clear is True:
			selection = cmds.polyListComponentConversion(objects, toFace=True)
			cmds.sets(selection, edit=True, remove=setName, noWarnings=True)
			##cmds.inViewMessage(amg="<span style=\"color:#bfff00;\"> INFO: </span> Selection Set emptied for selected object(s)", fade=True, pos="midCenterTop", fontSize=9)
			print ("Selection Set emptied for selected object(s).")

def NT_MakeSetsMutuallyExclusive(setNames=[SET_NAME]):
	for setName in setNames:
		if cmds.objExists(PARTITION_NAME) and cmds.objectType(PARTITION_NAME) == "partition":
			partitionSets = cmds.partition(PARTITION_NAME, query=True) or []
			if setName in partitionSets:
				partitionSets.remove(setName)
			for s in partitionSets:
				if cmds.objExists(setName) and cmds.objectType(setName) == "objectSet":
					setFaces = cmds.sets(setName, query=True)
					if setFaces:
						cmds.sets(setFaces, edit=True, remove=s, noWarnings=True)

def NT_ColorSetExists(*args, **kwargs):
	object = None
	colorSetName = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			object = arg
		elif i == 1:
			colorSetName = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "object" or key == "obj":
			selection = value
		elif key == "colorSetName" or key == "csn":
			colorSetName = value
	
	if object is None:
		object = NT_GetCurrentSel()[1][0]
	
	if len(object) > 0 and colorSetName is not None:
		colorSets = cmds.polyColorSet(object, q=True, acs=True)
		if colorSets is not None:
			if colorSetName in colorSets:
				return True
	
	return False

def NT_SetVertexColorFaces(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	progressStep = 0
	selection = None
	colorSetName = None
	colorSetDict = defaultdict(list)
	colorSetList = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			colorSetName = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "colorSetName" or key == "csn":
			colorSetName = value
		elif key == "progressStep" or key == "ps":
			progressStep = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(tf=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for face in selection:
			selList.add(face)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		
		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMeshPolygonComponent)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshPolygonComponent):
				dagPath.pop() # Remove shape
				# Get object name
				objectName = dagPath.fullPathName()
				
				# Check if any colorSet matches colorSetName
				colorSetExists = NT_ColorSetExists(objectName, csn=colorSetName)
				# If no matches were found, use current color set
				if colorSetName is None or colorSetExists is False:
					colorSetName = cmds.polyColorSet(objectName, q=True, ccs=True)
					# If no colorSet found, create new colorSet
					if colorSetName is None:
						colorSetName = cmds.polyColorSet(objectName, cr=True)
					colorSetName = colorSetName[0]
				
				# Iterate over faces
				if colorSetName is not None:
					# Create a new color set with colorSetName
					cmds.polyColorSet(objectName, cs=colorSetName, ccs=True)
					# Add colorSetName to dictionary
					colorSetDict[objectName] = colorSetName
					# Add colorSetName to list
					colorSetList.append(colorSetName)
					
					# Create variables
					meshNode = OpenMaya.MFnMesh(dagPath)
					colorsList = OpenMaya.MColorArray()
					faceIdsList = OpenMaya.MIntArray()
					vertexIdsList = OpenMaya.MIntArray()
					
					# Iterate over faces from selList
					face_iter = OpenMaya.MItMeshPolygon(dagPath, component)
					i = 0
					while not face_iter.isDone():
						# Get current face index
						faceId = face_iter.index()
						# Append colorsList
						colorsList.append(OpenMaya.MColor(0, 0, 0))
						# Append faceIdsList
						faceIdsList.append(faceId)
						# Progress bar
						if progressStep > 0 and (float(i)/progressStep).is_integer() is True:
							cmds.progressBar(gMainProgressBar, e=True, s=progressStep, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
						i += 1
						face_iter.next()
					meshNode.setFaceColors(colorsList, faceIdsList)
			
			if progressStep > 0:		
				cmds.progressBar(gMainProgressBar, e=True, s=1, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
			iterIndex += 1
			sel_iter.next()
	return colorSetList, colorSetDict

def NT_GetVertexColorFaces(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	progressStep = 0
	selection = None
	colorSetName = None
	vertexColorFacesDict = defaultdict(list)
	vertexColorFacesSel = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			colorSetName = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "colorSetName" or key == "csn":
			colorSetName = value
		elif key == "progressStep" or key == "ps":
			progressStep = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(tf=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for face in selection:
			selList.add(face)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()

		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMeshPolygonComponent)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshPolygonComponent):
				dagPath.pop() # Remove shape
				# Get object name
				objectName = dagPath.fullPathName()
				
				# Check if any colorSet matches colorSetName
				colorSetExists = NT_ColorSetExists(objectName, csn=colorSetName)
				# If no matches were found, use current color set
				if colorSetName is None or colorSetExists is False:
					colorSetName = cmds.polyColorSet(objectName, q=True, ccs=True)
					if colorSetName is not None:
						colorSetName = colorSetName[0]
				
				if colorSetName is not None:
					# Create vertexColorFacesList
					vertexColorFacesList = OpenMaya.MSelectionList()
					
					# Iterate over faces from selList
					face_iter = OpenMaya.MItMeshPolygon(dagPath, component)
					i = 0
					while not face_iter.isDone():
						# Get current face index
						faceId = face_iter.index()
						# Get face color indices
						colorIds = OpenMaya.MIntArray()
						face_iter.getColorIndices(colorIds, colorSetName)
						
						# If all vertices are colored, add to list
						if any(color < 0 for color in colorIds) is False:
							vertexColorFacesList.add(dagPath, face_iter.currentItem())
						
						if progressStep > 0 and (float(i)/progressStep).is_integer() is True:
							cmds.progressBar(gMainProgressBar, e=True, s=progressStep, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
						
						i += 1
						face_iter.next()
					
					if vertexColorFacesList.isEmpty() is False:
						# Create new list and merge elements (unflatten list)
						mergedList = OpenMaya.MSelectionList()
						mergedList.merge(vertexColorFacesList, OpenMaya.MSelectionList.kMergeNormal)
						# Add faces to dictionary
						mergedList.getSelectionStrings(vertexColorFacesDict[objectName])
						# Add to list
						vertexColorFacesSel.extend(vertexColorFacesDict[objectName])
			
			if progressStep > 0:
				cmds.progressBar(gMainProgressBar, e=True, s=1, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
			iterIndex += 1
			sel_iter.next()
	return vertexColorFacesSel, vertexColorFacesDict

def NT_GetSoftEdges(*args, **kwargs):
	# Create default args
	selection = None
	softEdge = True
	flatten = False
	softEdges, hardEdges = [], []
	getSmoothing = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			softEdge = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "softEdge" or key == "se":
			softEdge = value
		elif key == "flatten" or key == "fl":
			flatten = value
		elif key == "getSmoothing" or key == "gs":
			getSmoothing = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(toEdge=True)
	
	if selection is not None:
		selList = om.MSelectionList()
		for edge in selection:
			selList.add(edge)
		
		softEdgesList = om.MSelectionList()
		hardEdgesList = om.MSelectionList()
		
		# Iterate over selList
		for i in range(selList.length()):
			dagPath, component = selList.getComponent(i)
			if component.hasFn(om.MFn.kMeshEdgeComponent):
				dagPath.pop() # Remove shape
				edge_itr = om.MItMeshEdge(dagPath, component)
				while not edge_itr.isDone():
					smoothEdge = edge_itr.isSmooth
					
					if not getSmoothing:
						if smoothEdge is softEdge:
							softEdgesList.add((dagPath, edge_itr.currentItem()))
					
					elif getSmoothing:
						if smoothEdge:
							softEdgesList.add((dagPath, edge_itr.currentItem()))
						else:
							hardEdgesList.add((dagPath, edge_itr.currentItem()))
					
					edge_itr.next()
				
		softEdges = softEdgesList.getSelectionStrings()
		# Return full path strings
		if flatten is False:
			softEdges = cmds.ls(softEdges, long=True)
		else:
			softEdges = cmds.ls(softEdges, long=True, flatten=True)
		
		if getSmoothing:
			hardEdges = hardEdgesList.getSelectionStrings()
			# Return full path strings
			if flatten is False:
				hardEdges = cmds.ls(hardEdges, long=True)
			else:
				hardEdges = cmds.ls(hardEdges, long=True, flatten=True)
	
	if getSmoothing:
		return softEdges, hardEdges

	return softEdges

def NT_GetHiddenDisplayLayersMembers():
	selList = OpenMaya.MSelectionList()
	sel_iter = OpenMaya.MItDependencyNodes(OpenMaya.MFn.kDisplayLayer)
	while not sel_iter.isDone():
		dnFn = OpenMaya.MFnDependencyNode(sel_iter.item())
		if dnFn.name() != "defaultLayer" and dnFn.findPlug("visibility").asBool() is False:
			layerConnections = OpenMaya.MPlugArray()
			dnFn.getConnections(layerConnections)
			
			for i in range(layerConnections.length()):
				connectedNodes = OpenMaya.MPlugArray()
				layerConnections[i].connectedTo(connectedNodes, False, True)
				for c in range(connectedNodes.length()):
					selList.add(connectedNodes[c].node())
		
		sel_iter.next()
	
	objects = []
	selList.getSelectionStrings(objects)
	return objects

def NT_SmartBevel(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	selection = None
	objects = cmds.ls(hl=True, l=True)
	getBevelSelection = False
	usePolyBevelAttributes = False
	weightedNormals = 0
	selectBevelFaces = 0
	addToSelectionSet = 0
	bevelFacesDict = defaultdict(list)
	bevelFacesSel = []
	bevelNodes = []
	tolerance = 0.01
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load optionVars
	if cmds.optionVar(ex="NTSB_WeightedNormals") is True:
		weightedNormals = cmds.optionVar(q="NTSB_WeightedNormals")[0]
	if cmds.optionVar(ex="NTSB_SelectBevelFaces") is True:
		selectBevelFaces = cmds.optionVar(q="NTSB_SelectBevelFaces")[0]
	if cmds.optionVar(ex="NTSB_AddBevelFaces") is True:
		addToSelectionSet = cmds.optionVar(q="NTSB_AddBevelFaces")[0]
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "getBevelSelection" or key == "gbs":
			getBevelSelection = value
		elif key == "usePolyBevelAttributes" or key == "upba":
			usePolyBevelAttributes = value
		elif key == "weightedNormals" or key == "wn":
			weightedNormals = value
		elif key == "selectBevelFaces" or key == "sbf":
			selectBevelFaces = value
		elif key == "addToSelectionSet" or key == "atss":
			addToSelectionSet = value
	
	if getBevelSelection is False:
		currentSel, objects = NT_GetCurrentSel()
		cmds.select(objects, r=True)
		cmds.select(currentSel, r=True)
		# Open undo chunk
		cmds.undoInfo(ock=True)
	
	# Create bevel attributes dictionary
	bevelAttributes = {"polyBevelOffsetAsFraction": {"attr": ".offsetAsFraction", "invert": True, "value": 1}, 
					   "polyBevelOffsetWorld": {"attr": ".worldSpace", "invert": True, "value": 0}, 
					   "polyBevelOffset": {"attr": ".offset", "value": 1}, 
					   "polyBevelFraction": {"attr": ".fraction", "value": 0.5}, 
					   "polyBevelDepth": {"attr": ".depth", "value": 1}, 
					   "polyBevelSegment": {"attr": ".segments", "value": 1}, 
					   "polyBevelMitering": {"attr": ".mitering", "value": 1}, 
					   "polyBevelMiterAlong": {"attr": ".miterAlong", "value": 0}, 
					   "polyBevelChamfer": {"attr": ".chamfer", "value": 1}, 
					   "polyBevelAutofit": {"attr": ".autoFit", "value": 1}, 
					   "polyBevelForceParallel": {"attr": ".forceParallel", "value": 0}, 
					   "polyBevelSmoothingAngle": {"attr": ".smoothingAngle", "value": 60}, 
					   "polyBevelRound": {"attr": ".roundness", "value": 0.5},
					   "polyBevelAngleTolerance": {"attr": ".angleTolerance", "value": 180}, 
					   "polyBevelMergeVertexTolerance": {"attr": ".mergeVertexTolerance", "value": 0}, 
					   "polyBevelSubdivideNgons": {"attr": ".subdivideNgons", "value": 1}}
	# Smart bevel attributes
	if usePolyBevelAttributes is False:
		bevelAttributes["polyBevelOffsetAsFraction"]["optionVar"] = "NTSB_OffsetAsFraction"
		if "invert" in bevelAttributes["polyBevelOffsetAsFraction"]:
			del bevelAttributes["polyBevelOffsetAsFraction"]["invert"]
		bevelAttributes["polyBevelOffsetWorld"]["optionVar"] = "NTSB_WorldSpace"
		if "invert" in bevelAttributes["polyBevelOffsetWorld"]:
			del bevelAttributes["polyBevelOffsetWorld"]["invert"]
		bevelAttributes["polyBevelOffset"]["optionVar"] = "NTSB_Offset"
		bevelAttributes["polyBevelFraction"]["optionVar"] = "NTSB_Fraction"
		bevelAttributes["polyBevelDepth"]["optionVar"] = "NTSB_Depth"
		bevelAttributes["polyBevelSegment"]["optionVar"] = "NTSB_Segments"
		bevelAttributes["polyBevelMitering"]["optionVar"] = "NTSB_Mitering"
		bevelAttributes["polyBevelMitering"]["offset"] = -1
		bevelAttributes["polyBevelMiterAlong"]["optionVar"] = "NTSB_MiteringAlong"
		bevelAttributes["polyBevelMiterAlong"]["offset"] = -1
		bevelAttributes["polyBevelChamfer"]["optionVar"] = "NTSB_Chamfer"
		bevelAttributes["polyBevelForceParallel"]["optionVar"] = "NTSB_ForceParallel"
		bevelAttributes["polyBevelSmoothingAngle"]["optionVar"] = "NTSB_SmoothingAngle"
		bevelAttributes["polyBevelAngleTolerance"]["optionVar"] = "NTSB_AngleTolerence"
		bevelAttributes["polyBevelMergeVertexTolerance"]["optionVar"] = "NTSB_MergeTolerence"
		bevelAttributes["polyBevelSubdivideNgons"]["optionVar"] = "NTSB_SubdivideNgons"
	# Set bevel attributes values from optionVar
	for option, attribute in six.iteritems(bevelAttributes):
		optionVarName = option
		if "optionVar" in attribute:
			optionVarName = attribute["optionVar"]
		if cmds.optionVar(ex=optionVarName) is True:
			if isinstance(cmds.optionVar(q=optionVarName), list):
				attribute["value"] = cmds.optionVar(q=optionVarName)[0]
			else:
				attribute["value"] = cmds.optionVar(q=optionVarName)
			if "offset" in attribute:
				attribute["value"] += attribute["offset"]
	# Use NormalToolkit Smoothing Angle
	if cmds.optionVar(ex="NTSB_NTSmoothingAngle") is True and cmds.optionVar(ex="sn_angle_v") is True:
		if cmds.optionVar(q="NTSB_NTSmoothingAngle")[0] == 1:
			bevelAttributes["polyBevelSmoothingAngle"]["value"] = cmds.optionVar(q="sn_angle_v")
	
	# Bevel flags from keyworded arguments
	for key, value in six.iteritems(kwargs):
		if key == "offsetAsFraction" or key == "oaf":
			bevelAttributes["polyBevelOffsetAsFraction"]["value"] = value
			if "invert" in bevelAttributes["polyBevelOffsetAsFraction"]:
				del bevelAttributes["polyBevelOffsetAsFraction"]["invert"]
		elif key == "worldSpace" or key == "ws":
			bevelAttributes["polyBevelOffsetWorld"]["value"] = value
			if "invert" in bevelAttributes["polyBevelOffsetWorld"]:
				del bevelAttributes["polyBevelOffsetWorld"]["invert"]
		elif key == "offset" or key == "o":
			bevelAttributes["polyBevelOffset"]["value"] = value
		elif key == "fraction" or key == "f":
			bevelAttributes["polyBevelFraction"]["value"] = value
		elif key == "depth" or key == "d":
			bevelAttributes["polyBevelDepth"]["value"] = value
		elif key == "segments" or key == "sg":
			bevelAttributes["polyBevelSegment"]["value"] = value
		elif key == "mitering" or key == "m":
			bevelAttributes["polyBevelMitering"]["value"] = value
		elif key == "miteringAlong" or key == "ma":
			bevelAttributes["polyBevelMiterAlong"]["value"] = value
		elif key == "chamfer" or key == "c":
			bevelAttributes["polyBevelChamfer"]["value"] = value
		elif key == "autoFit" or key == "af":
			bevelAttributes["polyBevelAutofit"]["value"] = value
		elif key == "smoothingAngle" or key == "sa":
			bevelAttributes["polyBevelSmoothingAngle"]["value"] = value
		elif key == "roundness" or key == "r":
			bevelAttributes["polyBevelRound"]["value"] = value
		elif key == "angleTolerance" or key == "at":
			bevelAttributes["polyBevelAngleTolerance"]["value"] = value
		elif key == "mergeVertexTolerance" or key == "mvt":
			bevelAttributes["polyBevelMergeVertexTolerance"]["value"] = value
		elif key == "subdivideNgons" or key == "sng":
			bevelAttributes["polyBevelSubdivideNgons"]["value"] = value
		# Unused
		elif key == "name" or key == "n":
			bevelName = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(te=True)
	
	if not objects:
		objects = cmds.ls(selection, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")

	if selection is not None:		
		selList = OpenMaya.MSelectionList()
		# If selection is a list, add each element to selList
		if isinstance(selection, list) is True:
			try:
				for each in selection:
					selList.add(each)
			except:
				pass
		# If selection is a string, add to selList
		elif isinstance(selection, six.string_types) is True:
			try:
				selList.add(selection)
			except:
				pass
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		compList = OpenMaya.MSelectionList()
		
		if selList.isEmpty() is False:
			# Progress bar
			if cmds.progressBar(gMainProgressBar, q=True, vis=True) is False:
				objectFaces = cmds.polyEvaluate(objects, face=True)
				if not isinstance(objectFaces, int):
					objectFaces = 0
				cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Smart Bevel in progress...", min=0, max=(selList.length()+objectFaces))
			
			# Iterate over selList
			sel_iter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMeshEdgeComponent)
			##iterIndex = 0
			while not sel_iter.isDone():
				sel_iter.getDagPath(dagPath, component)
				meshNode = OpenMaya.MFnMesh(dagPath)
				dagPath.pop() # Remove shape
				
				# Get object name
				objectName = dagPath.fullPathName()
				objectRotation = None
				
				# Add current components to selectionList
				compList.clear()
				compList.add(dagPath, component)
				
				# Create new list and merge elements (unflatten list)
				##mergedList = OpenMaya.MSelectionList()
				##if compList.isEmpty() is False:
					##mergedList.merge(compList, OpenMaya.MSelectionList.kMergeNormal)
				# Get edges strings
				edgeSel = []
				compList.getSelectionStrings(edgeSel)
				# Return full path strings
				edgeSel = cmds.ls(edgeSel, long=True)
				
				# Convert selected edges to faces
				faceSel = cmds.polyListComponentConversion(objectName, toFace=True)
				
				if getBevelSelection is False:
					# Create a list of bevel edge Ids
					fnComp = OpenMaya.MFnSingleIndexedComponent(component)
					edgeIds = OpenMaya.MIntArray()
					fnComp.getElements(edgeIds)
					
					# Get list of non manifold edges
					nonManifoldEdges = cmds.polyInfo(objectName, nme=True, nmv=True)
					nonManifoldEdges = cmds.ls(cmds.polyListComponentConversion(nonManifoldEdges, te=True), fl=True)
					# Extract edge ids from strings
					##nonManifoldEdgesIds = [int(re.split("[\[\]]", edge)[1]) for edge in nonManifoldEdges]
					nonManifoldEdgesIds = [int(re.split("\.e\[([0-9:]*)\]", edge)[1]) for edge in nonManifoldEdges]
					# Compare bevel edges ids and non manifold edges ids
					nonManifoldEdgesIds = set(edgeIds).intersection(nonManifoldEdgesIds)
					# If non manifold edge encountered, skip bevel
					if bool(nonManifoldEdgesIds) is True:
						cmds.warning("{0} skipped. Cannot bevel non-manifold edge(s).".format(objectName), noContext=True)
						sel_iter.next()
						continue
					# FIX FOR MAYA 2019 # Set object world space rotation to 0
					objectRotation = cmds.xform(objectName, query=True, objectSpace=True, rotation=True)
					cmds.xform(objectName, worldSpace=True, rotation=[0, 0, 0])
					# Bevel
					bevelNode = cmds.polyBevel3(edgeSel, offset=0, offsetAsFraction=0, autoFit=1, depth=bevelAttributes["polyBevelDepth"]["value"], mitering=bevelAttributes["polyBevelMitering"]["value"], miterAlong=bevelAttributes["polyBevelMiterAlong"]["value"], chamfer=bevelAttributes["polyBevelChamfer"]["value"], segments=bevelAttributes["polyBevelSegment"]["value"], worldSpace=1, subdivideNgons=1, mergeVertices=0, mergeVertexTolerance=0.0001, miteringAngle=180, angleTolerance=180, ch=True)
					bevelNode = cmds.rename(bevelNode[0], "smartBevel1")
					bevelNodes.append(bevelNode)
				
				# Add set members to faceList
				faceList = OpenMaya.MSelectionList()
				for face in faceSel:
					faceList.add(face)
				
				faceList.getDagPath(0, dagPath, component)
				# Iterate over shell faces
				face_iter = OpenMaya.MItMeshPolygon(dagPath, component)
				bevelFacesList = OpenMaya.MSelectionList()
				paramUtil = OpenMaya.MScriptUtil()
				paramPtr = paramUtil.asDoublePtr()
				##bevelEdges = []
				##bevelEdgesList = OpenMaya.MSelectionList()
				
				while not face_iter.isDone():
					faceId = face_iter.index()
					zeroArea = face_iter.zeroArea()
					'''
					areaParam = OpenMaya.MScriptUtil()
					areaParam.createFromDouble(0.0)
					areaPtr = areaParam.asDoublePtr()
					face_iter.getArea(areaPtr, OpenMaya.MSpace.kWorld)
					print areaParam.getDouble(areaPtr)
					'''
					# Add zero area faces to list
					if zeroArea is True:
						# Add face to list
						bevelFacesList.add(dagPath, face_iter.currentItem())
					else:
						face_iter.getArea(paramPtr, OpenMaya.MSpace.kWorld)
						param = paramUtil.getDouble(paramPtr)
						if param < tolerance:
							# Add face to list
							bevelFacesList.add(dagPath, face_iter.currentItem())
					
					cmds.progressBar(gMainProgressBar, e=True, s=1, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
					face_iter.next()
				
				if bevelFacesList.isEmpty() is False:
					# Create new list and merge elements (unflatten list)
					mergedList = OpenMaya.MSelectionList()
					mergedList.merge(bevelFacesList, OpenMaya.MSelectionList.kMergeNormal)
					# Add faces to dictionary
					mergedList.getSelectionStrings(bevelFacesDict[objectName])
					# Add to list
					bevelFacesSel.extend(bevelFacesDict[objectName])
				
				if getBevelSelection is False:
					# Weighted normals
					if weightedNormals == 1:
						# Freeze scale
						cmds.makeIdentity(objectName, a=True, t=False, r=False, s=True, n=False, pn=True)
						cmds.setAttr((bevelNode+".offset"), 0.001)
						cmds.setAttr((bevelNode+".smoothingAngle"), bevelAttributes["polyBevelSmoothingAngle"]["value"])

						# Set vertex normal method
						vertexNormalMethod = cmds.getAttr("{0}.vertexNormalMethod".format(objectName))
						if vertexNormalMethod != 3:
							cmds.setAttr("{0}.vertexNormalMethod".format(objectName), 3)
						
						# Get soft edges
						softEdges = NT_GetSoftEdges(cmds.polyListComponentConversion(objectName, te=True))
						# Lock normals
						##cmds.polyNormalPerVertex(objectName, fn=True)
						##cmds.polyNormalPerVertex(cmds.polyListComponentConversion(bevelFacesDict[objectName], tv=True), fn=True)
						cmds.polyNormalPerVertex(cmds.polyListComponentConversion(objectName, tv=True), fn=True)

						# Set vertex normal method
						if vertexNormalMethod != 3:
							cmds.setAttr("{0}.vertexNormalMethod".format(objectName), vertexNormalMethod)

						# Re-soften edges
						if len(softEdges) > 0:
							cmds.polySoftEdge(softEdges, a=180, ch=True)
						# Duplicate mesh
						duplicatedObject = cmds.duplicate(objectName, rc=True)
						duplicatedShape = cmds.ls(cmds.listRelatives(duplicatedObject, f=True, ni=True, s=True), ni=True, l=True)
						
						# Clear NormalToolkit_SelectionSet
						NT_ModifiySelectionSet(cmds.polyListComponentConversion(duplicatedObject, tf=True), clear=True, setName=SET_NAME)
						# Break shape connections
						DisconnectAllAttributes(duplicatedShape)
						
						# Get display colors
						##displayColors = cmds.polyOptions(objectName, q=True, cs=True)
						displayColors = meshNode.displayColors()
						# Transfer attributes
						normalTransfer = cmds.transferAttributes(duplicatedObject[0], objectName, pos=0, nml=1, uvs=0, clb=0, col=0, spa=4, sm=3)
						cmds.setAttr(normalTransfer[0]+".isHistoricallyInteresting", 0)
						# Set display colors
						##cmds.polyOptions(objectName, cs=displayColors[0])
						meshNode.setDisplayColors(displayColors)
						# Parent duplicated mesh as intermediate object shape
						duplicatedShape = cmds.parent(duplicatedShape, objectName, relative=True, shape=True)
						cmds.setAttr((duplicatedShape[0]+".intermediateObject"), 1)
						# Delete transform
						cmds.delete(duplicatedObject)
						##objects.append(objectName)
						
					for attribute in six.itervalues(bevelAttributes):
						if "value" in attribute:
							if "invert" in attribute and attribute["invert"] is True:
								attrValue = (0 == attribute["value"])
							else:
								attrValue = attribute["value"]
							if attrValue is not None:
								cmds.setAttr((bevelNode+attribute["attr"]), attrValue)
					
					# FIX FOR MAYA 2019 # Rotate object back to initial position
					if objectRotation is not None:
						cmds.xform(objectName, objectSpace=True, rotation=objectRotation)
				
				##iterIndex += 1
				cmds.progressBar(gMainProgressBar, e=True, s=1, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
				sel_iter.next()
	
	if getBevelSelection is False:
		# Restore selection
		cmds.select(objects, r=True)
		if cmds.selectMode(q=True, co=True) is True:
			cmds.selectMode(co=True)
			cmds.select(currentSel, r=True)
		# Select bevel faces
		if selectBevelFaces == 1:
			if cmds.selectMode(q=True, co=True) is False:
				cmds.selectType(fc=True)
			if len(bevelFacesSel) > 0:
				cmds.selectMode(co=True)
				cmds.select(bevelFacesSel, r=True)
		elif len(bevelNodes) > 0:
			if cmds.selectMode(q=True, co=True) is True:
				cmds.select(cl=True)
		# Select bevel nodes
		if len(bevelNodes) > 0:
			cmds.select(bevelNodes, add=True)
			cmds.setToolTo("ShowManips")
		# Add bevel faces to Selection Set
		if addToSelectionSet == 1:
			NT_ClearFullSelectionSet(objects, setName=SET_NAME)
			# Add bevel faces to Selection Set
			if cmds.objExists(SET_NAME) and bevelFacesSel:
				cmds.sets(bevelFacesSel, edit=True, forceElement=SET_NAME, noWarnings=True)
				#NT_AddToSelectionSet(bevelFacesSel, setName=SET_NAME)
		# Close undo chunk
		cmds.undoInfo(cck=True)
		cmds.progressBar(gMainProgressBar, e=True, ep=True)
	return bevelFacesSel, bevelFacesDict

def NT_GetBevelFaces(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	currentSel = None
	objects = None
	bevelFacesDict = defaultdict(list)
	bevelFacesList = []
	ignoreFilteredBevels = False
	filteredBevelNodes = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "ignoreFilteredBevels" or key == "ifb":
			ignoreFilteredBevels = value
	
	if objects is None:
		currentSel, objects = NT_GetCurrentSel()
	
	if currentSel is None:
		currentSel = cmds.ls(sl=True, l=True)
	
	if objects is not None:
		# Get selected bevels
		bevelNodesFilter = cmds.ls(currentSel, l=True, typ=["polyBevel", "polyBevel2", "polyBevel3"])
		# If bevel nodes are selected, get objects from bevels listConnections
		if len(bevelNodesFilter) > 0:
			objects = cmds.ls(cmds.listConnections(bevelNodesFilter, s=True, d=False, c=False, t="mesh"), l=True)
			# Remove intermediate objects
			objects = cmds.ls(objects, l=True, ni=True)
			# Remove duplicates objects
			if objects is not None:
				objects = list(OrderedDict.fromkeys(objects))
			##restoreSelection = objects
	
	if objects is not None and len(objects) > 0:
		##nestedDict = lambda: defaultdict(nestedDict)
		##objectsDict = nestedDict()
		default_factory = (lambda: defaultdict(dict))
		objectsDict = defaultdict(default_factory)
		
		# Check if objects have any bevel nodes
		objectHistory = cmds.listHistory(objects, il=1, pdo=True)
		bevelNodes = cmds.ls(objectHistory, l=True, typ=["polyBevel", "polyBevel2", "polyBevel3"])
		if len(bevelNodes) <= 0:
			return bevelFacesList, bevelFacesDict
		
		# Progress bar
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Building dictionary in progress...", min=0, max=(len(objects)))
		progressBarFaces = 0
		
		# Create a dictionary with bevelNodes and mergeNodes attributes
		for object in objects:
			# Check for bevel and merges nodes in object's history
			objectHistory = cmds.listHistory(object, il=1, pdo=True)
			allBevelNodes = cmds.ls(objectHistory, l=True, typ=["polyBevel", "polyBevel2", "polyBevel3"])
			mergeNodes = cmds.ls(objectHistory, l=True, typ=["polyMergeVert"])
			
			# If bevel nodes were selected, filter out the other bevel nodes
			if len(bevelNodesFilter) > 0:
				##bevelNodes = filter(set(bevelNodes).__contains__, bevelNodesFilter)
				bevelNodes = set(allBevelNodes).intersection(bevelNodesFilter)
				if not (len(bevelNodes) == 1 and allBevelNodes.index(next(iter(bevelNodes))) == 0) and not ignoreFilteredBevels:
					filteredBevelNodes = set(allBevelNodes).difference(bevelNodes)
			
			# If a mergeNode is located before the bevel nodes in history chain, we can ignore it to avoid selection errors
			for mergeNode in list(mergeNodes):
				keepMergeNode = False
				for bevelNode in bevelNodes:
					if objectHistory.index(bevelNode) > objectHistory.index(mergeNode):
						keepMergeNode = True
						break
				if keepMergeNode is False:
					mergeNodes.remove(mergeNode)
			
			if len(bevelNodes) > 0:
				# Set bevel nodes offset to 0
				for bevelNode in bevelNodes:
					objectsDict[object]["bevelNodes"][bevelNode] = {".offsetAsFraction": cmds.getAttr(bevelNode+".offsetAsFraction"), ".offset": cmds.getAttr(bevelNode+".offset")}
					cmds.setAttr((bevelNode+".mergeVertices"), 0)
					cmds.setAttr((bevelNode+".offsetAsFraction"), 0)
					cmds.setAttr((bevelNode+".offset"), 0)
				# Disable merge nodes
				for mergeNode in mergeNodes:
					objectsDict[object]["mergeNodes"][mergeNode] = {".nodeState": cmds.getAttr(mergeNode+".nodeState")}
					cmds.setAttr((mergeNode+".nodeState"), 1)
				# Disable filtered bevels
				for filteredBevel in filteredBevelNodes:
					objectsDict[object]["mergeNodes"][filteredBevel] = {".nodeState": cmds.getAttr(filteredBevel+".nodeState")}
					cmds.setAttr((filteredBevel+".nodeState"), 1)
				if len(mergeNodes) > 0:
					progressBarFaces += cmds.polyEvaluate(object, f=True)+1

			cmds.progressBar(gMainProgressBar, e=True, s=1, st="Building dictionary in progress...")
		cmds.progressBar(gMainProgressBar, e=True, ep=True)
	
	if objects is not None and "objectsDict" in locals():
		progressBarMax = ((cmds.polyEvaluate(objects, f=True)*1)+(progressBarFaces*2))
		progressBarSteps = (len(str(progressBarMax))*len(str(progressBarMax)))
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selecting bevel faces in progress...", min=0, max=((len(objects)*2)+progressBarMax))
		
		# Get bevel faces
		objectEdges = cmds.polyListComponentConversion(objects, te=True)
		bevelFacesDict = NT_SmartBevel(objectEdges, gbs=True)[1]
		
		for object, objectDict in six.iteritems(objectsDict):
			# Restore bevel nodes attributes
			for bevelNode in objectDict["bevelNodes"]:
				for attr, value in six.iteritems(objectDict["bevelNodes"][bevelNode]):
					cmds.setAttr((bevelNode+attr), value)
			
			# If object has merge nodes
			if len(objectDict["mergeNodes"]) > 0:
				# Duplicate object
				duplicatedObject = cmds.duplicate(object)
				# Get bevel faces for duplicated object
				duplicatedObjectFaces = [duplicatedObject[0]+"."+face.split(".", 1)[1] for face in bevelFacesDict[object]]
				# Create a color set on duplicated object
				colorSet = cmds.polyColorSet(duplicatedObject[0], cr=True)[0]
				# Set vertex color on duplicated object based on bevel faces
				colorSetList = NT_SetVertexColorFaces(duplicatedObjectFaces, csn=colorSet, ps=progressBarSteps)[0]
				
				# Re-enable object's merge nodes
				for mergeNode in objectDict["mergeNodes"]:
					for attr, value in six.iteritems(objectDict["mergeNodes"][mergeNode]):
						cmds.setAttr((mergeNode+attr), value)
				
				# If undo is turned off, turn it on temporarily
				undoState = cmds.undoInfo(query=True, state=True)
				if not undoState:
					cmds.undoInfo(state=True)

				# Open undo chunk
				cmds.undoInfo(ock=True)
				# Create a color set on object
				colorSetName = cmds.polyColorSet(object, cr=True)[0]
				# Transfer vertex colors from duplicated object to object
				transferColorSet = cmds.transferAttributes(duplicatedObject[0], object, pos=0, nml=0, uvs=0, col=1, scs=colorSetList[0], tcs=colorSetName, spa=0, sm=3, clb=1)
				# Close undo chunk
				cmds.undoInfo(cck=True)
				
				# Get object's faces with vertex color
				vertexColorFacesSel = NT_GetVertexColorFaces(cmds.polyListComponentConversion(object, tf=True), csn=colorSetName, ps=progressBarSteps)[0]
				# Replace object's dictionary value with new faces list
				bevelFacesDict[object] = vertexColorFacesSel
				
				# Undo chunk
				cmds.undo()

				# Restore undo state
				if not undoState:
					cmds.undoInfo(state=False)

				# Delete duplicated object
				cmds.delete(duplicatedObject)
			
			# Add object's dictionary value to bevelFacesList
			bevelFacesList.extend(bevelFacesDict[object])
			cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selecting bevel faces in progress...")
		
		##cmds.select(bevelFacesList, add=True)
		
		# Restore selection
		##if "restoreSelection" in locals() and len(restoreSelection) > 0:
			##cmds.select(restoreSelection, r=True)
		cmds.progressBar(gMainProgressBar, e=True, ep=True)

	return bevelFacesList, bevelFacesDict

def NT_SelectBevelFaces(*args, **kwargs):
	# Create default args
	objects = None
	bevelFacesDict = defaultdict(list)
	bevelFacesList = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
	
	if objects is None:
		objects = NT_GetCurrentSel(objects)[1]
	
	# Get bevel faces
	bevelFacesList, bevelFacesDict = NT_GetBevelFaces(objects)
	
	if len(bevelFacesList) > 0:
		# Select objects
		##cmds.select(list(bevelFacesDict.keys()), r=True)
		cmds.select(objects, r=True)
		# Set selection mode to face component mode
		cmds.selectMode(co=True)
		cmds.selectType(fc=True)
		# Select bevel faces
		cmds.select(bevelFacesList, r=True)
	else:
		cmds.warning("No bevel nodes found", noContext=True)
	
	return bevelFacesList, bevelFacesDict

def NT_GetWindowSizeHint(windowName, *args):
	windowSize = None
	
	windowPointer = MQtUtil.findWindow(windowName)
	if windowPointer:
		windowWidget = wrapInstance(long(windowPointer), QtWidgets.QMainWindow)
		windowSize = (windowWidget.sizeHint().width(), windowWidget.sizeHint().height())
	
	return windowSize

def NT_SmartTransferNormals(*args, **kwargs):
	# Create default args
	selection = None
	reselect = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	if selection is None:
		selection = NT_GetCurrentSel()[0]
		reselect = True
	
	selectType = NT_GetComponentType()
	
	if not selectType:
		cmds.warning("Please select valid components", noContext=True)
		return
	
	facesSel = selection
	if selectType != "fc":
		facesSel = cmds.polyListComponentConversion(selection, toFace=True, internal=True)
	facesSelDict = NT_SelectionDictionary(facesSel)[0]
	
	displayColorsDict = {}
	for obj in six.iterkeys(facesSelDict):
		objShape = next(iter(cmds.listRelatives(obj, fullPath=True, shapes=True, noIntermediate=True) or []), None)
		if objShape and not cmds.getAttr("{0}.displayColors".format(objShape)):
			displayColorsDict[obj] = objShape
			cmds.setAttr("{0}.displayColors".format(objShape), 0) # needed otherwise undoing will turn on color display
	
	for obj, faces in six.iteritems(facesSelDict):
		# Save soft edge perimeter for later
		edgePerimeter = cmds.polyListComponentConversion(faces, toEdge=True, border=True)
		edgePerimeterSoft = NT_GetSoftEdges(edgePerimeter)
		edgeSoft = NT_GetSoftEdges(cmds.polyListComponentConversion(cmds.polyListComponentConversion(edgePerimeter, toVertex=True), toEdge=True))
		
		
		## Duplicate object
		duplicatedObj = cmds.ls(cmds.duplicate(obj), long=True)[0]
		duplicatedObjFaces = ["{0}.{1}".format(duplicatedObj, face.split(".", 1)[-1]) for face in faces]
		hardEdgesSet = cmds.sets(NT_GetSoftEdges(cmds.polyListComponentConversion(duplicatedObj, toEdge=True), softEdge=False), name="hardEdgesSet1")
		duplicatedObjFacesSet = cmds.sets(duplicatedObjFaces, name="duplicatedObjFacesSet1")
		duplicatedObjBorderEdgesSet = cmds.sets(GetBorderEdges(selection=cmds.polyListComponentConversion(duplicatedObj, toEdge=True)), name="duplicatedObjBorderEdgesSet1")
		
		
		## Find face perimeter
		
		# Split hard edges
		polySplitNode = None
		if cmds.sets(hardEdgesSet, query=True):
			polySplitNode = next(iter(cmds.polySplitEdge(cmds.sets(hardEdgesSet, query=True))), None)
		
		# Grow selection
		facePerimeter = cmds.polyListComponentConversion(cmds.polyListComponentConversion(cmds.sets(duplicatedObjFacesSet, query=True), toVertex=True), toFace=True)
		facePerimeterSet = cmds.sets("{0}.f[*]".format(duplicatedObj), name="facePerimeterSet1")
		cmds.sets(facePerimeter, remove=facePerimeterSet)
		
		# Delete faces
		if cmds.sets(facePerimeterSet, query=True):
			cmds.delete(cmds.sets(facePerimeterSet, query=True))
		if cmds.objExists(facePerimeterSet):
			cmds.delete(facePerimeterSet)
		
		# Delete polysplit node
		if polySplitNode:
			cmds.delete(polySplitNode)
		
		# Delete bevel faces
		bevelFaces = NT_ViewSelectionSet(objects=duplicatedObj, returnSelection=True, setName=SET_NAME)
		if len(bevelFaces) > 0:
			cmds.delete(bevelFaces)
		
		
		## Cleanup surface
		
		# Find all elements
		duplicatedObjAllFacesSet = cmds.sets("{0}.f[*]".format(duplicatedObj), name="duplicatedObjAllFacesSet1")
		duplicatedObjFacesShell = []
		while cmds.sets(duplicatedObjAllFacesSet, query=True):
			faceStr = cmds.ls(cmds.sets(duplicatedObjAllFacesSet, query=True), long=True, flatten=True)[0]
			faceId = int(re.split("\.f\[([0-9:]*)\]", faceStr)[1])
			shellFaces = cmds.polySelect(duplicatedObj, noSelection=True, extendToShell=faceId, asSelectString=True)
			shellFacesSet = cmds.sets(shellFaces, name="shellFacesSet1")
			duplicatedObjFacesShell.append(shellFacesSet)
			cmds.sets(shellFaces, remove=duplicatedObjAllFacesSet)
		if cmds.objExists(duplicatedObjAllFacesSet):
			cmds.delete(duplicatedObjAllFacesSet)
			
		fillHoleFacesSet = cmds.sets(empty=True, name="fillHoleFacesSet1")
		
		# For each element
		for facesShellSet in duplicatedObjFacesShell:
			# Fill holes
			fillHoles = cmds.polyCloseBorder(cmds.sets(facesShellSet, query=True))[0]
			
			# Get all faces of element
			faceStr = cmds.ls(cmds.sets(facesShellSet, query=True), long=True, flatten=True)[0]
			faceId = int(re.split("\.f\[([0-9:]*)\]", faceStr)[1])
			shellFaces = cmds.polySelect(duplicatedObj, noSelection=True, extendToShell=faceId, asSelectString=True)
			
			# Remove faces created by the fill hole from the set
			shellFillHoleFacesSet = cmds.sets(shellFaces, name="shellFillHoleFacesSet1")
			cmds.sets(cmds.sets(facesShellSet, query=True), remove=shellFillHoleFacesSet)
			
			# Find largest face from fill hole
			fillHoleFaceDict = {}
			for fillHoleFace in cmds.ls(cmds.sets(shellFillHoleFacesSet, query=True), long=True, flatten=True):
				fillHoleFaceDict[fillHoleFace] = GetFacesArea(fillHoleFace)
			
			if len(fillHoleFaceDict) > 0:
				# Delete largest face in fillHoleFaceDict
				cmds.delete(max(fillHoleFaceDict, key=fillHoleFaceDict.get))
			
			# Add element fill hole faces to set
			if cmds.sets(shellFillHoleFacesSet, query=True):
				cmds.sets(cmds.sets(shellFillHoleFacesSet, query=True), addElement=fillHoleFacesSet)
			if cmds.objExists(shellFillHoleFacesSet):
				cmds.delete(shellFillHoleFacesSet)
		

		'''## Retopologize object

		# Get fill hole faces count
		fillHolesFaces = cmds.sets(fillHoleFacesSet, query=True)
		targetFaceCount = cmds.polyEvaluate(duplicatedObj, face=True) - len(cmds.ls(fillHolesFaces, flatten=True)) - 1

		# Remove unattached vertex
		cmds.delete(cmds.polyListComponentConversion(duplicatedObj, toVertex=True))

		# Soften holes
		if fillHolesFaces:
			cmds.polySoftEdge(fillHolesFaces, angle=50)

		# Retopo
		cmds.polyRetopo(duplicatedObj, targetFaceCount=targetFaceCount, anisotropy=0, anisotropyFilter=0, geodesicRadius=0.0001, curveSingularitySeparation=0, curveInfluenceDirection=0)'''

		
		# Create fill hole vertex set
		fillHoleVertexSet = cmds.sets(cmds.polyListComponentConversion(cmds.sets(fillHoleFacesSet, query=True), toVertex=True), name="fillHoleVertexSet1")
		
		if cmds.sets(fillHoleFacesSet, query=True):
			# Delete fill hole vertex
			fillHoleVertices = cmds.polyListComponentConversion(cmds.sets(fillHoleFacesSet, query=True), toVertex=True)
			if len(fillHoleVertices) > 0:
				cmds.delete(fillHoleVertices)
			
			# Soften fill hole edges
			fillHoleEdges = cmds.polyListComponentConversion(cmds.sets(fillHoleFacesSet, query=True), toEdge=True)
			if len(fillHoleEdges) > 0:
				fillHoleEdgesSoft = NT_GetSoftEdges(fillHoleEdges)
				cmds.polySoftEdge(fillHoleEdges, angle=5)
				if len(fillHoleEdgesSoft) > 0:
					cmds.polySoftEdge(fillHoleEdgesSoft, angle=180)
			
				# Cleanup fill hole edges
				fillHoleEdgesSoft = NT_GetSoftEdges(fillHoleEdges)
				if len(fillHoleEdgesSoft) > 0:
					cmds.polyDelEdge(fillHoleEdgesSoft, cleanVertices=True)
		
		# Merge fill hole faces to center (only if all edges are hard)
		while cmds.sets(fillHoleFacesSet, query=True):
			fillHoleFace = cmds.ls(cmds.sets(fillHoleFacesSet, query=True), flatten=True, long=True)[0]
			
			fillHoleFaceSoftEdges = NT_GetSoftEdges(cmds.polyListComponentConversion(fillHoleFace, toEdge=True))
			if len(fillHoleFaceSoftEdges) > 0:
				cmds.sets(fillHoleFace, remove=fillHoleFacesSet)
				continue
			
			fillHoleVertices = cmds.ls(cmds.polyListComponentConversion(fillHoleFace, toVertex=True), flatten=True, long=True)
			verticesCenter = GetVerticesCenter(fillHoleVertices)
			verticesCenter.extend(fillHoleVertices)
			cmds.move(*verticesCenter, worldSpace=True)
			cmds.polyMergeVertex(fillHoleVertices, distance=0.000001)
		
		# Cleanup edges
		cmds.polySoftEdge(duplicatedObj, angle=5)
		fillHoleEdges = cmds.polyListComponentConversion(cmds.sets(fillHoleFacesSet, query=True), toEdge=True)
		softEdges = NT_GetSoftEdges(fillHoleEdges)
		if len(softEdges) > 0:
			cmds.polyDelEdge(softEdges, cleanVertices=True)
		if cmds.objExists(fillHoleFacesSet):
			cmds.delete(fillHoleFacesSet)
		
		# Delete floating vertices
		duplicatedObjEdgesSet = cmds.sets("{0}.e[*]".format(duplicatedObj), name="duplicatedObjEdgesSet1")
		duplicatedObjBorderEdges = GetBorderEdges(selection=cmds.sets(duplicatedObjEdgesSet, query=True))
		cmds.sets(duplicatedObjBorderEdges, remove=duplicatedObjEdgesSet)
		cmds.sets(cmds.polyListComponentConversion(cmds.sets(duplicatedObjFacesSet, query=True), toEdge=True), addElement=duplicatedObjEdgesSet)
		if cmds.sets(duplicatedObjBorderEdgesSet, query=True):
			cmds.sets(cmds.sets(duplicatedObjBorderEdgesSet, query=True), remove=duplicatedObjEdgesSet)
		duplicatedObjVertices = cmds.polyListComponentConversion(cmds.sets(duplicatedObjEdgesSet, query=True), toVertex=True)
		if len(duplicatedObjVertices) > 0:
			cmds.delete(duplicatedObjVertices)
		if cmds.objExists(duplicatedObjEdgesSet):
			cmds.delete(duplicatedObjEdgesSet)
		if cmds.objExists(duplicatedObjFacesSet):
			cmds.delete(duplicatedObjFacesSet)
		if cmds.objExists(duplicatedObjBorderEdgesSet):
			cmds.delete(duplicatedObjBorderEdgesSet)
		
		# Cleanup floating edges
		if cmds.sets(fillHoleVertexSet, query=True):
			softEdges = NT_GetSoftEdges(cmds.polyListComponentConversion(cmds.sets(fillHoleVertexSet, query=True), toEdge=True))
			if len(softEdges) > 0:
				cmds.polyDelEdge(softEdges, cleanVertices=True)
		if cmds.objExists(fillHoleVertexSet):
			cmds.delete(fillHoleVertexSet)
		
		# Unlock normals & soften edges
		cmds.polyNormalPerVertex(duplicatedObj, unFreezeNormal=True)
		cmds.polySoftEdge(duplicatedObj, angle=180)
		if cmds.sets(hardEdgesSet, query=True):
			cmds.polySoftEdge(cmds.sets(hardEdgesSet, query=True), angle=0)
		
		
		## Transfer normals from duplicated object to original object
		
		# Transfer attributes
		#cmds.makeIdentity(duplicatedObj, apply=True, translate=False, rotate=True, scale=False, normal=False, preserveNormals=True)
		cmds.transferAttributes(duplicatedObj, faces, transferPositions=False, transferNormals=True, transferUVs=False, transferColors=False, sampleSpace=0, searchMethod=0)
		cmds.delete(obj, constructionHistory=True)
		
		# Turn off display colors
		if obj in displayColorsDict:
			cmds.setAttr("{0}.displayColors".format(displayColorsDict[obj]), 0)
		
		# Fix edge perimeter normals
		if len(edgePerimeterSoft) > 0:
			perimeterVertexFaceConstraint = cmds.ls(cmds.polyListComponentConversion(edgePerimeterSoft, toVertexFace=True), long=True, flatten=True)
			allVertexFace = cmds.ls(cmds.polyListComponentConversion(faces, toVertexFace=True), long=True, flatten=True)
			perimeterVertexFace = [vf for vf in perimeterVertexFaceConstraint if vf in allVertexFace]
			
			# needs to apply polySoftEdge or some normals gets randomly unlocked for unknown reasons
			cmds.polySoftEdge(edgeSoft, angle=0)
			PropagateVertexFaceNormalV2(perimeterVertexFace, vertexFaceConstraint=perimeterVertexFaceConstraint, softEdges=edgeSoft)
		
		# Delete duplicate object
		cmds.delete(hardEdgesSet)
		cmds.delete(duplicatedObj)
	
	if reselect:
		cmds.select(selection, replace=True)

def NT_TransferNormals(*args, **kwargs):
	# Create default args
	sourceObj = None
	destinationSel = None
	reselect = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			sourceObj = arg
		elif i == 1:
			destinationSel = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "sourceObj" or key == "src":
			sourceObj = value
		elif key == "destinationSel" or key == "dst":
			destinationSel = value
	
	if sourceObj is None or not isinstance(sourceObj, six.string_types):
		cmds.warning("Please input a valid source object", noContext=True)
	
	if destinationSel is None:
		destinationSel = NT_GetCurrentSel()[0]
		reselect = True
	
	selectType = NT_GetComponentType()
	vertexFaceSel = []
	vertexNormalsList = []
	
	if not selectType:
		facesSel = cmds.polyListComponentConversion(destinationSel, toFace=True)
	else:
		facesSel = destinationSel
		if selectType != "fc":
			if selectType != "v":
				vertexSel = cmds.polyListComponentConversion(destinationSel, toVertex=True)
			else:
				vertexSel = list(destinationSel)
			
			facesSel = cmds.polyListComponentConversion(destinationSel, toFace=True)
			
			if vertexSel:
				vertexFaceSel = cmds.ls(cmds.polyListComponentConversion(vertexSel, toVertexFace=True), long=True, flatten=True)

			'''facesSelVert = cmds.polyListComponentConversion(facesSel, toVertex=True)
			vertexSel = componentListDifference(facesSelVert, vertexSel)'''
	
	facesSelDict = NT_SelectionDictionary(facesSel)[0]
	
	displayColorsDict = {}
	for obj in six.iterkeys(facesSelDict):
		objShape = next(iter(cmds.listRelatives(obj, fullPath=True, shapes=True, noIntermediate=True) or []), None)
		if objShape and not cmds.getAttr("{0}.displayColors".format(objShape)):
			displayColorsDict[obj] = objShape
			cmds.setAttr("{0}.displayColors".format(objShape), 0) # needed otherwise undoing will turn on color display
	
	# Get current vertex normals to fix collateral later
	'''vertexList, vertexNormalsList, unlockList = [], [], []
	if vertexSel:
		vertexFaceSel = cmds.ls(cmds.polyListComponentConversion(vertexSel, toVertexFace=True), long=True, flatten=True)
		vertexNormals = cmds.polyNormalPerVertex(vertexFaceSel, query=True, normalXYZ=True)
		lockedNormals = cmds.polyNormalPerVertex(vertexFaceSel, query=True, freezeNormal=True)

		vertexNormalsIter = iter(vertexNormals)
		for i, x in enumerate(vertexNormalsIter):
			v = [x, next(vertexNormalsIter), next(vertexNormalsIter)]
			if lockedNormals[i]:
				vertexList.append(vertexFaceSel[i])
				vertexNormalsList.append(v)
			else:
				unlockList.append(vertexFaceSel[i])'''

	# If undo is turned off, turn it on temporarily
	undoState = cmds.undoInfo(query=True, state=True)
	if not undoState:
		cmds.undoInfo(state=True)

	try:
		currentHl = cmds.ls(hilite=True, long=True)
		currentSel = cmds.ls(selection=True, long=True)

		# Fix hilite selection when undoing
		if reselect:
			cmds.hilite(currentHl)
			#cmds.select(destinationSel)
		else:
			cmds.hilite(currentHl)
			#cmds.select(currentSel)

		# open undo chunk
		cmds.undoInfo(openChunk=True)

		for obj, faces in six.iteritems(facesSelDict):
			# Save soft edge perimeter for later
			edgePerimeter = cmds.polyListComponentConversion(faces, toEdge=True, border=True)
			edgePerimeterSoft = NT_GetSoftEdges(edgePerimeter)
			edgeSoft = NT_GetSoftEdges(cmds.polyListComponentConversion(cmds.polyListComponentConversion(edgePerimeter, toVertex=True), toEdge=True))
			
			## Transfer normals from source object to selected faces
			
			# Transfer attributes
			#objSrc = sourceObj
			#if cmds.ls(obj, long=True) == cmds.ls(sourceObj, long=True):
				#objSrc = cmds.ls(cmds.duplicate(obj), long=True)[0]
			
			# Duplicate source object
			objSrc = next(iter(cmds.ls(cmds.duplicate(sourceObj), long=True)))

			# Apply smooth mesh preview
			applySmoothMeshPreview(objSrc)

			# Create empty transform
			tmpTransform = cmds.createNode("transform", skipSelect=True)
			# Match object matrix
			cmds.xform(tmpTransform, matrix=cmds.xform(obj, query=True, matrix=True, worldSpace=True), worldSpace=True)
			# Parent source object in empty transform
			objSrc = cmds.parent(objSrc, tmpTransform)
			# Freeze transformations
			cmds.makeIdentity(objSrc, apply=True, translate=True, rotate=True, scale=True, normal=False, preserveNormals=True)

			# Get search method from optionVar
			searchMethod = 0
			if cmds.optionVar(exists="NTTN_SearchMethod"):
				searchMethod = cmds.optionVar(query="NTTN_SearchMethod")
				if searchMethod == 2:
					searchMethod = 3
				else:
					searchMethod = 0
			
			# Transfer normals
			cmds.transferAttributes(objSrc, faces, transferPositions=False, transferNormals=True, transferUVs=False, transferColors=False, sampleSpace=0, searchMethod=searchMethod)
			# Delete history so we can delete the source object safely
			cmds.delete(obj, constructionHistory=True)

			#if cmds.ls(obj, long=True) == cmds.ls(sourceObj, long=True):
				#cmds.delete(objSrc)
			
			# Delete empty transform
			cmds.delete(tmpTransform)
			
			# Turn off display colors
			if obj in displayColorsDict:
				cmds.setAttr("{0}.displayColors".format(displayColorsDict[obj]), 0)
			
			# Fix edge perimeter normals
			if len(edgePerimeterSoft) > 0:
				perimeterVertexFaceConstraint = cmds.ls(cmds.polyListComponentConversion(edgePerimeterSoft, toVertexFace=True), long=True, flatten=True)
				allVertexFace = cmds.ls(cmds.polyListComponentConversion(faces, toVertexFace=True), long=True, flatten=True)
				perimeterVertexFace = [vf for vf in perimeterVertexFaceConstraint if vf in allVertexFace]
				
				# needs to apply polySoftEdge or some normals gets randomly unlocked for unknown reasons
				cmds.polySoftEdge(edgeSoft, angle=0)
				PropagateVertexFaceNormalV2(perimeterVertexFace, vertexFaceConstraint=perimeterVertexFaceConstraint, softEdges=edgeSoft)
		
		'''if all([vertexList, vertexNormalsList]):
			cmds.polyNormalPerVertex(vertexList, xyz=vertexNormalsList
		if unlockList:
			cmds.polyNormalPerVertex(unlockList, unFreezeNormal=True)'''

		if vertexFaceSel:
			vertexNormals = cmds.polyNormalPerVertex(vertexFaceSel, query=True, normalXYZ=True)
			vertexNormalsIter = iter(vertexNormals)
			for i, x in enumerate(vertexNormalsIter):
				vertexNormalsList.append([x, next(vertexNormalsIter), next(vertexNormalsIter)])

		# Restore selection
		if reselect:
			cmds.hilite(currentHl)
			cmds.select(destinationSel)
		else:
			cmds.hilite(currentHl)
			cmds.select(currentSel)

	except Exception as e:
		cmds.error(e, noContext=True)
	finally:
		# close undo chunk
		cmds.undoInfo(closeChunk=True)
		
		# if not faces transfer, undo and transfer selected vertices only
		if all([vertexFaceSel, vertexNormalsList]):
			cmds.undo()

			# open undo chunk
			cmds.undoInfo(openChunk=True)
			try:
				edgeSel = cmds.polyListComponentConversion(vertexFaceSel, toEdge=True)
				softEdges = NT_GetSoftEdges(edgeSel)
				# transfer vertex normals
				cmds.polyNormalPerVertex(vertexFaceSel, normalXYZ=vertexNormalsList)
				# restore soft edges
				if softEdges:
					softEdgesDict = componentDictionary(softEdges)
					for sEdges in six.itervalues(softEdgesDict):
						cmds.polySoftEdge(sEdges, angle=180)
				
				# Restore selection
				if reselect:
					cmds.hilite(currentHl)
					cmds.select(destinationSel)
				else:
					cmds.hilite(currentHl)
					cmds.select(currentSel)
			except Exception as e:
				cmds.error(e, noContext=True)
			finally:
				# close undo chunk
				cmds.undoInfo(closeChunk=True)

		# Restore undo state
		if not undoState:
			cmds.undoInfo(state=False)

def NT_InstanceDictionary(*args, **kwargs):
	# Create default args
	objects = None
	instanceDict = defaultdict(lambda: defaultdict(list))
	objectsToIgnore = []
	uninstancedObjects = []
	select = False
	setName = SET_NAME

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
		elif i == 1:
			select = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "select" or key == "sl":
			select = value
		elif key == "setName" or key == "sn":
			setName = value
	
	if not objects:
		objects = NT_GetCurrentSel(allDescendents=True)[1]

	if objects:
		NT_CreateSelectionSet(setName=setName)
		NT_selDict = NT_SelectionDictionary(cmds.sets(setName, query=True))[0]

	for obj in objects:	
		# skip object if not in NormalToolkit Selection Set
		if obj not in NT_selDict:
			continue
		objShape = next(iter(cmds.listRelatives(obj, fullPath=True, noIntermediate=True, shapes=True) or []), None)
		objParents = cmds.listRelatives(objShape, fullPath=True, allParents=True)
		if len(objParents) > 1:
			uninstancedObject = next(iter(cmds.ls(cmds.duplicate(obj), long=True)))
			# if has parent, unparent to avoid group instances
			if cmds.listRelatives(uninstancedObject, fullPath=True, parent=True):
				uninstancedObject = next(iter(cmds.ls(cmds.parent(uninstancedObject, world=True), long=True)))

				# make sure it didn't create a new parent when unparenting (maya bug with instances)
				objParent = cmds.listRelatives(uninstancedObject, fullPath=True, parent=True)
				if objParent:
					uninstancedObject = next(iter(cmds.ls(cmds.parent(uninstancedObject, world=True), long=True)))
					cmds.delete(objParent)

			uninstancedObjects.append(uninstancedObject)
			instanceDict[uninstancedObject]["main"] = obj

			for objParent in objParents:
				objInstanceShape = next(iter(cmds.listRelatives(objParent, fullPath=True, noIntermediate=True, shapes=True) or []), None)
				objInstance = next(iter(cmds.listRelatives(objInstanceShape, fullPath=True, parent=True, noIntermediate=True, type="transform") or []), None)
				objectsToIgnore.append(objInstance)
				if objInstance != obj:
					instanceDict[uninstancedObject]["instances"].append(objInstance)
	if select:
		currentSel = [x for x in objects if x not in objectsToIgnore]
		currentSel.extend(uninstancedObjects)
		cmds.select(currentSel, replace=True)

	return instanceDict

def NT_PropagateInstances(*args, **kwargs):
	# Create default args
	instanceDict = defaultdict(lambda: defaultdict(list))
	objectsToRemove = []
	instancedObjects = []
	select = False

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			instanceDict = arg
		elif i == 1:
			select = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "instanceDict" or key == "idct":
			instanceDict = value
		elif key == "select" or key == "sl":
			select = True
	
	if select:
		currentSel = cmds.ls(selection=True, long=True)

	for uninstancedObject, uninstancedObjectDict in six.iteritems(instanceDict):
		if cmds.objExists(uninstancedObject):
			if isinstance(uninstancedObjectDict["main"], six.string_types) and cmds.objExists(uninstancedObjectDict["main"]):
				instancedObjectShape = next(iter(cmds.listRelatives(uninstancedObjectDict["main"], fullPath=True, noIntermediate=True, shapes=True) or []), None)
				uninstancedObjectShape = next(iter(cmds.listRelatives(uninstancedObject, fullPath=True, noIntermediate=True, shapes=True) or []), None)

				if uninstancedObjectShape:
					if instancedObjectShape:
						cmds.delete(instancedObjectShape)
					uninstancedObjectShape = next(iter(cmds.parent(uninstancedObjectShape, uninstancedObjectDict["main"], relative=True, shape=True)))
					cmds.rename(uninstancedObjectShape, GetShortName(instancedObjectShape))
				
				objectsToRemove.append(uninstancedObject)
				instancedObjects.append(uninstancedObjectDict["main"])
	
	if objectsToRemove:
		cmds.delete(objectsToRemove)
	
	if select:
		currentSel = [x for x in currentSel if x not in objectsToRemove]
		currentSel.extend(instancedObjects)
		cmds.select(currentSel, replace=True)

def NT_GetPointsFromMesh(obj):
	try:
		if obj:
			selList = om.MSelectionList()
			selList.add(obj)

			dagPath = selList.getDagPath(0)
			if dagPath.isValid():
				fnMesh = om.MFnMesh(dagPath)
				vertices = fnMesh.getPoints(om.MSpace.kObject)
				polygonCounts, polygonConnects = fnMesh.getVertices()
				#normals = fnMesh.getNormals(om.MSpace.kObject)
				normalCounts, polygonNormalsIds = fnMesh.getNormalIds()
				edgeSmoothings = {x: {"vertices": fnMesh.getEdgeVertices(x), "isSmooth": fnMesh.isEdgeSmooth(x)} for x in range(fnMesh.numEdges)}
				#edgeSmoothings = {fnMesh.getEdgeVertices(x): fnMesh.isEdgeSmooth(x) for x in range(fnMesh.numEdges)}

				return {"vertices": vertices, "polygonCounts": polygonCounts, "polygonConnects": polygonConnects, "normalCounts": normalCounts, "polygonNormalsIds": polygonNormalsIds, "edgeSmoothings": edgeSmoothings}
	except Exception as e:
		pass
	
	return None

def NT_GetDataFromObject(obj):
	objectTransform, objectShape = None, None

	if cmds.objExists(obj or ""):

		if cmds.objectType(obj) == "transform":
			objectTransform = obj
			objectShape = next(iter(cmds.listRelatives(obj, fullPath=True, noIntermediate=True, shapes=True) or []), None)
		elif cmds.objectType(obj) == "mesh":
			objectTransform = next(iter(cmds.listRelatives(obj, fullPath=True, parent=True) or []), None)
			objectShape = obj

		if all([objectTransform, objectShape]):
			dataDict = NT_GetPointsFromMesh(objectShape)
			if dataDict:
				objMatrix = cmds.xform(objectTransform, query=True, matrix=True, worldSpace=True)

				return {"vertices": dataDict["vertices"], "polygonCounts": dataDict["polygonCounts"], "polygonConnects": dataDict["polygonConnects"], "normalCounts": dataDict["normalCounts"], "polygonNormalsIds": dataDict["polygonNormalsIds"], "edgeSmoothings": dataDict["edgeSmoothings"], "matrix": objMatrix}

	return {}

'''def NT_WeightedHardEdge(*args, **kwargs):
	# Create default args
	vertices = []
	selection = False
	polyNormalPerVertexNode = None
	
	# Load arguments (override default args)
	if len(args) > 0:
		if not isinstance(args[0], (list, tuple)):
			vertices = [args[0]]
		else:
			vertices = args[0]
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "vertices" or key == "v":
			if not isinstance(value, (list, tuple)):
				vertices = [value]
			else:
				vertices = value
		elif key == "selection" or key == "sl":
			selection = True
	
	if selection:
		vertices.extend(cmds.ls(selection=True, long=True))
	
	vertices = cmds.ls(cmds.polyListComponentConversion(vertices, toVertex=True), long=True, flatten=True)
	for vertex in vertices:
		vertexFaces = cmds.ls(cmds.polyListComponentConversion(vertex, toVertexFace=True), long=True, flatten=True)
		vertexFacesNormals = cmds.polyNormalPerVertex(vertexFaces, query=True, xyz=True)
		vertexFacesNormals = list(zip(*[vertexFacesNormals[x::3] for x in range(3)]))
		vertexFacesNormalsDict = OrderedDict(zip(vertexFaces, vertexFacesNormals))
		vertexNormals = list(OrderedDict.fromkeys(vertexFacesNormals))
		if len(vertexNormals) > 1:
			v1 = om.MVector(vertexNormals[0])
			v2 = om.MVector(vertexNormals[1])
			v1_parallel = ([round(x, 6)+0 for x in NormalizeVector(list(v1-v2))])
			v2_parallel = ([round(x, 6)+0 for x in NormalizeVector(list(v2-v1))])
			for k, v in six.iteritems(dict(vertexFacesNormalsDict)):
				if v == vertexNormals[0]:
					vertexFacesNormalsDict[k] = v1_parallel
				elif v == vertexNormals[1]:
					vertexFacesNormalsDict[k] = v2_parallel
			if vertexFacesNormalsDict:
				polyNormalPerVertexNode = next(iter(cmds.polyNormalPerVertex(vertexFacesNormalsDict.keys(), edit=True, xyz=vertexFacesNormalsDict.values()) or []), None)
	
	return polyNormalPerVertexNode'''

def NT_WeightedHardEdge(*args, **kwargs):
	# Create default args
	edges = []
	selection = False
	polyNormalPerVertexNode = None
	
	# Load arguments (override default args)
	if len(args) > 0:
		if not isinstance(args[0], (list, tuple)):
			edges = [args[0]]
		else:
			edges = args[0]
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "e" or key == "e":
			if not isinstance(value, (list, tuple)):
				edges = [value]
			else:
				edges = value
		elif key == "selection" or key == "sl":
			selection = True
	
	if selection:
		#edges.extend(cmds.ls(selection=True, long=True))
		edges.extend(cmds.polyListComponentConversion(toEdge=True))
	
	vertexFacesNormalsDict = OrderedDict()
	edges = cmds.ls(edges, long=True, flatten=True)
	for edge in edges:
		edgeVertexFaces = cmds.ls(cmds.polyListComponentConversion(edge, toVertexFace=True), long=True, flatten=True)
		sortedVertexFaces = getSortedVertexFaces(edgeVertexFaces)
		for vertexFaces in sortedVertexFaces:
			vertexFacesNormals = cmds.polyNormalPerVertex(vertexFaces, query=True, xyz=True)
			vertexFacesNormals = list(zip(*[vertexFacesNormals[x::3] for x in range(3)]))
			#vertexFacesNormalsDict = OrderedDict(zip(vertexFaces, vertexFacesNormals))
			vertexFacesNormalsDict.update(zip(vertexFaces, vertexFacesNormals))
			vertexNormals = list(OrderedDict.fromkeys(vertexFacesNormals))
			if len(vertexNormals) > 1:
				v1 = om.MVector(vertexNormals[0])
				v2 = om.MVector(vertexNormals[1])
				v1_parallel = ([round(x, 6)+0 for x in NormalizeVector(list(v1-v2))])
				v2_parallel = ([round(x, 6)+0 for x in NormalizeVector(list(v2-v1))])
				for k, v in six.iteritems(dict(vertexFacesNormalsDict)):
					if v == vertexNormals[0]:
						vertexFacesNormalsDict[k] = v1_parallel
					elif v == vertexNormals[1]:
						vertexFacesNormalsDict[k] = v2_parallel
	
	if vertexFacesNormalsDict:
		polyNormalPerVertexNode = next(iter(cmds.polyNormalPerVertex(list(vertexFacesNormalsDict.keys()), edit=True, xyz=list(vertexFacesNormalsDict.values())) or []), None)
	
	return polyNormalPerVertexNode

def NT_ProcessWeightedHardEdge(obj, weightedFacesSet, softEdgesSet):
	hardEdges = []
	if all([obj, weightedFacesSet, softEdgesSet]):
		if cmds.objExists(weightedFacesSet) and cmds.objectType(weightedFacesSet) == "objectSet" and cmds.objExists(softEdgesSet) and cmds.objectType(softEdgesSet) == "objectSet":
			hardEdges = []
			softEdges = cmds.ls(cmds.sets(softEdgesSet, query=True), long=True)
			if softEdges:
				objEdges = cmds.ls(cmds.polyListComponentConversion(obj, toEdge=True), long=True)
				hardEdges = componentListDifference(objEdges, softEdges)
			weightedFaces = cmds.ls(cmds.sets(weightedFacesSet, query=True), long=True)
			if all([weightedFaces, hardEdges]):
				internalEdges = cmds.ls(cmds.polyListComponentConversion(cmds.polyListComponentConversion(weightedFaces, toVertex=True, internal=True), toEdge=True, internal=True), long=True)
				internalEdges = componentListIntersection(hardEdges, internalEdges)
				if internalEdges:
					NT_WeightedHardEdge(internalEdges)
			
	return hardEdges

def NT_ProcessNormals(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the NormalToolkit plugin first.", noContext=True)
		return

	# Create default args
	objects = []

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value

	if not objects:
		objects = NT_GetCurrentSel()[1]
	
	if objects:
		startTime = time.time()
		processedNormals = False
		selectionSet = False

		# Setup progress bar
		gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
		cmds.progressBar(gMainProgressBar, edit=True, beginProgress=True, isInterruptable=True, status="Processing normals in progress...", maxValue=(len(objects*9)))

		# Fix for hanging previous progress
		if cmds.progressBar(gMainProgressBar, query=True, isCancelled=True):
			cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)
			cmds.progressBar(gMainProgressBar, edit=True, beginProgress=True, isInterruptable=True, status="Processing normals in progress...")
		cmds.progressBar(gMainProgressBar, edit=True, step=1)
		cmds.progressBar(gMainProgressBar, edit=True, step=-1)

		# Store current selection
		currentSel = cmds.ls(selection=True, long=True)

		# Make sure there is no cached polyBase
		disablePolyBaseCache(objects)

		# Make sure that set faces are mutually exclusive
		NT_MakeSetsMutuallyExclusive()

		# Get bevel set dict
		NT_CreateSelectionSet(setName=SET_NAME)
		NT_bevelDict, NT_bevelObjects, NT_bevelFaces = NT_SelectionDictionary(cmds.sets(SET_NAME, query=True))

		# Get fillet set dict
		NT_CreateSelectionSet(setName=FILLET_SET_NAME)
		NT_filletDict, NT_filletObjects, NT_filletFaces = NT_SelectionDictionary(cmds.sets(FILLET_SET_NAME, query=True))

		# Get mainFaces set dict
		#mainFacesSet = cmds.sets(cmds.polyListComponentConversion(objects, toFace=True), facets=True)
		#cmds.sets(NT_bevelFaces, NT_filletFaces, remove=mainFacesSet, noWarnings=True)
		#NT_mainDict = NT_SelectionDictionary(cmds.sets(mainFacesSet, q=True))[0]
		#cmds.delete(mainFacesSet)
		mainFacesList = componentListDifference(cmds.ls(cmds.polyListComponentConversion(objects, toFace=True), long=True), NT_bevelFaces + NT_filletFaces)
		NT_mainDict = NT_SelectionDictionary(mainFacesList)[0]

		for obj in objects:
			if cmds.progressBar(gMainProgressBar, query=True, isCancelled=True):
				return
			
			if not any([obj in d for d in (NT_bevelDict, NT_filletDict)]):
				cmds.progressBar(gMainProgressBar, edit=True, step=6)
				continue

			selectionSet = True

			# Get soft and hard edges
			softEdges, hardEdges = NT_GetSoftEdges(cmds.polyListComponentConversion(obj, toEdge=True), getSmoothing=True)
			if not softEdges:
				cmds.warning("No soft edges, cannot process normals on object: {0}".format(obj))
				cmds.progressBar(gMainProgressBar, edit=True, step=6)
				continue
			
			processedNormals = True

			# Default variables
			mainFaces, filletFaces, bevelFaces = [], [], []
			objectFaces = OrderedDict([("mainFaces", []), ("filletFaces", []), ("bevelFaces", [])])
			#mainFacesData, filletFacesData, bevelFacesData = {}, {}, {}
			vertices, polygonCounts, polygonConnects = [], [], []
			faceVertexIds = OrderedDict()
			vertexPosDict = OrderedDict()
			normalsIdsDict = OrderedDict()
			edgesConnects = OrderedDict()
			#normalsValueDict = OrderedDict()
			historyNode = None
			polySoftEdgeNode = None

			# Unlock object normals
			cmds.polyNormalPerVertex(obj, unFreezeNormal=True)
			
			if softEdges:
				historyNode = cmds.polySoftEdge(softEdges[0], angle=180)

			# Get current object data
			objectData = NT_GetDataFromObject(obj)

			targetSelList = om.MSelectionList()
			targetSelList.add(obj)
			targetDagPath = targetSelList.getDagPath(0)
			faceIter = om.MItMeshPolygon(targetDagPath)

			cmds.progressBar(gMainProgressBar, edit=True, step=1)
			
			# Re-order object data: mainFaces -> filletFaces -> bevelFaces
			for i, d in enumerate([NT_mainDict, NT_filletDict, NT_bevelDict]):
				if obj in d:
					faces = d[obj]
					objectFaces[list(objectFaces.keys())[i]] = d[obj]
					
					for face in cmds.ls(faces, long=True, flatten=True):
						# Get face id
						faceId = int(re.findall(r"[\w]+", face)[-1])

						# Get face vertex count
						faceVertexCount = objectData["polygonCounts"][faceId]
						
						# Get face vertex ids
						connectStart = sum(objectData["polygonCounts"][:faceId])
						connectEnd = connectStart + faceVertexCount
						#faceVertexIds = objectData["polygonConnects"][connectStart:connectEnd]
						faceVertexIds[faceId] = objectData["polygonConnects"][connectStart:connectEnd]

						# Get edge smoothings
						faceIter.setIndex(faceId)
						edgeIds = faceIter.getEdges()
						edgesConnects.update([(edgeId, objectData["edgeSmoothings"][edgeId]["isSmooth"]) for edgeId in edgeIds])

						# Get face vertex normals
						normalsCount = objectData["normalCounts"][faceId]
						connectStart = sum(objectData["normalCounts"][:faceId])
						connectEnd = connectStart + normalsCount
						normalsIdsDict[faceId] = objectData["polygonNormalsIds"][connectStart:connectEnd]

						# Get face vertex positions
						faceVertexPos = {x: objectData["vertices"][x] for x in faceVertexIds[faceId] if x not in vertexPosDict}
						#faceVertexNormals = {x: objectData["normals"][x] for x in normalsIdsDict[faceId] if x not in normalsValueDict}

						# Append face data to lists
						vertexPosDict.update(faceVertexPos)
						polygonCounts.append(faceVertexCount)
						polygonConnects.extend(faceVertexIds[faceId])
						#normalsValueDict.update(faceVertexNormals)
						#normalIds.extend(normalsIdsDict[faceId])
					
				cmds.progressBar(gMainProgressBar, edit=True, step=1)

			# Create vertex position list ordered by vertex id
			vertices = [vertexPosDict[x] for x in sorted(vertexPosDict)]
			#normals = [normalsValueDict[x] for x in sorted(normalsValueDict)]

			if all([vertices, polygonCounts, polygonConnects]) and any([objectFaces["bevelFaces"], objectFaces["filletFaces"]]):
				# Create mesh with re-ordered faces
				#sourceMeshFn = om.MFnMesh()
				#mesh_object = sourceMeshFn.create(vertices, polygonCounts, polygonConnects)
				objectName = next(iter(cmds.createReorderedObject(vertices=vertices, polygonCounts=polygonCounts, polygonConnects=polygonConnects, edgeSmoothings=list(edgesConnects.values())) or []), None)

				# If the object cannot be created, skip
				if not objectName:
					cmds.progressBar(gMainProgressBar, edit=True, step=5)
					cmds.warning("{0} was skipped; could not process normals.".format(obj), noContext=True)
					continue

				# Assign default shading
				#cmds.sets(mesh.name(), edit=True, forceElement="initialShadingGroup")

				# Get objectName
				#dagNode = om.MFnDagNode(mesh_object)
				#sourceDagPath = dagNode.getPath()
				#objectName = sourceDagPath.fullPathName()
				# Set object matrix
				cmds.xform(objectName, matrix=objectData["matrix"], worldSpace=True)

				# Create mainFaces, filletFaces and bevelFaces lists
				#faceCount = sourceMeshFn.numPolygons
				faceCount = cmds.polyEvaluate(objectName, face=True)

				filletCount, bevelCount = 0, 0
				if obj in NT_filletDict:
					#filletCount = len(cmds.ls(NT_filletDict[obj], long=True, flatten=True))
					filletCount = getComponentCount(NT_filletDict[obj])
				
				if obj in NT_bevelDict:
					#bevelCount = len(cmds.ls(NT_bevelDict[obj], long=True, flatten=True))
					bevelCount = getComponentCount(NT_bevelDict[obj])

				mainCount = faceCount - filletCount - bevelCount

				if mainCount > 1:
					mainFaces = "{0}.f[0:{1}]".format(objectName, mainCount-1)
				else:
					mainFaces = "{0}.f[0]".format(objectName)
				
				if filletCount > 1:
					filletFaces = "{0}.f[{1}:{2}]".format(objectName, mainCount, mainCount+filletCount-1)
				elif filletCount > 0:
					filletFaces = "{0}.f[{1}]".format(objectName, mainCount)
				
				if bevelCount > 1:
					bevelFaces = "{0}.f[{1}:{2}]".format(objectName, mainCount+filletCount, mainCount+filletCount+bevelCount-1)
				elif bevelCount > 0:
					bevelFaces = "{0}.f[{1}]".format(objectName, mainCount+filletCount)
			
				# Get soft edges
				objSoftEdges = NT_GetSoftEdges(cmds.polyListComponentConversion(objectName, toEdge=True))

				cmds.progressBar(gMainProgressBar, edit=True, step=1)

				# Set vertex normal method
				if cmds.optionVar(exists="NTPN_OverrideVertexNormalMethod") and cmds.optionVar(query="NTPN_OverrideVertexNormalMethod")[0] == 1:
					cmds.setAttr("{0}.vertexNormalMethod".format(objectName), 0)
				else:
					cmds.setAttr("{0}.vertexNormalMethod".format(objectName), cmds.getAttr("{0}.vertexNormalMethod".format(obj)))

				# Lock bevelFaces and filletFaces perimeter
				borderEdges = cmds.polyListComponentConversion(bevelFaces, toEdge=True, border=True)
				borderEdges.extend(cmds.polyListComponentConversion(filletFaces, toEdge=True, border=True))
				borderVertex = cmds.polyListComponentConversion(borderEdges, toVertex=True)
				if borderEdges:
					cmds.polySoftEdge(borderEdges, angle=0)
				if borderVertex:
					cmds.polyNormalPerVertex(borderVertex, freezeNormal=True)
				if objSoftEdges:
					cmds.polySoftEdge(objSoftEdges, angle=180)
				
				cmds.progressBar(gMainProgressBar, edit=True, step=1)

				#cmds.transferAttributes(objectName, obj, transferNormals=True, sampleSpace=0, searchMethod=3)
				#cmds.delete(obj, constructionHistory=True)
				#cmds.delete(objectName, constructionHistory=True)
				
				# Get vertex normal data
				sourceSelList = om.MSelectionList()
				sourceSelList.add(objectName)
				sourceDagPath = sourceSelList.getDagPath(0)
				sourceMeshFn = om.MFnMesh(sourceDagPath)
				objectNormals = sourceMeshFn.getNormals(om.MSpace.kObject)
				objectNormalCounts, objectNormalsIds = sourceMeshFn.getNormalIds()

				# Index vertex normal values
				objectNormalsDict = OrderedDict()
				for i, normalCount in enumerate(objectNormalCounts):
					connectStart = sum(objectNormalCounts[:i])
					connectEnd = connectStart + normalCount
					normalIds = objectNormalsIds[connectStart:connectEnd]
					normalValues = [objectNormals[x] for x in normalIds]

					objectNormalsDict[i] = {"normalCount": normalCount, "normalIds": normalIds, "normalValues": normalValues}

				# Get re-ordered vertex normals values
				normalsIdsDictSorted = dict(sorted(normalsIdsDict.items()))
				vertexNormals = OrderedDict()
				faceIds = []
				vertexIds = []
				#vertexFaceStrings = []
				for x, fId in enumerate(faceVertexIds.keys()):
					vertexNormals[fId] = objectNormalsDict[x]["normalValues"]
					faceIds.extend([x for i in normalsIdsDictSorted[x]])
					vertexIds.extend(faceVertexIds[x])
					#vertexFaceStrings.extend(["{0}.vtxFace[{1}][{2}]".format(obj, vtx, x) for vtx in faceVertexIds[x]])
				
				vertexNormals = OrderedDict(sorted(vertexNormals.items()))
				vertexNormals = [item for sublist in vertexNormals.values() for item in sublist]

				# Get re-ordered vertex normals ids
				'''normalsIdsDictSorted = dict(sorted(normalsIdsDict.items()))
				faceIds = []
				vertexIds = []
				for fId, nIds in six.iteritems(normalsIdsDictSorted):
					faceIds.extend([fId for x in nIds])
					vertexIds.extend(faceVertexIds[fId])'''
				
				# Delete re-ordered faces object
				cmds.delete(objectName)
				#om.MGlobal.deleteNode(mesh_object)

				cmds.progressBar(gMainProgressBar, edit=True, step=1)

				'''if all([vertexNormals, faceIds, vertexIds]):
					# Transfer vertex normals to original mesh
					targetSelList = om.MSelectionList()
					targetSelList.add(obj)
					targetDagPath = targetSelList.getDagPath(0)
					if targetDagPath.isValid():
						targetMeshFn = om.MFnMesh(targetDagPath)
						targetMeshFn.setFaceVertexNormals(vertexNormals, faceIds, vertexIds, om.MSpace.kObject)
						targetMeshFn.updateSurface()
					
					#cmds.setFaceVertexNormals(obj, vertexNormals=vertexNormals, faceIds=faceIds, vertexIds=vertexIds)'''
				
				# Set only the vertex normals of the selection set borders
				borderEdges = cmds.polyListComponentConversion(objectFaces["bevelFaces"], toEdge=True, border=True)
				borderEdges.extend(cmds.polyListComponentConversion(objectFaces["filletFaces"], toEdge=True, border=True))
				borderVertex = cmds.polyListComponentConversion(borderEdges, toVertex=True)
				borderVertexIds = getComponentIds(borderVertex)

				ignoredFaces = componentListIntersection(hardEdges, cmds.ls(borderEdges, long=True))
				ignoredFaces = componentListIntersection(cmds.ls(cmds.polyListComponentConversion(ignoredFaces, toFace=True), long=True), objectFaces["mainFaces"])
				ignoredFaceIds = getComponentIds(ignoredFaces)

				lockedVertexFace = []
				lockedNormals = []
				for (vertexNormal, vertexId, faceId) in zip(vertexNormals, vertexIds, faceIds):
					if vertexId in borderVertexIds and faceId not in ignoredFaceIds:
						lockedVertexFace.append("{0}.vtxFace[{1}][{2}]".format(obj, vertexId, faceId))
						lockedNormals.append(vertexNormal)

				'''# Set only the vertex normals of the selection set borders
				edgesList = cmds.ls(cmds.polyListComponentConversion(objectFaces["bevelFaces"], objectFaces["filletFaces"], toEdge=True), long=True)
				edgesList = componentListIntersection(edgesList, softEdges)
				vertexFaceList = flattenList(cmds.polyListComponentConversion(edgesList, toVertexFace=True))
				vertexFaceIds = [tuple([int(id) for id in re.findall(r"[\w]+", i)[-2:]]) for i in vertexFaceList]

				borderEdges = cmds.polyListComponentConversion(objectFaces["bevelFaces"], toEdge=True, border=True)
				borderEdges.extend(cmds.polyListComponentConversion(objectFaces["filletFaces"], toEdge=True, border=True))
				borderVertexList = flattenList(cmds.polyListComponentConversion(borderEdges, toVertex=True))
				borderVertexIds = [int(re.findall(r"[\w]+", i)[-1]) for i in borderVertexList]

				lockedVertexFace = []
				lockedNormals = []
				for (vertexNormal, vertexId, faceId) in zip(vertexNormals, vertexIds, faceIds):
					if (vertexId, faceId) in vertexFaceIds and vertexId in borderVertexIds:
						lockedVertexFace.append("{0}.vtxFace[{1}][{2}]".format(obj, vertexId, faceId))
						lockedNormals.append(vertexNormal)'''
				
				cmds.progressBar(gMainProgressBar, edit=True, step=1)

				# Set the vertex normals
				if all([lockedVertexFace, lockedNormals]):
					cmds.polyNormalPerVertex(lockedVertexFace, xyz=lockedNormals)
				
				# Unlock Vertex Normals on hard edge faces
				'''if softEdges:
					vertexFaceList = cmds.ls(cmds.polyListComponentConversion(obj, toVertexFace=True), flatten=True)
					softEdgesVertexFaces = cmds.ls(cmds.polyListComponentConversion(softEdges, toVertexFace=True), flatten=True)
					vertexFaceList = [vtx for vtx in vertexFaceList if vtx not in softEdgesVertexFaces]
					cmds.polyNormalPerVertex(vertexFaceList, unFreezeNormal=True)'''
					
				#vertexFaceList = cmds.ls(cmds.polyListComponentConversion(objectFaces["bevelFaces"], objectFaces["filletFaces"], toVertexFace=True), flatten=True)
				#vertexFaceIds = [tuple([int(id) for id in re.findall(r"[\w]+", i)[-2:]]) for i in vertexFaceList]
			
			else:
				cmds.progressBar(gMainProgressBar, edit=True, step=4)
			
			# Undo split hard edges
			if historyNode:
				cmds.delete(historyNode)
			# Soften edges
			if softEdges and any([objectFaces["bevelFaces"], objectFaces["filletFaces"]]):
				polySoftEdgeNode = next(iter(cmds.polySoftEdge(softEdges, angle=180) or []), None)
			
			# Weighted Hard Edges
			if cmds.optionVar(exists="NTPN_WeightedHardEdgeIntersections") and cmds.optionVar(query="NTPN_WeightedHardEdgeIntersections")[0] == 1:
				if hardEdges and any([objectFaces["bevelFaces"], objectFaces["filletFaces"]]):
					weightedFaces = [item for sublist in [objectFaces["bevelFaces"], objectFaces["filletFaces"]] for item in sublist]
					#internalEdges = cmds.ls(cmds.polyListComponentConversion(weightedFaces, toEdge=True, internal=True), long=True)
					internalEdges = cmds.ls(cmds.polyListComponentConversion(cmds.polyListComponentConversion(weightedFaces, toVertex=True, internal=True), toEdge=True, internal=True), long=True)
					internalEdges = componentListIntersection(hardEdges, internalEdges)
					if internalEdges:
						polyNormalPerVertexNode = NT_WeightedHardEdge(internalEdges)

						# Change nodes connections so the polySoftEdge node is in front of the polyNormalPerVertex node
						if all([polySoftEdgeNode, polyNormalPerVertexNode]):
							pnpv_source = next(iter(cmds.listConnections("{0}.inputPolymesh".format(polySoftEdgeNode), source=True, destination=False, plugs=True) or []), None)
							pse_destination = next(iter(cmds.listConnections("{0}.output".format(polyNormalPerVertexNode), source=False, destination=True, plugs=True) or []), None)
							if all([pnpv_source, pse_destination]):
								cmds.connectAttr(pnpv_source, "{0}.inputPolymesh".format(polyNormalPerVertexNode), force=True)
								cmds.connectAttr("{0}.output".format(polyNormalPerVertexNode), "{0}.inputPolymesh".format(polySoftEdgeNode), force=True)
								cmds.connectAttr("{0}.output".format(polySoftEdgeNode), pse_destination, force=True)
			
			cmds.progressBar(gMainProgressBar, edit=True, step=1)
		
		# Restore selection
		cmds.select(currentSel)

		cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)

		if processedNormals:
			print ("Finished processing normals in {0} seconds.".format(round(time.time()-startTime, 2)))
		else:
			if not selectionSet:
				cmds.warning("No objects could be processed. Verify your Selection Sets.", noContext=True)
			else:
				cmds.warning("No objects could be processed. Verify that your object(s) has soft edges.", noContext=True)	
	else:
		cmds.warning("No objects selected.", noContext=True)

class NT_SmartBevelWin(OptionsWindow):
	def __init__(self, showWindow=True):
		self.windowName = "NT_SmartBevelWin"
		self.pfx = "NTSB_"
		kwargs = {"windowSize": [540, 360], 
		          "windowTitle": "Smart Bevel Options", 
		          "runLabel": "Bevel", 
		          "minWindowSize": 360, 
		          "rowOffset": 143, 
				  "showWindow": showWindow}
		
		super(NT_SmartBevelWin, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		##cmds.evalDeferred("NormalToolkit.NT_SmartBevel()")
		NT_SmartBevel()

	def controlsCallback(self, *args):
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		settings = self.querySettings()
		# Offset As Fraction
		if (settings[self.pfx+"OffsetAsFraction"][0] == 0):
			cmds.rowLayout(self.pfx+"FractionRow", e=True, en=False)
			cmds.rowLayout(self.pfx+"OffsetRow", e=True, en=True)
			cmds.rowLayout(self.pfx+"WorldSpaceRow", e=True, en=True)
		elif (settings[self.pfx+"OffsetAsFraction"][0] == 1):
			cmds.rowLayout(self.pfx+"FractionRow", e=True, en=True)
			cmds.rowLayout(self.pfx+"OffsetRow", e=True, en=False)
			cmds.rowLayout(self.pfx+"WorldSpaceRow", e=True, en=False)
		# Chamfer
		if (settings[self.pfx+"Chamfer"][0] == 0):
			cmds.rowLayout(self.pfx+"DepthRow", e=True, en=False)
		elif (settings[self.pfx+"Chamfer"][0] == 1):
			cmds.rowLayout(self.pfx+"DepthRow", e=True, en=True)
		# Use Normal Toolkit Angle
		if (settings[self.pfx+"NTSmoothingAngle"][0] == 0):
			cmds.rowLayout(self.pfx+"SmoothingAngleRow", e=True, en=True)
		elif (settings[self.pfx+"NTSmoothingAngle"][0] == 1):
			cmds.rowLayout(self.pfx+"SmoothingAngleRow", e=True, en=False)
		# Merge vertices
		if (settings[self.pfx+"MergeVertices"][0] == 0):
			cmds.rowLayout(self.pfx+"MergeTolerenceRow", e=True, en=False)
		elif (settings[self.pfx+"MergeVertices"][0] == 1):
			cmds.rowLayout(self.pfx+"MergeTolerenceRow", e=True, en=True)
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/normaltoolkit-smart-bevel/")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Smart Bevel Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Weighted Normals
		cmds.rowLayout(self.pfx+"WeightedNormalsRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Weighted Normals:")
		cmds.checkBoxGrp(self.pfx+"WeightedNormals", dtg=self.pfx+"WeightedNormals", l="", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		self.separationRow(3, 2, 4)
		# Select Bevel Faces
		cmds.rowLayout(self.pfx+"SelectBevelFacesRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Select Bevel Faces:")
		cmds.checkBoxGrp(self.pfx+"SelectBevelFaces", dtg=self.pfx+"SelectBevelFaces", l="", v1=True, h=18, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Add To Selection Set
		cmds.rowLayout(self.pfx+"AddBevelFacesRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Add To Selection Set:")
		cmds.checkBoxGrp(self.pfx+"AddBevelFaces", dtg=self.pfx+"AddBevelFaces", l="", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# START: Poly Bevel Settings Frame
		cmds.frameLayout(self.pfx+"PolyBevelSettingsFrame", l="Poly Bevel Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"PolyBevelSettingsForm")
		
		# START: Poly Bevel Settings Column #1
		cmds.columnLayout(self.pfx+"PolyBevelSettingsColumn1", adj=True, cat=("left", 0))
		# Fraction
		cmds.rowLayout(self.pfx+"FractionRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Fraction:")
		cmds.floatSliderGrp(self.pfx+"Fraction", dtg=self.pfx+"Fraction", l="", f=True, pre=4, v=0.5, min=0, max=1, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Offset As Fraction
		cmds.rowLayout(self.pfx+"OffsetAsFractionRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"OffsetAsFraction", dtg=self.pfx+"OffsetAsFraction", l="", l1="Offset As Fraction", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Offset
		cmds.rowLayout(self.pfx+"OffsetRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Offset:")
		cmds.floatSliderGrp(self.pfx+"Offset", dtg=self.pfx+"Offset", l="", f=True, pre=4, v=1, min=0, max=10, fmx=1000000, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Offset In World Space
		cmds.rowLayout(self.pfx+"WorldSpaceRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"WorldSpace", dtg=self.pfx+"WorldSpace", l="", l1="Offset In World Space", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		self.separationRow(3, 2, 4)
		# Segments
		cmds.rowLayout(self.pfx+"SegmentsRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Segments:")
		cmds.intSliderGrp(self.pfx+"Segments", dtg=self.pfx+"Segments", l="", f=True, v=1, min=1, max=32, fmx=10000, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Depth
		cmds.rowLayout(self.pfx+"DepthRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Depth:")
		cmds.floatSliderGrp(self.pfx+"Depth", dtg=self.pfx+"Depth", l="", f=True, pre=4, v=1, min=-1, max=1, fmx=100, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Chamfer
		cmds.rowLayout(self.pfx+"ChamferRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"Chamfer", dtg=self.pfx+"Chamfer", l="", l1="Chamfer", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		self.separationRow(3, 2, 4)
		# Mitering
		cmds.rowLayout(self.pfx+"MiteringRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Mitering:")
		cmds.optionMenuGrp(self.pfx+"Mitering", dtg=self.pfx+"Mitering", l="", cw2=(0, 140), cc=(partial(self.controlsCallback)))
		cmds.menuItem(l="Auto")
		cmds.menuItem(l="Uniform")
		cmds.menuItem(l="Patch")
		cmds.menuItem(l="Radial")
		cmds.menuItem(l="None")
		cmds.optionMenuGrp(self.pfx+"Mitering", e=True, v="Uniform")
		cmds.setParent("..")
		# Mitering Along
		cmds.rowLayout(self.pfx+"MiteringAlongRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Mitering Along:")
		cmds.optionMenuGrp(self.pfx+"MiteringAlong", dtg=self.pfx+"MiteringAlong", l="", cw2=(0, 140), cc=(partial(self.controlsCallback)))
		cmds.menuItem(l="Auto")
		cmds.menuItem(l="Center")
		cmds.menuItem(l="Edge")
		cmds.menuItem(l="Hard Edge")
		cmds.optionMenuGrp(self.pfx+"MiteringAlong", e=True, v="Auto")
		cmds.setParent("..")
		# Force Parallel
		cmds.rowLayout(self.pfx+"ForceParallelRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"ForceParallel", dtg=self.pfx+"ForceParallel", l="", l1="Force Parallel", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		self.separationRow(3, 2, 4)
		# Smoothing Angle
		cmds.rowLayout(self.pfx+"SmoothingAngleRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Smoothing Angle:")
		cmds.floatSliderGrp(self.pfx+"SmoothingAngle", dtg=self.pfx+"SmoothingAngle", l="", f=True, pre=4, v=180, min=0, max=180, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Use Normal Toolkit Angle
		cmds.rowLayout(self.pfx+"NTSmoothingAngleRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"NTSmoothingAngle", dtg=self.pfx+"NTSmoothingAngle", l="", l1="Use Normal Toolkit Angle", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# END: Poly Bevel Settings Column #1
		cmds.setParent("..")
		
		# END: Poly Bevel Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# START: Cleanup Frame
		cmds.frameLayout(self.pfx+"CleanupFrame", l="Cleanup Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"CleanupForm")
		
		# START: Cleanup Column #1
		cmds.columnLayout(self.pfx+"CleanupColumn1", adj=True, cat=("left", 0))
		# Merge Tolerence
		cmds.rowLayout(self.pfx+"MergeTolerenceRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Merge Tolerence:")
		cmds.floatSliderGrp(self.pfx+"MergeTolerence", dtg=self.pfx+"MergeTolerence", l="", f=True, pre=4, v=0, min=0, max=1, fmx=100000, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Merge Vertices
		cmds.rowLayout(self.pfx+"MergeVerticesRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"MergeVertices", dtg=self.pfx+"MergeVertices", l="", l1="Merge Vertices", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		self.separationRow(3, 2, 4)
		# Angle Tolerence
		cmds.rowLayout(self.pfx+"AngleTolerenceRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Angle Tolerence:")
		cmds.floatSliderGrp(self.pfx+"AngleTolerence", dtg=self.pfx+"AngleTolerence", l="", f=True, pre=4, v=180, min=0, max=180, fmx=10000, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Subdivide Ngons
		cmds.rowLayout(self.pfx+"SubdivideNgonsRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Subdivide Ngons:")
		cmds.checkBoxGrp(self.pfx+"SubdivideNgons", dtg=self.pfx+"SubdivideNgons", l="", v1=True, h=18, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Cleanup Column #1
		cmds.setParent("..")
		
		# END: Cleanup Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		cmds.formLayout(self.scrollForm, e=True,
						ac=(self.pfx+"PolyBevelSettingsFrame", "top", 0, self.pfx+"SettingsFrame"),
						af=[(self.pfx+"PolyBevelSettingsFrame", "left", 0), (self.pfx+"PolyBevelSettingsFrame", "right", 0)],
						an=(self.pfx+"PolyBevelSettingsFrame", "bottom"))
		cmds.formLayout(self.scrollForm, e=True,
						ac=(self.pfx+"CleanupFrame", "top", 0, self.pfx+"PolyBevelSettingsFrame"),
						af=[(self.pfx+"CleanupFrame", "left", 0), (self.pfx+"CleanupFrame", "right", 0)],
						an=(self.pfx+"CleanupFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		cmds.formLayout(self.pfx+"PolyBevelSettingsForm", e=True,
						af=[(self.pfx+"PolyBevelSettingsColumn1", "top", 0), (self.pfx+"PolyBevelSettingsColumn1", "left", 0), (self.pfx+"PolyBevelSettingsColumn1", "right", 0)],
						an=(self.pfx+"PolyBevelSettingsColumn1", "bottom"))
		cmds.formLayout(self.pfx+"CleanupForm", e=True,
						af=[(self.pfx+"CleanupColumn1", "top", 0), (self.pfx+"CleanupColumn1", "left", 0), (self.pfx+"CleanupColumn1", "right", 0)],
						an=(self.pfx+"CleanupColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))

class NT_QuickSelectionWin(OptionsWindow):
	def __init__(self):
		self.windowName = "NT_QuickSelectionWin"
		self.pfx = "NTQS_"
		kwargs = {"windowSize": [440, 170], 
		          "windowTitle": "Triplanar Selection Options", 
		          "runLabel": "Select", 
		          "minWindowSize": 300, 
		          "rowOffset": 143, 
				  "preview": False}
		
		super(NT_QuickSelectionWin, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		mel.eval("NT_QuickSelection()")
	
	def controlsCallback(self, *args):
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		settings = self.querySettings()
		# Use Normal Toolkit Angle
		if (settings[self.pfx+"NTSmoothingAngle"][0] == 0):
			cmds.rowLayout(self.pfx+"AngleTolerenceRow", e=True, en=True)
		elif (settings[self.pfx+"NTSmoothingAngle"][0] == 1):
			cmds.rowLayout(self.pfx+"AngleTolerenceRow", e=True, en=False)
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/normaltoolkit-selection-sets/#triplanar-selection")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Triplanar Selection Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Angle Tolerence
		cmds.rowLayout(self.pfx+"AngleTolerenceRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Angle Tolerence:")
		cmds.floatSliderGrp(self.pfx+"AngleTolerence", dtg=self.pfx+"AngleTolerence", l="", f=True, pre=4, v=5, min=0, max=180, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Use Normal Toolkit Angle
		cmds.rowLayout(self.pfx+"NTSmoothingAngleRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"NTSmoothingAngle", dtg=self.pfx+"NTSmoothingAngle", l="", l1="Use Normal Toolkit Angle", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Set Orientation From Selected Faces
		cmds.rowLayout(self.pfx+"CustomOrientationRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"CustomOrientation", dtg=self.pfx+"CustomOrientation", l="", l1="Set Orientation From Selected Faces", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))

class MayaNode(object):
	def __init__(self, node_name):
		selection = om.MSelectionList()
		self._mobject = om.MObject()
		self._node = om.MFnDependencyNode()
		self._uuid = None
		self._mdagpath = om.MDagPath()
		try:
			selection.add(node_name)
			self._mobject = selection.getDependNode(0)
			self._node = om.MFnDependencyNode(self._mobject)
			self._uuid = self._node.uuid()
			self._mdagpath = selection.getDagPath(0)
		except:
			pass
	
	def __repr__(self):
		return '<{0}("{1}") object at {2}>'.format(self.__class__.__name__, self.name(), hex(id(self)))
	
	def objExists(self, objName):
		try:
			selection = om.MSelectionList()
			selection.add(objName)
			if om.MFnDependencyNode(selection.getDependNode(0)).uuid() == self._uuid:
				return True
		except RuntimeError:
			pass
		return False
	
	def name(self, long=False):
		nodeName = None
		
		if not self._mobject.isNull():
			if self._mdagpath.isValid():
				if long:
					nodeName = self._mdagpath.fullPathName()
				else:
					nodeName = self._mdagpath.partialPathName()
			else:
				nodeName = self._node.name()
		
		if nodeName and not self.objExists(nodeName):
			nodeName = None
		
		return nodeName

class MayaNodeThread(Thread):
	def __init__(self, obj=None, func=None):
		Thread.__init__(self)
		
		self._stopThread = False
		self._mayaNode = None
		self._func = None
		self._lastObjectName = None
		
		self.setObject(obj)
		self.setFunc(func)
	
	def stopThread(self):
		self._stopThread = True
	
	def callFunc(self):
		if callable(self._func):
			executeDeferred(self._func)
	
	def setObject(self, obj):
		if obj and cmds.objExists(obj):
			self._mayaNode = MayaNode(obj)
	
	def clearObject(self):
		self._mayaNode = None
		self._lastObjectName = None
		self.callFunc()
	
	def setFunc(self, func):
		if callable(func):
			self._func = func
	
	def clearFunc(self):
		self._func = None
	
	@property
	def mNode(self):
		return self._mayaNode
	
	def run(self):
		while True:
			if self._stopThread:
				break
			
			if self.mNode:
			
				objName = self.mNode.name()
				if not objName:
					self.clearObject()
				
				if objName != self._lastObjectName:
					self._lastObjectName = objName
					self.callFunc()
			
			time.sleep(0.05)

class NT_TransferNormalsWin(OptionsWindow):
	def __init__(self):
		self.windowName = "NT_TransferNormalsWin"
		self.pfx = "NTTN_"
		kwargs = {"windowSize": [380, 200], 
		          "windowTitle": "Transfer Normals", 
		          "runLabel": "Transfer Normals", 
		          "minWindowSize": 300, 
		          "rowOffset": 90, 
				  "preview": False}
		
		# Create textField thread
		self.objThread = MayaNodeThread()
		self.objThread.daemon = True
		
		global sourceHistoryScriptJob
		if "sourceHistoryScriptJob" in globals() and cmds.scriptJob(exists=sourceHistoryScriptJob) is True:
			cmds.scriptJob(k=sourceHistoryScriptJob, force=True)
		sourceHistoryScriptJob = cmds.scriptJob(event=("SceneOpened", partial(self.resetSourceHistory)), protected=True)
		
		global sourceHistory
		if "sourceHistory" not in globals():
			sourceHistory = []
		
		super(NT_TransferNormalsWin, self).__init__(self.windowName, **kwargs)
	
	def resetSourceHistory(self):
		global sourceHistory
		sourceHistory = []
	
	def updateSource(self):
		if self.objThread and isinstance(self.objThread, Thread) and self.objThread.is_alive():
			if self.objThread.mNode:
				obj = self.objThread.mNode.name()
				
				if obj:
					cmds.textField(self.pfx+"SourceObjectField", edit=True, text=obj, backgroundColor=(0.32, 0.52, 0.65))
					return
		
		cmds.textField(self.pfx+"SourceObjectField", edit=True, text="No object picked", backgroundColor=(0.25, 0.25, 0.25))
	
	def getSource(self):
		obj = None
		
		if self.objThread and isinstance(self.objThread, Thread) and self.objThread.is_alive():
			if self.objThread.mNode:
				obj = self.objThread.mNode.name()
		
		return obj
	
	def setSource(self, object=None, *args):
		objects = NT_GetCurrentSel(object)[1]
		if len(objects) > 0:
			self.objThread.setObject(objects[0])
			
			if not self.objThread.is_alive():
				self.objThread.setFunc(self.updateSource)
				self.objThread.start()
			
			global sourceHistory
			if "sourceHistory" in globals():
				obj = self.objThread.mNode
				objName = obj.name()
				if objName and objName not in [x.name() for x in sourceHistory if x.name()]:
					sourceHistory.append(obj)
	
	def clearSource(self):
		if self.objThread and isinstance(self.objThread, Thread) and self.objThread.is_alive():
			self.objThread.clearObject()
	
	def selectSource(self):
		obj = self.getSource()
		
		if obj:
			cmds.select(obj)
	
	def sourceHistoryPopup(self, popupObj, buttonObj):
		# Get previous source objects
		popupItems = []
		global sourceHistory
		if "sourceHistory" in globals():
			popupItems = [x.name() for x in sourceHistory if x.name()]
		
		# Clear popupMenu items
		cmds.popupMenu(popupObj, edit=True, deleteAllItems=True)
		
		# Populate popupMenu
		if len(popupItems) > 0:
			currentObj = self.getSource()
			for obj in reversed(popupItems):
				enableItem = True
				if obj == currentObj:
					enableItem = False
				cmds.menuItem(parent=popupObj, label=obj, command=(partial(self.setSource, obj)), enable=enableItem, enableCommandRepeat=False)
		else:
			cmds.menuItem(parent=popupObj, label="No previous source objects", enable=False, enableCommandRepeat=False)
		
	def closeEvent(self):
		if self.objThread and isinstance(self.objThread, Thread) and self.objThread.is_alive():
			self.objThread.stopThread()
	
	def postInit(self):
		cmds.scriptJob(uiDeleted=(self.windowName, partial(self.closeEvent)), runOnce=True, protected=True)
	
	def runCmd(self, *args):
		obj = self.getSource()
		
		if obj:
			NT_TransferNormals(sourceObj=obj)
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/normaltoolkit-normals/#transfer-normals-tool")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Transfer Normals Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		#cmds.rowLayout(self.pfx+"AngleTolerenceRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.rowLayout(self.pfx+"SourceObjectRow", numberOfColumns=3, columnWidth=(1, self.rowOffset), columnAttach3=("right", "left", "left"), columnOffset3=(0, 0, 0), adjustableColumn=3)
		cmds.text(label="Source Object:")
		cmds.iconTextButton(self.pfx+"SourceObjectButton", width=17, height=26, image="popupMenuIcon.png")
		cmds.textField(self.pfx+"SourceObjectField", editable=False, height=25, drawInactiveFrame=True, text="No object picked")
		cmds.setParent("..")
		cmds.rowLayout(self.pfx+"SourceObjectButtonRow", numberOfColumns=4, columnWidth=(1, self.rowOffset+17), height=28, columnAttach4=("left", "left", "left", "left"), columnOffset4=(0, 3, 1, 1))
		cmds.text(label="")
		cmds.iconTextButton(self.pfx+"SetSourceButton", style="textOnly", label="Set Source", annotation="Set the selected object as Source Object", command=(partial(self.setSource)), flat=False, width=100, height=23)
		cmds.iconTextButton(self.pfx+"ResetSourceButton", style="textOnly", label="Reset", annotation="Reset the Source Object", command=(partial(self.clearSource)), flat=False, width=64, height=23)
		cmds.iconTextButton(self.pfx+"SelectSourceButton", style="textOnly", label="Select", annotation="Select the Source Object", command=(partial(self.selectSource)), flat=False, width=64, height=23)
		cmds.setParent("..")
		cmds.rowLayout(self.pfx+"SearchMethodRow", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"))
		cmds.text(label="Search Method:")
		cmds.radioButtonGrp(self.pfx+"SearchMethod", docTag=self.pfx+"SearchMethod", numberOfRadioButtons=2, columnWidth3=(0, 140, 110), label="", labelArray2=("Closest along normals", "Closest to point"), onCommand=(partial(self.controlsCallback)), select=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=100)
		cmds.iconTextButton(self.pfx+"applyButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 4), (self.pfx+"SettingsColumn1", "left", 8), (self.pfx+"SettingsColumn1", "right", 8), (self.pfx+"SettingsColumn1", "bottom", 4)])
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 0, 0), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		
		# Create popupMenu
		cmds.popupMenu(button=1, parent=self.pfx+"SourceObjectButton", postMenuCommand=(partial(self.sourceHistoryPopup)))
		cmds.setParent("..")

class NT_ProcessNormalsWin(OptionsWindow):
	def __init__(self, showWindow=True):
		self.windowName = "NT_ProcessNormalsWin"
		self.pfx = "NTPN_"
		kwargs = {"windowSize": [250, 170], 
		          "windowTitle": "Process Normals Options", 
		          "runLabel": "Process Normals", 
		          "minWindowSize": 225, 
		          "rowOffset": 5, 
				  "preview": False, 
				  "showWindow": showWindow, 
				  "parentWindow": "NormalToolkitWin"}
		
		super(NT_ProcessNormalsWin, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		mel.eval("VNTF_processNormals(0)")

	def createUI(self):
		self.windowForm = self.pfx+"WindowForm"
		self.scrollLayout = self.pfx+"ScrollLayout"
		self.scrollForm = self.pfx+"ScrollForm"

		# If window already opened, delete it
		if cmds.window(self.windowName, exists=True):
			if not self.showWindow:
				return
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True, parent=self.parentWindow)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/normaltoolkit-process-normals/#process-normals-options")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Process Normals Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Use Improved Process
		cmds.rowLayout(self.pfx+"UseImprovedProcess_Row", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"UseImprovedProcess", dtg=self.pfx+"UseImprovedProcess", l="", l1="Use Improved Process", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Override Vertex Normal Method
		cmds.rowLayout(self.pfx+"OverrideVertexNormalMethod_Row", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"OverrideVertexNormalMethod", dtg=self.pfx+"OverrideVertexNormalMethod", l="", l1="Override Vertex Normal Method", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Weighted Hard Edge Intersections
		cmds.rowLayout(self.pfx+"WeightedHardEdgeIntersections_Row", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"WeightedHardEdgeIntersections", dtg=self.pfx+"WeightedHardEdgeIntersections", l="", l1="Weighted Hard Edge Intersections", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=100)
		#cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 0, 0), (self.pfx+"applyButton", "right", 2, 50)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 50), (self.pfx+"closeButton", "right", 0, 100)],
						an=(self.pfx+"closeButton", "bottom"))