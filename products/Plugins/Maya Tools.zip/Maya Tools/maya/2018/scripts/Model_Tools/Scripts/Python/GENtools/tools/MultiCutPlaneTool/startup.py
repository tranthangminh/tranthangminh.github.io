#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Multi Cut Plane Tool")
		self.scriptLoader.setStartupFile("MultiCutPlaneTool.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Mesh Tools")
		self.scriptLoader.setMenuItemDict({"image": "polyCut.png", "subMenu": True, "tearOff": True})
		self.scriptLoader.setMenuItemFunc(self.createMenuItem)
		return self.scriptLoader
	
	def createMenuItem(self):
		cmds.menuItem(divider=True, dividerLabel="Axis")
		cmds.menuItem(label="X", image="polyCut.png", sourceType="mel", command="CutAlongX")
		cmds.menuItem(label="Y", image="polyCut.png", sourceType="mel", command="CutAlongY")
		cmds.menuItem(label="Z", image="polyCut.png", sourceType="mel", command="CutAlongZ")