#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import maya.mel as mel

# for python 3 compatibility
import six

ROOT_FILE = __file__
ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
ROOT_DIR = ROOT_DIR_RAW
if not isinstance(ROOT_FILE, six.text_type):
	try:
		ROOT_FILE = ROOT_FILE.decode(sys.getfilesystemencoding())
		ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
		ROOT_DIR = ROOT_DIR_RAW.encode(sys.getfilesystemencoding())
	except:
		pass

def getParentDir(dir):
    try:
        return os.path.abspath(os.path.join(dir, os.pardir))
    except:
        return dir

GENtools_Domain = "https://gentools.etiennenadeau.com"
GENtools_Root = getParentDir(getParentDir(ROOT_DIR))