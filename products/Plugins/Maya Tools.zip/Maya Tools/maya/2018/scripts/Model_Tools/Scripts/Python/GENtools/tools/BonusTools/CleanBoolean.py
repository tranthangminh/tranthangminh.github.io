#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds

from ...core.general.panels import getOutlinerList

def getShortName(objectSel):
	return objectSel.split("|")[-1]

def CleanBoolean(objectSel=None, operation=1):
	"""
	Creates a new poly as the result of a boolean operation on input polys
	If no objects are specified in the command line, then the objects from the active list are used.
	
	:param objectSel: objects to use for the boolean operation
	:param operation: 1=union, 2=difference, 3=intersection
	:return: returns the object name
	"""
	
	if objectSel is not None:
		currentSel = cmds.ls(objectSel, l=True, typ="transform")
	else:
		currentSel = cmds.ls(sl=True, l=True, typ="transform")
	
	if len(cmds.ls(currentSel, l=True, dag=True, ni=True, o=True, typ="mesh")) < 2:
		return None
	
	# Fix objects that turns green when undoing
	cmds.ogs(reset=True)
	
	objectName = getShortName(currentSel[0])
	objectParent = cmds.listRelatives(currentSel[0], f=True, p=True)
	originalOutlinerList = getOutlinerList(currentSel[0])

	try:
		combinedObject = cmds.polyCBoolOp(*currentSel, operation=operation)
	except:
		combinedObject = ""
	if combinedObject:
		# Match transforms
		cmds.parent(combinedObject[0], currentSel[0])
		cmds.makeIdentity(combinedObject[0], a=True, t=True, r=True, s=True, n=False, pn=True)
		# Match pivot
		cmds.matchTransform(combinedObject[0], currentSel[0], piv=True)
		# Re-parent object
		if objectParent is not None:
			cmds.parent(combinedObject[0], objectParent[0])
		else:
			cmds.parent(combinedObject[0], w=True)
		# Delete history
		cmds.delete(combinedObject[0], ch=True)
		# Clean empty groups
		transforms = cmds.ls(currentSel, l=True, typ="transform")
		transformsDesc = cmds.listRelatives(transforms, f=True, ad=True, typ="transform")
		if transformsDesc is not None:
			transforms.extend(transformsDesc)
		if transforms is not None:
			counter = 0
			for transform in transforms:
				if cmds.objExists(transform) is True:
					childrens = cmds.listRelatives(transform, f=True, c=True)
					if childrens is not None:
						if len(cmds.ls(childrens, ni=True, l=True)) <= 0 and cmds.listHistory(childrens, pdo=True) is None:
							childrens = None
					if childrens is None:
						parent = cmds.listRelatives(transform, f=True, p=True, ni=True)
						if parent is not None:
							transforms.extend(parent)
						cmds.delete(transform)
						counter += 1
		combinedObject = cmds.rename(combinedObject[0], objectName)
	
		# Reorder object in outliner
		originalPosition = 0
		originalOutlinerList = list(filter(cmds.objExists, originalOutlinerList))
		if currentSel[0] in originalOutlinerList:
			originalPosition = originalOutlinerList.index(currentSel[0])
		
		currentPosition = 0
		currentOutlinerList = getOutlinerList(currentSel[0])
		if currentSel[0] in currentOutlinerList:
			currentPosition = currentOutlinerList.index(currentSel[0])

		reorderPosition = originalPosition - currentPosition
		if reorderPosition != 0:
			cmds.reorder(currentSel[0], relative=reorderPosition)

	return combinedObject