#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as OpenMaya
from maya.OpenMayaUI import MQtUtil
from maya.api.OpenMaya import MMatrix, MVector
from collections import OrderedDict, Callable
from functools import partial
from webbrowser import open_new_tab
try:
	from PySide2.QtCore import *
	from PySide2.QtGui import *
	from PySide2.QtWidgets import *
	from shiboken2 import wrapInstance
except ImportError:
	from PySide.QtCore import *
	from PySide.QtGui import *
	from shiboken import wrapInstance

# for python 3 compatibility
import six
from six.moves import zip
try:
	from past.builtins import long
except:
	pass

from ...core.gui.options import helpCmd

CREATE_SETTINGS = 0
SAVE_SETTINGS = 1
RESET_SETTINGS = 2

class DefaultOrderedDict(OrderedDict):
	def __init__(self, default_factory=None, *a, **kw):
		if (default_factory is not None and not isinstance(default_factory, Callable)):
			raise TypeError("first argument must be callable")
		OrderedDict.__init__(self, *a, **kw)
		self.default_factory = default_factory

	def __getitem__(self, key):
		try:
			return OrderedDict.__getitem__(self, key)
		except KeyError:
			return self.__missing__(key)

	def __missing__(self, key):
		if self.default_factory is None:
			raise KeyError(key)
		self[key] = value = self.default_factory()
		return value

	def __reduce__(self):
		if self.default_factory is None:
			args = tuple()
		else:
			args = self.default_factory,
		return type(self), args, None, None, list(self.items())

	def copy(self):
		return self.__copy__()

	def __copy__(self):
		return type(self)(self.default_factory, self)

	def __deepcopy__(self, memo):
		import copy
		return type(self)(self.default_factory, copy.deepcopy(list(self.items())))

	def __repr__(self):
		return "OrderedDefaultDict(%s, %s)" % (self.default_factory, OrderedDict.__repr__(self))

def MAM_GetComponentType(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	selList = OpenMaya.MSelectionList()
	
	if selection is not None:
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
	else:
		OpenMaya.MGlobal_getActiveSelectionList(selList)
	
	filterDict = []
	filterDict.append(("v", OpenMaya.MFn.kMeshVertComponent))
	filterDict.append(("eg", OpenMaya.MFn.kMeshEdgeComponent))
	filterDict.append(("fc", OpenMaya.MFn.kMeshPolygonComponent))
	filterDict.append(("puv", OpenMaya.MFn.kMeshMapComponent))
	filterDict.append(("pvf", OpenMaya.MFn.kMeshVtxFaceComponent))
	filterDict = OrderedDict(filterDict)
	
	for key, filter in six.iteritems(filterDict):
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		try:
			if sel_iter.hasComponents():
				return key
		except:
			pass
	
	return None

def MAM_GetShortName(objectSel):
	dagPath = []
	shortName = objectSel
	dagPath = shortName.split("|")
	if(len(dagPath)>0):
		shortName = dagPath[len(dagPath)-1]
	return shortName

def MAM_ObjectSelDictionary(selection=None):
	# Create empty dictionary
	if(selection is None):
		selection = cmds.polyListComponentConversion(tf=True)
	#objectSelDict = defaultdict(list)
	objectSelDict = DefaultOrderedDict(list)
	objectList = []
	faceSelList = []
	
	if(selection is not None):
		selList = OpenMaya.MSelectionList()
		for each in selection:
			selList.add(each)

		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		compList = OpenMaya.MSelectionList()
		
		sel_iter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMeshPolygonComponent)
		#objectSelDict = {}
		while not sel_iter.isDone():
			sel_iter.getDagPath(dagPath, component)
			dagPath.pop()
			node = dagPath.fullPathName()
			
			# Add current components to selectionList
			compList.clear()
			compList.add(dagPath, component)
			
			# Get selection strings
			objComponents = []
			compList.getSelectionStrings(objComponents)
			# Return full path strings
			objComponents = cmds.ls(objComponents, l=True)
			
			# Add to dictionary
			objectSelDict[node].extend(objComponents)
			objectList.append(node)
			faceSelList.extend(objComponents)
			
			sel_iter.next()
	
	return objectSelDict, objectList, faceSelList

def GetManipPosition(defaultPosition=None, forceManip=False):
	# Force current tool to Move tool
	if forceManip:
		currentTool = cmds.currentCtx()
		cmds.setToolTo("moveSuperContext")
	
	context = cmds.currentCtx()
	context_pos = defaultPosition
	
	if cmds.superCtx(context, exists=True):
		context_name = cmds.superCtx(context, query=True)
		
		# When the mouse is in UV Editor, we need to get the viewport context instead
		if context_name == "texMoveContext":
			context_name = "Move"
		elif context_name == "texRotateContext":
			context_name = "Rotate"
		elif context_name == "texScaleContext":
			context_name = "Scale"
		
		context_type = cmds.contextInfo(context, query=True, c=True)
		
		if context_type in ("manipMove", "texMove") and cmds.manipMoveContext(context_name, query=True, manipVisible=True):
			context_pos = cmds.manipMoveContext(context_name, query=True, position=True)
		elif context_type in ("manipRotate", "texRotate") and cmds.manipRotateContext(context_name, query=True, manipVisible=True):
			context_pos = cmds.manipRotateContext(context_name, query=True, position=True)
		elif context_type in ("manipScale", "texScale") and cmds.manipScaleContext(context_name, query=True, manipVisible=True):
			context_pos = cmds.manipScaleContext(context_name, query=True, position=True)
	
	# Restore tool
	if forceManip:
		# evalDeferred needed to avoid random crash
		cmds.evalDeferred('import maya.cmds as cmds;cmds.setToolTo("{0}")'.format(currentTool))
	
	return context_pos

def GetHardEdges(*args, **kwargs):
	# Create default args
	selection = None
	hardEdges = []
	hardEdgesList = OpenMaya.MSelectionList()
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(te=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for edge in selection:
			selList.add(edge)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		
		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshEdgeComponent):
				dagPath.pop() # Remove shape
				edge_itr = OpenMaya.MItMeshEdge(dagPath, component)
				while not edge_itr.isDone():
					edgeId = edge_itr.index()
					smoothEdge = edge_itr.isSmooth()
					node = dagPath.fullPathName()
					
					if smoothEdge is False:
						hardEdgesList.add(dagPath, edge_itr.currentItem())
					
					edge_itr.next()
			
			iterIndex += 1
			sel_iter.next()
		
		# Create new list and merge elements (unflatten list)
		mergedList = OpenMaya.MSelectionList()
		if hardEdgesList.isEmpty() is False:
			mergedList.merge(hardEdgesList, OpenMaya.MSelectionList.kMergeNormal)
		
		mergedList.getSelectionStrings(hardEdges)
		# Return full path strings
		hardEdges = cmds.ls(hardEdges, l=True)
	return hardEdges

def GetFacesNormals(*args):
	faces = None
	if len(args) > 0:
		faces = args[0]
	if faces is None:
		faces = cmds.filterExpand(ex=False, fp=True, sm=34)
	facesNormal = []
	
	if faces is not None:
		faceList = OpenMaya.MSelectionList()
		for face in faces:
			faceList.add(face)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		
		sel_iter = OpenMaya.MItSelectionList(faceList)
		iterIndex = 0
		
		while not sel_iter.isDone():
			faceList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshPolygonComponent):
				face_itr = OpenMaya.MItMeshPolygon(dagPath, component)
				while not face_itr.isDone():
					faceNormal = OpenMaya.MVector()
					face_itr.getNormal(faceNormal)
					faceNormal.normalize()
					
					if faceNormal is not None:
						facesNormal.append([faceNormal.x, faceNormal.y, faceNormal.z])
					
					face_itr.next()
			
			iterIndex += 1
			sel_iter.next()
	
	return facesNormal

def CenterWindow(windowName):
    if cmds.window(windowName, ex=True) is True:
        gMainWindow = mel.eval("$gMainWindow = $gMainWindow")
        gMainWindowWidth = (cmds.window(gMainWindow, q=True, w=True)/2)
        gMainWindowHeight = (cmds.window(gMainWindow, q=True, h=True)/2)
        leftPosition = gMainWindowWidth-(cmds.window(windowName, q=True, w=True)/2)
        topPosition = gMainWindowHeight-(cmds.window(windowName, q=True, h=True)/2)
        cmds.window(windowName, e=True, le=leftPosition, te=topPosition)
        return [topPosition, leftPosition]

def ProgressBarWindow(**kwargs):
	title = "Progress Window"
	width = 300
	maxValue = 100
	centered = True
	for key, value in six.iteritems(kwargs):
		if key == "name" or key == "n":
			name = value
		elif key == "title" or key == "t":
			title = value
		elif key == "width" or key == "w":
			width = value
		elif key == "maxValue" or key == "max":
			maxValue = value
		elif key == "centered" or key == "c":
			centered = value
	
	if "name" in locals():
		if(cmds.window(name, ex=True) is True):
			cmds.deleteUI(name, wnd=True)
		progressWin = cmds.window(name, t=title, s=False, mxb=False, tlb=True)
	else:
		progressWin = cmds.window(t=title, s=False, mxb=False, tlb=True)
	cmds.columnLayout(adj=True)
	progressBarName = cmds.progressBar(max=maxValue, w=width)
	cmds.showWindow(progressWin)
	if centered is True:
		CenterWindow(progressWin)
	
	return progressWin, progressBarName

def GetShells(obj, sel):
	result = []
	shellIds = cmds.polyEvaluate(sel, usi=True)
	shellIds = list(set(shellIds))
	for shell in shellIds:
		uvsInShell = cmds.polyEvaluate(obj, uis=shell)
		result.append(uvsInShell)
	return result

def DisconnectAllAttributes(node, source=True, destination=True):
	connectionPairs = []
	if source is True:
		connections = cmds.listConnections(node, p=True, c=True, d=False, s=True)
		if connections is not None:
			connectionPairs.extend(list(zip(connections[1::2], connections[::2])))
	if destination is True:
		connections = cmds.listConnections(node, p=True, c=True, d=True, s=False)
		if connections is not None:
			connectionPairs.extend(list(zip(connections[::2], connections[1::2])))
	for srcAttr, destAttr in connectionPairs:
		try:
			cmds.disconnectAttr(srcAttr, destAttr)
		except:
			pass

def ListRemoveDuplicates(l):
    s = set(); n = 0
    for x in l:
        if x not in s: s.add(x); l[n] = x; n += 1
    del l[n:]

def ResetPolySelectConstraint():
	if (cmds.optionVar(ex="polySelectConstraintState") is True):
		cmds.optionVar(sv=("polySelectConstraintState", ""))
	cmds.polySelectConstraint(disable=True)

def MAMAO_saveSettings(save, *args):
	controlsList = [("MAMAO_DeleteHistory", True), 
					("MAMAO_SuspendRefresh", True), 
					("MAMAO_HideUVEditor", False), 
					("MAMAO_TurnOffUndo", False), 
					("MAMAO_WindowTransparency", False), 
					("MAMAO_SaveWindowSize", True), 
					("MAMAO_ParentUVEditor", True)]
	for ctl in controlsList:
		if (cmds.optionVar(ex=ctl[0]) is False or save == RESET_SETTINGS):
			cmds.optionVar(iv=(ctl[0], ctl[1]))
	# Save
	if (save == SAVE_SETTINGS):
		for ctl in controlsList:
			if (cmds.checkBoxGrp(ctl[0], q=True, ex=True) is True):
				controlValue = cmds.checkBoxGrp(ctl[0], q=True, v1=True)
				cmds.optionVar(iv=(ctl[0], controlValue))

def MAMAO_querySettings():
	# Create non-existing optionVar
	MAMAO_saveSettings(CREATE_SETTINGS)
	# Delete object(s) history
	MAMAO_DeleteHistory = cmds.optionVar(q="MAMAO_DeleteHistory")
	# Suspend viewport refresh
	MAMAO_SuspendRefresh = cmds.optionVar(q="MAMAO_SuspendRefresh")
	# Hide UV Editor
	MAMAO_HideUVEditor = cmds.optionVar(q="MAMAO_HideUVEditor")
	# Turn off undo
	MAMAO_TurnOffUndo = cmds.optionVar(q="MAMAO_TurnOffUndo")
	# Window transparency
	MAMAO_WindowTransparency = cmds.optionVar(q="MAMAO_WindowTransparency")
	# Save window size
	MAMAO_SaveWindowSize = cmds.optionVar(q="MAMAO_SaveWindowSize")
	# Parent to UV Editor
	MAMAO_ParentUVEditor = cmds.optionVar(q="MAMAO_ParentUVEditor")
	# Return string array
	return {"MAMAO_DeleteHistory": MAMAO_DeleteHistory, "MAMAO_SuspendRefresh": MAMAO_SuspendRefresh, "MAMAO_HideUVEditor": MAMAO_HideUVEditor, "MAMAO_TurnOffUndo": MAMAO_TurnOffUndo, "MAMAO_WindowTransparency": MAMAO_WindowTransparency, "MAMAO_SaveWindowSize": MAMAO_SaveWindowSize, "MAMAO_ParentUVEditor": MAMAO_ParentUVEditor}

def MAM_saveSettings(save, *args):
	# Projection type
	if (cmds.optionVar(ex="MAM_ProjectionType") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_ProjectionType", 3))
	# Multiple objects
	if (cmds.optionVar(ex="MAM_MultipleObjects") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_MultipleObjects", 1))
	# Front axis
	if (cmds.optionVar(ex="MAM_FrontAxis") is False or save == RESET_SETTINGS):
		cmds.optionVar(sv=("MAM_FrontAxis", "Y"))
	# Projection width
	if (cmds.optionVar(ex="MAM_ProjectionWidth") is False or save == RESET_SETTINGS):
		cmds.optionVar(fv=("MAM_ProjectionWidth", 800))
	# Projection height
	if (cmds.optionVar(ex="MAM_ProjectionHeight") is False or save == RESET_SETTINGS):
		cmds.optionVar(fv=("MAM_ProjectionHeight", 800))
	# Reset rotations
	if (cmds.optionVar(ex="MAM_ResetRotations") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_ResetRotations", True))
	# Projection order
	if (cmds.optionVar(ex="MAM_ProjectionOrder") is False or save == RESET_SETTINGS):
		cmds.optionVar(sv=("MAM_ProjectionOrder", "X Y Z"))
	# Angle threshold
	if (cmds.optionVar(ex="MAM_ProjectionAngle") is False or save == RESET_SETTINGS):
		cmds.optionVar(fv=("MAM_ProjectionAngle", 80))
	# Cleanup UVs
	if (cmds.optionVar(ex="MAM_CleanupUVs") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_CleanupUVs", True))
	# Cut hard edges
	if (cmds.optionVar(ex="MAM_CutHardEdges") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_CutHardEdges", False))
	# Flip reversed
	if (cmds.optionVar(ex="MAM_FlipReversed") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_FlipReversed", True))
	# Layout UVs
	if (cmds.optionVar(ex="MAM_LayoutUVs") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_LayoutUVs", False))
	# Packing resolution
	if (cmds.optionVar(ex="MAM_PackingResolution") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_PackingResolution", 512))
	# Packing iterations
	if (cmds.optionVar(ex="MAM_PackingIterations") is False or save == RESET_SETTINGS):
		cmds.optionVar(iv=("MAM_PackingIterations", 1))
	# Texture map size
	if (cmds.optionVar(ex="MAM_TextureMapSize") is False or save == RESET_SETTINGS):
		cmds.optionVar(sv=("MAM_TextureMapSize", "512"))
	# Shell padding
	if (cmds.optionVar(ex="MAM_ShellPadding") is False or save == RESET_SETTINGS):
		cmds.optionVar(fv=("MAM_ShellPadding", 3))
	# Scale mode
	if (cmds.optionVar(ex="MAM_ScaleMode") is False or save == RESET_SETTINGS):
		cmds.optionVar(sv=("MAM_ScaleMode", "Uniform"))
	# Save
	if (save == SAVE_SETTINGS):			
		# Projection type
		if (cmds.radioButtonGrp("MAM_ProjectionType", q=True, ex=True) is True):
			controlValue = cmds.radioButtonGrp("MAM_ProjectionType", q=True, sl=True)
			cmds.optionVar(iv=("MAM_ProjectionType", controlValue))
		# Multiple objects
		if (cmds.radioButtonGrp("MAM_MultipleObjects", q=True, ex=True) is True):
			controlValue = cmds.radioButtonGrp("MAM_MultipleObjects", q=True, sl=True)
			cmds.optionVar(iv=("MAM_MultipleObjects", controlValue))
		# Front axis
		if (cmds.optionMenuGrp("MAM_FrontAxis", q=True, ex=True) is True):
			controlValue = cmds.optionMenuGrp("MAM_FrontAxis", q=True, v=True)
			cmds.optionVar(sv=("MAM_FrontAxis", controlValue))
		# Projection width
		if (cmds.floatFieldGrp("MAM_ProjectionWidth", q=True, ex=True) is True):
			controlValue = cmds.floatFieldGrp("MAM_ProjectionWidth", q=True, v1=True)
			cmds.optionVar(fv=("MAM_ProjectionWidth", controlValue))
		# Projection height
		if (cmds.floatFieldGrp("MAM_ProjectionHeight", q=True, ex=True) is True):
			controlValue = cmds.floatFieldGrp("MAM_ProjectionHeight", q=True, v1=True)
			cmds.optionVar(fv=("MAM_ProjectionHeight", controlValue))
		# Reset rotations
		if (cmds.checkBoxGrp("MAM_ResetRotations", q=True, ex=True) is True):
			controlValue = cmds.checkBoxGrp("MAM_ResetRotations", q=True, v1=True)
			cmds.optionVar(iv=("MAM_ResetRotations", controlValue))
		# Projection order
		if (cmds.optionMenuGrp("MAM_ProjectionOrder", q=True, ex=True) is True):
			controlValue = cmds.optionMenuGrp("MAM_ProjectionOrder", q=True, v=True)
			cmds.optionVar(sv=("MAM_ProjectionOrder", controlValue))
		# Angle threshold
		if (cmds.floatSliderGrp("MAM_ProjectionAngle", q=True, ex=True) is True):
			controlValue = cmds.floatSliderGrp("MAM_ProjectionAngle", q=True, v=True)
			cmds.optionVar(fv=("MAM_ProjectionAngle", controlValue))
		# Cleanup UVs
		if (cmds.checkBoxGrp("MAM_CleanupUVs", q=True, ex=True) is True):
			controlValue = cmds.checkBoxGrp("MAM_CleanupUVs", q=True, v1=True)
			cmds.optionVar(iv=("MAM_CleanupUVs", controlValue))
		# Cut hard edges
		if (cmds.checkBoxGrp("MAM_CutHardEdges", q=True, ex=True) is True):
			controlValue = cmds.checkBoxGrp("MAM_CutHardEdges", q=True, v1=True)
			cmds.optionVar(iv=("MAM_CutHardEdges", controlValue))
		# Flip reversed
		if (cmds.checkBoxGrp("MAM_FlipReversed", q=True, ex=True) is True):
			controlValue = cmds.checkBoxGrp("MAM_FlipReversed", q=True, v1=True)
			cmds.optionVar(iv=("MAM_FlipReversed", controlValue))
		# Layout UVs
		if (cmds.checkBoxGrp("MAM_LayoutUVs", q=True, ex=True) is True):
			controlValue = cmds.checkBoxGrp("MAM_LayoutUVs", q=True, v1=True)
			cmds.optionVar(iv=("MAM_LayoutUVs", controlValue))
		# Packing resolution
		if (cmds.intSliderGrp("MAM_PackingResolution", q=True, ex=True) is True):
			controlValue = cmds.intSliderGrp("MAM_PackingResolution", q=True, v=True)
			cmds.optionVar(iv=("MAM_PackingResolution", controlValue))
		# Packing iterations
		if (cmds.intSliderGrp("MAM_PackingIterations", q=True, ex=True) is True):
			controlValue = cmds.intSliderGrp("MAM_PackingIterations", q=True, v=True)
			cmds.optionVar(iv=("MAM_PackingIterations", controlValue))
		# Texture map size
		if (cmds.optionMenuGrp("MAM_TextureMapSize", q=True, ex=True) is True):
			controlValue = cmds.optionMenuGrp("MAM_TextureMapSize", q=True, v=True)
			cmds.optionVar(sv=("MAM_TextureMapSize", controlValue))
		# Shell padding
		if (cmds.floatFieldGrp("MAM_ShellPadding", q=True, ex=True) is True):
			controlValue = cmds.floatFieldGrp("MAM_ShellPadding", q=True, v1=True)
			cmds.optionVar(fv=("MAM_ShellPadding", controlValue))
		# Scale mode
		if (cmds.optionMenuGrp("MAM_ScaleMode", q=True, ex=True) is True):
			controlValue = cmds.optionMenuGrp("MAM_ScaleMode", q=True, v=True)
			cmds.optionVar(sv=("MAM_ScaleMode", controlValue))

def MAM_querySettings():
	# Create non-existing optionVar
	MAM_saveSettings(CREATE_SETTINGS)
	# Projection type
	MAM_ProjectionType = cmds.optionVar(q="MAM_ProjectionType")
	# Multiple objects
	MAM_MultipleObjects = cmds.optionVar(q="MAM_MultipleObjects")
	# Front axis
	MAM_FrontAxis = cmds.optionVar(q="MAM_FrontAxis")
	# Projection width
	MAM_ProjectionWidth = cmds.optionVar(q="MAM_ProjectionWidth")
	# Projection height
	MAM_ProjectionHeight = cmds.optionVar(q="MAM_ProjectionHeight")
	# Reset rotations
	MAM_ResetRotations = cmds.optionVar(q="MAM_ResetRotations")
	# Projection order
	MAM_ProjectionOrder = cmds.optionVar(q="MAM_ProjectionOrder")
	# Angle threshold
	MAM_ProjectionAngle = cmds.optionVar(q="MAM_ProjectionAngle")
	# Cleanup UVs
	MAM_CleanupUVs = cmds.optionVar(q="MAM_CleanupUVs")
	# Cut hard edges
	MAM_CutHardEdges = cmds.optionVar(q="MAM_CutHardEdges")
	# Flip reversed
	MAM_FlipReversed = cmds.optionVar(q="MAM_FlipReversed")
	# Layout UVs
	MAM_LayoutUVs = cmds.optionVar(q="MAM_LayoutUVs")
	# Packing resolution
	MAM_PackingResolution = cmds.optionVar(q="MAM_PackingResolution")
	# Packing iterations
	MAM_PackingIterations = cmds.optionVar(q="MAM_PackingIterations")
	# Texture map size
	MAM_TextureMapSize = cmds.optionVar(q="MAM_TextureMapSize")
	# Shell padding
	MAM_ShellPadding = cmds.optionVar(q="MAM_ShellPadding")
	# Scale mode
	MAM_ScaleMode = cmds.optionVar(q="MAM_ScaleMode")
	# Return string array
	return {"projectionType": MAM_ProjectionType, "multipleObjects": MAM_MultipleObjects, "frontAxis": MAM_FrontAxis, "projectionWidth": MAM_ProjectionWidth, "projectionHeight": MAM_ProjectionHeight, "resetRotations": MAM_ResetRotations, "projectionOrder": MAM_ProjectionOrder, "projectionAngle": MAM_ProjectionAngle, "cleanupUVs": MAM_CleanupUVs, "cutHardEdges": MAM_CutHardEdges, "flipReversed": MAM_FlipReversed, "layoutUVs": MAM_LayoutUVs, "packingResolution": MAM_PackingResolution, "packingIterations": MAM_PackingIterations, "textureMapSize": MAM_TextureMapSize, "shellPadding": MAM_ShellPadding, "scaleMode": MAM_ScaleMode}

def MAM_AutoProjection(*args, **kwargs):
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	# Projection Settings
	MAM_settings = MAM_querySettings()
	MAMAO_settings = MAMAO_querySettings()
	projectionSel = None
	objectSelDict = None
	displayProgressBar = True
	constructionHistory = 1
	
	# A # Load optionVar
	projectionWidth = MAM_settings["projectionWidth"]
	projectionHeight = MAM_settings["projectionHeight"]
	
	# Advanced settings
	deleteHistory = MAMAO_settings["MAMAO_DeleteHistory"]
	if deleteHistory == 0:
		constructionHistory = 1
	else:
		constructionHistory = 0
	suspendRefresh = MAMAO_settings["MAMAO_SuspendRefresh"]
	hideUVEditor = MAMAO_settings["MAMAO_HideUVEditor"]
	
	# B # Load arguments (override A)
	for i, arg in enumerate(args):
		if i == 0:
			projectionSel = arg
		elif i == 1:
			multipleObjects = arg
		elif i == 2:
			projectionWidth = arg
		elif i == 3:
			projectionHeight = arg
		elif i == 4:
			constructionHistory = arg
		elif i == 5:
			suspendRefresh = arg
		elif i == 6:
			hideUVEditor = arg
	
	# C # Load keyworded arguments (override B)
	for key, value in six.iteritems(kwargs):
		if key == "objectSelDict" or key == "osd":
			objectSelDict = value
		elif key == "selection" or key == "sl":
			projectionSel = value
		elif key == "multipleObjects" or key == "mo":
			multipleObjects = value
		elif key == "projectionWidth" or key == "pw":
			projectionWidth = value
		elif key == "projectionHeight" or key == "ph":
			projectionHeight = value
		elif key == "displayProgressBar" or key == "dpb":
			displayProgressBar = value
		elif key == "constructionHistory" or key == "ch":
			constructionHistory = value
		elif key == "suspendRefresh" or key == "sr":
			suspendRefresh = value
		elif key == "hideUVEditor" or key == "huv":
			hideUVEditor = value
	
	if objectSelDict is None:
		if projectionSel is None:
			projectionSel = cmds.ls(sl=True, l=True)
		# Get selected faces
		projectionSel = cmds.polyListComponentConversion(projectionSel, tf=True)
		# Create objectSel dictionary
		objectSelDict = MAM_ObjectSelDictionary(projectionSel)
		objectSelDict = objectSelDict[0]
	
	if objectSelDict is not None:
		# Progress bar
		if displayProgressBar is True:
			cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="UV Mapping in progress...", max=(len(objectSelDict)))
		
		# Get projection_position
		projection_position = None
		# Projection position is the bounding box center of the selected objects
		if multipleObjects == 2:
			projection_position = [0, 0, 0]
			for obj in objectSelDict:
				objBoundingBox = cmds.objectCenter(obj, gl=True)
				projection_position[0] += objBoundingBox[0]
				projection_position[1] += objBoundingBox[1]
				projection_position[2] += objBoundingBox[2]
			projection_position = [x / len(objectSelDict) for x in projection_position]
		# Projection position is the last selected object pivot
		elif multipleObjects == 3:
			projection_position = cmds.xform(next(reversed(objectSelDict)), query=True, worldSpace=True, rotatePivot=True)
		
		# For each selected object
		for obj, sel in six.iteritems(objectSelDict):
			# Progress bar
			if cmds.progressBar(gMainProgressBar, q=True, ic=True):
				# Script aborpted
				return "Cancelled"
			# Clear selection (increase speed)
			cmds.select(cl=True)
			if len(sel) > 0:
				# Get object scale
				scaleValueX = cmds.getAttr(obj+".scaleX")
				scaleValueY = cmds.getAttr(obj+".scaleY")
				scaleValueZ = cmds.getAttr(obj+".scaleZ")
				# Set Projection Scale values
				scaleX = ((1/scaleValueX)*projectionWidth)
				if (cmds.upAxis(q=True, ax=True) == "y"):
					scaleY = ((1/scaleValueY)*projectionHeight)
					scaleZ = ((1/scaleValueZ)*projectionWidth)
				else:
					scaleY = ((1/scaleValueZ)*projectionHeight)
					scaleZ = ((1/scaleValueY)*projectionWidth)
				
				projection_translation = MVector(0, 0, 0)
				# Get difference between projection position and object pivot
				if multipleObjects in (2, 3):
					pivot_position = cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True)
					projection_translation = MVector(projection_position) - MVector(pivot_position)
				
				# Get object-space pivot position
				pivot_position = cmds.xform(obj, query=True, objectSpace=True, rotatePivot=True)
				projection_translation += MVector(pivot_position)
				
				# Automatic Projection
				cmds.polyAutoProjection(sel, cm=False, l=0, sc=1, o=1, p=6, ws=False, ro=(90, 0, 0), s=(scaleX, scaleY, scaleZ), t=projection_translation)
				
				# Refresh viewport
				if suspendRefresh == 0:
					cmds.refresh(cv=True)
					MAM_UVEditorPanels = cmds.getPanel(sty="polyTexturePlacementPanel")
					cmds.textureWindow(MAM_UVEditorPanels[0], e=True, ref=True)
				
			# Progress bar
			if displayProgressBar is True:
				cmds.progressBar(gMainProgressBar, e=True, s=1, st="UV Mapping in progress...")
		
		return "Finished"
	
def MAM_TriPlanarProjectionProc(osd_obj, osd_sel, multipleObjects, frontAxis, projectionWidth, projectionHeight, resetRotations, projectionOrder, projectionAngle, cleanupUVs=1, customProjectionPos=None, suspendRefresh=1, hideUVEditor=0, constructionHistory=0):
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	# Reset rotations
	if resetRotations == 1:
		# Get object-space rotation
		objectRotations = cmds.xform(osd_obj, q=True, os=True, ro=True)
		# Set world-space rotation to 0
		tmpTransform = cmds.createNode("transform", skipSelect=True)
		cmds.matchTransform(osd_obj, tmpTransform, rotation=True)
		cmds.delete(tmpTransform)
	
	# Create Mesh
	osd_shape = cmds.listRelatives(osd_obj, f=True, ni=True, s=True)
	deformerShape = cmds.polyMapDel(osd_sel[0], ch=True)
	
	# Create polyProjectionNode list
	polyProjectionNodeList = []
	
	# Create projectedList
	projectedList = OpenMaya.MSelectionList()
	# Create intersectList
	intersectList = OpenMaya.MSelectionList()
	for each in osd_sel:
		intersectList.add(each)
	
	# For each projection plane
	for i, projectionPlane in enumerate(projectionOrder):
		# Progress bar
		if cmds.progressBar(gMainProgressBar, q=True, ic=True):
			# Script aborpted
			return "Cancelled"
		
		# Projection settings
		if (projectionPlane == "front"):
			cAxis = [1, 0, 0]
		elif (projectionPlane == "back"):
			cAxis = [-1, 0, 0]
		elif (projectionPlane == "right"):
			cAxis = [0, 1, 0]
		elif (projectionPlane == "left"):
			cAxis = [0, -1, 0]
		elif (projectionPlane == "top"):
			cAxis = [0, 0, 1]
		elif (projectionPlane == "bottom"):
			cAxis = [0, 0, -1]
		
		# Make selection constraint
		ResetPolySelectConstraint()
		
		cmds.polySelectConstraint(m=3, t=0x0008, o=1, oa=(cAxis[0], cAxis[1], cAxis[2]), ob=(0, projectionAngle))
		
		# Create constraintList 
		constraintList = OpenMaya.MSelectionList()
		OpenMaya.MGlobal_getActiveSelectionList(constraintList)
		
		## START: All and Next ##
		# Remove faces not selected by user
		constraintList.intersect(intersectList)
		# Remove projectedList from constraintList
		if projectedList.isEmpty() is False:
			constraintList.merge(projectedList, OpenMaya.MSelectionList.kRemoveFromList)
		## END: All and Next ##
		
		# Add constraintList to projectedList
		if constraintList.isEmpty() is False:
			projectedList.merge(constraintList, OpenMaya.MSelectionList.kMergeNormal)
		
		# Return constraintList as string
		constraintSel = []
		constraintList.getSelectionStrings(constraintSel)
		
		polyProjectionNode = None
		
		# Reset constraint
		ResetPolySelectConstraint()
		
		# Progress bar
		cmds.progressBar(gMainProgressBar, e=True, s=1, st="UV Mapping in progress...")		
		if len(constraintSel) > 0:
			# Projection flags
			if (projectionPlane == "front"):
				#projectionFlags = "md='x', ra=-90"
				projectionFlags = {"rx": 90, "ry": 0, "rz": 90, "ra": 0, "psu": projectionWidth, "psv": projectionHeight}
			elif (projectionPlane == "back"):
				#projectionFlags = "md='x', isu=-1, ra=90"
				projectionFlags = {"rx": 90, "ry": 0, "rz": -90, "ra": 0, "psu": projectionWidth, "psv": projectionHeight}
			elif (projectionPlane == "right"):
				#projectionFlags = "md='y', ra=180"
				projectionFlags = {"rx": 90, "ry": 0, "rz": -180, "ra": 0, "psu": projectionWidth, "psv": projectionHeight}
			elif (projectionPlane == "left"):
				#projectionFlags = "md='y', isv=-1"
				projectionFlags = {"rx": 90, "ry": 0, "rz": 0, "ra": 0, "psu": projectionWidth, "psv": projectionHeight}
			elif (projectionPlane == "top"):
				#projectionFlags = "md='z'"
				projectionFlags = {"rx": 0, "ry": 0, "rz": 0, "ra": 0, "psu": projectionWidth, "psv": projectionHeight}
				if (frontAxis == "X"):
					projectionFlags["ra"] = -90
			elif (projectionPlane == "bottom"):
				#projectionFlags = "md='z', isv=-1"
				projectionFlags = {"rx": -180, "ry": 0, "rz": 0, "ra": 0, "psu": projectionWidth, "psv": projectionHeight}
				if (frontAxis == "X"):
					projectionFlags["ra"] = 90
			
			if customProjectionPos is None:
				projection_position = cmds.xform(osd_obj, query=True, worldSpace=True, rotatePivot=True)
			else:
				projection_position = customProjectionPos
			
			faceComponentList = ["."+face.split(".", 1)[1] for face in constraintSel]
			
			polyProjectionNode = cmds.createNode("polyPlanarProj", ss=True)
			cmds.setAttr((polyProjectionNode+".worldSpace"), 1)
			cmds.setAttr((polyProjectionNode+".inputMatrix"), cmds.getAttr((osd_shape[0]+".worldMatrix")), typ="matrix")
			cmds.setAttr((polyProjectionNode+".projectionCenterX"), projection_position[0])
			cmds.setAttr((polyProjectionNode+".projectionCenterY"), projection_position[1])
			cmds.setAttr((polyProjectionNode+".projectionCenterZ"), projection_position[2])
			cmds.setAttr((polyProjectionNode+".rotateX"), projectionFlags["rx"])
			cmds.setAttr((polyProjectionNode+".rotateY"), projectionFlags["ry"])
			cmds.setAttr((polyProjectionNode+".rotateZ"), projectionFlags["rz"])
			cmds.setAttr((polyProjectionNode+".rotationAngle"), projectionFlags["ra"])
			cmds.setAttr((polyProjectionNode+".projectionWidth"), projectionFlags["psu"])
			cmds.setAttr((polyProjectionNode+".projectionHeight"), projectionFlags["psv"])
			cmds.setAttr((polyProjectionNode+".uvSetName"), cmds.polyUVSet(osd_shape[0], q=True, cuv=True)[0], typ="string")
			cmds.setAttr((polyProjectionNode+".inputComponents"), len(constraintSel), *faceComponentList, typ="componentList")
			# Refresh viewport
			if suspendRefresh == 0:
				cmds.refresh(cv=True)
				MAM_UVEditorPanels = cmds.getPanel(sty="polyTexturePlacementPanel")
				cmds.textureWindow(MAM_UVEditorPanels[0], e=True, ref=True)
		# Connect polyProjectionNode
		if polyProjectionNode is not None:
			if len(polyProjectionNodeList) > 0:
				cmds.connectAttr((polyProjectionNodeList[len(polyProjectionNodeList)-1]+".output"), (polyProjectionNode+".inputPolymesh"), f=True)
			polyProjectionNodeList.append(polyProjectionNode)
		# Connect last polyProjectionNode to shape
		if i == len(projectionOrder)-1:
			cmds.connectAttr((deformerShape[0]+".output"), (polyProjectionNodeList[0]+".inputPolymesh"))
			cmds.connectAttr((polyProjectionNodeList[len(polyProjectionNodeList)-1]+".output"), (osd_shape[0]+".inMesh"), f=True)
		# Progress bar
		cmds.progressBar(gMainProgressBar, e=True, s=1, st="UV Mapping in progress...")

	# Remove already projected faces
	if projectedList.isEmpty() is False:
		intersectList.merge(projectedList, OpenMaya.MSelectionList.kRemoveFromList)
	# Return intersectList as string
	unprojectedSel = []
	intersectList.getSelectionStrings(unprojectedSel)
	# Create objectSel dictionary of unprojected faces	
	if len(unprojectedSel) > 0:
		unprojectedSelDict = MAM_ObjectSelDictionary(unprojectedSel)
		unprojectedSelDict = unprojectedSelDict[0]
	
	# Automatic Mapping on unmapped faces
	if "unprojectedSelDict" in locals() and len(unprojectedSelDict) > 0:
		MAM_AutoProjection(osd=unprojectedSelDict, mo=multipleObjects, pw=projectionWidth, ph=projectionHeight, dpb=False, ch=True, sr=suspendRefresh, huv=hideUVEditor)
	
	# Cleanup nonManifoldUVs
	if cleanupUVs == 1:
		nonManifoldUVs = cmds.polyInfo(osd_obj, nuv=True, nue=True)
		# First pass, edges
		if (nonManifoldUVs is not None):
			nonManifoldUVsList = cmds.polyListComponentConversion(nonManifoldUVs, tvf=True)
			nonManifoldUVsList = cmds.polyListComponentConversion(nonManifoldUVsList, te=True, internal=True)
			if len(nonManifoldUVsList) > 0:
				polyCutNode = cmds.polyMapCut(nonManifoldUVsList[0], ch=True)
				nonManifoldInputComponents = ["."+uvMap.split(".", 1)[1] for uvMap in nonManifoldUVsList]
				cmds.setAttr((polyCutNode[0]+".inputComponents"), len(nonManifoldUVsList), *nonManifoldInputComponents, typ="componentList")
		nonManifoldUVs = cmds.polyInfo(osd_obj, nuv=True, nue=True)
		# Second pass, UVs
		if (nonManifoldUVs is not None):
			nonManifoldUVs = cmds.polyListComponentConversion(nonManifoldUVs, te=True)
			if len(nonManifoldUVs) > 0:
				nonManifoldUVsList = nonManifoldUVsList + nonManifoldUVs
				if "polyCutNode" not in locals():
					polyCutNode = cmds.polyMapCut(nonManifoldUVsList[0], ch=True)
				nonManifoldInputComponents = ["."+uvMap.split(".", 1)[1] for uvMap in nonManifoldUVsList]
				cmds.setAttr((polyCutNode[0]+".inputComponents"), len(nonManifoldUVsList), *nonManifoldInputComponents, typ="componentList")
	
	# Restore rotations
	if resetRotations == 1:
		if "objectRotations" in locals():
			cmds.xform(osd_obj, os=True, ro=(objectRotations[0], objectRotations[1], objectRotations[2]))
	
	# Progress bar
	cmds.progressBar(gMainProgressBar, e=True, s=1, st="UV Mapping in progress...")
	return "Finished"

def MAM_TriPlanarProjection(*args, **kwargs):
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	# Projection Settings
	MAM_settings = MAM_querySettings()
	MAMAO_settings = MAMAO_querySettings()
	projectionSel = None
	objectSelDict = None
	
	# A # Load optionVar
	multipleObjects = MAM_settings["multipleObjects"]
	frontAxis = MAM_settings["frontAxis"]
	projectionWidth = MAM_settings["projectionWidth"]
	projectionHeight = MAM_settings["projectionHeight"]
	resetRotations = MAM_settings["resetRotations"]
	projectionOrder = MAM_settings["projectionOrder"]
	projectionAngle = MAM_settings["projectionAngle"]
	cleanupUVs = MAM_settings["cleanupUVs"]
	
	# Advanced settings
	deleteHistory = MAMAO_settings["MAMAO_DeleteHistory"]
	if deleteHistory == 0:
		constructionHistory = 1
	else:
		constructionHistory = 0
	suspendRefresh = MAMAO_settings["MAMAO_SuspendRefresh"]
	hideUVEditor = MAMAO_settings["MAMAO_HideUVEditor"]
	
	# B # Load arguments (override A)
	for i, arg in enumerate(args):
		if i == 0:
			projectionSel = arg
		elif i == 1:
			multipleObjects = arg
		elif i == 2:
			frontAxis = arg
		elif i == 3:
			projectionWidth = arg
		elif i == 4:
			projectionHeight = arg
		elif i == 5:
			resetRotations = arg
		elif i == 6:
			projectionOrder = arg
		elif i == 7:
			projectionAngle = arg
		elif i == 8:
			cleanupUVs = arg
		elif i == 9:
			constructionHistory = arg
		elif i == 10:
			suspendRefresh = arg
		elif i == 11:
			hideUVEditor = arg
	
	# C # Load keyworded arguments (override B)
	for key, value in six.iteritems(kwargs):
		if key == "objectSelDict" or key == "osd":
			objectSelDict = value
		elif key == "selection" or key == "sl":
			projectionSel = value
		elif key == "multipleObjects" or key == "mo":
			multipleObjects = value
		elif key == "frontAxis" or key == "fa":
			frontAxis = value
		elif key == "projectionWidth" or key == "pw":
			projectionWidth = value
		elif key == "projectionHeight" or key == "ph":
			projectionHeight = value
		elif key == "resetRotations" or key == "rr":
			resetRotations = value
		elif key == "projectionOrder" or key == "po":
			projectionOrder = value
		elif key == "projectionAngle" or key == "pa":
			projectionAngle = value
		elif key == "cleanupUVs" or key == "cuv":
			cleanupUVs = value
		elif key == "constructionHistory" or key == "ch":
			constructionHistory = value
		elif key == "suspendRefresh" or key == "sr":
			suspendRefresh = value
		elif key == "hideUVEditor" or key == "huv":
			hideUVEditor = value
	
	# Projection Order
	if (projectionOrder == "X Y Z"):
		#projectionOrder = ["bottom", "top", "left", "right", "back", "front"]
		projectionOrder = ["front", "back", "right", "left", "top", "bottom"]
	elif (projectionOrder == "X Z Y"):
		#projectionOrder = ["left", "right", "bottom", "top", "back", "front"]
		projectionOrder = ["front", "back", "top", "bottom", "right", "left"]
	elif (projectionOrder == "Y X Z"):
		#projectionOrder = ["bottom", "top", "back", "front", "left", "right"]
		projectionOrder = ["right", "left", "front", "back", "top", "bottom"]
	elif (projectionOrder == "Y Z X"):
		#projectionOrder = ["back", "front", "bottom", "top", "left", "right"]
		projectionOrder = ["right", "left", "top", "bottom", "front", "back"]
	elif (projectionOrder == "Z X Y"):
		#projectionOrder = ["left", "right", "back", "front", "bottom", "top"]
		projectionOrder = ["top", "bottom", "front", "back", "right", "left"]
	elif (projectionOrder == "Z Y X"):
		#projectionOrder = ["back", "front", "left", "right", "bottom", "top"]
		projectionOrder = ["top", "bottom", "right", "left", "front", "back"]
		
	if objectSelDict is None:
		if projectionSel is None:
			projectionSel = cmds.ls(sl=True, l=True)
		# Get selected faces
		projectionSel = cmds.polyListComponentConversion(projectionSel, tf=True)
		# Create objectSel dictionary
		objectSelDict = MAM_ObjectSelDictionary(projectionSel)
		objectSelDict = objectSelDict[0]
	
	if objectSelDict is not None:		
		# Delete history
		#if constructionHistory == 0:
			#cmds.delete(osd_obj, ch=True)
		
		# Select Facet component mode
		cmds.selectMode(co=True)
		cmds.selectType(fc=True)
		
		# Get projection_position
		projection_position = None
		# Projection position is the bounding box center of the selected objects
		if multipleObjects == 2:
			projection_position = [0, 0, 0]
			for obj in objectSelDict:
				objBoundingBox = cmds.objectCenter(obj, gl=True)
				projection_position[0] += objBoundingBox[0]
				projection_position[1] += objBoundingBox[1]
				projection_position[2] += objBoundingBox[2]
			projection_position = [x / len(objectSelDict) for x in projection_position]
		# Projection position is the last selected object pivot
		elif multipleObjects == 3:
			projection_position = cmds.xform(next(reversed(objectSelDict)), query=True, worldSpace=True, rotatePivot=True)
		
		# Progress bar
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="UV Mapping in progress...", max=((len(objectSelDict)*(len(projectionOrder)*2)+1)+(len(objectSelDict))))
		
		# For each selected object
		for obj, sel in six.iteritems(objectSelDict):
			cmds.select(obj, r=True)
			projectionStatus = MAM_TriPlanarProjectionProc(obj, sel, multipleObjects, frontAxis, projectionWidth, projectionHeight, resetRotations, projectionOrder, projectionAngle, cleanupUVs, projection_position, suspendRefresh, hideUVEditor, constructionHistory)
		
		if "projectionStatus" in locals():
			return projectionStatus
		else:
			return "Finished"

def MAM_NormalBasedProjectionProc(object, objectFaces, projectionWidth, projectionHeight, constructionHistory):
	# Retrieve face normal vector
	meanVector = MVector(0, 0, 0)
	vectorStrings = GetFacesNormals(objectFaces)
	
	for vectorString in vectorStrings:
		normalVector = MVector(vectorString[0], vectorString[1], vectorString[2])
		meanVector += normalVector

	meanVector = meanVector/(len(vectorStrings))
	
	# Normalize mean vector and invert it
	if (meanVector.x is not 0):
		meanVector = MVector(-meanVector.x, meanVector.y, meanVector.z)
	if (meanVector.y is not 0):
		meanVector = MVector(meanVector.x, -meanVector.y, meanVector.z)
	if (meanVector.z is not 0):
		meanVector = MVector(meanVector.x, meanVector.y, -meanVector.z)
	
	# Converting the object-space vector to world space
	transformMatrix = cmds.xform(object, q=True, m=True, ws=True)
	transformMatrix = MMatrix(transformMatrix)
	meanVector = MVector(meanVector * transformMatrix)
	
	# Create new tempCamera (by cloning the perspective camera)
	tempCamera = cmds.duplicate("persp")
	cmds.camera(tempCamera[0], e=True, o=True)
	
	# Get current active modelling panel and switch the camera there to $tempCamera
	activePanel = cmds.getPanel(wf=True)
	cmds.lookThru(tempCamera[0], activePanel)

	# Position the temporary camera
	cmds.viewPlace(tempCamera[0], vd=(meanVector.x, meanVector.y, meanVector.z))
	cmds.viewFit(objectFaces)
	
	# Make projection
	cmds.select(objectFaces, r=True)
	projection_position = cmds.xform(object, query=True, worldSpace=True, rotatePivot=True)
	camRotation = cmds.xform(tempCamera[0], q=True, ws=True, ro=True)
	UVProjection = cmds.polyProjection(objectFaces, ch=constructionHistory, t="Planar", ibd=True, kir=True, pcx=projection_position[0], pcy=projection_position[1], pcz=projection_position[2], rx=camRotation[0], ry=camRotation[1], rz=camRotation[2], psu=projectionWidth, psv=projectionHeight)
	
	# Switch back to perspective camera and remove the temporary one
	cmds.lookThru("persp", activePanel)
	cmds.delete(tempCamera)
	
	# Orient shell to nearest 90 degree
	cmds.polyLayoutUV(objectFaces, flipReversed=False, layout=0, layoutMethod=1, percentageSpace=0.2, rotateForBestFit=3, scale=0, separate=0, constructionHistory=constructionHistory)
	
	return UVProjection
	
def MAM_NormalBasedProjection(*args, **kwargs):
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	# Projection Settings
	MAM_settings = MAM_querySettings()
	MAMAO_settings = MAMAO_querySettings()
	projectionSel = None
	objectSelDict = None
	
	# A # Load optionVar
	projectionWidth = MAM_settings["projectionWidth"]
	projectionHeight = MAM_settings["projectionHeight"]
	resetRotations = MAM_settings["resetRotations"]
	
	# Advanced settings
	deleteHistory = MAMAO_settings["MAMAO_DeleteHistory"]
	if deleteHistory == 0:
		constructionHistory = 1
	else:
		constructionHistory = 0
	suspendRefresh = MAMAO_settings["MAMAO_SuspendRefresh"]
	hideUVEditor = MAMAO_settings["MAMAO_HideUVEditor"]
	
	# B # Load arguments (override A)
	for i, arg in enumerate(args):
		if i == 0:
			projectionSel = arg
		elif i == 1:
			projectionWidth = arg
		elif i == 2:
			projectionHeight = arg
		elif i == 3:
			resetRotations = arg
		elif i == 4:
			constructionHistory = arg
		elif i == 5:
			suspendRefresh = arg
		elif i == 6:
			hideUVEditor = arg
	
	# C # Load keyworded arguments (override B)
	for key, value in six.iteritems(kwargs):
		if key == "objectSelDict" or key == "osd":
			objectSelDict = value
		elif key == "selection" or key == "sl":
			projectionSel = value
		elif key == "projectionWidth" or key == "pw":
			projectionWidth = value
		elif key == "projectionHeight" or key == "ph":
			projectionHeight = value
		elif key == "resetRotations" or key == "rr":
			resetRotations = value
		elif key == "constructionHistory" or key == "ch":
			constructionHistory = value
		elif key == "suspendRefresh" or key == "sr":
			suspendRefresh = value
		elif key == "hideUVEditor" or key == "huv":
			hideUVEditor = value
	
	if objectSelDict is None:
		if projectionSel is None:
			projectionSel = cmds.ls(sl=True, l=True)
		# Get selected faces
		projectionSel = cmds.polyListComponentConversion(projectionSel, tf=True)
		# Create objectSel dictionary
		objectSelDict = MAM_ObjectSelDictionary(projectionSel)
		objectSelDict = objectSelDict[0]
	
	if objectSelDict is not None:
		shellNumber = 0
		for obj, sel in six.iteritems(objectSelDict):
			# Get shell count
			shellIds = cmds.polyEvaluate(sel, usi=True)
			#shellIds = list(OrderedDict.fromkeys(shellIds))
			shellIds = list(set(shellIds))
			shellNumber += len(shellIds)
		
		if shellNumber <= 0:
			return None
		
		# Progress bar
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="UV Mapping in progress...", max=(shellNumber))
		for obj, sel in six.iteritems(objectSelDict):
			# Clear selection (increase speed)
			cmds.select(cl=True)
			# Get shells
			uvShells = GetShells(obj, sel)
			for uvShell in uvShells:
				# Progress bar
				if cmds.progressBar(gMainProgressBar, q=True, ic=True):
					# Script aborpted
					return "Cancelled"
				# Get face shell
				faceShell = cmds.polyListComponentConversion(uvShell, fuv=True, tf=True)
				# NormalBasedProjection
				UVProjection = MAM_NormalBasedProjectionProc(obj, faceShell, projectionWidth, projectionHeight, constructionHistory)
				# Refresh viewport
				if suspendRefresh == 0:
					cmds.refresh(cv=True)
					MAM_UVEditorPanels = cmds.getPanel(sty="polyTexturePlacementPanel")
					cmds.textureWindow(MAM_UVEditorPanels[0], e=True, ref=True)
				# Progress bar
				cmds.progressBar(gMainProgressBar, e=True, s=1, st="UV Mapping in progress...")
		
		return "Finished"

def MultiAutomaticMapping(*args, **kwargs):
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="UV Mapping in progress...")
	# Fix for hanging previous progress
	if cmds.progressBar(gMainProgressBar, q=True, ic=True):
		cmds.progressBar(gMainProgressBar, e=True, ep=True)
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="UV Mapping in progress...")
	cmds.progressBar(gMainProgressBar, e=True, s=1)
	cmds.progressBar(gMainProgressBar, e=True, s=-1)
	# Projection Settings
	MAM_settings = MAM_querySettings()
	MAMAO_settings = MAMAO_querySettings()
	currentSel = cmds.ls(sl=True, l=True)
	currentHl = cmds.ls(hl=True, l=True)
	
	# A # Load optionVar
	projectionType = MAM_settings["projectionType"]
	multipleObjects = MAM_settings["multipleObjects"]
	frontAxis = MAM_settings["frontAxis"]
	projectionWidth = MAM_settings["projectionWidth"]
	projectionHeight = MAM_settings["projectionHeight"]
	resetRotations = MAM_settings["resetRotations"]
	projectionOrder = MAM_settings["projectionOrder"]
	projectionAngle = MAM_settings["projectionAngle"]
	cleanupUVs = MAM_settings["cleanupUVs"]
	cutHardEdges = MAM_settings["cutHardEdges"]
	flipReversed = MAM_settings["flipReversed"]
	layoutUVs = MAM_settings["layoutUVs"]
	packingResolution = MAM_settings["packingResolution"]
	packingIterations = MAM_settings["packingIterations"]
	textureMapSize = MAM_settings["textureMapSize"]
	shellPadding = MAM_settings["shellPadding"]
	scaleMode = MAM_settings["scaleMode"]
	
	# Advanced settings
	deleteHistory = MAMAO_settings["MAMAO_DeleteHistory"]
	if deleteHistory == 0:
		constructionHistory = 1
	else:
		constructionHistory = 0
	suspendRefresh = MAMAO_settings["MAMAO_SuspendRefresh"]
	hideUVEditor = MAMAO_settings["MAMAO_HideUVEditor"]
	turnOffUndo = MAMAO_settings["MAMAO_TurnOffUndo"]
	
	# B # Load arguments (override A)
	for i, arg in enumerate(args):
		if i == 0:
			currentSel = arg
		elif i == 1:
			projectionType = arg
		elif i == 2:
			multipleObjects = arg
		elif i == 3:
			frontAxis = arg
		elif i == 4:
			projectionWidth = arg
		elif i == 5:
			projectionHeight = arg
		elif i == 6:
			resetRotations = arg
		elif i == 7:
			projectionOrder = arg
		elif i == 8:
			projectionAngle = arg
		elif i == 9:
			cleanupUVs = arg
		elif i == 10:
			cutHardEdges = arg
		elif i == 11:
			flipReversed = arg
		elif i == 12:
			layoutUVs = arg
		elif i == 13:
			packingResolution = arg
		elif i == 14:
			packingIterations = arg
		elif i == 15:
			textureMapSize = arg
		elif i == 16:
			shellPadding = arg
		elif i == 17:
			scaleMode = arg
		elif i == 18:
			constructionHistory = arg
		elif i == 19:
			suspendRefresh = arg
			hideUVEditor = arg
			turnOffUndo = 0
	
	# C # Load keyworded arguments (override B)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sl":
			currentSel = value
		elif key == "projectionType" or key == "pt":
			projectionType = value
		elif key == "multipleObjects" or key == "mo":
			multipleObjects = value
		elif key == "frontAxis" or key == "fa":
			frontAxis = value
		elif key == "projectionWidth" or key == "pw":
			projectionWidth = value
		elif key == "projectionHeight" or key == "ph":
			projectionHeight = value
		elif key == "resetRotations" or key == "rr":
			resetRotations = value
		elif key == "projectionOrder" or key == "po":
			projectionOrder = value
		elif key == "projectionAngle" or key == "pa":
			projectionAngle = value
		elif key == "cleanupUVs" or key == "cuv":
			cleanupUVs = value
		elif key == "cutHardEdges" or key == "che":
			cutHardEdges = value
		elif key == "flipReversed" or key == "fr":
			flipReversed = value
		elif key == "layoutUVs" or key == "luv":
			layoutUVs = value
		elif key == "packingResolution" or key == "pr":
			packingResolution = value
		elif key == "packingIterations" or key == "pi":
			packingIterations = value
		elif key == "textureMapSize" or key == "tms":
			textureMapSize = value
		elif key == "shellPadding" or key == "sp":
			shellPadding = value
		elif key == "scaleMode" or key == "sc":
			scaleMode = value
		elif key == "constructionHistory" or key == "ch":
			constructionHistory = value
		elif key == "suspendRefresh" or key == "sr":
			suspendRefresh = value
		elif key == "hideUVEditor" or key == "huv":
			hideUVEditor = value
		elif key == "turnOffUndo" or key == "tou":
			turnOffUndo = value
	
	# Get selection type
	selectType = MAM_GetComponentType(currentSel)
	
	# Create objectSel dictionary
	objectSelDict, objectSel, osd_sel = MAM_ObjectSelDictionary(cmds.polyListComponentConversion(currentSel, tf=True))
	
	if len(objectSelDict) > 0:
		# Disable viewport temporarily
		if suspendRefresh == 1:			
			cmds.refresh(suspend=True)
		# Turn off undos
		if turnOffUndo == 1:
			cmds.undoInfo(st=False)
		# Open undo chunk
		else:
			cmds.undoInfo(ock=True)
		
		try:
			# Disable UV Editor temporarily
			if suspendRefresh == 1 and hideUVEditor == 1:
				# Check if a polyTexturePlacementPanel exists
				MAM_UVEditorPanels = cmds.getPanel(sty="polyTexturePlacementPanel")
				MAM_UVEditor = cmds.scriptedPanel(MAM_UVEditorPanels[0], q=True, ctl=True)
				MAM_UVEditorSplit = MAM_UVEditor.split("|")
				MAM_UVEditor = MAM_UVEditorSplit[0]
				if(cmds.window(MAM_UVEditor, ex=True) is True):
					# Change window visibility to False
					cmds.window(MAM_UVEditor, e=True, vis=False)
			
			# Run projection script
			if (projectionType == 1):
				projectionStatus = MAM_TriPlanarProjection(osd=objectSelDict, ost=selectType, mo=multipleObjects, fa=frontAxis, pw=projectionWidth, ph=projectionHeight, rr=resetRotations, po=projectionOrder, pa=projectionAngle, cuv=cleanupUVs, ch=constructionHistory, sr=suspendRefresh, huv=hideUVEditor)
			elif (projectionType == 2):
				projectionStatus = MAM_NormalBasedProjection(osd=objectSelDict, pw=projectionWidth, ph=projectionHeight, rr=resetRotations, ch=constructionHistory, sr=suspendRefresh, huv=hideUVEditor)
			else:
				projectionStatus = MAM_AutoProjection(osd=objectSelDict, mo=multipleObjects, pw=projectionWidth, ph=projectionHeight, dpb=True, ch=constructionHistory, sr=suspendRefresh, huv=hideUVEditor)
			
			if "projectionStatus" in locals() and projectionStatus == "Finished":
				# Delete history
				if constructionHistory == 0:
					cmds.delete(objectSel, ch=True)
				
				if cutHardEdges == 1 or flipReversed == 1:
					for sel in six.itervalues(objectSelDict):
						# Cut hard edges
						if cutHardEdges == 1:
							selEdgeList = cmds.polyListComponentConversion(sel, fromFace=True, toEdge=True)
							selHardEdges = GetHardEdges(selEdgeList)
							if len(selHardEdges) > 0:
								cmds.polyMapCut(selHardEdges, constructionHistory=constructionHistory)
						
						# Flip reversed
						if flipReversed == 1:
							cmds.polyLayoutUV(sel, flipReversed=True, layout=0, rotateForBestFit=0, scale=0, constructionHistory=constructionHistory)
				
				# Layout
				if (layoutUVs == 1):
					if cmds.polyInfo(nuv=True, nue=True) is None:
						# Progress bar
						cmds.progressBar(gMainProgressBar, e=True, ep=True)
						textureMapSize = float(textureMapSize)
						shellPadding = (shellPadding/textureMapSize)
						if scaleMode == "Off":
							layoutScaleMode = 1
							preScaleMode = 0
						elif scaleMode == "Uniform":
							layoutScaleMode = 2
							preScaleMode = 1
						elif scaleMode == "Non-uniform":
							layoutScaleMode = 3
							preScaleMode = 1
						if len(osd_sel) > 0:
							cmds.u3dLayout(osd_sel, res=packingResolution, mut=packingIterations, spc=shellPadding, mar=shellPadding, ls=layoutScaleMode, scl=preScaleMode)
					else:
						cmds.evalDeferred('import maya.cmds as cmds;cmds.warning("Cannot layout UVs: Mesh has non-manifold UVs.")')
			elif "projectionStatus" in locals() and projectionStatus == None:
				pass
			else:
				cmds.evalDeferred("import maya.cmds as cmds;cmds.warning('Script aborpted by user')")
			
			# Restore selection
			cmds.selectMode(co=True)
			cmds.selectMode(o=True)
			if (selectType is not None):
				cmds.select(objectSel, r=True)
				cmds.select(currentHl, add=True)
				cmds.selectMode(co=True)
				exec("cmds.selectType("+selectType+"=True)")
			restoreSel = []
			for sel in currentSel:
				if cmds.objExists(sel) is True:
					restoreSel.append(sel)
			cmds.select(restoreSel, r=True)
			
			# Re-enable UV Editor
			if suspendRefresh == 1 and hideUVEditor == 1:
				if(cmds.window(MAM_UVEditor, ex=True) is True):
					cmds.window(MAM_UVEditor, e=True, vis=True)
					if(cmds.window("MultiAutomaticMappingWin", ex=True) is True):
						windowState = cmds.window("MultiAutomaticMappingWin", q=True, st=True)
						cmds.window("MultiAutomaticMappingWin", e=True, vis=False, st=windowState)
						cmds.window("MultiAutomaticMappingWin", e=True, vis=True, st=windowState)
		
		except Exception as e:
			raise Exception(e)
		
		finally:
			# Re-enable viewport
			if suspendRefresh == 1:
				cmds.refresh(suspend=False)
			# Turn off undos
			if turnOffUndo == 1:
				cmds.undoInfo(st=True)
			# Close undo chunk
			else:
				cmds.undoInfo(cck=True)
			# Progress bar
			cmds.progressBar(gMainProgressBar, e=True, ep=True)
		
		# Print message
		print ("Selected objects automatically mapped.")
	# Progress bar
	cmds.progressBar(gMainProgressBar, e=True, ep=True)

def MAM_controlsCallback(*args):
	# Save settings
	MAM_saveSettings(SAVE_SETTINGS)
	# Query optionVar
	MAM_settings = MAM_querySettings()
	if (cmds.window("MultiAutomaticMappingWin", ex=True) is True):
		if (MAM_settings["projectionType"] == 1):
			cmds.rowLayout("MAM_MultipleObjectsRow", e=True, en=True)
			cmds.rowLayout("MAM_FrontAxisRow", e=True, en=True)
			cmds.rowLayout("MAM_ResetRotationsRow", e=True, en=True)
			cmds.rowLayout("MAM_ProjectionOrderRow", e=True, en=True)
			cmds.rowLayout("MAM_ProjectionAngleRow", e=True, en=True)
		elif (MAM_settings["projectionType"] == 2):
			cmds.rowLayout("MAM_MultipleObjectsRow", e=True, en=False)
			cmds.rowLayout("MAM_FrontAxisRow", e=True, en=False)
			cmds.rowLayout("MAM_ResetRotationsRow", e=True, en=True)
			cmds.rowLayout("MAM_ProjectionOrderRow", e=True, en=False)
			cmds.rowLayout("MAM_ProjectionAngleRow", e=True, en=False)
		else:
			cmds.rowLayout("MAM_MultipleObjectsRow", e=True, en=True)
			cmds.rowLayout("MAM_FrontAxisRow", e=True, en=False)
			cmds.rowLayout("MAM_ResetRotationsRow", e=True, en=False)
			cmds.rowLayout("MAM_ProjectionOrderRow", e=True, en=False)
			cmds.rowLayout("MAM_ProjectionAngleRow", e=True, en=False)
		if (MAM_settings["layoutUVs"] == 1):
			cmds.rowLayout("MAM_PackingResolutionRow", e=True, en=True)
			cmds.rowLayout("MAM_PackingIterationsRow", e=True, en=True)
			cmds.rowLayout("MAM_TextureMapSizeRow", e=True, en=True)
			cmds.rowLayout("MAM_ShellPaddingRow", e=True, en=True)
			cmds.rowLayout("MAM_ScaleModeRow", e=True, en=True)
		else:
			cmds.rowLayout("MAM_PackingResolutionRow", e=True, en=False)
			cmds.rowLayout("MAM_PackingIterationsRow", e=True, en=False)
			cmds.rowLayout("MAM_TextureMapSizeRow", e=True, en=False)
			cmds.rowLayout("MAM_ShellPaddingRow", e=True, en=False)
			cmds.rowLayout("MAM_ScaleModeRow", e=True, en=False)
		#cmds.setFocus("MultiAutomaticMappingWin")

def MAM_windowSetup():
	# Query optionVar
	MAM_settings = MAM_querySettings()
	# Projection type
	if (cmds.radioButtonGrp("MAM_ProjectionType", q=True, ex=True) is True):
		cmds.radioButtonGrp("MAM_ProjectionType", e=True, sl=MAM_settings["projectionType"])
	# Multiple objects
	if (cmds.radioButtonGrp("MAM_MultipleObjects", q=True, ex=True) is True):
		cmds.radioButtonGrp("MAM_MultipleObjects", e=True, sl=MAM_settings["multipleObjects"])
	# Front axis
	if (cmds.optionMenuGrp("MAM_FrontAxis", q=True, ex=True) is True):
		cmds.optionMenuGrp("MAM_FrontAxis", e=True, v=MAM_settings["frontAxis"])
	# Projection width
	if (cmds.floatFieldGrp("MAM_ProjectionWidth", q=True, ex=True) is True):
		cmds.floatFieldGrp("MAM_ProjectionWidth", e=True, v1=MAM_settings["projectionWidth"])
	# Projection height
	if (cmds.floatFieldGrp("MAM_ProjectionHeight", q=True, ex=True) is True):
		cmds.floatFieldGrp("MAM_ProjectionHeight", e=True, v1=MAM_settings["projectionHeight"])
	# Reset rotations
	if (cmds.checkBoxGrp("MAM_ResetRotations", q=True, ex=True) is True):
		cmds.checkBoxGrp("MAM_ResetRotations", e=True, v1=MAM_settings["resetRotations"])
	# Projection order
	if (cmds.optionMenuGrp("MAM_ProjectionOrder", q=True, ex=True) is True):
		cmds.optionMenuGrp("MAM_ProjectionOrder", e=True, v=MAM_settings["projectionOrder"])
	# Angle threshold
	if (cmds.floatSliderGrp("MAM_ProjectionAngle", q=True, ex=True) is True):
		cmds.floatSliderGrp("MAM_ProjectionAngle", e=True, v=MAM_settings["projectionAngle"])
	# Cleanup UVs
	if (cmds.checkBoxGrp("MAM_CleanupUVs", q=True, ex=True) is True):
		cmds.checkBoxGrp("MAM_CleanupUVs", e=True, v1=MAM_settings["cleanupUVs"])
	# Cut hard edges
	if (cmds.checkBoxGrp("MAM_CutHardEdges", q=True, ex=True) is True):
		cmds.checkBoxGrp("MAM_CutHardEdges", e=True, v1=MAM_settings["cutHardEdges"])
	# Flip reversed
	if (cmds.checkBoxGrp("MAM_FlipReversed", q=True, ex=True) is True):
		cmds.checkBoxGrp("MAM_FlipReversed", e=True, v1=MAM_settings["flipReversed"])
	# Layout UVs
	if (cmds.checkBoxGrp("MAM_LayoutUVs", q=True, ex=True) is True):
		 cmds.checkBoxGrp("MAM_LayoutUVs", e=True, v1=MAM_settings["layoutUVs"])
	# Packing resolution
	if (cmds.intSliderGrp("MAM_PackingResolution", q=True, ex=True) is True):
		cmds.intSliderGrp("MAM_PackingResolution", e=True, v=MAM_settings["packingResolution"])
	# Packing iterations
	if (cmds.intSliderGrp("MAM_PackingIterations", q=True, ex=True) is True):
		cmds.intSliderGrp("MAM_PackingIterations", e=True, v=MAM_settings["packingIterations"])
	# Texture map size
	if (cmds.optionMenuGrp("MAM_TextureMapSize", q=True, ex=True) is True):
		cmds.optionMenuGrp("MAM_TextureMapSize", e=True, v=MAM_settings["textureMapSize"])
	# Shell padding
	if (cmds.floatFieldGrp("MAM_ShellPadding", q=True, ex=True) is True):
		cmds.floatFieldGrp("MAM_ShellPadding", e=True, v1=MAM_settings["shellPadding"])
	# Scale mode
	if (cmds.optionMenuGrp("MAM_ScaleMode", q=True, ex=True) is True):
		cmds.optionMenuGrp("MAM_ScaleMode", e=True, v=MAM_settings["scaleMode"])
	# Update controls
	MAM_controlsCallback()

def MAM_buttonsCmd(runScript, closeWindow, *args):
	if(closeWindow is True):
		if(cmds.window("MultiAutomaticMappingWin", ex=True) is True):
			# evalDeferred fixes rare occurence of a crash
			cmds.evalDeferred("import maya.cmds as cmds;cmds.deleteUI('MultiAutomaticMappingWin', wnd=True)")
	if(runScript is True):
		# Save settings
		MAM_saveSettings(SAVE_SETTINGS)
		# Run script
		MultiAutomaticMapping()

def MAM_resetSettings(*args):
	# Reset settings
	MAM_saveSettings(RESET_SETTINGS)
	# Update controls
	MAM_windowSetup()

def MAM_scrollResized(*args):
	scrollLayoutWidth = cmds.scrollLayout("MAM_ScrollLayout", q=True, w=True)
	scrollFormWidth = cmds.formLayout("MAM_ScrollForm", q=True, w=True)
	if (scrollLayoutWidth > scrollFormWidth+10):
		cmds.formLayout("MAM_ScrollForm", e=True, af=[("MAM_ProjectionSettingsFrame", "right", 2), ("MAM_LayoutSettingsFrame", "right", 2)])
	else:
		cmds.formLayout("MAM_ScrollForm", e=True, af=[("MAM_ProjectionSettingsFrame", "right", 0), ("MAM_LayoutSettingsFrame", "right", 0)])

def MAM_separationRow(row1_h, row2_h, row3_h):
	cmds.rowLayout(h=row1_h)
	cmds.setParent("..")
	cmds.rowLayout(h=row2_h, bgc=(0.266, 0.266, 0.266))
	cmds.setParent("..")
	cmds.rowLayout(h=row3_h)
	cmds.setParent("..")

def MAMAO_ParentUVEditorCallback(*args, **kwargs):
	saveSettings = True
	for key, value in six.iteritems(kwargs):
		if key == "save" or key == "s":
			saveSettings = value
	# Check if a polyTexturePlacementPanel exists
	MAM_UVEditorPanels = cmds.getPanel(sty="polyTexturePlacementPanel")
	MAM_UVEditor = cmds.scriptedPanel(MAM_UVEditorPanels[0], q=True, ctl=True)
	MAM_UVEditorPanels = MAM_UVEditor.split("|")
	MAM_UVEditor = MAM_UVEditorPanels[0]
	MAM_WindowParent = MQtUtil.mainWindow()
	# Parent to UV Editor callback
	if (cmds.checkBoxGrp("MAMAO_ParentUVEditor", q=True, ex=True) is True and cmds.window("MultiAutomaticMappingWin", q=True, ex=True) is True and cmds.checkBoxGrp("MAMAO_ParentUVEditor", q=True, v1=True) != cmds.optionVar(q="MAMAO_ParentUVEditor") and cmds.window(MAM_UVEditor, ex=True) is True):
		MAMAO_ParentUVEditor = cmds.checkBoxGrp("MAMAO_ParentUVEditor", q=True, v1=True)
		if saveSettings is True:
			cmds.optionVar(iv=("MAMAO_ParentUVEditor", MAMAO_ParentUVEditor))
		if MAMAO_ParentUVEditor == 0:
			cmds.evalDeferred("MultiAutomaticMapping.MultiAutomaticMappingOptions(p=False)")
		else:
			cmds.evalDeferred("MultiAutomaticMapping.MultiAutomaticMappingOptions(p=True)")
		cmds.evalDeferred("MultiAutomaticMapping.MAM_advancedOptions()")
		return True
	return False

def MAMAO_controlsCallback(*args):
	# Save settings
	MAMAO_saveSettings(SAVE_SETTINGS)
	# Query optionVar
	MAMAO_settings = MAMAO_querySettings()
	if (cmds.window("MultiAutomaticMappingAdvancedOptions", ex=True) is True):
		if (MAMAO_settings["MAMAO_SuspendRefresh"] == 0):
			cmds.rowLayout("MAMAO_HideUVEditorRow", e=True, en=False)
		elif (MAMAO_settings["MAMAO_SuspendRefresh"] == 1):
			cmds.rowLayout("MAMAO_HideUVEditorRow", e=True, en=True)
		if (MAMAO_settings["MAMAO_WindowTransparency"] == 0):
			MAM_QWindow.setWindowOpacity(1)

def MAMAO_windowSetup():
	# Query optionVar
	MAMAO_settings = MAMAO_querySettings()
	for key, value in six.iteritems(MAMAO_settings):
		if (cmds.checkBoxGrp(key, q=True, ex=True) is True):
			cmds.checkBoxGrp(key, e=True, v1=value)
	# Update controls
	MAMAO_controlsCallback()

def MAMAO_buttonsCmd(runScript, closeWindow, *args):
	if(closeWindow is True):
		if(cmds.window("MultiAutomaticMappingAdvancedOptions", ex=True) is True):
			# evalDeferred fixes rare occurence of a crash
			cmds.evalDeferred("import maya.cmds as cmds;cmds.deleteUI('MultiAutomaticMappingAdvancedOptions', wnd=True)")
	if(runScript is True):
		# Save settings
		MAMAO_saveSettings(SAVE_SETTINGS)

def MAMAO_resetSettings(*args):
	# Reset settings
	MAMAO_saveSettings(RESET_SETTINGS)
	# Parent to UV Editor callback
	parentUVEditorCallback = MAMAO_ParentUVEditorCallback(s=False)
	if parentUVEditorCallback is False:
		# Update controls
		MAMAO_windowSetup()

def MAM_advancedOptions(*args):
	# If window already opened, delete it
	if(cmds.window("MultiAutomaticMappingAdvancedOptions", ex=True) is True):
		cmds.deleteUI("MultiAutomaticMappingAdvancedOptions", wnd=True)
	if(cmds.window("MultiAutomaticMappingWin", ex=True) is True):
		windowState = cmds.window("MultiAutomaticMappingWin", q=True, st=True)
		cmds.window("MultiAutomaticMappingAdvancedOptions", t="Multi Automatic Mapping Advanced Options", mb=True, s=False, mxb=False, tlb=True, vis=False, p="MultiAutomaticMappingWin")
	else:
		cmds.window("MultiAutomaticMappingAdvancedOptions", t="Multi Automatic Mapping Advanced Options", mb=True, s=False, mxb=False, tlb=True, vis=False)
	
	# Edit menu
	cmds.menu(l="Edit")
	cmds.menuItem(l="Save Settings", c=(partial(MAMAO_saveSettings, SAVE_SETTINGS)), ecr=False)
	cmds.menuItem(l="Reset Settings", c=(partial(MAMAO_resetSettings)), ecr=False)
	cmds.setParent("..")
	# Help menu
	cmds.menu(l="Help", helpMenu=True)
	cmds.menuItem(l="Help on Multi Automatic Mapping Advanced Options", i="help.png", command=(partial(helpCmd, helpUrl="/docs/multi-automatic-mapping/#advanced-settings")), ecr=False)
	cmds.setParent("..")
	
	# START: Window Form
	cmds.formLayout("MAMAO_WindowForm")
	
	# START: Tab Layout
	cmds.tabLayout("MAMAO_TabLayout", tv=False)
	cmds.formLayout("MAMAO_TabForm")
	
	# START: Performances Settings Frame
	cmds.frameLayout("MAMAO_PerformancesSettingsFrame", l="Performances Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
	cmds.formLayout("MAMAO_PerformancesSettingsForm")

	# START: Performances Settings Column #1
	cmds.columnLayout("MAMAO_PerformancesSettingsColumn1", adj=True, cat=("left", 0))
	# Delete object(s) history
	cmds.rowLayout("MAMAO_DeleteHistoryRow", nc=2, cw=(1, 5), cat=(1, "right", 0), ct2=("left", "left"))
	cmds.text(l="")
	cmds.checkBoxGrp("MAMAO_DeleteHistory", l="", l1="Delete object(s) history", v1=1, h=18, cw2=(2, 140), cc=(partial(MAMAO_controlsCallback)))
	cmds.setParent("..")
	# Suspend viewport refresh
	cmds.rowLayout("MAMAO_SuspendRefreshRow", nc=2, cw=(1, 5), cat=(1, "right", 0), ct2=("left", "left"))
	cmds.text(l="")
	cmds.checkBoxGrp("MAMAO_SuspendRefresh", l="", l1="Suspend viewport refresh", v1=1, h=18, cw2=(2, 140), cc=(partial(MAMAO_controlsCallback)))
	cmds.setParent("..")
	# Hide UV Editor
	cmds.rowLayout("MAMAO_HideUVEditorRow", nc=2, cw=(1, 25), cat=(1, "right", 0), ct2=("left", "left"))
	cmds.text(l="")
	cmds.checkBoxGrp("MAMAO_HideUVEditor", l="", l1="Hide UV Editor", v1=0, h=18, cw2=(2, 140), cc=(partial(MAMAO_controlsCallback)))
	cmds.setParent("..")
	# Turn off undo
	cmds.rowLayout("MAMAO_TurnOffUndoRow", nc=2, cw=(1, 5), cat=(1, "right", 0), ct2=("left", "left"))
	cmds.text(l="")
	cmds.checkBoxGrp("MAMAO_TurnOffUndo", l="", l1="Turn off undo", v1=0, h=18, cw2=(2, 140), cc=(partial(MAMAO_controlsCallback)))
	cmds.setParent("..")
	# Separation
	cmds.rowLayout(h=1)
	cmds.setParent("..")

	# END: Performances Settings Column #1
	cmds.setParent("..")
	
	# END: Performances Settings Frame
	cmds.setParent("..")
	cmds.setParent("..")
	
	# START: Window Settings Frame
	cmds.frameLayout("MAMAO_WindowSettingsFrame", l="Window Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
	cmds.formLayout("MAMAO_WindowSettingsForm")
	
	# START: Window Settings Column #1
	cmds.columnLayout("MAMAO_WindowSettingsColumn1", adj=True, cat=("left", 0))
	# Window transparency
	cmds.rowLayout("MAMAO_WindowTransparencyRow", nc=2, cw=(1, 5), cat=(1, "right", 0), ct2=("left", "left"))
	cmds.text(l="")
	cmds.checkBoxGrp("MAMAO_WindowTransparency", l="", l1="Window transparency", v1=0, h=18, cw2=(2, 140), cc=(partial(MAMAO_controlsCallback)))
	cmds.setParent("..")
	# Save window size
	cmds.rowLayout("MAMAO_SaveWindowSizeRow", nc=2, cw=(1, 5), cat=(1, "right", 0), ct2=("left", "left"))
	cmds.text(l="")
	cmds.checkBoxGrp("MAMAO_SaveWindowSize", l="", l1="Save window size", v1=1, h=18, cw2=(2, 140), cc=(partial(MAMAO_controlsCallback)))
	cmds.setParent("..")
	# Parent to UV Editor
	cmds.rowLayout("MAMAO_ParentUVEditorRow", nc=2, cw=(1, 5), cat=(1, "right", 0), ct2=("left", "left"))
	cmds.text(l="")
	cmds.checkBoxGrp("MAMAO_ParentUVEditor", l="", l1="Parent to UV Editor", v1=1, h=18, cw2=(2, 140), cc=(partial(MAMAO_ParentUVEditorCallback)))
	cmds.setParent("..")
	# Separation
	cmds.rowLayout(h=1)
	cmds.setParent("..")
	# END: Window Settings Column #1
	cmds.setParent("..")
	
	# END: Window Settings Frame
	cmds.setParent("..")
	cmds.setParent("..")
	
	# END: Tab Layout
	cmds.setParent("..")
	cmds.setParent("..")
	
	# Buttons
	cmds.formLayout("MAMAO_ButtonForm")
	cmds.iconTextButton("MAMAO_executeButton", l="Save", c=(partial(MAMAO_buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=False)
	cmds.iconTextButton("MAMAO_closeButton", l="Close", c=(partial(MAMAO_buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
	cmds.setParent("..")
	
	# END: Window Form
	cmds.setParent("..")
	
	# Window Form Layout
	cmds.formLayout("MAMAO_WindowForm", e=True,
					af=[("MAMAO_TabLayout", "top", 0), ("MAMAO_TabLayout", "left", 0), ("MAMAO_TabLayout", "right", 0)],
					ac=("MAMAO_TabLayout", "bottom", 5, "MAMAO_ButtonForm"))
	cmds.formLayout("MAMAO_WindowForm", e=True,
					an=("MAMAO_ButtonForm", "top"),
					af=[("MAMAO_ButtonForm", "left", 5), ("MAMAO_ButtonForm", "right", 5), ("MAMAO_ButtonForm", "bottom", 5)])
	
	# Tabs Form Layout
	cmds.formLayout("MAMAO_TabForm", e=True,
					af=[("MAMAO_PerformancesSettingsFrame", "top", 0), ("MAMAO_PerformancesSettingsFrame", "left", 2), ("MAMAO_PerformancesSettingsFrame", "right", 2)],
					an=("MAMAO_PerformancesSettingsFrame", "bottom"))
	cmds.formLayout("MAMAO_TabForm", e=True,
					ac=("MAMAO_WindowSettingsFrame", "top", 0, "MAMAO_PerformancesSettingsFrame"),
					af=[("MAMAO_WindowSettingsFrame", "left", 2), ("MAMAO_WindowSettingsFrame", "right", 2)],
					an=("MAMAO_WindowSettingsFrame", "bottom"))
	
	# Columns Form Layout
	cmds.formLayout("MAMAO_PerformancesSettingsForm", e=True,
					af=[("MAMAO_PerformancesSettingsColumn1", "top", 0), ("MAMAO_PerformancesSettingsColumn1", "left", 0), ("MAMAO_PerformancesSettingsColumn1", "right", 0)],
					an=("MAMAO_PerformancesSettingsColumn1", "bottom"))
	cmds.formLayout("MAMAO_WindowSettingsForm", e=True,
					af=[("MAMAO_WindowSettingsColumn1", "top", 0), ("MAMAO_WindowSettingsColumn1", "left", 0), ("MAMAO_WindowSettingsColumn1", "right", 0)],
					an=("MAMAO_WindowSettingsColumn1", "bottom"))				
	
	# Buttons Form Layout
	cmds.formLayout("MAMAO_ButtonForm", e=True,
					af=("MAMAO_executeButton", "top", 0),
					ap=[("MAMAO_executeButton", "left", 0, 0), ("MAMAO_executeButton", "right", 2, 50)],
					an=("MAMAO_executeButton", "bottom"))
	cmds.formLayout("MAMAO_ButtonForm", e=True,
					af=("MAMAO_closeButton", "top", 0),
					ap=[("MAMAO_closeButton", "left", 2, 50), ("MAMAO_closeButton", "right", 0, 100)],
					an=("MAMAO_closeButton", "bottom"))
	
	# Window Setup
	MAMAO_windowSetup()
	# Show window
	cmds.showWindow("MultiAutomaticMappingAdvancedOptions")
	if(cmds.window("MultiAutomaticMappingWin", ex=True) is True):
		winMarginLeft = (cmds.window("MultiAutomaticMappingWin", q=True, w=True)-190)/2
		winMarginTop = (cmds.window("MultiAutomaticMappingWin", q=True, h=True)-270)/2
		winLeftEdge = cmds.window("MultiAutomaticMappingWin", q=True, le=True)+winMarginLeft
		winTopEdge = cmds.window("MultiAutomaticMappingWin", q=True, te=True)+winMarginTop
		cmds.window("MultiAutomaticMappingAdvancedOptions", e=True, t="Multi Automatic Mapping Advanced Options", le=winLeftEdge, te=winTopEdge)
	# Edit window size
	cmds.window("MultiAutomaticMappingAdvancedOptions", e=True, w=190, h=270, rtf=True, s=False, vis=True)
	# Set focus on window
	cmds.setFocus("MultiAutomaticMappingAdvancedOptions")

class MainWindow(QMainWindow):
	def __init__(self, windowName, windowParent):
		super(MainWindow, self).__init__(windowParent)
		# Window title
		self.setWindowTitle("Multi Automatic Mapping Options")
		# Window object name
		self.setObjectName(windowName)
		# Window type
		self.setWindowFlags(Qt.Window)
		# Save window position
		self.setProperty("saveWindowPref", True)
		
		# Create UI
		self.createUI()
		# Show UI
		self.initUI()
		# Create UI Callbacks
		self.installEventFilter(self)
	
	def eventFilter(self, obj, event):
		if obj == self and cmds.optionVar(q="MAMAO_WindowTransparency") == 1:
			if event.type() == QEvent.WindowDeactivate:
				currentWindow = cmds.window("MultiAutomaticMappingWin", q=True, fw=True)
				if currentWindow != "MultiAutomaticMappingAdvancedOptions":
					self.setWindowOpacity(0.6)
				return True
			elif event.type() == QEvent.WindowActivate:
				self.setWindowOpacity(1)
				return True
			else:
				return False
		else:
			return QMainWindow.eventFilter(self, obj, event)
	
	def closeEvent(self, event):
		if(cmds.window("MultiAutomaticMappingAdvancedOptions", ex=True) is True):
			cmds.deleteUI("MultiAutomaticMappingAdvancedOptions", wnd=True)
		event.accept()
	
	def createUI(self):		
		# If window already opened, delete it
		if(cmds.window("MultiAutomaticMappingWinEmbedded", ex=True) is True):
			cmds.deleteUI("MultiAutomaticMappingWinEmbedded", wnd=True)
		cmds.window("MultiAutomaticMappingWinEmbedded")
		
		# Embed in PyQT UI
		windowControl = MQtUtil.findControl("MultiAutomaticMappingWinEmbedded")
		windowWidget = wrapInstance(long(windowControl), QWidget)
		self.setCentralWidget(windowWidget)
		
		# START: Window Form
		cmds.formLayout("MAM_WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout("MAM_TabLayout", tv=False)
		cmds.formLayout("MAM_TabForm")
	
		# START: Scroll Layout
		cmds.scrollLayout("MAM_ScrollLayout", cr=True, rc=(partial(MAM_scrollResized)), w=480)
		cmds.formLayout("MAM_ScrollForm")
		
		# START: Projection Settings Frame
		cmds.frameLayout("MAM_ProjectionSettingsFrame", l="Projection Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout("MAM_ProjectionSettingsForm")
		
		# START: Projection Settings Column #1
		cmds.columnLayout("MAM_ProjectionSettingsColumn1", adj=True, cat=("left", 0))
		# Projection type
		cmds.rowLayout("MAM_ProjectionTypeRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Projection type:")
		cmds.radioButtonGrp("MAM_ProjectionType", nrb=3, l="", la3=("Tri-planar", "Normal-based", "Automatic"), sl=3, cw4=(0, 115, 135, 120), onc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Multiple objects
		cmds.rowLayout("MAM_MultipleObjectsRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Projection position:")
		cmds.radioButtonGrp("MAM_MultipleObjects", nrb=3, l="", la3=("Object's pivot", "Bounding box center", "Last object's pivot"), sl=1, cw4=(0, 115, 135, 120), onc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Separation
		MAM_separationRow(3, 2, 4)
		# Front axis
		cmds.rowLayout("MAM_FrontAxisRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Front axis:")
		cmds.optionMenuGrp("MAM_FrontAxis", l="", cw2=(0, 140), cc=(partial(MAM_controlsCallback)))
		cmds.menuItem(l="X")
		cmds.menuItem(l="Y")
		cmds.optionMenuGrp("MAM_FrontAxis", e=True, v="Y")
		cmds.setParent("..")
		# Projection width
		cmds.rowLayout("MAM_ProjectionWidthRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Projection width:")
		cmds.floatFieldGrp("MAM_ProjectionWidth", l="", pre=4, v1=800, cw2=(1, 80), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Projection height
		cmds.rowLayout("MAM_ProjectionHeightRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Projection height:")
		cmds.floatFieldGrp("MAM_ProjectionHeight", l="", pre=4, v1=800, cw2=(1, 80), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Separation
		MAM_separationRow(3, 2, 3)
		# Reset rotations
		cmds.rowLayout("MAM_ResetRotationsRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Reset rotations:")
		cmds.checkBoxGrp("MAM_ResetRotations", l="", v1=1, h=18, cw2=(2, 140), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Projection order
		cmds.rowLayout("MAM_ProjectionOrderRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Projection order:")
		cmds.optionMenuGrp("MAM_ProjectionOrder", l="", cw2=(0, 140), cc=(partial(MAM_controlsCallback)))
		cmds.menuItem(l="X Y Z")
		cmds.menuItem(l="X Z Y")
		cmds.menuItem(d=True)
		cmds.menuItem(l="Y X Z")
		cmds.menuItem(l="Y Z X")
		cmds.menuItem(d=True)
		cmds.menuItem(l="Z X Y")
		cmds.menuItem(l="Z Y X")
		cmds.optionMenuGrp("MAM_ProjectionOrder", e=True, v="X Y Z")
		cmds.setParent("..")
		# Angle threshold
		cmds.rowLayout("MAM_ProjectionAngleRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Angle threshold:")
		cmds.floatSliderGrp("MAM_ProjectionAngle", l="", f=True, pre=4, v=80, min=0, max=180, cw3=(1, 80, 120), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Separation
		MAM_separationRow(3, 2, 4)
		# Cleanup UVs
		cmds.rowLayout("MAM_CleanupUVsRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Cleanup UVs:")
		cmds.checkBoxGrp("MAM_CleanupUVs", l="", v1=1, h=18, cw2=(2, 140), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Cut hard edges
		cmds.rowLayout("MAM_CutHardEdgesRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Cut hard edges:")
		cmds.checkBoxGrp("MAM_CutHardEdges", l="", v1=0, cw2=(2, 140), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Projection Settings Column #1
		cmds.setParent("..")
		
		# END: Projection Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# START: Layout Settings Frame
		cmds.frameLayout("MAM_LayoutSettingsFrame", l="Layout Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout("MAM_LayoutSettingsForm")
		
		# START: Layout Settings Column #1
		cmds.columnLayout("MAM_LayoutSettingsColumn1", adj=True, cat=("left", 0))
		
		# Flip reversed
		cmds.rowLayout("MAM_FlipReversedRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Flip reversed:")
		cmds.checkBoxGrp("MAM_FlipReversed", l="", v1=1, cw2=(2, 140), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Separation
		MAM_separationRow(3, 2, 4)
		# Layout UVs
		cmds.rowLayout("MAM_LayoutUVsRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Layout UVs:")
		cmds.checkBoxGrp("MAM_LayoutUVs", l="", v1=0, cw2=(2, 140), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Packing resolution
		cmds.rowLayout("MAM_PackingResolutionRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Packing resolution:")
		cmds.intSliderGrp("MAM_PackingResolution", l="", f=True, v=512, min=64, max=4096, cw3=(1, 80, 120), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Packing iterations
		cmds.rowLayout("MAM_PackingIterationsRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Packing iterations:")
		cmds.intSliderGrp("MAM_PackingIterations", l="", f=True, v=1, min=1, max=50, cw3=(1, 80, 120), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Texture map size
		cmds.rowLayout("MAM_TextureMapSizeRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Texture map size:")
		cmds.optionMenuGrp("MAM_TextureMapSize", l="", cw2=(0, 140), cc=(partial(MAM_controlsCallback)))
		cmds.menuItem(l="8192")
		cmds.menuItem(l="4096")
		cmds.menuItem(l="2048")
		cmds.menuItem(l="1024")
		cmds.menuItem(l="512")
		cmds.menuItem(l="256")
		cmds.menuItem(l="128")
		cmds.menuItem(l="64")
		cmds.menuItem(l="32")
		cmds.optionMenuGrp("MAM_TextureMapSize", e=True, v="512")
		cmds.setParent("..")
		# Shell padding
		cmds.rowLayout("MAM_ShellPaddingRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Shell padding:")
		cmds.floatFieldGrp("MAM_ShellPadding", l="", pre=4, v1=3, cw2=(1, 80), cc=(partial(MAM_controlsCallback)))
		cmds.setParent("..")
		# Scale mode
		cmds.rowLayout("MAM_ScaleModeRow", nc=2, cw=(1, 115), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Scale mode:")
		cmds.optionMenuGrp("MAM_ScaleMode", l="", cw2=(0, 140), cc=(partial(MAM_controlsCallback)))
		cmds.menuItem(l="Off")
		cmds.menuItem(l="Uniform")
		cmds.menuItem(l="Non-uniform")
		cmds.optionMenuGrp("MAM_ScaleMode", e=True, v="Uniform")
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Layout Settings Column #1
		cmds.setParent("..")
		
		# END: Layout Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout("MAM_ButtonForm", nd=150)
		cmds.iconTextButton("MAM_executeButton", l="Project", c=(partial(MAM_buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton("MAM_applyButton", l="Apply", c=(partial(MAM_buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton("MAM_closeButton", l="Close", c=(partial(MAM_buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# MAM_ProjectionWidth popupMenu
		cmds.popupMenu(p="MAM_ProjectionWidth")
		cmds.menuItem(l="Reset", c=("cmds.floatFieldGrp('MAM_ProjectionWidth', e=True, v1=800)\ncmds.optionVar(fv=('MAM_ProjectionWidth', 800))"), ecr=False)
		# MAM_ProjectionHeight popupMenu
		cmds.popupMenu(p="MAM_ProjectionHeight")
		cmds.menuItem(l="Reset", c=("cmds.floatFieldGrp('MAM_ProjectionHeight', e=True, v1=800)\ncmds.optionVar(fv=('MAM_ProjectionHeight', 800))"), ecr=False)
		# MAM_ProjectionAngle popupMenu
		cmds.popupMenu(p="MAM_ProjectionAngle")
		cmds.menuItem(l="Reset", c=("cmds.floatSliderGrp('MAM_ProjectionAngle', e=True, v=80)\ncmds.optionVar(fv=('MAM_ProjectionAngle', 80))"), ecr=False)
		# MAM_PackingResolution popupMenu
		cmds.popupMenu(p="MAM_PackingResolution")
		cmds.menuItem(l="Reset", c=("cmds.intSliderGrp('MAM_PackingResolution', e=True, v=512)\ncmds.optionVar(iv=('MAM_PackingResolution', 512))"), ecr=False)
		# MAM_PackingIterations popupMenu
		cmds.popupMenu(p="MAM_PackingIterations")
		cmds.menuItem(l="Reset", c=("cmds.intSliderGrp('MAM_PackingIterations', e=True, v=1)\ncmds.optionVar(iv=('MAM_PackingIterations', 1))"), ecr=False)
		# MAM_ShellPadding popupMenu
		cmds.popupMenu(p="MAM_ShellPadding")
		cmds.menuItem(l="Reset", c=("cmds.floatFieldGrp('MAM_ShellPadding', e=True, v1=3)\ncmds.optionVar(fv=('MAM_ShellPadding', 3))"), ecr=False)
		
		# Window Form Layout
		cmds.formLayout("MAM_WindowForm", e=True,
						af=[("MAM_TabLayout", "top", 0), ("MAM_TabLayout", "left", 0), ("MAM_TabLayout", "right", 0)],
						ac=("MAM_TabLayout", "bottom", 5, "MAM_ButtonForm"))
		cmds.formLayout("MAM_WindowForm", e=True,
						an=("MAM_ButtonForm", "top"),
						af=[("MAM_ButtonForm", "left", 5), ("MAM_ButtonForm", "right", 5), ("MAM_ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout("MAM_TabForm", e=True,
						af=[("MAM_ScrollLayout", "top", 0), ("MAM_ScrollLayout", "left", 0), ("MAM_ScrollLayout", "right", 0), ("MAM_ScrollLayout", "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout("MAM_ScrollForm", e=True,
						af=[("MAM_ProjectionSettingsFrame", "top", 0), ("MAM_ProjectionSettingsFrame", "left", 0), ("MAM_ProjectionSettingsFrame", "right", 0)],
						an=("MAM_ProjectionSettingsFrame", "bottom"))
		cmds.formLayout("MAM_ScrollForm", e=True,
						ac=("MAM_LayoutSettingsFrame", "top", 0, "MAM_ProjectionSettingsFrame"),
						af=[("MAM_LayoutSettingsFrame", "left", 0), ("MAM_LayoutSettingsFrame", "right", 0)],
						an=("MAM_LayoutSettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout("MAM_ProjectionSettingsForm", e=True,
						af=[("MAM_ProjectionSettingsColumn1", "top", 0), ("MAM_ProjectionSettingsColumn1", "left", 0), ("MAM_ProjectionSettingsColumn1", "right", 0)],
						an=("MAM_ProjectionSettingsColumn1", "bottom"))
		cmds.formLayout("MAM_LayoutSettingsForm", e=True,
						af=[("MAM_LayoutSettingsColumn1", "top", 0), ("MAM_LayoutSettingsColumn1", "left", 0), ("MAM_LayoutSettingsColumn1", "right", 0)],
						an=("MAM_LayoutSettingsColumn1", "bottom"))				
		
		# Buttons Form Layout
		cmds.formLayout("MAM_ButtonForm", e=True,
						af=("MAM_executeButton", "top", 0),
						ap=[("MAM_executeButton", "left", 0, 0), ("MAM_executeButton", "right", 2, 50)],
						an=("MAM_executeButton", "bottom"))
		cmds.formLayout("MAM_ButtonForm", e=True,
						af=("MAM_applyButton", "top", 0),
						ap=[("MAM_applyButton", "left", 2, 50), ("MAM_applyButton", "right", 2, 100)],
						an=("MAM_applyButton", "bottom"))
		cmds.formLayout("MAM_ButtonForm", e=True,
						af=("MAM_closeButton", "top", 0),
						ap=[("MAM_closeButton", "left", 2, 100), ("MAM_closeButton", "right", 0, 150)],
						an=("MAM_closeButton", "bottom"))
	
	def initUI(self):
		# Create menu bar
		menubar = self.menuBar()
		
		# Edit menu
		cmds.menu(l="Edit", p="MultiAutomaticMappingWin")
		cmds.menuItem(l="Save Settings", c=(partial(MAM_saveSettings, SAVE_SETTINGS)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(MAM_resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem("MAM_AdvancedSettings", l="Advanced Settings", i="advancedSettings.png", c=(partial(MAM_advancedOptions)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True, p="MultiAutomaticMappingWin")
		cmds.menuItem(l="Help on Multi Automatic Mapping Options", i="help.png", command=(partial(helpCmd, helpUrl="/docs/multi-automatic-mapping/")), ecr=False)
		cmds.setParent("..")
		
		# Window Setup
		MAM_windowSetup()
		
		# Show window
		self.show()
		# Edit window size
		cmds.window("MultiAutomaticMappingWin", e=True, rtf=True, s=True, mxb=True)
		if not cmds.windowPref("MultiAutomaticMappingWin", exists=True) or cmds.optionVar(q="MAMAO_SaveWindowSize") == 0:
			cmds.window("MultiAutomaticMappingWin", e=True, w=550, h=415)
		# Set focus on window
		cmds.evalDeferred("import maya.cmds as cmds;cmds.setFocus('MultiAutomaticMappingWin')")
		
def MultiAutomaticMappingOptions(*args, **kwargs):
	parentWindow = True
	for key, value in six.iteritems(kwargs):
		if key == "parent" or key == "p":
			parentWindow = value
	# If window already exists, remove it first
	if(cmds.window("MultiAutomaticMappingWin", ex=True) is True):
		cmds.deleteUI("MultiAutomaticMappingWin", wnd=True)
	# Check if a polyTexturePlacementPanel exists
	MAM_UVEditorPanels = cmds.getPanel(sty="polyTexturePlacementPanel")
	MAM_UVEditor = cmds.scriptedPanel(MAM_UVEditorPanels[0], q=True, ctl=True)
	MAM_UVEditorPanels = MAM_UVEditor.split("|")
	MAM_UVEditor = MAM_UVEditorPanels[0]
	MAM_WindowParent = MQtUtil.mainWindow()
	# Parent the window to the polyTexturePlacementPanel so it stays on top
	MAMAO_windowSetup()
	if(cmds.window(MAM_UVEditor, ex=True) is True and cmds.optionVar(q="MAMAO_ParentUVEditor") == 1 and parentWindow is True):
		MAM_WindowParent = MQtUtil.findControl(MAM_UVEditor)
	MAM_WindowParent = wrapInstance(long(MAM_WindowParent), QWidget)
	# Create window
	global MAM_QWindow
	MAM_QWindow = MainWindow("MultiAutomaticMappingWin", MAM_WindowParent)
