#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.mel as mel
from functools import partial

# for python 3 compatibility
import six

from ...core.gui.options import OptionsWindow, helpCmd

def CleanIntermediateShapes(*args, **kwargs):
	# Create default args
	objects = None
	selection = True
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load SelectSimilar optionVars
	if cmds.optionVar(exists="CIS_SearchScope") is True:
		searchScope = cmds.optionVar(query="CIS_SearchScope")
		if searchScope == 2:
			selection = False
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "selection" or key == "sel":
			selection = value

	shapes_deleted = False
	
	if selection:
		if objects:
			objects = cmds.ls(objects, l=True, type="transform")
		else:
			objects = cmds.ls(sl=True, l=True, type="transform")
	else:
		objects = cmds.ls(l=True, type="transform")
	
	# delete shapeOrig nodes
	for object in objects:
		# get all the transforms in hierarchy
		children = cmds.ls(object, cmds.listRelatives(object, f=True, ad=True, type="transform"), l=True)
		for child in children:
			# get the shapes of child
			shapes = cmds.listRelatives(child, f=True, s=True)
			# do not delete if there is only one shape node
			if shapes is not None and len(shapes) > 1 :
				for shape in shapes:
					# if nothing is connected to the shape node, delete it
					connections = cmds.listConnections(shape)
					if not connections:
						cmds.delete(shape)
						shapes_deleted = True
	
	# Refresh attribute editor if visible
	if cmds.workspaceControl("AttributeEditor", query=True, visible=True) and cmds.workspaceControl("AttributeEditor", query=True, r=True) and shapes_deleted:
		mel.eval("editSelected;")

class CleanIntermediateShapesOptions(OptionsWindow):
	def __init__(self):
		self.windowName = "CleanIntermediateShapesOptionsWin"
		self.pfx = "CIS_"
		kwargs = {"windowSize": [360, 140], 
		          "windowTitle": "Clean Intermediate Shapes Options", 
		          "runLabel": "Cleanup", 
		          "minWindowSize": 180, 
		          "rowOffset": 143, 
				  "preview": False}
		
		super(CleanIntermediateShapesOptions, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		CleanIntermediateShapes()
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/bonustools-mesh/#clean-intermediate-shapes")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Clean Intermediate Shapes Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Selection / Whole Scene
		cmds.rowLayout(self.pfx+"SearchScopeRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Search Scope:")
		cmds.radioButtonGrp(self.pfx+"SearchScope", dtg=self.pfx+"SearchScope", l="", nrb=2, la2=("Selection", "Whole Scene"), sl=1, cw3=(0, 80, 80), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))
