#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.mel as mel
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya
from collections import OrderedDict

# for python 3 compatibility
import six

from ...core.general.selections import getCurrentSel

def MT_GetCurrentSel(*args):
	objects = None
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects

def MT_GetComponentType(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	selList = OpenMaya.MSelectionList()
	
	if selection is not None:
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
	else:
		OpenMaya.MGlobal_getActiveSelectionList(selList)
	
	filterDict = []
	filterDict.append(("v", OpenMaya.MFn.kMeshVertComponent))
	filterDict.append(("fc", OpenMaya.MFn.kMeshPolygonComponent))
	filterDict.append(("eg", OpenMaya.MFn.kMeshEdgeComponent))
	#filterDict.append(("puv", OpenMaya.MFn.kMeshMapComponent))
	#filterDict.append(("pvf", OpenMaya.MFn.kMeshVtxFaceComponent))
	#filterDict.append(("cv", OpenMaya.MFn.kCurveCVComponent))
	filterDict = OrderedDict(filterDict)
	
	for key, filter in six.iteritems(filterDict):
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		try:
			if sel_iter.hasComponents() is True:
				return key
		except:
			pass
	
	return None

def MultiTransform(selection=None):
	currentSel, currentHl, objects = getCurrentSel(selection)
	if selection is not None:
		currentSel = selection
	
	transformNodes = []
	
	if len(objects) <= 1:
		mel.eval('performPolyMove "" 0')
	else:
		selectType = MT_GetComponentType(currentSel)
		
		# Get components type
		if selectType is None:
			currentSel = cmds.polyListComponentConversion(currentSel, tv=True)
			cmds.selectMode(co=True)
			cmds.selectType(v=True)
			selectType = "v"
		if selectType == "v":
			componentsSel = cmds.polyListComponentConversion(currentSel, tv=True)
		elif selectType == "fc":
			componentsSel = cmds.polyListComponentConversion(currentSel, tf=True)
		elif selectType == "eg":
			componentsSel = cmds.polyListComponentConversion(currentSel, te=True)
		
		# Create transform nodes
		if len(componentsSel) > 0:
			selList = OpenMaya.MSelectionList()
			for each in componentsSel:
				try:
					selList.add(each)
				except:
					pass
			
			dagPath = OpenMaya.MDagPath()
			component = OpenMaya.MObject()
			
			# Iterate over selList
			sel_iter = OpenMaya.MItSelectionList(selList)
			iterIndex = 0
			while not sel_iter.isDone():
				selList.getDagPath(iterIndex, dagPath, component)
				dagPath.pop() # Remove shape
				
				componentsList = []
				sel_iter.getStrings(componentsList)
				#componentsList = cmds.ls(componentsList, l=True, fl=True)
				
				transformNode = []
				if selectType == "v":
					transformNode = cmds.polyMoveVertex(componentsList, ch=True)
				elif selectType == "fc":
					transformNode = cmds.polyMoveFacet(componentsList, ch=True)
				elif selectType == "eg":
					transformNode = cmds.polyMoveEdge(componentsList, ch=True)
				
				# Rename node
				transformNode = cmds.rename(transformNode[0], "multiTransform1")
				
				# Add node to transform list
				#transformNodes.extend(transformNode)
				transformNodes.append(transformNode)
				
				iterIndex += 1
				sel_iter.next()
		
		if len(transformNodes) > 0:
			if len(transformNodes) > 1:
				for transformNode in transformNodes:
					if transformNode == transformNodes[len(transformNodes)-1]:
						continue
					# Connect transform node to main transform
					outputsList = ["localCenter", "localDirectionX", "localDirectionY", "localDirectionZ", "localRotateX", "localRotateY", "localRotateZ", "localScaleX", "localScaleY", "localScaleZ", "localTranslateX", "localTranslateY", "localTranslateZ", "offset", "pivotX", "pivotY", "pivotZ", "random", "rotateX", "rotateY", "rotateZ", "scaleX", "scaleY", "scaleZ", "translateX", "translateY", "translateZ"]
					for outputName in outputsList:
						if cmds.attributeQuery(outputName, ex=True, n=transformNodes[len(transformNodes)-1]) is True and cmds.attributeQuery(outputName, ex=True, n=transformNode) is True:
							cmds.connectAttr(transformNodes[len(transformNodes)-1]+"."+outputName, transformNode+"."+outputName, f=True)
					# Disable history display
					cmds.setAttr((transformNode+".isHistoricallyInteresting"), 0)
			
			cmds.select(currentSel, r=True)
			cmds.select(transformNodes[len(transformNodes)-1], add=True)
			cmds.setToolTo("ShowManips")

	return transformNodes

def RandomTransforms(axis="x", local=False, opposite=False, distance=1, edge=0, random=1):
	axis = axis.lower()
	localString = ""

	if axis not in ["x", "y", "z"]:
		return
	
	if local:
		localString = "l"

	# Store selection
	currentSel = cmds.ls(selection=True, long=True)

	if distance > 0:
		if opposite:
			distance *= -1

		facesSel = cmds.polyListComponentConversion(currentSel, toFace=True)

		# Random transform
		transformNodes = MultiTransform(facesSel)
		if transformNodes:
			cmds.setAttr("{0}.random".format(transformNodes[-1]), random)
			cmds.setAttr("{0}.{1}t{2}".format(transformNodes[-1], localString, axis), distance)
		# Random transform
		transformNodes = MultiTransform(facesSel)
		if transformNodes:
			cmds.setAttr("{0}.random".format(transformNodes[-1]), random)
			cmds.setAttr("{0}.{1}t{2}".format(transformNodes[-1], localString, axis), distance*-1)

	if edge > 0:
		if opposite:
			edge *= -1

		edgesSel = cmds.polyListComponentConversion(currentSel, toEdge=True)

		# Random transform
		transformNodes = MultiTransform(edgesSel)
		if transformNodes:
			cmds.setAttr("{0}.random".format(transformNodes[-1]), random)
			cmds.setAttr("{0}.{1}t{2}".format(transformNodes[-1], localString, axis), edge)
		# Random transform
		transformNodes = MultiTransform(edgesSel)
		if transformNodes:
			cmds.setAttr("{0}.random".format(transformNodes[-1]), random)
			cmds.setAttr("{0}.{1}t{2}".format(transformNodes[-1], localString, axis), edge*-1)

		# Restore selection
		cmds.select(currentSel)