from PySide2 import QtCore
from PySide2 import QtGui
from PySide2 import QtWidgets
from shiboken2 import wrapInstance
import maya.OpenMayaUI as omui, maya.OpenMaya as om, maya.cmds as mc, maya.mel as mm, maya.utils, json, math, sys, os, re
from array import array
from random import randint

def shaKi_maya_main_window():
	python_version = sys.version
	shaKi_main_window_ptr = omui.MQtUtil.mainWindow()
	if python_version[:2] == '3.':
		return wrapInstance(int(shaKi_main_window_ptr), QtWidgets.QWidget)
	else:
		return wrapInstance(long(shaKi_main_window_ptr), QtWidgets.QWidget)


class QListWidget_Custom(QtWidgets.QListWidget):

	def __init__(self, name, parent=None):
		super(QListWidget_Custom, self).__init__(parent)

	def keyPressEvent(self, e):
		if e.key() == QtCore.Qt.Key_Delete:
			self._del_item()

	def _del_item(self):
		for item in self.selectedItems():
			self.takeItem(self.row(item))


class QTableWidget_Custom(QtWidgets.QTableWidget):

	def __init__(self, name, parent=None):
		super(QTableWidget_Custom, self).__init__(parent)
		self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
		self.setDragDropMode(QtWidgets.QAbstractItemView.InternalMove)
		self.setDragDropOverwriteMode(False)
		self.setDropIndicatorShown(True)

	def keyPressEvent(self, event):
		if event.key() == QtCore.Qt.Key_Delete:
			self.run_del_key()
		if event.key() == QtCore.Qt.Key_Up:
			self.move_item_up()
		if event.key() == QtCore.Qt.Key_Down:
			self.move_item_down()

	def run_del_key(self):
		mc.undoInfo(ock=True)
		index_list = []
		for model_index in self.selectionModel().selectedRows():
			index = QtCore.QPersistentModelIndex(model_index)
			index_list.append(index)

		shader_list = MainClass_ShaderKit().get_selected_list_items(self)
		x = 0
		kill_count = 0
		for index in index_list:
			check = MainClass_ShaderKit().shaKi_delete_shader(shader_list[x])
			if check is not False:
				self.removeRow(index.row())
				kill_count += 1
			x += 1

		if kill_count > 0:
			om.MGlobal.displayInfo(('Info: Deleted {0} shader').format(kill_count))
		MainClass_ShaderKit().check_if_table_larger_than_widget(self)
		mc.undoInfo(cck=True)

	def move_item_up(self):
		indexes = set(index.row() for index in self.selectedIndexes())
		indexes = list(indexes)
		new_indexes = []
		for i in indexes:
			self.selectRow(i)
			current_row = self.currentRow()
			if current_row > 0:
				item_text = self.takeItem(current_row, 0)
				item_label = self.cellWidget(current_row, 1)
				target_row = current_row - 1
				self.insertRow(target_row)
				self.setItem(target_row, 0, item_text)
				self.setCellWidget(target_row, 1, item_label)
				self.setRowHeight(target_row, 25)
				remove_row = current_row + 1
				self.removeRow(remove_row)
				new_indexes.append(target_row)

		self.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
		for i in new_indexes:
			self.selectRow(i)

		self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

	def move_item_down(self):
		row_count = self.rowCount() - 1
		indexes = set(index.row() for index in self.selectedIndexes())
		indexes = list(indexes)
		indexes.sort(reverse=True)
		new_indexes = []
		for i in indexes:
			self.selectRow(i)
			current_row = self.currentRow()
			if current_row < row_count:
				item_text = self.takeItem(current_row, 0)
				item_label = self.cellWidget(current_row, 1)
				target_row = current_row + 2
				self.insertRow(target_row)
				self.setItem(target_row, 0, item_text)
				self.setCellWidget(target_row, 1, item_label)
				self.setRowHeight(target_row, 25)
				remove_row = current_row
				self.removeRow(remove_row)
				position = current_row + 1
				new_indexes.append(position)

		self.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
		for i in new_indexes:
			self.selectRow(i)

		self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)


class QPushButton_Custom(QtWidgets.QPushButton):
	rmb_clicked = QtCore.Signal()

	def __init__(self, name, parent=None):
		super(QPushButton_Custom, self).__init__(name, parent)

	def mousePressEvent(self, mouse_event):
		if mouse_event.button() == QtCore.Qt.RightButton:
			self.setDown(True)
			return
		super(QPushButton_Custom, self).mousePressEvent(mouse_event)

	def mouseReleaseEvent(self, mouse_event):
		if mouse_event.button() == QtCore.Qt.RightButton:
			self.setDown(False)
			self.rmb_clicked.emit()
			return
		super(QPushButton_Custom, self).mouseReleaseEvent(mouse_event)


class QDialog_Custom_Warning(QtWidgets.QDialog):

	def __init__(self, parent=shaKi_maya_main_window()):
		super(QDialog_Custom_Warning, self).__init__(parent)
		self.setWindowTitle('  Save as')
		maya_version = mc.about(v=True)
		if int(self.maya_version) >= 2022:
			pass
		else:
			self.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowContextHelpButtonHint)
		os_check = sys.platform
		if os_check == 'darwin':
			self.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowStaysOnTopHint)
		self.create_widgets()
		self.create_layout()
		self.create_connections()

	def create_widgets(self):
		self.shaKi_warning_message_label = QtWidgets.QLabel()
		self.shaKi_warning_message_label.setText('')
		self.ok_btn = QtWidgets.QPushButton('Ok')
		self.cancel_btn = QtWidgets.QPushButton('Cancel')

	def create_layout(self):
		message_layout = QtWidgets.QHBoxLayout()
		message_layout.addWidget(self.shaKi_warning_message_label)
		btn_layout = QtWidgets.QHBoxLayout()
		btn_layout.addWidget(self.ok_btn)
		btn_layout.addWidget(self.cancel_btn)
		main_layout = QtWidgets.QVBoxLayout(self)
		main_layout.addLayout(message_layout)
		main_layout.addLayout(btn_layout)

	def create_connections(self):
		self.ok_btn.clicked.connect(self.accept)
		self.cancel_btn.clicked.connect(self.close)


class QDialog_Create_Settings(QtWidgets.QDialog):

	def __init__(self, create_settings_list, parent=shaKi_maya_main_window()):
		super(QDialog_Create_Settings, self).__init__(parent)
		self.create_settings_list = create_settings_list
		self.shaKi_create_settings_win = self
		self.shaKi_create_settings_win.setModal(True)
		self.shaKi_create_settings_win.setWindowTitle('  Create Menu Settings')
		maya_version = mc.about(v=True)
		if int(maya_version) >= 2022:
			pass
		else:
			self.shaKi_create_settings_win.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowContextHelpButtonHint)
		os_check = sys.platform
		if os_check == 'darwin':
			self.shaKi_create_settings_win.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowStaysOnTopHint)
		self.shaKi_create_settings_win.setMinimumSize(300, 400)
		self.shaKi_create_settings_available_renderer = mc.renderer(q=True, ava=True)
		self.MCSK = MainClass_ShaderKit()
		self.shaKi_create_setings_maya_shader_lib = self.MCSK.shaKi_maya_shader_lib
		self.shaKi_create_setings_maya_shader_lib = self.MCSK.shaKi_arnold_shader_lib
		self.shaKi_create_setings_redshift_shader_lib = self.MCSK.shaKi_redshift_shader_lib
		self.load_default_json()
		self.create_default_shader_libs()
		self.create_widgets()
		self.create_layout()
		self.create_connections()
		self.shaKi_create_settings_win.setWindowIcon(QtGui.QIcon(self.MCSK.icon_RS_logo))

	def load_default_json(self):
		try:
			json_file = self.MCSK.shaKi_user_path + 'Shader_Kit_Settings_Default.json'
			with open(json_file) as (f):
				self.json_data_lib = json.load(f)
			self.shaKi_default_ID_lib = self.json_data_lib['ID']
			del self.json_data_lib['ID']
		except IOError:
			self.MCSK.shaKi_message_box('Info', "Can't find the Shader_Kit_Settings_Default.json file in the current path.\nCurrent path: %s\nPlease make sure the file is in the correct folder." % self.MCSK.shaKi_user_path)

	def create_default_shader_libs(self):
		self.maya_default_shaders = self.json_data_lib['Maya']
		self.shaKi_default_shader_lib_list = [self.maya_default_shaders]
		self.shaKi_user_shader_lib_list = [self.MCSK.shaKi_maya_shader_lib]
		for i in self.shaKi_create_settings_available_renderer:
			if i == 'arnold':
				self.arnold_default_shaders = self.json_data_lib['Arnold']
				self.shaKi_default_shader_lib_list.append(self.arnold_default_shaders)
				self.shaKi_user_shader_lib_list.append(self.MCSK.shaKi_arnold_shader_lib)
			if i == 'redshift':
				self.redshift_default_shaders = self.json_data_lib['Redshift']
				self.shaKi_default_shader_lib_list.append(self.redshift_default_shaders)
				self.shaKi_user_shader_lib_list.append(self.MCSK.shaKi_redshift_shader_lib)
			if i == 'vray':
				self.vray_default_shaders = self.json_data_lib['VRay']
				self.shaKi_default_shader_lib_list.append(self.vray_default_shaders)
				self.shaKi_user_shader_lib_list.append(self.MCSK.shaKi_vray_shader_lib)
			else:
				continue

	def setup_renderer_tables(self, table_list, shader_lib_list, user_lib_list):
		x = 0
		for table in table_list:
			default_shader_list = shader_lib_list[x]
			user_shader_list = user_lib_list[x]
			table.setRowCount(len(default_shader_list))
			table.setStyleSheet(self.MCSK.shaKi_styleSheet)
			table.setColumnCount(1)
			table.setShowGrid(False)
			table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
			table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectItems)
			h_Header = table.horizontalHeader()
			h_Header.setFixedHeight(0)
			h_Header.setMinimumSectionSize(1)
			h_Header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
			v_Header = table.verticalHeader()
			v_Header.setFixedWidth(0)
			for i in range(len(default_shader_list)):
				self.setup_table_items(table, user_shader_list, i, default_shader_list[i])

			x += 1

	def setup_table_items(self, table, user_shader_list, row, text):
		checkbox = QtWidgets.QCheckBox()
		checkbox.setText('%s' % text)
		if text in user_shader_list:
			checkbox.setChecked(True)
		else:
			checkbox.setChecked(False)
		table.setCellWidget(row, 0, checkbox)
		table.setRowHeight(row, 30)

	def setup_vertical_box_layout(self, layout, wdgs=None, sCM=None):
		if sCM:
			layout.setContentsMargins(sCM[0], sCM[1], sCM[2], sCM[3])
		if wdgs:
			for i in wdgs:
				layout.addWidget(i)

	def create_widgets(self):
		self.shaKi_settings_maya_widget = QtWidgets.QWidget()
		self.shaKi_settings_maya_widget.setVisible(True)
		self.shaKi_settings_arnold_widget = QtWidgets.QWidget()
		self.shaKi_settings_redshift_widget = QtWidgets.QWidget()
		self.shaKi_settings_vray_widget = QtWidgets.QWidget()
		self.shaKi_settings_maya_table = QtWidgets.QTableWidget()
		self.shaKi_settings_arnold_table = QtWidgets.QTableWidget()
		self.shaKi_settings_redshift_table = QtWidgets.QTableWidget()
		self.shaKi_settings_vray_table = QtWidgets.QTableWidget()
		self.shaKi_settings_table_list = [
		 self.shaKi_settings_maya_table]
		for i in self.shaKi_create_settings_available_renderer:
			if i == 'arnold':
				self.shaKi_settings_table_list.append(self.shaKi_settings_arnold_table)
			if i == 'redshift':
				self.shaKi_settings_table_list.append(self.shaKi_settings_redshift_table)
			if i == 'vray':
				self.shaKi_settings_table_list.append(self.shaKi_settings_vray_table)
			else:
				continue

		self.setup_renderer_tables(self.shaKi_settings_table_list, self.shaKi_default_shader_lib_list, self.shaKi_user_shader_lib_list)
		self.shaKi_settings_tab_widget = QtWidgets.QTabWidget()
		self.shaKi_settings_tab_widget.setStyleSheet(self.MCSK.shaKi_styleSheet)
		self.shaKi_settings_tab_widget.setTabPosition(QtWidgets.QTabWidget.North)
		self.shaKi_settings_tab_widget.addTab(self.shaKi_settings_maya_widget, 'Maya')
		for i in self.shaKi_create_settings_available_renderer:
			if i == 'arnold':
				self.shaKi_settings_tab_widget.addTab(self.shaKi_settings_arnold_widget, 'Arnold')
			if i == 'redshift':
				self.shaKi_settings_tab_widget.addTab(self.shaKi_settings_redshift_widget, 'Redshift')
			if i == 'vray':
				self.shaKi_settings_tab_widget.addTab(self.shaKi_settings_vray_widget, 'VRay')
			else:
				continue

		self.shaKi_settings_save_btn = QPushButton_Custom('Save')
		self.MCSK.setup_button(self.shaKi_settings_save_btn, style=self.MCSK.shaKi_styleSheet, tip='Save shader selection', h=30)
		self.shaKi_settings_cancel_btn = QPushButton_Custom('Cancel')
		self.MCSK.setup_button(self.shaKi_settings_cancel_btn, style=self.MCSK.shaKi_styleSheet, tip='Discard changes and close window', h=30)
		self.shaKi_settings_clear_btn = QPushButton_Custom('Clear')
		self.MCSK.setup_button(self.shaKi_settings_clear_btn, style=self.MCSK.shaKi_styleSheet, tip='Clear Checkboxes', h=30)
		self.shaKi_settings_reset_btn = QPushButton_Custom('Reset')
		self.MCSK.setup_button(self.shaKi_settings_reset_btn, style=self.MCSK.shaKi_styleSheet, tip='Reset Checkboxes', h=30)

	def create_layout(self):
		shaKi_settings_maya_layout = QtWidgets.QVBoxLayout()
		self.setup_vertical_box_layout(shaKi_settings_maya_layout, wdgs=[self.shaKi_settings_maya_table], sCM=[0, 0, 0, 0])
		shaKi_settings_arnold_layout = QtWidgets.QVBoxLayout()
		self.setup_vertical_box_layout(shaKi_settings_arnold_layout, wdgs=[self.shaKi_settings_arnold_table], sCM=[0, 0, 0, 0])
		shaKi_settings_redshift_layout = QtWidgets.QVBoxLayout()
		self.setup_vertical_box_layout(shaKi_settings_redshift_layout, wdgs=[self.shaKi_settings_redshift_table], sCM=[0, 0, 0, 0])
		shaKi_settings_vray_layout = QtWidgets.QVBoxLayout()
		self.setup_vertical_box_layout(shaKi_settings_vray_layout, wdgs=[self.shaKi_settings_vray_table], sCM=[0, 0, 0, 0])
		self.shaKi_settings_maya_widget.setLayout(shaKi_settings_maya_layout)
		self.shaKi_settings_arnold_widget.setLayout(shaKi_settings_arnold_layout)
		self.shaKi_settings_redshift_widget.setLayout(shaKi_settings_redshift_layout)
		self.shaKi_settings_vray_widget.setLayout(shaKi_settings_vray_layout)
		shaKi_settings_btns_layout = QtWidgets.QHBoxLayout()
		shaKi_settings_btns_layout.setSpacing(1)
		shaKi_settings_btns_layout.setContentsMargins(0, 0, 0, 0)
		shaKi_settings_btns_layout.addWidget(self.shaKi_settings_save_btn)
		shaKi_settings_btns_layout.addWidget(self.shaKi_settings_cancel_btn)
		shaKi_settings_btns_layout.addWidget(self.shaKi_settings_clear_btn)
		shaKi_settings_btns_layout.addWidget(self.shaKi_settings_reset_btn)
		shaKi_prefs_main_layout = QtWidgets.QVBoxLayout(self)
		shaKi_prefs_main_layout.setSpacing(0)
		shaKi_prefs_main_layout.setContentsMargins(0, 0, 0, 0)
		shaKi_prefs_main_layout.addWidget(self.shaKi_settings_tab_widget)
		shaKi_prefs_main_layout.addLayout(shaKi_settings_btns_layout)

	def create_connections(self):
		self.shaKi_settings_save_btn.clicked.connect(self.shaKi_create_settings_save)
		self.shaKi_settings_cancel_btn.clicked.connect(self.shaKi_create_settings_cancel)
		self.shaKi_settings_clear_btn.clicked.connect(lambda : self.shaKi_create_settings_reset_clear(False))
		self.shaKi_settings_reset_btn.clicked.connect(lambda : self.shaKi_create_settings_reset_clear(True))

	def shaKi_create_settings_save(self):
		export_dict = {}
		export_dict['ID'] = self.shaKi_default_ID_lib
		tmp_list = []
		update_create_list = []
		selection_check = []
		for i in self.shaKi_create_settings_available_renderer:
			if i == 'arnold':
				pass
			else:
				export_dict['Arnold'] = []
			if i == 'redshift':
				pass
			else:
				export_dict['Redshift'] = []
			if i == 'vray':
				pass
			else:
				export_dict['VRay'] = []

		for i in range(len(self.shaKi_settings_table_list)):
			table = self.shaKi_settings_table_list[i]
			rows = table.rowCount()
			key = self.shaKi_settings_tab_widget.tabText(i)
			for i in range(rows):
				cell_widget = table.cellWidget(i, 0)
				box_isChecked = cell_widget.isChecked()
				if box_isChecked == True:
					tmp_list.append(cell_widget.text())
					update_create_list.append(cell_widget.text())

			export_dict[('{0}').format(key)] = tmp_list
			if len(tmp_list) == 0:
				selection_check.append(False)
			else:
				selection_check.append(True)
			tmp_list = []

		if True in selection_check:
			json_file = self.MCSK.shaKi_user_path + 'Shader_Kit_Settings_User.json'
			with open(json_file, 'w') as (file_for_write):
				json.dump(export_dict, file_for_write, indent=4)
			self.shaKi_update_create_shader_list(update_create_list)
			self.close()
		else:
			self.MCSK.shaKi_message_box('Warning', 'No shader selected. Please select a shader to continue.')

	def shaKi_update_create_shader_list(self, shader_list):
		self.create_settings_list.clear()
		for i in shader_list:
			self.create_settings_list.addItem(('{0}').format(i))

	def shaKi_create_settings_cancel(self):
		self.close()

	def shaKi_create_settings_reset_clear(self, state):
		for i in range(len(self.shaKi_settings_table_list)):
			table = self.shaKi_settings_table_list[i]
			rows = table.rowCount()
			for i in range(rows):
				cell_widget = table.cellWidget(i, 0)
				cell_widget.setChecked(state)


class MainClass_ShaderKit(QtWidgets.QDialog):
	shaKi_instance = None

	@classmethod
	def show_shaKi_dialog(cls):
		if not cls.shaKi_instance:
			cls.shaKi_instance = MainClass_ShaderKit()
		if cls.shaKi_instance.isHidden():
			cls.shaKi_instance.show()
		else:
			cls.shaKi_instance.raise_()
			cls.shaKi_instance

	def __init__(self, parent=shaKi_maya_main_window()):
		super(MainClass_ShaderKit, self).__init__(parent)
		self.shaKi_user_path = self.get_asset_path()
		self.python_version = sys.version
		self.shader_kit_window = self
		self.shader_kit_window.setMinimumWidth(200)
		self.shader_kit_window.setObjectName('RS_Shader_Kit')
		self.maya_version = mc.about(v=True)
		if int(self.maya_version) >= 2022:
			pass
		else:
			self.shader_kit_window.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowContextHelpButtonHint)
		os_check = sys.platform
		if os_check == 'darwin':
			self.shader_kit_window.setWindowFlags(self.windowFlags() ^ QtCore.Qt.WindowStaysOnTopHint)
		self.filter_enabled_check = False
		self.shaKi_updated_create_list_after_save = []
		self.shaKi_available_renderer = mc.renderer(q=True, ava=True)
		self.shaKi_read_json_file()
		self.shaKi_create_shader_libs()
		self.shaKi_create_styleSheet()
		self.shaKi_load_images()
		self.shaKi_create_pageSizes()
		self.shaKi_create_widgets()
		self.shaKi_create_layouts()
		self.shaKi_create_connections()
		self.shaKi_create_libraries()
		self.shaKi_change_active_page('  Shader Kit', 30, False)
		self.shader_kit_window.setWindowIcon(QtGui.QIcon(self.icon_RS_logo))

	def get_asset_path(self):
		user_path = os.path.expanduser("~").replace("\\", "/") + "/maya/" + str(mc.about(version=True)) + "/scripts"
		if int(mc.about(version=True)) >= 2023:
			user_path = os.path.expanduser("~").replace("\\", "/") + "/Documents/maya/" + str(mc.about(version=True)) + "/scripts"
		asset_path = user_path + "/Model_Tools/Scripts/Python/RSTools/RS_Assets/"
		return asset_path

	def shaKi_convert_data_to_dict(self, data):
		tmp_lib = data[0]
		keys = list(tmp_lib)
		values = list(tmp_lib.values())
		for i in range(len(values)):
			values[i] = eval(values[i])

		tmp_dict = {keys[i]:values[i] for i in range(len(keys))}
		return tmp_dict

	def shaKi_read_json_file(self):
		self.shaKi_id_lib = []
		self.shaKi_maya_shader_lib = []
		self.shaKi_arnold_shader_lib = []
		self.shaKi_redshift_shader_lib = []
		self.shaKi_vray_shader_lib = []
		try:
			json_file = self.shaKi_user_path + 'Shader_Kit_Settings_User.json'
			with open(json_file) as (f):
				data_lib = json.load(f)
			id_tmp = data_lib['ID']
			self.shaKi_id_lib = self.shaKi_convert_data_to_dict(id_tmp)
			self.shaKi_maya_shader_lib = data_lib['Maya']
			for i in self.shaKi_available_renderer:
				if i == 'arnold':
					self.shaKi_arnold_shader_lib = data_lib['Arnold']
				if i == 'redshift':
					self.shaKi_redshift_shader_lib = data_lib['Redshift']
				if i == 'vray':
					self.shaKi_vray_shader_lib = data_lib['VRay']
				else:
					continue

		except IOError:
			self.shaKi_message_box('Info', "Can't find the Shader_Kit_Settings_User.json file in the current path.\nCurrent path: %s\nPlease make sure the file is in the correct folder." % self.shaKi_user_path)

	def shaKi_create_shader_libs(self):
		self.shaKi_maya_version = mc.about(q=True, v=True)
		self.shaKi_shader_library = []
		for i in self.shaKi_maya_shader_lib:
			self.shaKi_shader_library.append(i)

		for i in self.shaKi_available_renderer:
			if i == 'arnold':
				self.shaKi_shader_library += self.shaKi_arnold_shader_lib
			if i == 'redshift':
				self.shaKi_shader_library += self.shaKi_redshift_shader_lib
			if i == 'vray':
				self.shaKi_shader_library += self.shaKi_vray_shader_lib
			else:
				continue

	def shaKi_create_libraries(self):
		self.shaKi_windowTitles = [
		 '  Shader Kit', '  Shader Kit']
		self.shaKi_lib_menuPage = [self.shaKi_shader_page]
		self.shaKi_lib_shaderSettings = [
		 self.shaKi_manager_settings_list, self.shaKi_manager_settings_create, self.shaKi_utilities_settings_fix]
		self.shaKi_lib_shaderSettingsBtn = [
		 self.shaKi_manager_list_btn, self.shaKi_manager_create_btn,
		 self.shaKi_util_fix_btn]
		self.shaKi_lib_settingsBtn = [
		 self.shaKi_lib_shaderSettingsBtn, '']
		if self.python_version[:2] == '3.':
			self.hotkey_library_launch = [{'name': 'ShaderKit', 'command': 'from importlib import reload\nimport RS_Shader_Kit\nreload(RS_Shader_Kit)\nRS_Shader_Kit.MainClass_ShaderKit.show_shaKi_dialog()'}]
		else:
			self.hotkey_library_launch = [{'name': 'ShaderKit', 'command': 'import RS_Shader_Kit\nreload(RS_Shader_Kit)\nRS_Shader_Kit.MainClass_ShaderKit.show_shaKi_dialog()'}]

	def shaKi_load_images(self):
		self.icon_RS_logo = QtGui.QPixmap('%sicon_RS_logo.png' % self.shaKi_user_path)
		self.shaKi_icon_shader_kit_active = QtGui.QPixmap('%sshader_kit_active' % self.shaKi_user_path)
		self.shaKi_icon_shader_kit_inactive = QtGui.QPixmap('%sshader_kit_inactive.png' % self.shaKi_user_path)
		self.shaKi_icon_shader_kit_settings = QtGui.QPixmap('%sshader_kit_settings.png' % self.shaKi_user_path)
		self.shaKi_icon_shader_kit_save = QtGui.QPixmap('%sshader_kit_save.png' % self.shaKi_user_path)
		self.shaKi_icon_expand = QtGui.QPixmap('%sicon_expand.png' % self.shaKi_user_path)
		self.shaKi_icon_collapse = QtGui.QPixmap('%sicon_collapse.png' % self.shaKi_user_path)
		self.shaKi_icon_manager_list_btn = QtGui.QPixmap('%sicon_manager_list.png' % self.shaKi_user_path)
		self.shaKi_icon_manager_create_btn = QtGui.QPixmap('%sicon_manager_create.png' % self.shaKi_user_path)
		self.shaKi_icon_manager_assign_btn = QtGui.QPixmap('%sicon_manager_assign.png' % self.shaKi_user_path)
		self.shaKi_icon_manager_select_btn = QtGui.QPixmap('%sicon_manager_select.png' % self.shaKi_user_path)
		self.shaKi_icon_util_fix_btn = QtGui.QPixmap('%sicon_util_fix.png' % self.shaKi_user_path)
		self.shaKi_icon_util_reassign_btn = QtGui.QPixmap('%sicon_util_reassign.png' % self.shaKi_user_path)
		self.shaKi_icon_util_ids_btn = QtGui.QPixmap('%sicon_util_id.png' % self.shaKi_user_path)
		self.shaKi_icon_util_delete_btn = QtGui.QPixmap('%sicon_util_unused.png' % self.shaKi_user_path)
		self.shaKi_icon_util_graph_btn = QtGui.QPixmap('%sicon_util_graph.png' % self.shaKi_user_path)

	def setup_button(self, button, style=None, tip=None, icon=None, q_icon=None, obj_name=None, iSize=None, h=None, w=None):
		if tip:
			button.setToolTip('%s' % tip)
		if style:
			button.setStyleSheet(style)
		if obj_name:
			button.setObjectName('%s' % obj_name)
		if icon:
			button.setIcon(QtGui.QPixmap(icon))
		if q_icon:
			button.setIcon(QtGui.QIcon(':%s' % q_icon))
		if iSize:
			button.setIconSize(QtCore.QSize(iSize, iSize))
		if h:
			button.setFixedHeight(h)
		if w:
			button.setFixedWidth(w)

	def setup_line_edit(self, line_edit, style=None, fPolicy=None, height=None, margin=None, placeholder=None, clear_btn=None):
		if fPolicy:
			line_edit.setFocusPolicy(QtCore.Qt.FocusPolicy(fPolicy))
		if height:
			line_edit.setFixedHeight(height)
		if style:
			line_edit.setStyleSheet(style)
		if margin:
			line_edit.setTextMargins(QtCore.QMargins(margin[0], margin[1], margin[2], margin[3]))
		if placeholder:
			line_edit.setPlaceholderText('%s' % placeholder)
		if clear_btn:
			line_edit.setClearButtonEnabled(clear_btn)

	def setup_spin_box(self, spin_box, style=None, sPolicy=None, setMin=None, setMax=None, setStep=None, val=None, obj_name=None, align=None):
		if style:
			spin_box.setStyleSheet(style)
		if sPolicy:
			spin_box.setSizePolicy(sPolicy[0], sPolicy[1])
		if setMin:
			spin_box.setMinimum(setMin)
		if setMax:
			spin_box.setMaximum(setMax)
		if setStep:
			spin_box.setSingleStep(setStep)
		if val:
			spin_box.setValue(val)
		if align:
			spin_box.setAlignment(align)

	def setup_layout_grid(self, grid, sCM=None, sS=None, items=None, iColN=None):
		if sCM:
			grid.setContentsMargins(sCM[0], sCM[1], sCM[2], sCM[3])
		if sS:
			grid.setSpacing(sS)
		if items:
			col = 0
			row = 0
			for i in items:
				grid.addWidget(i, row, col)
				col += 1
				if col == iColN:
					row += 1
					col = 0

	def shaKi_create_widgets(self):
		self.shaKi_menuWidget = QtWidgets.QWidget()
		self.shaKi_menuWidget.setFixedHeight(30)
		self.shaKi_menu_btn_icon = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_menu_btn_icon, style=self.shaKi_styleSheet, tip='Shader Manager', icon=self.shaKi_icon_shader_kit_inactive, obj_name='menuIcon', iSize=30)
		self.shaKi_save_btnIcon = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_save_btnIcon, style=self.shaKi_styleSheet, tip='LMB: Save Shader list\n\nALT: Load Shader list', icon=self.shaKi_icon_shader_kit_save, obj_name='menuIcon', iSize=30)
		self.shaKi_settings_btnIcon = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_settings_btnIcon, style=self.shaKi_styleSheet, tip='Create Menu Settings', icon=self.shaKi_icon_shader_kit_settings, obj_name='menuIcon', iSize=30)
		self.shaKi_stack = QtWidgets.QStackedWidget()
		self.shaKi_stack.setStyleSheet('* { background-color: rgb(70,70,70);}')
		self.shaKi_manager_widget_height = 275
		self.shaKi_manager_table_widget_height = 231
		self.shaKi_manager_header = QtWidgets.QWidget()
		self.shaKi_manager_header.setFixedHeight(25)
		self.shaKi_ui_managerLabel = QtWidgets.QPushButton('  Manager')
		self.setup_button(self.shaKi_ui_managerLabel, tip='LMB: Open / Close section\n\nWhen section is open:\n\nALT: Increase list size\n\nCTRL: Decrease list size', style=self.shaKi_styleSheet, obj_name='label', h=25)
		self.shaKi_ui_managerToggle = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_ui_managerToggle, tip='LMB: Open / Close section\n\nWhen section is open:\n\nALT: Increase list size\n\nCTRL: Decrease list size', style=self.shaKi_styleSheet, icon=self.shaKi_icon_expand, obj_name='toggle', h=25, w=25)
		self.shaKi_ui_manager_widget = QtWidgets.QWidget()
		self.shaKi_ui_manager_widget.setVisible(False)
		self.shaKi_manager_table = QTableWidget_Custom('')
		self.shaKi_manager_table.setStyleSheet(self.shaKi_styleSheet)
		self.shaKi_manager_table.setColumnCount(2)
		self.shaKi_manager_table.setShowGrid(False)
		self.shaKi_manager_table.setFixedHeight(self.shaKi_manager_table_widget_height)
		self.shaKi_manager_table.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
		self.shaKi_manager_table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
		self.shaKi_manager_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
		h_Header = self.shaKi_manager_table.horizontalHeader()
		h_Header.setFixedHeight(0)
		h_Header.setMinimumSectionSize(1)
		h_Header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
		self.shaKi_v_Header = self.shaKi_manager_table.verticalHeader()
		self.shaKi_v_Header.setFixedWidth(0)
		self.shaKi_manager_list_btn = QPushButton_Custom('')
		self.setup_button(self.shaKi_manager_list_btn, style=self.shaKi_styleSheet, tip='List Shader\n\nLMB: Lists all scene shaders\nLMB (If list is not empty): Adds new shaders & removes those that no longer exist\n\nALT: Sort list by name\n\nCTRL: Sort list by label color\n\nRMB: Settings', icon=self.shaKi_icon_manager_list_btn, obj_name='iconSettings', iSize=40)
		self.shaKi_manager_create_btn = QPushButton_Custom('')
		self.setup_button(self.shaKi_manager_create_btn, style=self.shaKi_styleSheet, tip='Create Shader\n\nALT: Duplicate Shader\n\nRMB: Settings', icon=self.shaKi_icon_manager_create_btn, obj_name='iconSettings', iSize=40)
		self.shaKi_manager_assign_btn = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_manager_assign_btn, style=self.shaKi_styleSheet, tip='Assign Shader\n\nLMB: Assign to object\n\nALT: Assign to faces\n\nCTRL: Random Shader assign', icon=self.shaKi_icon_manager_assign_btn, obj_name='icon', iSize=40)
		self.shaKi_manager_select_btn = QPushButton_Custom('')
		self.setup_button(self.shaKi_manager_select_btn, style=self.shaKi_styleSheet, tip='Select\n\nLMB: Attributes\n\nALT: Select Objects\n\nCTRL: Select Objects with the same Shader\n\nShift: Select Shader from current Object', icon=self.shaKi_icon_manager_select_btn, obj_name='icon', iSize=40)
		self.shaKi_utilities_header = QtWidgets.QWidget()
		self.shaKi_utilities_header.setFixedHeight(25)
		self.shaKi_ui_utilitiesLabel = QtWidgets.QPushButton('  Utilities')
		self.setup_button(self.shaKi_ui_utilitiesLabel, style=self.shaKi_styleSheet, obj_name='label', h=25)
		self.shaKi_ui_utilitiesToggle = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_ui_utilitiesToggle, style=self.shaKi_styleSheet, icon=self.shaKi_icon_expand, obj_name='toggle', h=25, w=25)
		self.shaKi_ui_utilities_widget = QtWidgets.QWidget()
		self.shaKi_ui_utilities_widget.setVisible(False)
		self.shaKi_util_fix_btn = QPushButton_Custom('')
		self.setup_button(self.shaKi_util_fix_btn, style=self.shaKi_styleSheet, tip='Fix\n\nLMB: Shading Groups\n\nALT: Prefixes\n\nRMB: Settings', icon=self.shaKi_icon_util_fix_btn, obj_name='iconSettings', iSize=40)
		self.shaKi_util_reassign_btn = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_util_reassign_btn, style=self.shaKi_styleSheet, tip='Reassign Shader\n\nLMB: For selected objects\n\nALT: Entire Scene', icon=self.shaKi_icon_util_reassign_btn, obj_name='icon', iSize=40)
		self.shaKi_util_ids_btn = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_util_ids_btn, style=self.shaKi_styleSheet, tip='Create Material IDs\n\nLMB: Lambert\n\nALT: Surface Shader\n\nSHIFT: Delete IDs', icon=self.shaKi_icon_util_ids_btn, obj_name='icon', iSize=40)
		self.shaKi_util_delete_unused_btn = QPushButton_Custom('')
		self.setup_button(self.shaKi_util_delete_unused_btn, style=self.shaKi_styleSheet, tip='Delete Unused Nodes', icon=self.shaKi_icon_util_delete_btn, obj_name='icon', iSize=40)
		self.shaKi_util_graph_btn = QPushButton_Custom('')
		self.setup_button(self.shaKi_util_graph_btn, style=self.shaKi_styleSheet, tip='Graph Materials\n\nLMB: Graph Materials from selected objects\n\nALT: Add Selected list item to Graph\n\nCTRL: Remove Selected nodes / list items from Graph\n\nSHIFT: Show Input and Output connections of selected nodes', icon=self.shaKi_icon_util_graph_btn, obj_name='icon', iSize=40)
		self.shaKi_list_search_label = QtWidgets.QLabel('Search')
		self.shaKi_list_search_label.setFixedWidth(55)
		self.shaKi_list_search_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
		self.shaKi_list_search_qFrame = QtWidgets.QFrame()
		self.shaKi_list_search_qFrame.setFrameShape(QtWidgets.QFrame.HLine)
		self.shaKi_list_search_qFrame.setStyleSheet(self.shaKi_styleSheet)
		self.shaKi_list_search_qFrame.setFixedHeight(1)
		self.shaKi_list_search_btn = QtWidgets.QPushButton()
		self.setup_button(self.shaKi_list_search_btn, style=self.shaKi_styleSheet, tip='Search Filter\n\nWhen the filter is active (white icon):\nLMB: Click to undo search filter', q_icon='search.png', w=30, h=30, obj_name='search')
		self.shaKi_list_search_btn.setEnabled(False)
		self.shaKi_list_search_line = QtWidgets.QLineEdit()
		self.setup_line_edit(self.shaKi_list_search_line, style=self.shaKi_styleSheet, placeholder='', height=30, clear_btn=True)
		self.shaKi_list_label_label = QtWidgets.QLabel('Labels')
		self.shaKi_list_label_label.setFixedWidth(55)
		self.shaKi_list_label_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
		self.shaKi_list_label_qFrame = QtWidgets.QFrame()
		self.shaKi_list_label_qFrame.setFrameShape(QtWidgets.QFrame.HLine)
		self.shaKi_list_label_qFrame.setStyleSheet(self.shaKi_styleSheet)
		self.shaKi_list_label_qFrame.setFixedHeight(1)
		self.shaKi_label_colorA = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorA, style='* { background-color: rgb(255,111,104);}', h=25)
		self.shaKi_label_colorB = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorB, style='* { background-color: rgb(254,183,116);}', h=25)
		self.shaKi_label_colorC = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorC, style='* { background-color: rgb(252,255,128);}', h=25)
		self.shaKi_label_colorD = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorD, style='* { background-color: rgb(174,248,160);}', h=25)
		self.shaKi_label_colorE = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorE, style='* { background-color: rgb(155,246,255);}', h=25)
		self.shaKi_label_colorF = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorF, style='* { background-color: rgb(143,186,255);}', h=25)
		self.shaKi_label_colorG = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorG, style='* { background-color: rgb(255,175,255);}', h=25)
		self.shaKi_label_colorH = QPushButton_Custom('')
		self.setup_button(self.shaKi_label_colorH, style='* { background-color: rgb(255,255,252);}', h=25)
		self.shaKi_create_shaderList = QListWidget_Custom('')
		self.shaKi_create_shaderList.setStyleSheet(self.shaKi_styleSheet)
		self.shaKi_create_shaderList.setFixedHeight(200)
		self.shaKi_create_shaderList.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
		for i in self.shaKi_shader_library:
			self.shaKi_create_shaderList.addItem(i)

		self.shaKi_fixScope_label = QtWidgets.QLabel('Scope')
		self.shaKi_fixScope_label.setFixedWidth(55)
		self.shaKi_fixScope_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
		self.shaKi_fixScope_qFrame = QtWidgets.QFrame()
		self.shaKi_fixScope_qFrame.setFrameShape(QtWidgets.QFrame.HLine)
		self.shaKi_fixScope_qFrame.setStyleSheet(self.shaKi_styleSheet)
		self.shaKi_fixScope_qFrame.setFixedHeight(1)
		self.shaKi_fixScope_selection_rb = QtWidgets.QRadioButton('Selection')
		self.shaKi_fixScope_selection_rb.setChecked(True)
		self.shaKi_fixScope_scene_rb = QtWidgets.QRadioButton('Scene')
		self.shaKi_fixScope_btnGrp = QtWidgets.QButtonGroup()
		self.shaKi_fixScope_btnGrp.addButton(self.shaKi_fixScope_selection_rb)
		self.shaKi_fixScope_btnGrp.addButton(self.shaKi_fixScope_scene_rb)
		self.shaKi_manager_settings_list = QtWidgets.QWidget()
		self.shaKi_manager_settings_create = QtWidgets.QWidget()
		self.shaKi_utilities_settings_fix = QtWidgets.QWidget()
		self.shaKi_shader_settings_stack = QtWidgets.QStackedWidget()
		self.shaKi_shader_settings_stack.setStyleSheet('* { background-color: rgb(55,55,55); border: none;}')
		self.shaKi_shader_settings_stack.setMinimumHeight(30)
		self.shaKi_shader_settings_stack.setContentsMargins(0, 5, 0, 0)
		self.shaKi_shader_settings_stack.setVisible(False)
		self.shaKi_shader_widget_lib = [
		 self.shaKi_ui_manager_widget, self.shaKi_ui_utilities_widget]
		self.shaKi_shader_toggle_lib = [self.shaKi_ui_managerToggle, self.shaKi_ui_utilitiesToggle]

	def shaKi_create_layouts(self):
		shaKi_menu_layout = QtWidgets.QHBoxLayout()
		shaKi_menu_layout.setContentsMargins(0, 0, 0, 0)
		shaKi_menu_layout.setSpacing(0)
		shaKi_menu_layout.addWidget(self.shaKi_menu_btn_icon)
		shaKi_menu_layout.addStretch()
		shaKi_menu_layout.addWidget(self.shaKi_save_btnIcon)
		shaKi_menu_layout.addWidget(self.shaKi_settings_btnIcon)
		self.shaKi_menuWidget.setLayout(shaKi_menu_layout)
		shaKi_manager_header_layout = QtWidgets.QHBoxLayout()
		shaKi_manager_header_layout.setContentsMargins(0, 0, 0, 0)
		shaKi_manager_header_layout.setSpacing(0)
		shaKi_manager_header_layout.addWidget(self.shaKi_ui_managerLabel)
		shaKi_manager_header_layout.addWidget(self.shaKi_ui_managerToggle)
		self.shaKi_manager_header.setLayout(shaKi_manager_header_layout)
		shaKi_manager_table_layout = QtWidgets.QVBoxLayout()
		shaKi_manager_table_layout.setContentsMargins(2, 0, 2, 0)
		shaKi_manager_table_layout.setSpacing(0)
		shaKi_manager_table_layout.addWidget(self.shaKi_manager_table)
		shaKi_manager_btn_layout = QtWidgets.QGridLayout()
		self.setup_layout_grid(shaKi_manager_btn_layout, sCM=[2, 0, 2, 0], sS=2, items=[
		 self.shaKi_manager_list_btn, self.shaKi_manager_create_btn,
		 self.shaKi_manager_assign_btn, self.shaKi_manager_select_btn], iColN=4)
		shaKi_manager_layout = QtWidgets.QVBoxLayout()
		shaKi_manager_layout.setContentsMargins(0, 0, 0, 0)
		shaKi_manager_layout.setSpacing(2)
		shaKi_manager_layout.addLayout(shaKi_manager_table_layout)
		shaKi_manager_layout.addLayout(shaKi_manager_btn_layout)
		self.shaKi_ui_manager_widget.setLayout(shaKi_manager_layout)
		shaKi_utilities_header_layout = QtWidgets.QHBoxLayout()
		shaKi_utilities_header_layout.setContentsMargins(0, 0, 0, 0)
		shaKi_utilities_header_layout.setSpacing(0)
		shaKi_utilities_header_layout.addWidget(self.shaKi_ui_utilitiesLabel)
		shaKi_utilities_header_layout.addWidget(self.shaKi_ui_utilitiesToggle)
		self.shaKi_utilities_header.setLayout(shaKi_utilities_header_layout)
		shaKi_utilities_layout = QtWidgets.QGridLayout()
		self.setup_layout_grid(shaKi_utilities_layout, sCM=[2, 0, 2, 0], sS=2, items=[
		 self.shaKi_util_fix_btn, self.shaKi_util_reassign_btn, self.shaKi_util_ids_btn,
		 self.shaKi_util_delete_unused_btn, self.shaKi_util_graph_btn], iColN=4)
		self.shaKi_ui_utilities_widget.setLayout(shaKi_utilities_layout)
		shaKi_search_separator = QtWidgets.QHBoxLayout()
		shaKi_search_separator.setContentsMargins(2, 0, 2, 0)
		shaKi_search_separator.setSpacing(2)
		shaKi_search_separator.addWidget(self.shaKi_list_search_label)
		shaKi_search_separator.addWidget(self.shaKi_list_search_qFrame)
		shaKi_search_layout = QtWidgets.QHBoxLayout()
		shaKi_search_layout.setContentsMargins(0, 0, 0, 0)
		shaKi_search_layout.setSpacing(0)
		shaKi_search_layout.addWidget(self.shaKi_list_search_btn)
		shaKi_search_layout.addWidget(self.shaKi_list_search_line)
		shaKi_label_separator = QtWidgets.QHBoxLayout()
		shaKi_label_separator.setContentsMargins(2, 0, 2, 0)
		shaKi_label_separator.setSpacing(2)
		shaKi_label_separator.addWidget(self.shaKi_list_label_label)
		shaKi_label_separator.addWidget(self.shaKi_list_label_qFrame)
		shaKi_label_layout = QtWidgets.QGridLayout()
		self.setup_layout_grid(shaKi_label_layout, sCM=[0, 0, 0, 0], sS=2, items=[self.shaKi_label_colorA, self.shaKi_label_colorB, self.shaKi_label_colorC,
		 self.shaKi_label_colorD, self.shaKi_label_colorE, self.shaKi_label_colorF, self.shaKi_label_colorG, self.shaKi_label_colorH], iColN=4)
		shaKi_manager_settings_list_layout = QtWidgets.QVBoxLayout()
		shaKi_manager_settings_list_layout.setContentsMargins(8, 2, 8, 0)
		shaKi_manager_settings_list_layout.setSpacing(8)
		shaKi_manager_settings_list_layout.addLayout(shaKi_search_separator)
		shaKi_manager_settings_list_layout.addLayout(shaKi_search_layout)
		shaKi_manager_settings_list_layout.addLayout(shaKi_label_separator)
		shaKi_manager_settings_list_layout.addLayout(shaKi_label_layout)
		shaKi_manager_settings_list_layout.addStretch()
		manager_create_list = QtWidgets.QVBoxLayout()
		manager_create_list.setContentsMargins(2, 2, 2, 0)
		manager_create_list.setSpacing(2)
		manager_create_list.addWidget(self.shaKi_create_shaderList)
		shaKi_manager_settings_create_layout = QtWidgets.QVBoxLayout()
		shaKi_manager_settings_create_layout.setContentsMargins(8, 3, 8, 0)
		shaKi_manager_settings_create_layout.setSpacing(4)
		shaKi_manager_settings_create_layout.addLayout(manager_create_list)
		shaKi_manager_settings_create_layout.addStretch()
		utilities_fix_scope_separator = QtWidgets.QHBoxLayout()
		utilities_fix_scope_separator.setContentsMargins(2, 0, 2, 0)
		utilities_fix_scope_separator.setSpacing(2)
		utilities_fix_scope_separator.addWidget(self.shaKi_fixScope_label)
		utilities_fix_scope_separator.addWidget(self.shaKi_fixScope_qFrame)
		utilities_fix_scope_options = QtWidgets.QHBoxLayout()
		utilities_fix_scope_options.setContentsMargins(10, 0, 2, 0)
		utilities_fix_scope_options.setSpacing(2)
		utilities_fix_scope_options.addWidget(self.shaKi_fixScope_selection_rb)
		utilities_fix_scope_options.addWidget(self.shaKi_fixScope_scene_rb)
		shaKi_utilities_settings_fix_layout = QtWidgets.QVBoxLayout()
		shaKi_utilities_settings_fix_layout.setContentsMargins(8, 2, 8, 0)
		shaKi_utilities_settings_fix_layout.setSpacing(8)
		shaKi_utilities_settings_fix_layout.addLayout(utilities_fix_scope_separator)
		shaKi_utilities_settings_fix_layout.addLayout(utilities_fix_scope_options)
		shaKi_utilities_settings_fix_layout.addStretch()
		self.shaKi_manager_settings_list.setLayout(shaKi_manager_settings_list_layout)
		self.shaKi_manager_settings_create.setLayout(shaKi_manager_settings_create_layout)
		self.shaKi_utilities_settings_fix.setLayout(shaKi_utilities_settings_fix_layout)
		self.shaKi_shader_settings_stack.addWidget(self.shaKi_manager_settings_list)
		self.shaKi_shader_settings_stack.addWidget(self.shaKi_manager_settings_create)
		self.shaKi_shader_settings_stack.addWidget(self.shaKi_utilities_settings_fix)
		shader_page_layout = QtWidgets.QVBoxLayout()
		shader_page_layout.setAlignment(QtCore.Qt.AlignTop)
		shader_page_layout.setContentsMargins(0, 2, 0, 0)
		shader_page_layout.setSpacing(2)
		shader_page_layout.addWidget(self.shaKi_manager_header)
		shader_page_layout.addWidget(self.shaKi_ui_manager_widget)
		shader_page_layout.addWidget(self.shaKi_utilities_header)
		shader_page_layout.addWidget(self.shaKi_ui_utilities_widget)
		shader_page_layout.addWidget(self.shaKi_shader_settings_stack)
		self.shaKi_shader_page = QtWidgets.QWidget()
		self.shaKi_shader_page.setLayout(shader_page_layout)
		self.shaKi_stack.addWidget(self.shaKi_shader_page)
		shaKi_stack_layout = QtWidgets.QVBoxLayout()
		shaKi_stack_layout.addWidget(self.shaKi_stack)
		shaKi_main_layout = QtWidgets.QVBoxLayout(self)
		shaKi_main_layout.setMargin(0)
		shaKi_main_layout.setSpacing(0)
		shaKi_main_layout.addWidget(self.shaKi_menuWidget)
		shaKi_main_layout.addLayout(shaKi_stack_layout)

	def shaKi_create_connections(self):
		self.shaKi_menu_btn_icon.clicked.connect(self.shaKi_run_menu_btn_icon)
		self.shaKi_ui_managerLabel.clicked.connect(self.shaKi_run_manager_header_LMB)
		self.shaKi_ui_managerToggle.clicked.connect(self.shaKi_run_manager_header_LMB)
		self.shaKi_ui_utilitiesLabel.clicked.connect(self.shaKi_run_utilities_header_LMB)
		self.shaKi_ui_utilitiesToggle.clicked.connect(self.shaKi_run_utilities_header_LMB)
		self.shaKi_manager_table.doubleClicked.connect(self.shaKi_rename)
		self.shaKi_manager_list_btn.clicked.connect(self.shaKi_run_manager_list_LMB)
		self.shaKi_manager_list_btn.rmb_clicked.connect(self.shaKi_run_manager_list_RMB)
		self.shaKi_list_search_line.returnPressed.connect(self.shaKi_filter_by_search)
		self.shaKi_list_search_btn.clicked.connect(self.shaKi_filter_by_search_end)
		self.shaKi_manager_create_btn.clicked.connect(self.shaKi_run_manager_create_LMB)
		self.shaKi_manager_create_btn.rmb_clicked.connect(self.shaKi_run_manager_create_RMB)
		self.shaKi_manager_assign_btn.clicked.connect(self.shaKi_run_manager_assign_btn_LMB)
		self.shaKi_manager_select_btn.clicked.connect(self.shaKi_run_manager_select_btn_LMB)
		self.shaKi_label_colorA.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorA))
		self.shaKi_label_colorB.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorB))
		self.shaKi_label_colorC.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorC))
		self.shaKi_label_colorD.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorD))
		self.shaKi_label_colorE.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorE))
		self.shaKi_label_colorF.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorF))
		self.shaKi_label_colorG.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorG))
		self.shaKi_label_colorH.clicked.connect(lambda : self.shaKi_assign_label(self.shaKi_label_colorH))
		self.shaKi_util_fix_btn.clicked.connect(self.shaKi_run_util_fix_LMB)
		self.shaKi_util_fix_btn.rmb_clicked.connect(self.shaKi_run_util_fix_RMB)
		self.shaKi_util_reassign_btn.clicked.connect(self.shaKi_run_util_reassign_LMB)
		self.shaKi_util_ids_btn.clicked.connect(self.shaKi_run_util_ids_LMB)
		self.shaKi_util_delete_unused_btn.clicked.connect(self.shaKi_run_util_delete_unused_LMB)
		self.shaKi_util_graph_btn.clicked.connect(self.shaKi_run_util_graph_LMB)
		self.shaKi_save_btnIcon.clicked.connect(self.shaKi_run_save_load_LMB)
		self.shaKi_settings_btnIcon.clicked.connect(self.shaKi_open_create_settings_window)

	def shaKi_create_styleSheet(self):
		self.shaKi_styleSheet = '\n            QDialog {\n                background-color: rgb(43,43,43);\n                }\n\n            QTabBar:tab {\n                height: 30px;\n                width: 85px;\n                font-size: 11px;\n            }\n\n            QTabBar:tab:selected {\n                background: rgb(255,111,126);\n            }\n\n            QFrame {\n                background-color: grey;\n                font-size: 11px;\n                }\n\n            QCheckBox {\n                font-size: 11px;\n                }\n\n            QCheckBox:indicator {\n                width: 13px;\n                height: 13px;\n                }\n\n            QRadioButton {\n                font-size: 11px;\n                }\n\n            QRadioButton:indicator {\n                width: 12px;\n                height: 12px;\n                }\n\n            QPushButton {\n                background-color: rgb(105,105,105);\n                border: none;\n                height: 30px;\n                font-size: 11px;\n                }\n\n            QPushButton:hover {\n                background-color: rgb(70,130,180)\n                }\n\n            QPushButton#default {\n                background-color: rgb(105,105,105);\n                border: none;\n                height: 30px;\n                }\n\n            QPushButton#menuIcon {\n                background-color: transparent;\n                border: none;\n                height: 40px;\n                }\n\n            QPushButton#label {\n                font: bold; \n                text-align: left; \n                color: rgb(187,187,187); \n                background-color: rgb(43,43,43);\n                border: none;\n                }\n\n            QPushButton#search {\n                background-color: #222222;\n                border: none;\n                }\n\n            QPushButton#toggle {\n                background-color: rgb(43,43,43);\n                border: none\n                }\n\n            QPushButton#icon {\n                background-color: rgb(63,63,63);\n                border: none;\n                height: 40px;\n                }\n            QPushButton#icon:hover {\n                background-color: rgb(90,90,90)\n                }\n\n            QPushButton#placeholder {\n                background-color: rgb(70,70,70);\n                border: none;\n                height: 40px;\n                }\n\n            QPushButton#iconSettings {\n                background-color: rgb(63,63,63);\n                border: none;\n                height: 40px;\n                }\n            QPushButton#iconSettings:hover {\n                background: qlineargradient(x1: 1, y1: 1, x2: 1, y2: 0,\n                                      stop: 0.06 rgb(0, 168, 255), stop: 0.07 rgb(90,90,90) );\n                }\n\n            QPushButton#namingBtnSettings {\n                background-color: rgb(112,112,112);\n                border: none;\n                height: 40px;\n                }\n            QPushButton#namingBtnSettings:hover {\n                background: qlineargradient(x1: 1, y1: 1, x2: 1, y2: 0,\n                                      stop: 0.06 rgb(0, 168, 255), stop: 0.07 rgb(90,90,90) );\n                }\n\n            QPushButton#namingBtn {\n                background-color: rgb(112,112,112);\n                border: none;\n                height: 40px;\n                }\n\n            QPushButton#namingBtn:hover {\n                background-color: rgb(90,90,90);\n                }\n\n            QLineEdit {\n                background-color: rgb(35,35,35);\n                border: none;\n                height: 25px;\n                font-size: 11px;\n                }\n\n            QLineEdit#ren {\n                background-color: rgb(55,55,55);\n                }\n              \n            QSpinBox {\n                background-color: rgb(35,35,35);\n                border: none;\n                height: 25px;\n                font-size: 11px;\n                }\n\n            QDoubleSpinBox {\n                background-color: rgb(35,35,35);\n                border: none;\n                height: 25px;\n                font-size: 11px;\n                }\n\n            QToolTip { \n                background-color: rgb(238,232,170);\n                color: black;\n                border: black solid 1px;\n                padding: 3px;\n                font-size: 11px;\n                }\n            \n            QSlider{\n                height: 40px;\n                }\n\n            QSlider:groove:horizontal {\n                background-color: rgb(35,35,35);\n                border-radius: 2px;\n                height: 4px;\n                }\n\n            QSlider:handle:horizontal {\n                background-color: rgb(150,150,150);\n                border-radius: 2px;\n                margin: 10px 0px;\n                width: 10px;\n                }\n\n            QListWidget#prefsList {\n                background-color: rgb(35,35,35);\n                border: none;\n                padding-top: 10px;\n                font-size: 11px;\n                }\n\n            QListWidget {\n                background-color: rgb(35,35,35);\n                border: none;\n                padding-top: 4px;\n                padding-left: 4px;\n                font-size: 11px;\n                }\n\n            QHeaderView::section {\n                background-color: rgb(20,20,20);\n                padding: 4px;\n                border: none;\n                font-size: 11px;\n                }\n            \n            QTableWidget {\n                background-color: rgb(50,50,50);\n                border: none;\n                outline: 0;\n                font-size: 11px;\n                }\n\n            QTableWidget::item {\n                background-color: rgb(50,50,50);\n                border-bottom: 1px solid #444444;\n                padding-left: 5px;\n                padding_right: 6px;\n                padding-top: 5px;\n                padding-bottom: 5px;\n                outline: 0;\n                font-size: 11px;\n                }\n\n            QTableWidget::item:selected {\n                background-color: rgb(255,111,126);\n                border: none;\n                }\n\n            QProgressDialog {\n                background-color: rgb(50,50,50);\n                }\n\n            QLabel {\n                background-color: rgb(50,50,50);\n                font-size: 11px;\n                }\n\n            '
		self.shader_kit_window.setStyleSheet(self.shaKi_styleSheet)

	def shaKi_create_pageSizes(self):
		self.shaKi_minSize_shader_kit = 54
		self.shaKi_maxSize_shader_kit = 390
		self.shaKi_pageSize_shader = self.shaKi_minSize_shader_kit

	def shaKi_switch_focus_to_main_widget(self):
		self.shaKi_menuWidget.setFocus()

	def shaKi_goToPage(self, widget_lib, toggle_lib, pageSize, index):
		menuBtnModifiers = QtGui.QGuiApplication.keyboardModifiers()
		currentPageIndex = self.shaKi_stack.currentIndex()
		settingsBtn = self.shaKi_lib_settingsBtn[currentPageIndex]
		self.shaKi_manager_widget_height = 275
		self.shaKi_manager_table_widget_height = 231
		self.shaKi_manager_table.setFixedHeight(self.shaKi_manager_table_widget_height)
		if self.shaKi_check_if_table_is_empty(page=True) == False:
			self.shaKi_manager_table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
		for i in settingsBtn:
			i.setStyleSheet(self.shaKi_styleSheet)

		if currentPageIndex == 0 and self.shaKi_shader_settings_stack.isVisible() == True:
			tempSize = self.shaKi_pageSize_shader
			self.shaKi_shader_settings_stack.setVisible(False)
			self.shaKi_pageSize_shader = tempSize
		title = self.shaKi_windowTitles[index]
		page = self.shaKi_lib_menuPage[index]
		if self.shaKi_menuWidget.isVisible():
			windowHeight = pageSize + 30
		else:
			windowHeight = pageSize
		if menuBtnModifiers == QtCore.Qt.NoModifier:
			self.shaKi_stack.setCurrentWidget(page)
			self.shaKi_set_menu_icon_status(0)
			self.shaKi_change_active_page('%s' % title, windowHeight, True)
		elif index == 2:
			pass
		else:
			self.shaKi_collapse_expand_header(widget_lib, toggle_lib, index)

	def shaKi_change_active_page(self, title, height, visibility):
		self.shader_kit_window.setWindowTitle('%s' % title)
		self.shader_kit_window.setFixedHeight(height)
		self.shaKi_stack.setVisible(visibility)

	def shaKi_set_menu_icon_status(self, index):
		if index != 2:
			index = self.shaKi_stack.currentIndex()
		if index == 0:
			self.shaKi_menu_btn_icon.setIcon(QtGui.QPixmap(self.shaKi_icon_shader_kit_active))
		else:
			self.shaKi_menu_btn_icon.setIcon(QtGui.QPixmap(self.shaKi_icon_shader_kit_inactive))

	def shaKi_collapse_expand_header(self, widgetLib, toggleLib, index):
		shaKi_menu_btn_modifiers = QtGui.QGuiApplication.keyboardModifiers()
		shaKi_page_index_check = self.shaKi_stack.currentIndex()
		if shaKi_page_index_check == index:
			if shaKi_menu_btn_modifiers == QtCore.Qt.AltModifier:
				for i in widgetLib:
					i.setVisible(False)

				for i in toggleLib:
					i.setIcon(QtGui.QPixmap(self.shaKi_icon_expand))

				tmp_window_height = self.shaKi_update_pageSize('min', index, '')
			elif shaKi_menu_btn_modifiers == QtCore.Qt.ControlModifier:
				for i in widgetLib:
					i.setVisible(True)

				for i in toggleLib:
					i.setIcon(QtGui.QPixmap(self.shaKi_icon_collapse))

				tmp_window_height = self.shaKi_update_pageSize('max', index, '')
			self.shader_kit_window.setFixedHeight(tmp_window_height)

	def shaKi_toggle_header(self, widgetName, icon, winSizeValue):
		winCurrentHeight = self.shader_kit_window.height()
		index = self.shaKi_stack.currentIndex()
		if widgetName.isVisible() == True:
			widgetName.setVisible(False)
			if icon:
				icon.setIcon(QtGui.QPixmap(self.shaKi_icon_expand))
			self.shader_kit_window.setFixedHeight(winCurrentHeight - winSizeValue)
		else:
			widgetName.setVisible(True)
			if icon:
				icon.setIcon(QtGui.QPixmap(self.shaKi_icon_collapse))
			self.shader_kit_window.setFixedHeight(winCurrentHeight + winSizeValue)
		currentStackHeight = self.shaKi_stack.frameSize().height()
		self.shaKi_update_pageSize('currentStackHeight', index, currentStackHeight)

	def shaKi_toggle_settings(self, clickedButton, settingsLib, settingsStack, settingsIndex, winSizeValue):
		winCurrentHeight = self.shader_kit_window.height()
		pageIndex = self.shaKi_stack.currentIndex()
		currentSettingsIndex = settingsStack.currentIndex()
		currentWidgetHeight = settingsStack.frameSize().height()
		settingsPage = settingsLib[settingsIndex]
		settingsBtn = clickedButton[settingsIndex]
		for i in clickedButton:
			if i == clickedButton[settingsIndex]:
				i.setStyleSheet('* { background-color: rgb(55,55,55);}')
			else:
				i.setStyleSheet(self.shaKi_styleSheet)

		if currentSettingsIndex != settingsIndex:
			if settingsStack.isVisible() == True:
				settingsStack.setVisible(False)
				self.shader_kit_window.setFixedHeight(winCurrentHeight - currentWidgetHeight)
			settingsStack.setCurrentWidget(settingsPage)
			winCurrentHeight = self.shader_kit_window.height()
		if settingsStack.isVisible() == True:
			settingsStack.setVisible(False)
			settingsBtn.setStyleSheet(self.shaKi_styleSheet)
			self.shader_kit_window.setFixedHeight(winCurrentHeight - winSizeValue)
		else:
			settingsStack.setVisible(True)
			self.shader_kit_window.setFixedHeight(winCurrentHeight + winSizeValue)

	def shaKi_update_pageSize(self, type, index, height):
		if type == 'menuToggle':
			if self.shaKi_menuWidget.isVisible() == True:
				menuHeight = -30
			else:
				menuHeight = 30
			self.shaKi_pageSize_shader -= menuHeight
			winCurrentHeight = self.shader_kit_window.height()
			self.shader_kit_window.setFixedHeight(winCurrentHeight - menuHeight)
		if type == 'min':
			if index == 0:
				self.shaKi_shader_settings_stack.setVisible(False)
				self.shaKi_pageSize_shader = tmp_window_height = self.shaKi_minSize_shader_kit
			if self.shaKi_menuWidget.isVisible() == True:
				tmp_window_height += 30
			return tmp_window_height
		if type == 'max':
			if index == 0:
				self.shaKi_pageSize_shader = tmp_window_height = self.shaKi_maxSize_shader_kit
			if self.shaKi_menuWidget.isVisible() == True:
				tmp_window_height += 30
			return tmp_window_height
		if type == 'currentStackHeight':
			if index == 0:
				self.shaKi_pageSize_shader = height

	def keyPressEvent(self, e):
		if e.key() == QtCore.Qt.Key_Enter:
			self.shaKi_switch_focus_to_main_widget()
		if e.key() == QtCore.Qt.Key_Return:
			self.shaKi_switch_focus_to_main_widget()
		if e.key() == QtCore.Qt.Key_1:
			self.shaKi_goToPage(self.shaKi_shader_widget_lib, self.shaKi_shader_toggle_lib, self.shaKi_pageSize_shader, 0)
		elif e.key() == QtCore.Qt.Key_3:
			shaKi_menu_btn_modifiers = QtGui.QGuiApplication.keyboardModifiers()
			if shaKi_menu_btn_modifiers == QtCore.Qt.AltModifier:
				currentPageIndex = self.shaKi_stack.currentIndex()
				if currentPageIndex == 0:
					self.shaKi_shader_settings_stack.setVisible(False)
				self.shaKi_change_active_page('  Shader Kit', 30, False)
				self.shaKi_set_menu_icon_status(2)
			elif self.shader_kit_window.height() == 30:
				return
			else:
				if self.shaKi_menuWidget.isVisible() == False:
					self.shaKi_menuWidget.setVisible(True)
				else:
					self.shaKi_menuWidget.setVisible(False)
				self.shaKi_update_pageSize('menuToggle', '', '')

		else:
			super(MainClass_ShaderKit, self).keyPressEvent(e)

	def shaKi_run_menu_btn_icon(self):
		get_current_window_Height = self.shader_kit_window.height()
		self.shaKi_goToPage(widget_lib=self.shaKi_shader_widget_lib, toggle_lib=self.shaKi_shader_toggle_lib, pageSize=self.shaKi_pageSize_shader, index=0)

	def shaKi_run_save_load_LMB(self):
		shaKi_manager_create_btn_modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if shaKi_manager_create_btn_modifiers == QtCore.Qt.NoModifier:
			self.shaKi_save_shader_list()
		if shaKi_manager_create_btn_modifiers == QtCore.Qt.AltModifier:
			self.shaKi_load_shader_list()

	def shaKi_run_manager_header_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_toggle_header(widgetName=self.shaKi_ui_manager_widget, icon=self.shaKi_ui_managerToggle, winSizeValue=self.shaKi_manager_widget_height)
		if modifiers == QtCore.Qt.AltModifier:
			if self.shaKi_ui_manager_widget.isVisible() == True:
				get_current_window_Height = self.shader_kit_window.height()
				self.shader_kit_window.setFixedHeight(get_current_window_Height + 60)
				self.shaKi_manager_widget_height += 60
				self.shaKi_manager_table.setFixedHeight(self.shaKi_manager_table_widget_height + 60)
				self.shaKi_manager_table_widget_height += 60
				self.check_if_table_larger_than_widget(self.shaKi_manager_table)
		if modifiers == QtCore.Qt.ControlModifier:
			if self.shaKi_ui_manager_widget.isVisible() == True:
				if self.shaKi_manager_widget_height > 200:
					get_current_window_Height = self.shader_kit_window.height()
					self.shader_kit_window.setFixedHeight(get_current_window_Height - 60)
					self.shaKi_manager_widget_height -= 60
					self.shaKi_manager_table.setFixedHeight(self.shaKi_manager_table_widget_height - 60)
					self.shaKi_manager_table_widget_height -= 60
					self.check_if_table_larger_than_widget(self.shaKi_manager_table)

	def shaKi_run_utilities_header_LMB(self):
		self.shaKi_toggle_header(widgetName=self.shaKi_ui_utilities_widget, icon=self.shaKi_ui_utilitiesToggle, winSizeValue=86)

	def shaKi_run_manager_list_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_list_shader()
		if modifiers == QtCore.Qt.AltModifier:
			self.shaKi_sort_list_alphabetically()
		if modifiers == QtCore.Qt.ControlModifier:
			self.shaKi_sort_list_by_label()

	def shaKi_run_manager_list_RMB(self):
		index = self.shaKi_lib_shaderSettingsBtn.index(self.shaKi_manager_list_btn)
		self.shaKi_toggle_settings(clickedButton=self.shaKi_lib_shaderSettingsBtn, settingsLib=self.shaKi_lib_shaderSettings, settingsStack=self.shaKi_shader_settings_stack, settingsIndex=index, winSizeValue=150)

	def shaKi_run_manager_create_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_create_shaders()
		if modifiers == QtCore.Qt.AltModifier:
			self.shaKi_duplicate()

	def shaKi_run_manager_create_RMB(self):
		index = self.shaKi_lib_shaderSettingsBtn.index(self.shaKi_manager_create_btn)
		self.shaKi_toggle_settings(clickedButton=self.shaKi_lib_shaderSettingsBtn, settingsLib=self.shaKi_lib_shaderSettings, settingsStack=self.shaKi_shader_settings_stack, settingsIndex=index, winSizeValue=224)

	def shaKi_run_manager_assign_btn_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_assign(True)
		if modifiers == QtCore.Qt.AltModifier:
			self.shaKi_assign(False)
		if modifiers == QtCore.Qt.ControlModifier:
			self.shaKi_assign_random()

	def shaKi_run_manager_select_btn_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_select_attributes()
		if modifiers == QtCore.Qt.AltModifier:
			self.shaKi_select_objects()
		if modifiers == QtCore.Qt.ControlModifier:
			self.shaKi_select_objects_with_same_shader()
		if modifiers == QtCore.Qt.ShiftModifier:
			self.shaKi_select_shader_from_obj_in_table()

	def shaKi_run_util_fix_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if self.shaKi_fixScope_selection_rb.isChecked():
			fix_list = self.get_selected_list_items(self.shaKi_manager_table)
		if self.shaKi_fixScope_scene_rb.isChecked():
			fix_list = mc.ls(mat=True)
		if fix_list:
			if modifiers == QtCore.Qt.NoModifier:
				self.shaKi_fix_shading_grp(fix_list)
			if modifiers == QtCore.Qt.AltModifier:
				self.shaKi_fix_prefixes(fix_list)
		else:
			self.shaKi_message_box('Warning', 'Please select a shader from the list.')

	def shaKi_run_util_fix_RMB(self):
		index = self.shaKi_lib_shaderSettingsBtn.index(self.shaKi_util_fix_btn)
		self.shaKi_toggle_settings(clickedButton=self.shaKi_lib_shaderSettingsBtn, settingsLib=self.shaKi_lib_shaderSettings, settingsStack=self.shaKi_shader_settings_stack, settingsIndex=index, winSizeValue=54)

	def shaKi_run_util_reassign_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_reassign_shader('selection')
		if modifiers == QtCore.Qt.AltModifier:
			self.shaKi_reassign_shader('scene')

	def shaKi_run_util_ids_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_create_id_colors('lambert')
		if modifiers == QtCore.Qt.AltModifier:
			self.shaKi_create_id_colors('surfaceShader')
		if modifiers == QtCore.Qt.ShiftModifier:
			self.shaKi_delete_id_colors()

	def shaKi_run_util_graph_LMB(self):
		modifiers = QtGui.QGuiApplication.keyboardModifiers()
		if modifiers == QtCore.Qt.NoModifier:
			self.shaKi_graph_materials(mode='object')
		if modifiers == QtCore.Qt.AltModifier:
			self.shaKi_graph_materials(mode='add')
		if modifiers == QtCore.Qt.ControlModifier:
			self.shaKi_graph_materials(mode='remove')
		if modifiers == QtCore.Qt.ShiftModifier:
			self.shaKi_graph_materials(mode='show')

	def shaKi_run_util_delete_unused_LMB(self):
		self.shaKi_delete_unused_nodes()

	def shaKi_create_hotkeys(self, hotkey, categoryName):
		name = hotkey['name']
		command = hotkey['command']
		try:
			mc.runTimeCommand(name, c=command, cat='%s' % categoryName, cl='python')
			om.MGlobal.displayInfo('Info: Added %s script to the hotkey editor.' % name)
		except:
			pass

	def shaKi_run_hotkeys(self):
		for key in self.hotkey_library_launch:
			self.shaKi_create_hotkeys(key, 'RS Tools')

	def warning_message(self, file_name):
		warning_dialog = QDialog_Custom_Warning()
		warning_dialog.shaKi_warning_message_label.setText('%s already exists. \nDo you want to replace it?' % file_name)
		button_response = warning_dialog.exec_()
		if button_response == QtWidgets.QDialog.Accepted:
			return True
		else:
			return False

	def split_name(self, object_input, split_input, split_position):
		if '%s' % split_input in object_input:
			temp_name = object_input.split('%s' % split_input)[split_position]
			return temp_name

	def shaKi_get_file_path(self, file_mode, cap, format_filter):
		get_path = mc.fileDialog2(fm=file_mode, ff='%s' % format_filter, ds=2, cap='%s' % cap)
		return get_path

	def shaKi_open_browser(self, site_code):
		if site_code == 'Documentation':
			mc.launch(web='https://www.rocket-square.com/docs')
		elif site_code == 'Website':
			mc.launch(web='https://www.rocket-square.com/')
		elif site_code == 'Gumroad':
			mc.launch(web='https://gumroad.com/eriklehmann')

	def shaKi_open_create_settings_window(self):
		create_settings_dialog = QDialog_Create_Settings(self.shaKi_create_shaderList)
		create_settings_dialog.show()

	def shaKi_message_box(self, title, message):
		shaKi_message_box = QtWidgets.QMessageBox()
		shaKi_message_box.setText('%s' % message)
		shaKi_message_box.setWindowTitle('%s' % title)
		shaKi_message_box.setWindowFlags(QtCore.Qt.WindowContextHelpButtonHint)
		shaKi_message_box.exec_()

	def shaKi_get_scene_shader(self):
		shaKi_get_shader_list = mc.ls(mat=True)
		shaKi_get_shader_list.sort()
		return shaKi_get_shader_list

	def get_selected_list_items(self, shader_table):
		shaders = shader_table.selectedItems()
		shaders_tmp = []
		for shader in shaders:
			text = shader.text()
			shaders_tmp.append(text)

		return shaders_tmp

	def get_all_list_items(self):
		row_count = self.shaKi_manager_table.rowCount()
		shader_list = []
		for i in range(0, row_count):
			item = self.shaKi_manager_table.item(i, 0)
			shader = item.text()
			shader_list.append(shader)

		return shader_list

	def shaKi_insert_item(self, row, text):
		item_text = QtWidgets.QTableWidgetItem(text)
		item_text.setTextAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignVCenter)
		item_text.setFlags(QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEnabled)
		item_label = QPushButton_Custom('')
		self.setup_button(item_label, style='* { background-color: rgb(60,60,60); border-radius: 7px;}', h=14, w=14)
		item_label.clicked.connect(self.shaKi_filter_by_label)
		self.shaKi_manager_table.setColumnWidth(1, 26)
		self.shaKi_manager_table.setItem(row, 0, item_text)
		self.shaKi_manager_table.setCellWidget(row, 1, item_label)
		self.shaKi_manager_table.setRowHeight(row, 27)

	def refresh_table(self, shader_list):
		self.shaKi_manager_table.setRowCount(0)
		self.shaKi_manager_table.setRowCount(len(shader_list))
		col = 0
		row = 0
		for i in shader_list:
			self.shaKi_insert_item(row, i)
			row = row + 1

	def refresh_labels(self, label_list):
		for i in range(len(label_list)):
			self.set_label_color(i, 1, label_list[i])

	def check_if_table_larger_than_widget(self, table):
		row_count = table.rowCount()
		fixed_table_height = row_count * 27 + 54
		if fixed_table_height > self.shaKi_manager_widget_height:
			table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
		else:
			table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)

	def get_rgb_values(self, row, col):
		label_item = self.shaKi_manager_table.cellWidget(row, col)
		rgb_values = re.findall('\\d+', '%s' % str(label_item.styleSheet()))
		if len(rgb_values) > 3:
			del rgb_values[3:]
		return rgb_values

	def set_label_color(self, row, col, rgb):
		label_item = self.shaKi_manager_table.cellWidget(row, col)
		label_item.setStyleSheet('* { background-color: rgb(%s,%s,%s); border-radius: 7px;}' % (rgb[0], rgb[1], rgb[2]))

	def get_row_indexes(self):
		indexes = []
		rows = self.shaKi_manager_table.selectionModel().selectedRows()
		for i in rows:
			index = re.search('QModelIndex\\((.*?)\\,0', str(i)).group(1)
			indexes.append(int(index))

		return indexes

	def shaKi_assign_label(self, btn):
		if self.filter_enabled_check == False:
			rgb_values = re.findall('\\d+', '%s' % str(btn.styleSheet()))
			rows = self.get_row_indexes()
			for r in rows:
				self.set_label_color(r, 1, rgb_values)

		else:
			self.shaKi_message_box('Warning', "You can't assign a label color when a Filter is active.")

	def get_row_of_clicked_widget(self):
		buttonClicked = self.sender()
		index = self.shaKi_manager_table.indexAt(buttonClicked.pos())
		row = index.row()
		return row

	def get_all_label_colors(self):
		label_color_list = []
		row_count = self.shaKi_manager_table.rowCount()
		for i in range(row_count):
			label_color = self.get_rgb_values(i, 1)
			label_color_list.append(label_color)

		return label_color_list

	def shaKi_filter_by_label(self):
		if self.filter_enabled_check == False:
			self.original_filter_by_label_shader_list = []
			self.original_filter_by_label_color_list = []
			self.tmp_filtered_list = []
			tmp_label_filter_list = []
			self.clicked_rgb = []
			row = self.get_row_of_clicked_widget()
			self.clicked_rgb = self.get_rgb_values(row, 1)
			row_count = self.shaKi_manager_table.rowCount()
			self.original_filter_by_label_shader_list = self.get_all_list_items()
			for i in range(row_count):
				label_color = self.get_rgb_values(i, 1)
				self.original_filter_by_label_color_list.append(label_color)
				if label_color == self.clicked_rgb:
					tmp_label_filter_list.append(self.original_filter_by_label_shader_list[i])

			self.refresh_table(tmp_label_filter_list)
			for i in range(len(tmp_label_filter_list)):
				self.set_label_color(i, 1, self.clicked_rgb)

			self.filter_enabled_check = True
			self.tmp_filtered_list = self.get_all_list_items()
		else:
			tmp_list = self.get_all_list_items()
			deleted_shaders = []
			for i in self.tmp_filtered_list:
				if i not in tmp_list:
					deleted_shaders.append(i)

			if deleted_shaders:
				rows_to_delete = []
				for i in deleted_shaders:
					x = self.original_filter_by_label_shader_list.index(i)
					rows_to_delete.append(x)

				rows_to_delete.reverse()
				for i in rows_to_delete:
					del self.original_filter_by_label_shader_list[i]
					del self.original_filter_by_label_color_list[i]

			self.refresh_table(self.original_filter_by_label_shader_list)
			self.refresh_labels(self.original_filter_by_label_color_list)
			self.filter_enabled_check = False

	def shaKi_filter_by_search(self):
		self.search_line_text = self.shaKi_list_search_line.text()
		self.search_original_list = self.get_all_list_items()
		self.search_labels_list = self.get_all_label_colors()
		self.search_filtered_list = []
		self.search_filtered_labels = []
		for i in range(len(self.search_original_list)):
			if self.search_line_text in self.search_original_list[i]:
				self.search_filtered_list.append(self.search_original_list[i])
				self.search_filtered_labels.append(self.search_labels_list[i])

		self.refresh_table(self.search_filtered_list)
		for i in range(len(self.search_filtered_labels)):
			self.set_label_color(i, 1, self.search_filtered_labels[i])

		self.shaKi_list_search_btn.setEnabled(True)
		self.shaKi_list_search_line.setEnabled(False)
		self.filter_enabled_check = True

	def shaKi_filter_by_search_end(self):
		self.refresh_table(self.search_original_list)
		self.refresh_labels(self.search_labels_list)
		self.shaKi_list_search_line.clear()
		self.shaKi_list_search_btn.setEnabled(False)
		self.shaKi_list_search_line.setEnabled(True)
		self.shaKi_list_search_line.setText(self.search_line_text)
		self.filter_enabled_check = False

	def shaKi_check_if_table_is_empty(self, page=False):
		row_count = self.shaKi_manager_table.rowCount()
		if row_count > 0:
			return False
		else:
			if page == False:
				self.shaKi_message_box('Warning', "The shader table is empty.\nPlease use the 'List Shader' button first or load a saved list.")
			return True

	def progress_bar_dialog(self, title, cancel, start, end, winWidth):
		self.progress_dialog = QtWidgets.QProgressDialog(('{0}').format(title), ('{0}').format(cancel), start, end, self)
		self.progress_dialog.setMinimumWidth(winWidth)
		self.progress_dialog.setWindowTitle('%s' % title)
		self.progress_dialog.setValue(start)
		self.progress_dialog.setCancelButtonText('    Cancel    ')
		self.progress_dialog.setFixedHeight(120)
		self.progress_dialog.setModal(True)
		self.progress_dialog.show()

	def shaKi_get_file_path(self, file_mode, cap, format_filter):
		get_path = mc.fileDialog2(fm=file_mode, ff='%s' % format_filter, ds=2, cap='%s' % cap)
		return get_path

	def shaKi_save_shader_list(self):
		if self.shaKi_check_if_table_is_empty() == False:
			shader_list = self.get_all_list_items()
			label_list = self.get_all_label_colors()
			save_to_file = self.shaKi_get_file_path(0, 'Save shader list to..', '*.json')
			my_dict = {'Shader': shader_list, 'Label': label_list}
			with open('%s' % save_to_file[0], 'w') as (jsonfile):
				json.dump(my_dict, jsonfile, indent=4)
			om.MGlobal.displayInfo(('Info: Saved file to {0}.').format(save_to_file[0]))

	def shaKi_load_shader_list(self):
		json_file = self.shaKi_get_file_path(4, 'Load shader list..', '*.json')
		with open(json_file[0]) as (f):
			table_data = json.load(f)
		shader_list = table_data['Shader']
		label_list = table_data['Label']
		self.refresh_table(shader_list)
		self.refresh_labels(label_list)

	def shaKi_rename(self):
		if self.filter_enabled_check == False:
			row = self.shaKi_manager_table.currentRow()
			item = self.shaKi_manager_table.item(row, 0)
			cell_text = item.text()
			shader_list = self.get_all_list_items()
			if cell_text == 'lambert1':
				om.MGlobal.displayWarning('The default shader lambert1 can not be renamed!')
			elif cell_text == 'standardSurface1':
				om.MGlobal.displayWarning('The default shader standardSurface1 can not be renamed!')
			else:
				shaKi_ren_dialog = mc.promptDialog(title='Rename', message='Enter new name:', button=['OK', 'Cancel'], defaultButton='OK', cancelButton='Cancel', dismissString='Cancel', tx='%s' % cell_text)
				if shaKi_ren_dialog == 'OK':
					shaKi_ren_replace = mc.promptDialog(query=True, text=True)
					if shaKi_ren_replace in shader_list:
						self.shaKi_message_box('Warning', 'This name already exists!')
					else:
						mc.rename(cell_text, shaKi_ren_replace)
						item.setText('%s' % shaKi_ren_replace)
		else:
			self.shaKi_message_box('Warning', "You can't rename Shader when a Filter is active.")

	def shaKi_delete_shader(self, shader):
		if shader == 'lambert1':
			om.MGlobal.displayWarning("You cannot delete 'lambert1'.")
			return False
		if shader == 'standardSurface1':
			om.MGlobal.displayWarning("You cannot delete 'standardSurface1'.")
			return False
		fix_list = []
		fix_list.append(shader)
		shader_del = mc.listConnections(shader, type='shadingEngine')
		mc.hyperShade(objects='%s' % shader_del[0])
		objects_with_shader = mc.ls(sl=True)
		if len(objects_with_shader) > 0:
			for k in objects_with_shader:
				mc.sets(e=True, fe='initialParticleSE')

		mc.select(shader)
		mc.delete()
		mc.delete(shader_del[0])

	def shaKi_list_shader(self):
		row_count = self.shaKi_manager_table.rowCount()
		shaKi_shader_list = self.shaKi_get_scene_shader()
		if 'particleCloud1' in shaKi_shader_list:
			index = shaKi_shader_list.index('particleCloud1')
			shaKi_shader_list.pop(index)
		if row_count > 0:
			if self.filter_enabled_check == False:
				differnce_list = []
				delete_list = []
				shader_from_list = self.get_all_list_items()
				for i in shaKi_shader_list:
					if i not in shader_from_list:
						differnce_list.append(i)

				for i in range(len(shader_from_list)):
					if shader_from_list[i] not in shaKi_shader_list:
						delete_list.append(i)

				for i in differnce_list:
					self.shaKi_manager_table.insertRow(row_count)
					self.shaKi_insert_item(row_count, i)
					row_count += 1

				delete_list.reverse()
				for i in delete_list:
					self.shaKi_manager_table.removeRow(i)

				om.MGlobal.displayInfo('Info: Updated list')
			else:
				self.shaKi_message_box('Warning', "You can't update the Shader list when a Filter is active.")
		else:
			self.filter_enabled_check = False
			self.shaKi_manager_table.setRowCount(0)
			for i in range(len(shaKi_shader_list)):
				self.shaKi_manager_table.insertRow(i)
				self.shaKi_insert_item(i, shaKi_shader_list[i])

			om.MGlobal.displayInfo('Info: Listed all scene shaders')
		self.check_if_table_larger_than_widget(self.shaKi_manager_table)

	def shaKi_sort_list_alphabetically(self):
		if self.shaKi_check_if_table_is_empty() == False:
			shader_list = self.get_all_list_items()
			label_list = self.get_all_label_colors()
			sorted_shader_list = []
			sorted_label_list = []
			sorted_index_array = sorted(range(len(shader_list)), key=lambda k: shader_list[k].lower())
			for i in sorted_index_array:
				sorted_shader_list.append(shader_list[i])
				sorted_label_list.append(label_list[i])

			self.refresh_table(sorted_shader_list)
			self.refresh_labels(sorted_label_list)

	def shaKi_sort_list_by_label(self):
		shader_list = self.get_all_list_items()
		label_list = self.get_all_label_colors()
		index_list = []
		index_list = sorted(range(len(label_list)), key=lambda k: label_list[k])
		sorted_shader_list = []
		sorted_label_list = []
		for index in index_list:
			sorted_shader_list.append(shader_list[index])
			sorted_label_list.append(label_list[index])

		self.refresh_table(sorted_shader_list)
		self.refresh_labels(sorted_label_list)

	def shaKi_rebuild_list_after_creation(self, shader_list, color_list):
		self.refresh_table(shader_list)
		x = 0
		for color in color_list:
			self.set_label_color(x, 1, color)
			x += 1

		self.check_if_table_larger_than_widget(self.shaKi_manager_table)

	def shaKi_create_shaders(self):
		if self.filter_enabled_check == False:
			if self.shaKi_check_if_table_is_empty() == False:
				selected_shaders = self.get_selected_list_items(self.shaKi_create_shaderList)
				if selected_shaders:
					current_shader_list = self.get_all_list_items()
					original_list_length = len(current_shader_list)
					current_label_color_list = self.get_all_label_colors()
					for shader in selected_shaders:
						shaKi_create_shader = mc.shadingNode('%s' % shader, asShader=True)
						shaKi_create_shading_grp = mc.sets(name='%sSG' % shaKi_create_shader, empty=True, renderable=True, noSurfaceShader=True)
						mc.connectAttr('%s.outColor' % shaKi_create_shader, '%s.surfaceShader' % shaKi_create_shading_grp)
						new_shader_name = mc.ls(sl=True)
						current_shader_list.append(new_shader_name[0])

					self.shaKi_rebuild_list_after_creation(current_shader_list, current_label_color_list)
					om.MGlobal.displayInfo(('Info: Added {0} shader to the list').format(len(selected_shaders)))
				else:
					self.shaKi_message_box('Warning', 'No Shader is selected.\nPlease Right-Mouse-Button click the create icon to open\nthe settings and select a shader from the create list.')
		else:
			self.shaKi_message_box('Warning', "You can't create Shader when a Filter is active.")

	def shaKi_duplicate(self):
		if self.filter_enabled_check == False:
			selected_items = self.get_selected_list_items(self.shaKi_manager_table)
			if selected_items:
				for item in selected_items:
					if item == 'lambert1':
						self.shaKi_message_box('Warning', "You cannot duplicate 'lambert1'.")
					elif item == 'standardSurface1':
						self.shaKi_message_box('Warning', "You cannot duplicate 'standardSurface1'.")
					else:
						mc.select(item)
						mc.hyperShade(dup=True)
						table_item = self.shaKi_manager_table.findItems('%s' % item, QtCore.Qt.MatchCaseSensitive)
						row = self.shaKi_manager_table.row(table_item[0]) + 1
						new_shader_name = mc.ls(sl=True)
						self.shaKi_manager_table.insertRow(row)
						self.shaKi_insert_item(row, new_shader_name[0])
						self.shaKi_fix_shading_grp(new_shader_name)

			else:
				self.shaKi_message_box('Warning', 'Please select a shader from the list.')
			self.check_if_table_larger_than_widget(self.shaKi_manager_table)
		else:
			self.shaKi_message_box('Warning', "You can't duplicate Shader when a Filter is active.")

	def shaKi_assign(self, transform):
		mc.undoInfo(ock=True)
		if self.shaKi_check_if_table_is_empty() == False:
			selected_shader = self.get_selected_list_items(self.shaKi_manager_table)
			if selected_shader:
				if len(selected_shader) == 1:
					selected_objects = mc.ls(sl=True, tr=transform)
					if selected_objects:
						if selected_shader[0] == 'lambert1':
							mc.sets(e=True, fe='initialShadingGroup')
						else:
							mc.hyperShade(a='%s' % selected_shader[0])
						om.MGlobal.displayInfo(('Info: Assigned "{0}" to {1} objects.').format(selected_shader[0], len(selected_objects)))
					else:
						self.shaKi_message_box('Warning', 'Please select geometry.')
				else:
					self.shaKi_message_box('Warning', 'Please select only one shader.')
			else:
				self.shaKi_message_box('Info', 'Please select a shader from the list.')
		mc.undoInfo(cck=True)

	def shaKi_assign_random(self):
		mc.undoInfo(ock=True)
		if self.shaKi_check_if_table_is_empty() == False:
			selected_shader = self.get_selected_list_items(self.shaKi_manager_table)
			if selected_shader:
				selected_objects = mc.ls(sl=True, tr=True)
				if selected_objects:
					shader_count = len(selected_shader)
					for i in selected_objects:
						shader_index = randint(1, shader_count) - 1
						mc.select(i)
						mc.hyperShade(a='%s' % selected_shader[shader_index])

					om.MGlobal.displayInfo('Assigned shader.')
				else:
					self.shaKi_message_box('Warning', 'Please select geometry.')
			else:
				self.shaKi_message_box('Note', 'Please select a shader from the list.')
		mc.undoInfo(cck=True)

	def shaKi_select_attributes(self):
		selected_item = self.get_selected_list_items(self.shaKi_manager_table)
		if selected_item:
			if len(selected_item) > 1:
				self.shaKi_message_box('Warning', 'Please select only one shader from the list.')
			else:
				mc.select(selected_item[0])
				mm.eval('AttributeEditor;')
		else:
			self.shaKi_message_box('Warning', 'Please select a shader from the list.')

	def shaKi_select_objects(self):
		selected_item = self.get_selected_list_items(self.shaKi_manager_table)
		if selected_item:
			if len(selected_item) > 1:
				self.shaKi_message_box('Warning', 'Please select only one shader from the list.')
			else:
				mc.hyperShade(objects='%s' % selected_item[0])
				shaKi_faces_sum = mc.polyEvaluate(fc=True)
				select_sha_obj_check = mc.ls(sl=True)
				if len(select_sha_obj_check) == 0:
					om.MGlobal.displayInfo('Info: No matches found.')
				else:
					faces = []
					for f in select_sha_obj_check:
						if 'f[' in f:
							faces.append(f)

					if len(faces) == 0:
						om.MGlobal.displayInfo('Info: Found %s object(s).' % len(select_sha_obj_check))
					else:
						om.MGlobal.displayInfo('Info: Found %s object(s) and %s face(s).' % (len(select_sha_obj_check) - len(faces), shaKi_faces_sum))
		else:
			self.shaKi_message_box('Warning', 'Please select a shader from the list.')

	def shaKi_select_objects_with_same_shader(self):
		if self.shaKi_check_if_table_is_empty() == False:
			selected_object = mc.ls(sl=True, o=True)
			if selected_object:
				if len(selected_object) == 1:
					shape_node = mc.ls(dag=True, o=True, s=True, sl=True)
					shading_group = mc.listConnections(shape_node, type='shadingEngine')
					shader_name = mc.ls(mc.listConnections(shading_group), mat=True)
					mc.hyperShade(objects='%s' % shader_name[0])
					faces_sum = mc.polyEvaluate(fc=True)
					objects_with_same_shader = mc.ls(sl=True)
					faces_list = []
					for f in objects_with_same_shader:
						if 'f[' in f:
							faces_list.append(f)

					if len(faces_list) == 0:
						om.MGlobal.displayInfo('Info: Found %s object(s).' % len(objects_with_same_shader))
					else:
						om.MGlobal.displayInfo('Info: Found %s object(s) and %s face(s).' % (len(objects_with_same_shader) - len(faces_list), faces_sum))
				else:
					self.shaKi_message_box('Warning', 'Please select only one object.')
			else:
				self.shaKi_message_box('Info', 'Please select an object.')

	def shaKi_select_shader_from_obj_in_table(self):
		if self.shaKi_check_if_table_is_empty() == False:
			selected_object = mc.ls(sl=True, o=True)
			if selected_object:
				if len(selected_object) == 1:
					shape_node = mc.ls(dag=True, o=True, s=True, sl=True)
					shading_group = mc.listConnections(shape_node, type='shadingEngine')
					shader_name = mc.ls(mc.listConnections(shading_group), mat=True)
					shader_index = []
					shader_table_list = self.get_all_list_items()
					for index in range(len(shader_table_list)):
						if shader_name[0] == shader_table_list[index]:
							shader_index = index
							break
						else:
							continue

					self.shaKi_manager_table.selectRow(shader_index)
					shader_index = self.shaKi_manager_table.currentIndex()
					self.shaKi_manager_table.setCurrentIndex(shader_index)
					self.shaKi_manager_table.selectionModel().select(shader_index, QtCore.QItemSelectionModel.ClearAndSelect | QtCore.QItemSelectionModel.Rows)
				else:
					self.shaKi_message_box('Warning', 'Please select only one object.')
			else:
				self.shaKi_message_box('Note', 'Please select an object.')

	def shaKi_fix_prefixes(self, fix_list):
		all_shaders = self.get_all_list_items()
		shader_count = len(all_shaders)
		update_name_list = []
		if self.filter_enabled_check == False:
			for i in fix_list:
				if 'pasted__' in i:
					matPrefixFix = i.replace('pasted__', '')
					mc.rename(i, matPrefixFix)
					for num in range(shader_count):
						if i == all_shaders[num]:
							table_item = self.shaKi_manager_table.item(num, 0)
							table_item.setText(matPrefixFix)

				elif 'exported__' in i:
					matPrefixFix = i.replace('exported__', '')
					mc.rename(i, matPrefixFix)
					for num in range(shader_count):
						if i == all_shaders[num]:
							table_item = self.shaKi_manager_table.item(num, 0)
							table_item.setText(matPrefixFix)

			om.MGlobal.displayInfo('Info: Fixed Shader Prefix(es).')
		else:
			self.shaKi_message_box('Warning', "You can't rename Shader when a Filter is active.")

	def shaKi_fix_shading_grp(self, fix_list):
		fixed = []
		for i in fix_list:
			if i == 'lambert1' or i == 'particleCloud1' or i == 'standardSurface1':
				continue
			else:
				try:
					shading_group = mc.listConnections(i, type='shadingEngine')
					if '%s' % shading_group[0] != '%sSG' % i:
						mc.rename(shading_group[0], '%sSG' % i)
						fixed.append(i)
				except:
					mc.sets(r=True, nss=True, em=True, name='%sSG' % i)
					mc.defaultNavigation(ce=True, s='%s' % i, d='%sSG' % i)
					fixed.append(i)

		if fixed:
			for fix in fixed:
				om.MGlobal.displayInfo('Info: Fixed Shading Group name for %s.' % fix)

		else:
			om.MGlobal.displayInfo('Info: Found no Shading Groups that needed to be fixed.')

	def shaKi_reassign_shader(self, scope):
		mc.undoInfo(ock=True)
		geometry_to_fix = []
		if scope == 'selection':
			tmp = mc.ls(sl=True)
			for i in tmp:
				shape_name = mc.listRelatives(i, s=True)
				geometry_to_fix.append(shape_name[0])

		if scope == 'scene':
			geometry_to_fix = mc.ls(geometry=True)
		reassign_check = []
		for geo in geometry_to_fix:
			k = mc.listConnections(geo, type='shadingEngine')
			if k != None:
				reassign_check.append(geo)

		mc.select(reassign_check, r=True)
		reassign_geometry = mc.ls(sl=True)
		if reassign_geometry:
			self.progress_bar_dialog('Processing...', 'Cancel', 0, len(reassign_geometry), 300)
			for i in range(len(reassign_geometry)):
				if self.progress_dialog.wasCanceled():
					break
				self.progress_dialog.setLabelText(('Reassigning shader to object {0} (of {1})').format(i, len(reassign_geometry)))
				self.progress_dialog.setValue(i)
				QtCore.QCoreApplication.processEvents()
				object_material = mc.listConnections(reassign_geometry[i], source=False, destination=True)
				shading_group = object_material[0]
				mc.select(reassign_geometry[i])
				mc.sets(e=True, forceElement=shading_group)
				mc.select(cl=True)

			self.progress_dialog.close()
		else:
			self.shaKi_message_box('Warning', 'Nothing found to reassign.')
		om.MGlobal.displayInfo('Info: All Shaders are reassigned.')
		mc.undoInfo(cck=True)
		return

	def shaKi_delete_unused_nodes(self):
		updated_list = []
		before_list = self.get_all_list_items()
		before_label_list = self.get_all_label_colors()
		mm.eval('MLdeleteUnused;')
		after_list = mc.ls(mat=True)
		after_label_list = []
		for i in range(len(before_list)):
			if before_list[i] in after_list:
				updated_list.append(before_list[i])
				after_label_list.append(before_label_list[i])

		self.shaKi_rebuild_list_after_creation(updated_list, after_label_list)
		om.MGlobal.displayInfo('Info: Deleted unused Nodes.')

	def shaKi_create_id_shader(self, id_name, shader_type):
		shader = mc.shadingNode('%s' % shader_type, asShader=True, n='%s' % id_name)
		shading_grp = mc.sets(name='%sSG' % shader, empty=True, renderable=True, noSurfaceShader=True)
		mc.connectAttr('%s.outColor' % shader, '%s.surfaceShader' % shading_grp)

	def shaKi_create_id_colors(self, shader_type):
		if self.filter_enabled_check == False:
			if self.shaKi_check_if_table_is_empty() == False:
				current_shader_list = self.get_all_list_items()
				current_label_color_list = self.get_all_label_colors()
				for i in self.shaKi_id_lib:
					if mc.objExists('%s' % i):
						om.MGlobal.displayInfo('Info: The %s shader already exists.' % i)
					else:
						self.shaKi_create_id_shader(i, shader_type)
						if shader_type == 'surfaceShader':
							mc.setAttr('%s.outColor' % i, tuple(self.shaKi_id_lib[i])[0], tuple(self.shaKi_id_lib[i])[1], tuple(self.shaKi_id_lib[i])[2], type='double3')
						else:
							mc.setAttr('%s.color' % i, tuple(self.shaKi_id_lib[i])[0], tuple(self.shaKi_id_lib[i])[1], tuple(self.shaKi_id_lib[i])[2], type='double3')
						new_shader_name = mc.ls(sl=True)
						current_shader_list.append(new_shader_name[0])

				self.shaKi_rebuild_list_after_creation(current_shader_list, current_label_color_list)
				om.MGlobal.displayInfo('Info: Created ID shader.')
		else:
			self.shaKi_message_box('Warning', "You can't create Shader when a Filter is active.")

	def shaKi_delete_id_colors(self):
		current_shader_list = self.get_all_list_items()
		original_list_length = len(current_shader_list)
		current_label_color_list = self.get_all_label_colors()
		for i in self.shaKi_id_lib:
			if mc.objExists(i):
				mc.hyperShade(objects='%s' % i)
				shaKi_delete_id_tmp = mc.ls(sl=True)
				if len(shaKi_delete_id_tmp) > 0:
					for k in shaKi_delete_id_tmp:
						mc.sets(e=True, fe='initialParticleSE')

				mc.delete('%s' % i)
				mc.delete('%sSG' % i)

		rows_to_delete = []
		for i in range(original_list_length):
			if current_shader_list[i] in self.shaKi_id_lib:
				rows_to_delete.append(i)

		rows_to_delete.reverse()
		for i in rows_to_delete:
			self.shaKi_manager_table.removeRow(i)

		om.MGlobal.displayInfo('Info: Created ID shader.')

	def shaKi_graph_materials(self, mode):
		hypershade_editor = mc.getPanel(scriptType='hyperShadePanel') or []
		hypershade_check = mc.scriptedPanel(hypershade_editor, q=True, control=True)
		if hypershade_check:
			all_panels = mc.getPanel(all=True)
			for panel_type in all_panels:
				if 'hyperShadePanel' in panel_type:
					hypershade_panel = panel_type

			if mode == 'object':
				objects = mc.filterExpand(mc.ls(sl=True), sm=12)
				if objects:
					mm.eval('hyperShadePanelGraphCommand("%s", "clearGraph");' % hypershade_panel)
					mm.eval('hyperShadePanelGraphCommand("%s", "graphMaterials");' % hypershade_panel)
				else:
					self.shaKi_message_box('Warning', 'Please select an object.')
			if mode == 'add':
				shader_list = self.get_selected_list_items(self.shaKi_manager_table)
				if shader_list:
					for i in shader_list:
						mc.select(i)
						mm.eval('hyperShadePanelGraphCommand("%s", "addSelected");' % hypershade_panel)

				else:
					self.shaKi_message_box('Warning', 'Please select a shader from the list.')
			if mode == 'remove':
				shader_list = self.get_selected_list_items(self.shaKi_manager_table)
				mm.eval('hyperShadePanelGraphCommand("%s", "removeSelected");' % hypershade_panel)
				if shader_list:
					for shader in shader_list:
						mc.select(shader)
						mm.eval('hyperShadePanelGraphCommand("%s", "removeSelected");' % hypershade_panel)

			if mode == 'show':
				mm.eval('hyperShadePanelGraphCommand("%s", "showUpAndDownstream");' % hypershade_panel)
		else:
			self.shaKi_message_box('Warning', 'Please open the Hypershade editor.')

def open_shader_kit_window(*args):
	try:
		rs_shader_kit.close()
		rs_shader_kit.deleteLater()
	except:
		pass
	rs_shader_kit = MainClass_ShaderKit()
	rs_shader_kit.show()