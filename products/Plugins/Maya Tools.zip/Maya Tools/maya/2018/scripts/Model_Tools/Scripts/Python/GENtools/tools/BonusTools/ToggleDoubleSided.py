#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds

def ToggleDoubleSided(doubleSidedState=None):
	# Get selected objects
	objects = cmds.ls(sl=True, l=True)
	objects.extend(cmds.ls(hl=True, l=True))
	# Get selected shapes
	if len(objects) > 0:
		objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	else:
		objectShapes = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh")
	if doubleSidedState is None:
		doubleSidedCounter = 0
		doubleSidedState = False
		for shape in objectShapes:
			try:
				doubleSidedCounter += cmds.getAttr(shape+".doubleSided")
			except:
				pass
		if len(objectShapes)/2 >= doubleSidedCounter:
			doubleSidedState = True		
	for shape in objectShapes:
		try:
			cmds.setAttr((shape+".doubleSided"), doubleSidedState)
		except:
			pass