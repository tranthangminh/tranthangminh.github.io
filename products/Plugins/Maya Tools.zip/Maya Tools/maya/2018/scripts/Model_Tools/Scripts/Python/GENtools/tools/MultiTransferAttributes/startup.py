#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Multi Transfer Attributes")
		self.scriptLoader.setStartupFile("MultiTransferAttributes.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Mesh")
		self.scriptLoader.setMenuItemDict({"image": "polyTransferAttributes.png", "sourceType": "mel", "command": "MultiTransferAttributes"})
		self.scriptLoader.setMenuItemOptionDict({"sourceType": "mel", "command": "MultiTransferAttributesOptions"})
		return self.scriptLoader