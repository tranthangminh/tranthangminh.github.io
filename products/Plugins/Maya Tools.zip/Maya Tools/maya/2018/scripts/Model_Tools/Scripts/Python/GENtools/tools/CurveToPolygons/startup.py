#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Curve To Polygons")
		self.scriptLoader.setToolDocumentation("/docs/curvetopolygons-overview/")
		self.scriptLoader.setStartupFile("CurveToPolygons.mel")
		self.scriptLoader.setStartupFunc("CTP_Startup")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Surfaces")
		self.scriptLoader.setMenuItemDict({"image": "extrude.png", "subMenu": True, "tearOff": True})
		self.scriptLoader.setMenuItemFunc(self.createMenuItem)
		return self.scriptLoader
	
	def createMenuItem(self):
		cmds.menuItem(label="Curve To Polygons", image="extrude.png", sourceType="mel", command="CurveToPolygons", dragDoubleClickCommand="CurveToPolygonsOptions")
		cmds.menuItem(image="extrude.png", optionBox=True, sourceType="mel", command="CurveToPolygonsOptions")
		cmds.menuItem(divider=True, dividerLabel="Edit NURBS Surfaces")
		cmds.menuItem(label="Create Curve From Pipe", image="wire.png", sourceType="mel", command="CreateCurveFromPipe")
		cmds.menuItem(label="Rebuild Pipe", image="rebuildSurface.png", sourceType="mel", command="RebuildPipe")