#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):	
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Move To Closest Vertex")
		self.scriptLoader.setStartupFile("MoveToClosestVertex.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Edit Mesh")
		self.scriptLoader.setMenuItemDict({"image": "polyMoveVertex.png", "sourceType": "mel", "command": "MoveToClosestVertex"})
		self.scriptLoader.setMenuItemOptionDict({"sourceType": "mel", "command": "MoveToClosestVertexOptions"})
		return self.scriptLoader