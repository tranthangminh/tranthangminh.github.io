#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Separate Object Per Material")
		self.scriptLoader.setStartupFile("SeparateObjectPerMaterial.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Mesh")
		self.scriptLoader.setMenuItemDict({"image": "polySeparate.png", "subMenu": True, "tearOff": True})
		self.scriptLoader.setMenuItemFunc(self.createMenuItem)
		return self.scriptLoader
	
	def createMenuItem(self):
		cmds.menuItem(label="Separate Object Per Material", image="polySeparate.png", sourceType="mel", command="SeparateObjectPerMaterial", dragDoubleClickCommand="SeparateObjectPerMaterialOptions")
		cmds.menuItem(image="polySeparate.png", optionBox=True, sourceType="mel", command="SeparateObjectPerMaterialOptions")
		cmds.menuItem(divider=True, dividerLabel="Mesh Display")
		cmds.menuItem(label="Fix Object Materials", image="render_adskMaterial.png", sourceType="mel", command="FixObjectMaterials")