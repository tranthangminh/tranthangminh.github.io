+ PLATFORM:win64 NormalToolkit 1.0.0.0 ..\
plug-ins: plugins
