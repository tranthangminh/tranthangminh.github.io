#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
from collections import defaultdict
import ast

from ..system.regedit import RegEdit

def getMayaVersion():
	maya_version = 0
	maya_version_list = cmds.about(version=True).split()
	if len(maya_version_list) > 1:
		for i in maya_version_list:
			if i.isnumeric():
				maya_version = int(i)
				break
		if "Extension" in maya_version_list:
			maya_version += 0.5
	else:
		maya_version = int(next(iter(maya_version_list), 0))
	return maya_version

def getMayaInstalls():
	maya_installs = defaultdict(dict)
	maya_installs_list = RegEdit().reg(rootKey="HKEY_LOCAL_MACHINE", regPath=r"SOFTWARE\Autodesk\Maya")[1]
	for maya_install in maya_installs_list:
		maya_installs[maya_install]["location"] = RegEdit().reg(rootKey="HKEY_LOCAL_MACHINE", regPath=r"SOFTWARE\Autodesk\Maya\{0}\Setup\InstallPath".format(maya_install), keyName="MAYA_INSTALL_LOCATION")
		maya_installs[maya_install]["version"] = RegEdit().reg(rootKey="HKEY_LOCAL_MACHINE", regPath=r"SOFTWARE\Autodesk\Maya\{0}".format(maya_install), keyName="UpdateVersion")
		if any(x is None for x in (maya_installs[maya_install]["location"], maya_installs[maya_install]["version"])):
			del maya_installs[maya_install]

	return maya_installs

def getGENtoolsInstalls():
	_defaultdict_dict = (lambda: defaultdict(dict))
	_registry_data = defaultdict(_defaultdict_dict)

	# Check for current installation
	gentools_list = RegEdit().reg(regPath=r"SOFTWARE\GENtools")[1]
	for tool in gentools_list:
		keys, values = RegEdit().reg(regPath=r"SOFTWARE\GENtools\{0}".format(tool))
		for key in keys:
			_registry_data[tool][key[0]] = key[1]
		for v in values:
			paths = RegEdit().reg(regPath=r"SOFTWARE\GENtools\{0}\{1}".format(tool, v))[0]
			for path in paths:
				path_value = path[1]
				if isinstance(path_value, str):
					if path_value.startswith("[") and path_value.endswith("]"):
						path_value = ast.literal_eval(path_value)
				_registry_data[tool][v][path[0]] = path_value
	
	return _registry_data