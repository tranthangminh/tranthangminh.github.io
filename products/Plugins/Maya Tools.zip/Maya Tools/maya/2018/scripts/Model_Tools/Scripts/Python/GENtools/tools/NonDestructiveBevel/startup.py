#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds
import os

ROOT_DIR = os.path.dirname(os.path.realpath(__file__))

class LoadScript(object):
	def getIconPath(self, iconName):
		return os.path.join(ROOT_DIR, os.path.join("icons", iconName))

	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Non-Destructive Bevel")
		self.scriptLoader.setToolDocumentation("/docs/nondestructivebevel-overview/")
		self.scriptLoader.setStartupFile("NonDestructiveBevel.mel")
		self.scriptLoader.setStartupFunc("NDB_Startup")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Mesh Tools")
		self.scriptLoader.setMenuItemDict({"image": self.getIconPath("NDB_NonDestructiveBevel_Icon_32.png"), "subMenu": True, "tearOff": True})
		self.scriptLoader.setMenuItemFunc(self.createMenuItem)
		return self.scriptLoader
	
	def createMenuItem(self):
		# Non-Destructive Bevel
		cmds.menuItem(label="Open Window", image=self.getIconPath("NDB_Window_Icon_32.png"), sourceType="mel", command="NDB_Window")
		cmds.menuItem(label="Toggle Pie Menu", image=self.getIconPath("NDB_PieMenu_Icon_32.png"), sourceType="mel", command="NDB_Toggle_Pie_Menu")
		cmds.menuItem(divider=True, dividerLabel="Manage")
		cmds.menuItem(label="Create", image=self.getIconPath("NDB_NonDestructiveBevel_Icon_32.png"), sourceType="mel", command="NDB_Create")
		cmds.menuItem(label="Reconnect", image=self.getIconPath("NDB_Reconnect_Icon_32.png"), sourceType="mel", command="NDB_Reconnect")
		cmds.menuItem(label="Remove", image=self.getIconPath("NDB_Remove_Icon_32.png"), sourceType="mel", command="NDB_Remove")
		cmds.menuItem(label="Clear", image=self.getIconPath("NDB_Clear_Icon_32.png"), sourceType="mel", command="NDB_Clear")
		cmds.menuItem(label="Bake Selected", image=self.getIconPath("NDB_Bake_Icon_32.png"), sourceType="mel", command="NDB_Bake_Selected")
		cmds.menuItem(label="Bake All", image=self.getIconPath("NDB_Bake_Icon_32.png"), sourceType="mel", command="NDB_Bake_All")
		cmds.menuItem(label="Edit Bevel", image=self.getIconPath("NDB_EditBevel_Icon_32.png"), sourceType="mel", command="NDB_Edit_Bevel")
		cmds.menuItem(label="Transfer Bevel Settings", image=self.getIconPath("NDB_TransferBevelSettings_Icon_32.png"), sourceType="mel", command="NDB_Transfer_Bevel_Settings")
		cmds.menuItem(divider=True, dividerLabel="Settings")
		cmds.menuItem(label="Toggle Bevel Display", image=self.getIconPath("NDB_BevelDisplay_Icon_32.png"), sourceType="mel", command="NDB_Toggle_Bevel_Display")
		cmds.menuItem(label="Toggle xRay", image=self.getIconPath("NDB_xRay_Icon_32.png"), sourceType="mel", command="NDB_Toggle_xRay")
		cmds.menuItem(label="Toggle Shading", image=self.getIconPath("NDB_Shading_Icon_32.png"), sourceType="mel", command="NDB_Toggle_Shading")
		cmds.menuItem(label="Toggle Real Time", image=self.getIconPath("NDB_RealTime_Icon_32.png"), sourceType="mel", command="NDB_Toggle_Real_Time")
		cmds.menuItem(label="Toggle Cage Display", image=self.getIconPath("NDB_ContextShading_Icon_32.png"), sourceType="mel", command="NDB_Toggle_Cage_Display")
		cmds.menuItem(label="Toggle Show Manips Override", image=self.getIconPath("NDB_ShowManip_Icon_32.png"), sourceType="mel", command="NDB_Toggle_Show_Manips_Override")