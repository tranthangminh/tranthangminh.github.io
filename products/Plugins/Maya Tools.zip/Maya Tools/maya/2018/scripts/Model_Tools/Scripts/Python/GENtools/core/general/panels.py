#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds

# for python 3 compatibility
from six.moves import range

def refreshOutliners():
	#mel.eval("AEdagNodeCommonRefreshOutliners();")
	eds = cmds.lsUI(editors=True)
	for i in range(len(eds)):
		if cmds.outlinerEditor(eds[i], exists=True) is True:
			cmds.outlinerEditor(eds[i], edit=True, refresh=True)

def hideInOutliner(nodeName, hide=True):
	# Apply to all DAG nodes
	nodeName = cmds.ls(nodeName, dagObjects=True, objectsOnly=True)
	# Hide/Unhide the items
	for i in range(len(nodeName)):
		cmds.setAttr((nodeName[i]+".hiddenInOutliner"), hide)
	# Refresh any outliner editors
	refreshOutliners()

def getOutlinerList(obj=None):
	# If object has a parent, get a list of the childrens
	if obj:
		parent = cmds.listRelatives(obj, parent=True, fullPath=True)
		if parent:
			return cmds.listRelatives(parent, children=True, type="transform", fullPath=True)
	# Otherwise, get list of assemblies in the scene
	return cmds.ls(assemblies=True, long=True)

def getOutlinerPosition(obj):
	return getOutlinerList(obj).index(obj)

def getActiveModelPanel():
	activeModelPanel = cmds.getPanel(withFocus=True)
	modelPanels = cmds.getPanel(type="modelPanel")
	if activeModelPanel not in modelPanels or not cmds.modelPanel(activeModelPanel, query=True, exists=True):
		activeModelPanel = "modelPanel4"
		if activeModelPanel not in modelPanels or not cmds.modelPanel(activeModelPanel, query=True, exists=True):
			activeModelPanel = None
	
	return activeModelPanel