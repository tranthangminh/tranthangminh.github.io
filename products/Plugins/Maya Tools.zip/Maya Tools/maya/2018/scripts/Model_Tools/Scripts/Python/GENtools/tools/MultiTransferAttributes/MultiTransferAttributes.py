#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya
from maya.mel import eval as melEval
from collections import defaultdict, OrderedDict, Mapping

# for python 3 compatibility
import six
from six.moves import range

def isclose(a, b, rt=0.000000001, at=0):
    return abs(a-b) <= max(rt * max(abs(a), abs(b)), at)

def CenterWindow(windowName):
    if cmds.window(windowName, ex=True) is True:
        gMainWindow = melEval("$gMainWindow = $gMainWindow")
        gMainWindowWidth = (cmds.window(gMainWindow, q=True, w=True)/2)
        gMainWindowHeight = (cmds.window(gMainWindow, q=True, h=True)/2)
        leftPosition = gMainWindowWidth-(cmds.window(windowName, q=True, w=True)/2)
        topPosition = gMainWindowHeight-(cmds.window(windowName, q=True, h=True)/2)
        cmds.window(windowName, e=True, le=leftPosition, te=topPosition)
        return [topPosition, leftPosition]

def ProgressBarWindow(**kwargs):
	title = "Progress Window"
	width = 300
	height = 25
	minValue = 0
	maxValue = 100
	centered = True
	for key, value in six.iteritems(kwargs):
		if key == "name" or key == "n":
			name = value
		elif key == "title" or key == "t":
			title = value
		elif key == "width" or key == "w":
			width = value
		elif key == "height" or key == "h":
			height = value
		elif key == "minValue" or key == "min":
			minValue = value
		elif key == "maxValue" or key == "max":
			maxValue = value
		elif key == "centered" or key == "c":
			centered = value
	
	if "name" in locals():
		if(cmds.window(name, ex=True) is True):
			cmds.deleteUI(name, wnd=True)
		progressWin = cmds.window(name, t=title, s=False, mxb=False, tlb=True)
	else:
		progressWin = cmds.window(t=title, s=False, mxb=False, tlb=True)
	cmds.formLayout("mainForm")
	progressBarName = cmds.progressBar(min=minValue, max=maxValue)
	cmds.setParent("..")
	
	cmds.formLayout("mainForm", e=True, af=[(progressBarName, "top", 0), (progressBarName, "left", 0), (progressBarName, "right", 0), (progressBarName, "bottom", 0)])
	
	cmds.showWindow(progressWin)
	cmds.window(progressWin, e=True, wh=(width, height), rtf=True)
	if centered is True:
		CenterWindow(progressWin)
	
	return progressWin, progressBarName

def GetCurrentSel(*args):
	objects = None
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects

def GetIsolatedObjects():
	isolatedObjects = None
	activeModelPanel = cmds.getPanel(wf=True)
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is False:
		activeModelPanel = "modelPanel4"
	
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is True:
		if cmds.isolateSelect(activeModelPanel, q=True, s=True) is True:
			isolatedObjects = cmds.ls(cmds.sets(cmds.isolateSelect(activeModelPanel, q=True, vo=True), q=True), l=True)
	
	return isolatedObjects

def GetHiddenDisplayLayersMembers():
	selList = OpenMaya.MSelectionList()
	sel_iter = OpenMaya.MItDependencyNodes(OpenMaya.MFn.kDisplayLayer)
	while not sel_iter.isDone():
		dnFn = OpenMaya.MFnDependencyNode(sel_iter.item())
		if dnFn.name() != "defaultLayer" and dnFn.findPlug("visibility").asBool() is False:
			layerConnections = OpenMaya.MPlugArray()
			dnFn.getConnections(layerConnections)
			
			for i in range(layerConnections.length()):
				connectedNodes = OpenMaya.MPlugArray()
				layerConnections[i].connectedTo(connectedNodes, False, True)
				for c in range(connectedNodes.length()):
					selList.add(connectedNodes[c].node())
		
		sel_iter.next()
	
	objects = []
	selList.getSelectionStrings(objects)
	return objects

def SelectMeshesBySize(*args, **kwargs):
	gMainProgressBar = melEval("$gMainProgressBar = $gMainProgressBar")
	maxSize = 1000
	ignoreHidden = True
	matchObjects = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			maxSize = int(arg)
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "maxSize" or key == "ms":
			maxSize = int(value)
		elif key == "ignoreHidden" or key == "ih":
			ignoreHidden = bool(value)
	
	if ignoreHidden is True:
		sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
		displayLayersMembers = cmds.ls(GetHiddenDisplayLayersMembers(), l=True, dag=True, ni=True, o=True, typ="mesh")
		sceneObjects = list(set(sceneObjects).difference(displayLayersMembers))
	else:
		sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh")
	
	sceneObjects = cmds.listRelatives(sceneObjects, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	sceneObjects = cmds.ls(sceneObjects, l=True, ni=True)
	if sceneObjects is not None:
		# Remove duplicates objects
		sceneObjects = list(OrderedDict.fromkeys(sceneObjects))
	
	if len(sceneObjects) > 0:
	
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True)
		# Fix for hanging previous progress
		if cmds.progressBar(gMainProgressBar, q=True, ic=True):
			cmds.progressBar(gMainProgressBar, e=True, ep=True)
			cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True)
		cmds.progressBar(gMainProgressBar, e=True, s=1)
		cmds.progressBar(gMainProgressBar, e=True, s=-1)
		
		cmds.progressBar(gMainProgressBar, e=True, bp=True, st="Selection in progress...", max=(len(sceneObjects)))
		
		for object in sceneObjects:
			if cmds.polyEvaluate(object, wa=True) < maxSize:
				matchObjects.append(object)
			cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
		
		cmds.select(matchObjects, r=True)
		cmds.progressBar(gMainProgressBar, e=True, ep=True)
	
	return matchObjects

def CompareSelfObjects(*args, **kwargs):
	# Create default args
	gMainProgressBar = melEval("$gMainProgressBar = $gMainProgressBar")
	progressBar = False
	objects = None
	targetObjects = None
	tolerance = 0.1
	objectSearchMethod = 3
	sourceList = []
	targetList = []
	sourceDict = defaultdict(list)
	transferAttrNodes = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "targetObjects" or key == "to":
			targetObjects = value
		elif key == "tolerance" or key == "t":
			tolerance = value
		elif key == "searchMethod" or key == "sm":
			objectSearchMethod = value
		elif key == "progressBar" or key == "pb":
			progressBar = value
	
	if objects is None:
		objects = GetCurrentSel(objects)[1]
	
	if objects is not None and len(objects) > 0:
		# Loop over objects
		for i, sourceObj in enumerate(objects):
			if targetObjects is None:
				targetObjects = list(objects)
			#else:
				#targetObjects = list(set(targetObjects).difference(objects))
			# Remove objects which already found a match
			targetObjects = list(set(targetObjects).difference(targetList))
			# Loop over a copy of objects
			for targetObj in targetObjects:
				if cmds.progressBar(gMainProgressBar, q=True, ic=True):
					return None, None
				objMatch = False
				if targetObj == sourceObj:
					objMatch = True
				elif cmds.polyEvaluate(sourceObj, v=True) == cmds.polyEvaluate(targetObj, v=True) and cmds.polyEvaluate(sourceObj, v=True) > 0:
					objMatch = False
					polyCompareNum = (cmds.polyCompare(sourceObj, targetObj, v=True, e=True, fd=True) - cmds.polyCompare(sourceObj, targetObj, c=True))
					# If face descriptions match, add object to list
					if polyCompareNum < 7:
						objMatch = True
					# Check if object surface area is similar
					if objectSearchMethod <= 4:
						worldAreaDigits = (len(str(int(min(cmds.polyEvaluate(sourceObj, wa=True), cmds.polyEvaluate(targetObj, wa=True))))))
						##worldAreaTolerance = ((worldAreaDigits*worldAreaDigits)*tolerance)/2
						worldAreaTolerance = ((worldAreaDigits*worldAreaDigits)*tolerance)
						if isclose(cmds.polyEvaluate(sourceObj, wa=True), cmds.polyEvaluate(targetObj, wa=True), at=worldAreaTolerance, rt=((float(10) ** worldAreaDigits)/10000000)*tolerance) is False:
							objMatch = False
						elif objectSearchMethod == 4:
							objMatch = True
					if polyCompareNum == 0 and objMatch is True:
						objMatch = True
					elif objectSearchMethod == 5 or (objectSearchMethod == 4 and objMatch is True):
						displayColors = cmds.polyOptions(targetObj, q=True, cs=True)[0]
						# Transfer vertex position
						transferAttr = cmds.transferAttributes(sourceObj, targetObj, pos=1, nml=0, uvs=0, col=0, spa=objectSearchMethod, sm=3)
						cmds.polyOptions(targetObj, cs=displayColors)
						polyCompareNum = (cmds.polyCompare(sourceObj, targetObj, v=True, e=True, fd=True) - cmds.polyCompare(sourceObj, targetObj, c=True))
						# If face descriptions match after transfer, add object to list and continue to the next
						if polyCompareNum < 7:
							objMatch = True
						else:
							objMatch = False
						#transferAttrNodes.extend(transferAttr)
						cmds.delete(transferAttr)
						#cmds.refresh(f=True)
						#cmds.undo()
				if objMatch is True:						
					targetList.append(targetObj)
					sourceDict[sourceObj].append(targetObj)
					if sourceObj not in sourceList:
						sourceList.append(sourceObj)
					if progressBar is True:
						cmds.progressBar(gMainProgressBar, e=True, s=(len(objects)-i), st="Selection in progress...")
				if progressBar is True:
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
		#cmds.delete(transferAttrNodes)
	return sourceList, sourceDict

def setAllPanelsToRenderer(renderer="base_OpenGL_Renderer", reset=True):
    """Possible values: base_OpenGL_Renderer, hwRender_OpenGL_Renderer, vp2Renderer"""
    modelPanels = cmds.getPanel(typ="modelPanel")
    for panel in modelPanels:
        cmds.modelEditor(panel, e=True, rnm=renderer)
    if reset or os.environ.get("MAYA_DISABLE_VP2_WHEN_POSSIBLE", False):
        cmds.ogs(reset=True)

def SelectAllMeshesOnce(*args, **kwargs):
	gMainProgressBar = melEval("$gMainProgressBar = $gMainProgressBar")
	objects = None
	tolerance = 5
	objectSearchMethod = 3
	ignoreHidden = True
	isolateConstraint = True
	isolatedObjects = None
	allObjects = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "tolerance" or key == "t":
			tolerance = value
		elif key == "searchMethod" or key == "sm":
			objectSearchMethod = value
		elif key == "ignoreHidden" or key == "ih":
			ignoreHidden = value
		elif key == "isolateConstraint" or key == "ic":
			isolateConstraint = value
	
	# Get selected objects
	objects = GetCurrentSel(objects)[1]
	
	# Get isolated objects list
	if isolateConstraint is True:
		isolatedObjects = GetIsolatedObjects()
	# Get all meshes in the scene
	if ignoreHidden is True:
		#if len(objects) > 0:
			#sceneObjects = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
		if isolatedObjects is not None:
			sceneObjects = cmds.ls(isolatedObjects, l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
		else:
			sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
		displayLayersMembers = cmds.ls(GetHiddenDisplayLayersMembers(), l=True, dag=True, ni=True, o=True, typ="mesh")
		sceneObjects = list(set(sceneObjects).difference(displayLayersMembers))
	else:
		#if len(objects) > 0:
			#sceneObjects = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
		if isolatedObjects is not None:
			sceneObjects = cmds.ls(isolatedObjects, l=True, dag=True, ni=True, o=True, typ="mesh")
		else:
			sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh")
	sceneObjects = cmds.listRelatives(sceneObjects, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	sceneObjects = cmds.ls(sceneObjects, l=True, ni=True)
	if sceneObjects is not None:
		# Remove duplicates objects
		sceneObjects = list(OrderedDict.fromkeys(sceneObjects))
		# Remove objects from sceneObjects
		#sceneObjects = list(set(sceneObjects).difference(objects))
	if len(sceneObjects) > 0:				
		if len(objects) <= 0:
			objects = list(sceneObjects)
			targetObjects = None
		else:
			objects = list(set(objects).intersection(sceneObjects))
			targetObjects = list(sceneObjects)
			if len(objects) <= 0:
				objects = list(sceneObjects)
				targetObjects = None
		
		if targetObjects is None:
			cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selection in progress...", min=0, max=(len(objects)*len(objects)))
		else:
			cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selection in progress...", min=0, max=(len(objects)*len(targetObjects)))
		
		# Pause viewport
		cmds.ogs(p=True)
		cmds.refresh(cv=True)
		
		#cmds.refresh(suspend=True)
		#gMainPane = melEval("$gMainPane = $gMainPane")
		#cmds.paneLayout(gMainPane, e=True, m=False)
		
		#viewportDisplay = cmds.modelEditor("modelPanel4", q=True, da=True)
		#modelPanels = cmds.getPanel(typ="modelPanel")
		#for panel in modelPanels:
			#cmds.modelEditor(panel, e=True, da="boundingBox")
		#setAllPanelsToRenderer()
		
		#cmds.select(cl=True)
		
		# List unique objects
		allObjects, allObjectsDict = CompareSelfObjects(objects, to=targetObjects, t=tolerance, sm=objectSearchMethod, pb=True)
		
		# Unpause viewport
		cmds.ogs(p=True)
		
		cmds.progressBar(gMainProgressBar, e=True, ep=True)
		
		#shader = cmds.shadingNode("lambert", asShader=True)
		#shadingGroup = cmds.sets(r=True, nss=True, em=True)
		#cmds.connectAttr(shader+".outColor", shadingGroup+".surfaceShader")
		#cmds.sets(objects, e=True, fe=shadingGroup)
		#cmds.undo()
		
		#cmds.select(cl=True)
		
		if allObjectsDict is not None:
			cmds.select(list(allObjectsDict.keys()), r=True)
			#cmds.evalDeferred("cmds.select({0}, r=True)".format(allObjectsDict.keys()))
			# Unpause viewport
			#cmds.evalDeferred("cmds.ogs(p=True)")
			#cmds.evalDeferred("cmds.select({0}, r=True)".format(list(allObjectsDict)))
			#cmds.select(allObjectsDict.keys(), add=True)
		
		#cmds.refresh(suspend=False)
		#cmds.paneLayout(gMainPane, e=True, m=True)
		#cmds.ogs(p=True)
		#setAllPanelsToRenderer(renderer="vp2Renderer")
		
		#for panel in modelPanels:
			#cmds.modelEditor(panel, e=True, da=viewportDisplay)
	
	return allObjects, allObjectsDict

def ObjectsNotInDict(objectDict, *args, **kwargs):
	gMainProgressBar = melEval("$gMainProgressBar = $gMainProgressBar")
	objects = None
	ignoreHidden = True
	isolateConstraint = True
	isolatedObjects = None
	objectsNotInDict = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "ignoreHidden" or key == "ih":
			ignoreHidden = value
		elif key == "isolateConstraint" or key == "ic":
			isolateConstraint = value
	
	# Get selected objects
	objects = GetCurrentSel(objects)[1]
	
	# Get isolated objects list
	if isolateConstraint is True:
		isolatedObjects = GetIsolatedObjects()
	# Get all meshes in the scene
	if ignoreHidden is True:
		if isolatedObjects is not None:
			sceneObjects = cmds.ls(isolatedObjects, l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
		else:
			sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
		displayLayersMembers = cmds.ls(GetHiddenDisplayLayersMembers(), l=True, dag=True, ni=True, o=True, typ="mesh")
		sceneObjects = list(set(sceneObjects).difference(displayLayersMembers))
	else:
		if isolatedObjects is not None:
			sceneObjects = cmds.ls(isolatedObjects, l=True, dag=True, ni=True, o=True, typ="mesh")
		else:
			sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh")
	sceneObjects = cmds.listRelatives(sceneObjects, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	sceneObjects = cmds.ls(sceneObjects, l=True, ni=True)
	if sceneObjects is not None:
		# Remove duplicates objects
		sceneObjects = list(OrderedDict.fromkeys(sceneObjects))
		# Remove objects from sceneObjects
		sceneObjects = list(set(sceneObjects).difference(objects))
	if len(sceneObjects) > 0:
		objectList = []
		[objectList.extend(objList) for key, objList in six.iteritems(objectDict)]
		[objectList.append(key) for key, objList in six.iteritems(objectDict)]
		for object in sceneObjects:
			if object not in objectList:
				objectsNotInDict.append(object)
	
	return objectsNotInDict

def MultiTransferAttributes(*args, **kwargs):
	objectDict = None
	currentSel = GetCurrentSel()[0]

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objectDict = arg

	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objectDict" or key == "od":
			objectDict = value

	if isinstance(objectDict, Mapping) is False:
		objectDict = SelectAllMeshesOnce()[1]
	
	if objectDict is not None:
		for key, objects in objectDict.items():
			if key in objects:
				objects.remove(key)
			if len(objects) <= 0:
				del objectDict[key]
	
	if cmds.window("MultiTransferAttributes", ex=True) is False:
		closeWindow = True
		melEval("MTA_Window();");
		cmds.window("MultiTransferAttributes", e=True, vis=False)
	
	# Pause viewport
	cmds.ogs(p=True)
	cmds.refresh(cv=True)
	
	for key, objects in six.iteritems(objectDict):
		melEval("MTA_loadButton(0,2);")
		melEval("MTA_loadButton(1,2);")
		cmds.select(key, r=True)
		melEval("MTA_loadButton(0,0);")
		cmds.select(objects, r=True)
		melEval("MTA_loadButton(1,0);")
		melEval("MTA_transferButton();")
	
	# Unpause viewport
	cmds.ogs(p=True)
	progressWinName, progressBarName = ProgressBarWindow(n="NT_ProgressWin", t="Refreshing viewport...", w=200, max=1)
	cmds.progressBar(progressBarName, e=True, s=2)
	cmds.evalDeferred("import maya.cmds as cmds;cmds.deleteUI('"+progressWinName+"', wnd=True)")

	if "closeWindow" in locals():
		cmds.deleteUI("MultiTransferAttributes", wnd=True)

	cmds.select(currentSel, r=True)

	return objectDict

def reduceListDecimals(targetList, max=3):
	newList = []
	for each in targetList:
		number = str(each)
		maxlen = max
		if "-" in number:
			maxlen = max+1
		splittedNum = number.split(".")
		maxlen -= len(splittedNum[0])
		number = round(each, maxlen)
		newList.append(number)
	return newList 
		
def createLODMatchDict(sourceList, targetList):
	sourceDict = {}
	matchDict = {}
	noMatchList = list(targetList)
	for sourceObj in sourceList:
		sourceDict[sourceObj] = {"objectCenter": cmds.objectCenter(sourceObj, gl=True), "boundingBox": cmds.xform(sourceObj, q=True, ws=True, bb=True)}
	
	for targetObj in targetList:
		targetCenter = cmds.objectCenter(targetObj, gl=True)
		#targetBoundingBox = cmds.exactWorldBoundingBox(targetObj)
		targetBoundingBox = cmds.xform(targetObj, q=True, ws=True, bb=True)
		for sourceObj, values in sourceDict.items():
			#if ["%.2f" % elem for elem in targetCenter] == ["%.2f" % elem for elem in values["objectCenter"]] and ["%.2f" % elem for elem in targetBoundingBox] == ["%.2f" % elem for elem in values["boundingBox"]]:
			#if ["%.2f" % elem for elem in targetBoundingBox] == ["%.2f" % elem for elem in values["boundingBox"]]:
			if reduceListDecimals(targetBoundingBox) == reduceListDecimals(values["boundingBox"]):
				matchDict[sourceObj] = targetObj
				noMatchList.remove(targetObj)
				del sourceDict[sourceObj]
				break
	
	if len(noMatchList) > 0:
		for targetObj in list(noMatchList):
			targetCenter = cmds.objectCenter(targetObj, gl=True)
			#targetBoundingBox = cmds.exactWorldBoundingBox(targetObj)
			targetBoundingBox = cmds.xform(targetObj, q=True, ws=True, bb=True)
			for sourceObj, values in sourceDict.items():
				if len([x for x in reduceListDecimals(targetBoundingBox) if x not in reduceListDecimals(values["boundingBox"])]) <= 2:
					matchDict[sourceObj] = targetObj
					noMatchList.remove(targetObj)
					del sourceDict[sourceObj]
					break
	
	for sourceObj, targetObj in six.iteritems(matchDict):
		cmds.transferAttributes(sourceObj, targetObj, pos=0, nml=0, uvs=2, col=0, spa=0, sm=3)
	
	cmds.delete(targetList, ch=True)
	
	if len(noMatchList) > 0:
		print("No match found for:")
		print(noMatchList)
		#print "\n".join(noMatchList)
	
	return matchDict, noMatchList

'''
import timeit as timeit
from functools import partial

import sys
scriptDirPath = (cmds.internalVar(userScriptDir=True)+"MultiTransferAttributes/")
sys.path.append(scriptDirPath)
import MultiTransferAttributes
reload(MultiTransferAttributes)

objectDict = MultiTransferAttributes.SelectAllMeshesOnce(t=5, sm=4)[1]
print dict(objectDict)
#print timeit.timeit(partial(MultiTransferAttributes.SelectAllMeshesOnce, t=2, sm=4), number=1)

#objectList = []
#[objectList.extend(objList) for key, objList in objectDict.iteritems()]
#[objectList.append(key) for key, objList in objectDict.iteritems()]
#cmds.select(objectList, r=True)

#MultiTransferAttributes.MultiTransferAttributes(objectDict)
'''