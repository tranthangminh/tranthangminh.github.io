#!/usr/bin/python
# -*- coding: utf-8 -*-
import logging
import threading
import maya.cmds as cmds
from functools import wraps
from maya.utils import executeDeferred, executeInMainThreadWithResult

def undo_chunk(function):
	@wraps(function)
	def wrapper(*args, **kwargs):
		cmds.undoInfo(openChunk=True)
		try:
			return function(*args, **kwargs)
		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=False)
	return wrapper

def make_undoable(function):
	@wraps(function)
	def wrapper(*args, **kwargs):
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		try:
			return function(*args, **kwargs)
		except Exception as e:
			logging.exception(e)
		finally:
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)
	return wrapper

def is_main_thread():
	return isinstance(threading.current_thread(), threading._MainThread)

def make_thread_safe(function):
	@wraps(function)
	def wrapper(*args, **kwargs):
		try:
			if is_main_thread():
				return function(*args, **kwargs)
			else:
				return executeInMainThreadWithResult(function, *args, **kwargs)
		except Exception as e:
			logging.exception(e)
	return wrapper

def deferred_thread_safe(function):
	@wraps(function)
	def wrapper(*args, **kwargs):
		try:
			if is_main_thread():
				return function(*args, **kwargs)
			else:
				return executeDeferred(function, *args, **kwargs)
		except Exception as e:
			logging.exception(e)
	return wrapper
