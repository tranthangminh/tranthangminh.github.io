+ PLATFORM:win64 NonDestructiveBevel 1.0.0.0 ..\
plug-ins: plugins
