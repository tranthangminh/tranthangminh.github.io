#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.mel as mel
from collections import OrderedDict
from webbrowser import open_new_tab
from functools import partial

# for python 3 compatibility
import six

from .utils.infos import getMayaVersion
from .gui.options import helpCmd

MAYA_VERSION = getMayaVersion()

def getFirstString(x):
	if isinstance(x, (list, tuple)):
		return next(iter(x), "")
	return x

class classproperty(property):
    def __get__(self, cls, owner):
        return classmethod(self.fget).__get__(None, owner)()

def open_url(*args):
	if args and args[0] and isinstance(args[0], six.string_types):
		open_new_tab(args[0])

class GENtoolsMainMenu(object):
	def __init__(self):
		super(GENtoolsMainMenu, self).__init__()
		
		self._menuItemDict = OrderedDict()
		self._startupList = []
		
	@classproperty
	def mainWindow(cls):
		return mel.eval("$gMainWindow = $gMainWindow")
	
	@classproperty
	def menuName(cls):
		return "GENtoolsMenu"
	
	@classproperty
	def markingMenuName(cls):
		return "GENtoolsMenuMM"
	
	@staticmethod
	def deleteMenu():
		if cmds.menu(GENtoolsMainMenu.menuName, exists=True):
			cmds.deleteUI(GENtoolsMainMenu.menuName, menu=True)
	
	@staticmethod
	def deleteMarkingMenu():
		if cmds.menu(GENtoolsMainMenu.markingMenuName, exists=True):
			cmds.deleteUI(GENtoolsMainMenu.markingMenuName, menu=True)
	
	def createMenu(self, startup=False):
		# Delete menu bar
		GENtoolsMainMenu.deleteMenu()
		# Create menu bar
		cmds.menu(GENtoolsMainMenu.menuName, parent=GENtoolsMainMenu.mainWindow, tearOff=True, label="GENtools")
		# Populate menu
		self.createMenuItems(GENtoolsMainMenu.menuName, startup=startup)
	
	def createMarkingMenu(self):
		# Delete marking menu
		GENtoolsMainMenu.deleteMarkingMenu()
		# Create marking menu
		cmds.popupMenu(GENtoolsMainMenu.markingMenuName, button=1, shiftModifier=False, altModifier=False, ctrlModifier=False, allowOptionBoxes=True, parent="viewPanes", markingMenu=True)
		# Populate menu
		self.createMenuItems(GENtoolsMainMenu.markingMenuName)

	def createMenuItem(self, menuParent, scriptDict={}, startup=False):
		if "menuItemDict" in scriptDict:
			cmds.setParent(menuParent, menu=True)
			menuItemDict = dict(scriptDict["menuItemDict"])
			
			# Create ordered subMenu inside the current category
			if "subMenuName" in scriptDict and scriptDict["subMenuName"]:
				subMenuItem = None
				
				# List all the elements of the main menu
				menuItemList = cmds.menu(menuParent, query=True, itemArray=True)
				
				# Get all the elements under the current category
				menuCategoryList = []
				miStart, miEnd = 0, 0
				for mi in menuItemList:
					if cmds.menuItem(mi, query=True, divider=True) and cmds.menuItem(mi, query=True, dividerLabel=True) == scriptDict["menuCategory"]:
						miStart = menuItemList.index(mi)+1
						continue
					if cmds.menuItem(mi, query=True, divider=True) and miStart < menuItemList.index(mi):
						miEnd = menuItemList.index(mi)
						break
				
				# Create a list of the elements under the current category
				if miEnd == 0:
					menuCategoryList = menuItemList[miStart:]
				elif miStart < miEnd:
					menuCategoryList = menuItemList[miStart:miEnd]
				
				# Check if the subMenu already exists in the current category
				for mi in menuCategoryList:
					if cmds.menuItem(mi, query=True, subMenu=True) and cmds.menuItem(mi, query=True, label=True) == scriptDict["subMenuName"]:
						subMenuItem = mi
						break
				
				# If the subMenu doesn't exist, create it
				if not subMenuItem:		
					menuItemInsert = {}
					menuCategoryDict = OrderedDict()
					
					# Create a dict of the elements under the current category
					for mi in menuCategoryList:
						menuCategoryDict[cmds.menuItem(mi, query=True, label=True)] = mi
					
					# Find where to insert the new subMenu to keep everything in alphabetical order
					menuCategoryKeys = list(menuCategoryDict.keys())
					menuCategoryKeys.append(scriptDict["subMenuName"])
					menuCategoryKeys = sorted(menuCategoryKeys)
					menuCategoryIndex = menuCategoryKeys.index(scriptDict["subMenuName"])
					if menuCategoryIndex:
						menuItemInsert = {"insertAfter": menuCategoryDict[menuCategoryKeys[menuCategoryIndex-1]]}
					elif miStart > 0:
						menuItemInsert = {"insertAfter": menuItemList[miStart-1]}
					
					# Create the subMenu item
					subMenuItem = cmds.menuItem(label=scriptDict["subMenuName"], subMenu=True, tearOff=True, **menuItemInsert)
					
					# Create top divider label
					cmds.menuItem(divider=True, dividerLabel=scriptDict["subMenuName"])
				
				else:
					# Set the subMenu as parent
					cmds.setParent(subMenuItem, menu=True)
			
			if menuItemDict:
				# Label
				if not any(x in menuItemDict for x in ["label", "l"]) and "toolName" in scriptDict:
					menuItemDict["label"] = scriptDict["toolName"]
				
				# Create menuItem
				menuItem = cmds.menuItem(**menuItemDict)
			
				if "menuItemOptionDict" in scriptDict and scriptDict["menuItemOptionDict"]:
					# image
					if not any(x in scriptDict["menuItemOptionDict"] for x in ["image", "i"]):
						scriptDict["menuItemOptionDict"]["image"] = cmds.menuItem(menuItem, query=True, image=True)
					
					# dragDoubleClickCommand
					if not cmds.menuItem(menuItem, query=True, dragDoubleClickCommand=True):
						cmd = None
						cmdType = "python"
						if "command" in scriptDict["menuItemOptionDict"]:
							cmd = scriptDict["menuItemOptionDict"]["command"]
						elif "c" in scriptDict["menuItemOptionDict"]:
							cmd = scriptDict["menuItemOptionDict"]["c"]
						if "sourceType" in scriptDict["menuItemOptionDict"]:
							cmdType = scriptDict["menuItemOptionDict"]["sourceType"]
						elif "stp" in scriptDict["menuItemOptionDict"]:
							cmdType = scriptDict["menuItemOptionDict"]["stp"]
						if cmd:
							cmds.menuItem(menuItem, edit=True, dragDoubleClickCommand=cmd, sourceType=cmdType)
					
					menuItemOption = cmds.menuItem(optionBox=True, **scriptDict["menuItemOptionDict"])
				
				if cmds.menuItem(menuItem, query=True, isCheckBox=True):
					if "menuCheckBoxDict" in scriptDict:
						# Bind checkbox and function
						if "checkBoxFunc" in scriptDict["menuCheckBoxDict"]:
							melList = scriptDict["menuCheckBoxDict"]["checkBoxFunc"]
							if melList:
								mel.eval('global string ${0}[];'.format(melList))
								mel.eval('appendStringArray($%s, {"%s"}, 1);' % (melList, menuItem))
						# Checkbox state
						if "optionVarName" in scriptDict and "optionVarName" in scriptDict["menuCheckBoxDict"]:
							startupVar = getFirstString(cmds.optionVar(query=scriptDict["optionVarName"]))
							checkBoxVar = getFirstString(cmds.optionVar(query=scriptDict["menuCheckBoxDict"]["optionVarName"]))
							if (startup and startupVar and checkBoxVar) or (not startup and checkBoxVar):
								cmds.menuItem(menuItem, edit=True, checkBox=True)
		
		if "menuItemFunc" in scriptDict and callable(scriptDict["menuItemFunc"]):
			# Run menuItem creation function
			scriptDict["menuItemFunc"]()
	
	def createMenuItems(self, menuParent, startup=False):
		if len(self.startupList) > 0:
			cmds.setParent(menuParent, menu=True)
			cmds.menuItem(divider=True, dividerLabel="Settings")
			cmds.menuItem(label="Startup Settings", image="QR_settings.png", sourceType="mel", command="GENtools_StartupOptionsWindow();")
		
		# Sort menuItemDict in alphabetical order
		iter_dict = sorted(six.iteritems(self.menuItemDict))
		if len(iter_dict) > 1:
			# menuItem without no category are appended at the bottom
			if iter_dict[0][0] == "":
				iter_dict.append(iter_dict.pop(iter_dict.index(iter_dict[0])))
		
		# Populate menu bar
		for key, value in iter_dict:			
			# Ignore empty menu
			if not value:
				continue
			
			cmds.setParent(menuParent, menu=True)
			
			# Create menu category
			cmds.menuItem(divider=True, dividerLabel=key)
			
			# Populate menu category
			if isinstance(value, dict):
				if "menuItemFunc" in value:
					for d in value["menuItemFunc"]:
						self.createMenuItem(menuParent, d, startup=startup)
				
				if "subMenu" in value:
					for d in value["subMenu"]:
						self.createMenuItem(menuParent, d)
		
		cmds.setParent(upLevel=True)
		
		if self.menuItemDict:
			cmds.setParent(menuParent, menu=True)
			cmds.menuItem(divider=True, dividerLabel="About")
			if MAYA_VERSION >= 2017:
				cmds.menuItem(label="Check Updates", image="redrawPaintEffects.png", sourceType="mel", command="GENtools_CheckUpdatesWindow();")
			cmds.menuItem(label="Documentation", image="info.png", command=partial(helpCmd, helpUrl="/docs/"))
			cmds.menuItem(label="About", image="menuIconHelp.png", sourceType="mel", command="GENtools_AboutWindow();")
			cmds.setParent(upLevel=True)
	
	@property
	def menuItemDict(self):
		return self._menuItemDict
	
	@property
	def startupList(self):
		return self._startupList
	
	def addMenuItem(self, scriptDict):
		if "startupFunc" in scriptDict:
			self._startupList.append(scriptDict)
		
		menuCategory = ""
		if "menuCategory" in scriptDict:
			menuCategory = scriptDict["menuCategory"]
		
		if menuCategory not in self.menuItemDict:
			self.menuItemDict[menuCategory] = {}
		
		if ("menuItemDict" in scriptDict and scriptDict["menuItemDict"]) or ("menuItemFunc" in scriptDict and scriptDict["menuItemFunc"]):
			if "menuItemDict" in scriptDict and "subMenu" in scriptDict["menuItemDict"]:
				if "subMenu" not in self.menuItemDict[menuCategory]:
					self.menuItemDict[menuCategory]["subMenu"] = []
				self.menuItemDict[menuCategory]["subMenu"].append(scriptDict)
			else:
				if "menuItemFunc" not in self.menuItemDict[menuCategory]:
					self.menuItemDict[menuCategory]["menuItemFunc"] = []
				self.menuItemDict[menuCategory]["menuItemFunc"].append(scriptDict)
		
		else:
			return
		
		if "toolName" in scriptDict:
			print(("#	> Adding {0} in GENtools menu".format(scriptDict["toolName"])))