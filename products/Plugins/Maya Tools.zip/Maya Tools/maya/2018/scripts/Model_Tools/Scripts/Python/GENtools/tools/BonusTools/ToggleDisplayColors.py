#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya
from collections import OrderedDict

# for python 3 compatibility
import six

def ToggleDisplayColors(*args, **kwargs):
	# Create default args
	objects = None
	toggleColors = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			toggleColors = arg
		elif i == 1:
			displayColors = arg
		elif i == 2:
			displayColorChannel = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "toggleColors" or key == "tc":
			toggleColors = value
		elif key == "displayColors" or key == "ds":
			displayColors = value
		elif key == "displayColorChannel" or key == "dcc":
			displayColorChannel = value
	
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	
	if len(objects) > 0:
		objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	else:
		objectShapes = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh")
	
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	objects = list(OrderedDict.fromkeys(objects))
	
	if len(objects) > 100:
		# Pause viewport 2.0
		pauseViewport = False
		modelPanels = cmds.getPanel(typ="modelPanel")
		for panel in modelPanels:
			if cmds.modelEditor(panel, q=True, rnm=True) == "vp2Renderer":
				pauseViewport = True
		if pauseViewport is True and cmds.ogs(q=True, p=True) is False:
			cmds.ogs(p=True)
			cmds.refresh(cv=True)
	
	selList = OpenMaya.MSelectionList()
	for each in objects:
		selList.add(each)

	dagPath = OpenMaya.MDagPath()
	component = OpenMaya.MObject()
	dagNode = OpenMaya.MObject()
	dependencyNode = OpenMaya.MFnDependencyNode() 

	sel_iter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMesh)
	while not sel_iter.isDone():
		sel_iter.getDagPath(dagPath, component)
		meshNode = OpenMaya.MFnMesh(dagPath)
		dagPath.pop() # Remove shape
		
		# Get object name
		objectName = dagPath.fullPathName()
		
		if "displayColors" not in locals():
			displayColors = meshNode.displayColors()
			if toggleColors:
				displayColors = not displayColors
		
		meshNode.setDisplayColors(displayColors)
		
		if "displayColorChannel" in locals():
			sel_iter.getDependNode(dagNode)
			dependencyNode.setObject(dagNode)
			dccPlug = dependencyNode.findPlug("displayColorChannel", True)
			try:
				dccPlug.setString(displayColorChannel)
			except:
				cmds.warning("{0} skipped. Display Color Channel is invalid.".format(objectName))
		
		sel_iter.next()
	
	# Unpause viewport 2.0
	if cmds.ogs(q=True, p=True) is True:
		cmds.ogs(p=True)
	
	# Need to reset viewport to avoid display issues
	cmds.ogs(reset=True)

# Toggle
#ToggleDisplayColors()

# On
#ToggleDisplayColors(True)

# Off
#ToggleDisplayColors(False)

# None
#ToggleDisplayColors(True, "None")

# Diffuse
#ToggleDisplayColors(True, "Diffuse")

# Ambient
#ToggleDisplayColors(True, "Ambient")