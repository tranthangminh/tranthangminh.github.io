#!/usr/bin/python
# -*- coding: utf-8 -*-
from maya.OpenMayaUI import MQtUtil
try:
	from PySide2 import QtWidgets, QtCore, QtGui
	from shiboken2 import wrapInstance
except ImportError:
	from PySide import QtCore, QtGui
	from PySide import QtGui as QtWidgets
	from shiboken import wrapInstance
import os
import sys
import maya.cmds as cmds

# for python 3 compatibility
import six
try:
	from past.builtins import long
except:
	pass

from .widgets import QWindowCustom, QFrameTitleBar, QFrameUrl
from .updates_ui import Ui_MainWindow as updates_ui
from .utils import clearLayout

ROOT_FILE = __file__
ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
ROOT_DIR = ROOT_DIR_RAW
if not isinstance(ROOT_FILE, six.text_type):
	try:
		ROOT_FILE = ROOT_FILE.decode(sys.getfilesystemencoding())
		ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
		ROOT_DIR = ROOT_DIR_RAW.encode(sys.getfilesystemencoding())
	except:
		pass

class GENtoolsUpdatesWindow(QWindowCustom):
	def __init__(self, status=""):
		# If window already exists, delete window
		self.deleteInstances()
		
		try:
			windowParent = wrapInstance(long(MQtUtil.mainWindow()), QtWidgets.QWidget)
		except Exception as e:
			windowParent = None
		
		ui_file = os.path.join(ROOT_DIR_RAW, r"updates_ui.ui")
		ui_widget = updates_ui
		self._status = status
		
		customWidgets = [QFrameTitleBar, QFrameUrl]
		
		super(GENtoolsUpdatesWindow, self).__init__(parent=windowParent, ui_file=ui_file, ui_widget=ui_widget, customWidgets=customWidgets)
		
		# Window object name
		self.windowName = "GENtools_Updates"
		self.setObjectName(self.windowName)
		# Window title
		self.setWindowTitle("Check Updates")
		
		self.resize(QtCore.QSize(350, 230))

		# Show UI
		self.initUI()
	
	def getStyleSheet(self):
		return ("""			
			QFrame.windowFrame{
				background-color: rgba(45, 45, 45, 80%);
				border-bottom-left-radius: 2px;
				border-bottom-right-radius: 2px;
			}
			
			QLabel.title{
				color: rgba(255, 255, 255, 100%);
				font-size: 16px;
				font-weight: bold;
				text-transform: uppercase;
			}

			QLabel.description{
				font-size: 14px;
			}
			
			QFrameUrl.link QLabel, QFrameUrl.artstationLink QLabel{
				color: rgba(255, 255, 255, 100%);
			}
			
			QFrameUrl.link[hover=true] QLabel, QFrameUrl.artstationLink[hover=true] QLabel{
				color: rgba(200, 200, 200, 100%);
			}
			
			QFrameUrl.artstationLink QLabel{
				font-size: 14px;
			}
			
			QFrameTitleBar.titleBar{
				background-color: rgba(15, 15, 15, 80%);
				border-bottom: 1px solid rgba(55, 55, 55, 80%);
			}

			QPushButton{
				color: rgba(255, 255, 255, 100%);
				font-weight: bold;
				font-size: 14px;
				background-color: rgba(230, 86, 22, 100%);
				border-radius: 5px;
				padding: 8px 15px 8px 15px;
				border: none;
				min-width: 70px;
				margin: 0 1px 1px 1px;
			}
			
			QPushButton:disabled{
				color: rgba(255, 255, 255, 50%);
				background-color: rgba(230, 86, 22, 50%);
			}
			
			QPushButton:hover{
				background-color: rgba(209, 49, 10, 100%);
			}
			
			QPushButton:pressed{
				margin: 1px 0 0 2px;
			}
		""")
	
	def deleteInstances(self):
		global _GENtoolsUpdatesWinInstance
		if "_GENtoolsUpdatesWinInstance" in globals():
			try:
				_GENtoolsUpdatesWinInstance.close()
			except:
				pass
		_GENtoolsUpdatesWinInstance = self
	
	def setStatus(self, status):
		if status:
			self._status = status
			self.setControlsProperty()
			self.resize(self.sizeHint())

	def setControlsProperty(self):
		if self._ui_widget:
			# UI Controls
			self._ui_widget.windowFrame.setProperty("class", "windowFrame")
			self._ui_widget.titleBar.setText("Check Updates")
			self._ui_widget.titleBar.setProperty("defaultCss", False)
			self._ui_widget.updateTitle.setProperty("class", "title")
			self._ui_widget.updateDescription.setProperty("class", "description")
			self._ui_widget.updateLink.setText("ArtStation library")
			self._ui_widget.updateLink.setUrl("https://www.artstation.com/marketplace/library")
			self._ui_widget.updateLink.setIcon(":/images/artstation_logo_32.png")
			self._ui_widget.updateLink.setIconHover(":/images/artstation_logo_hover_32.png")
			self._ui_widget.updateLink.setProperty("class", "artstationLink")
			self._ui_widget.updateLink.hide()

			if self._status == "newUpdateAvailable":
				self._ui_widget.updateTitle.setText("New update available")
				self._ui_widget.updateDescription.setText("To download the new update, go to your ArtStation library and select your GENtools product.")
				self._ui_widget.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Close|QtWidgets.QDialogButtonBox.Ignore)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Ignore).setText("Ignore")
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Ignore).clicked.connect(self.ignoreUpdate)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Ignore).setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setText("Later")
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).clicked.connect(self.updateLater)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
				self._ui_widget.updateLink.show()

			elif self._status == "noUpdateAvailable":
				self._ui_widget.updateTitle.setText("No update available")
				self._ui_widget.updateDescription.setText("Your version is up to date! We'll continue checking for new updates periodically.")
				self._ui_widget.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setText("Close")
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).clicked.connect(self.close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))

			elif self._status == "checkingUpdates":
				self._ui_widget.updateTitle.setText("Checking for updates")
				self._ui_widget.updateDescription.setText("Verifying if new updates are available...")
				self._ui_widget.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setText("Close")
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).clicked.connect(self.close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))

			elif self._status == "error":
				self._ui_widget.updateTitle.setText("Cannot reach server")
				self._ui_widget.updateDescription.setText("Could not verify for new updates because the server did not respond in time. Please try again later.")
				self._ui_widget.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setText("Close")
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).clicked.connect(self.close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
			
			else:
				self._ui_widget.updateTitle.setText("Unexpected error")
				self._ui_widget.updateDescription.setText("An unexpected error occured, could not verify updates.")
				self._ui_widget.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setText("Close")
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).clicked.connect(self.close)
				self._ui_widget.buttonBox.button(QtWidgets.QDialogButtonBox.Close).setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))

			# fix for python 3 compatibility
			shadowOpacity = 100
			if sys.version_info[0] > 2:
				shadowOpacity *= 0.8
			
			self.addWidgetShadow(self._ui_widget.windowFrame, shadowRadius=16, shadowOpacity=shadowOpacity)
	
	def updateLater(self):
		cmds.optionVar(intValue=("GENtools_Check_Updates", 1))
		self.close()
	
	def ignoreUpdate(self):
		cmds.optionVar(intValue=("GENtools_Check_Updates", 0))
		self.close()
		