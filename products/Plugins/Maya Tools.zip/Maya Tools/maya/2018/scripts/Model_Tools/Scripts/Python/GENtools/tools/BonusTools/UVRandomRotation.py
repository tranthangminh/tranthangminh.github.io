#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.api.OpenMaya as OpenMaya
import maya.cmds as cmds
from collections import OrderedDict
from functools import partial
import random

# for python 3 compatibility
import six
from six.moves import range

from ...core.gui.options import OptionsWindow, helpCmd

def GetCurrentSel(*args):
	objects = None
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects

def GetUVShellList(selection=None):
	if selection is None:
		selection = GetCurrentSel()[0]
	
	selection = cmds.polyListComponentConversion(selection, toUV=True)

	shells = []
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for sel in selection:
			selList.add(sel)
		
		for each in range(selList.length()):
			dagPath, component = selList.getComponent(each)
			
			node = dagPath.fullPathName()
			uvSet = cmds.polyUVSet(node, query=True, currentUVSet=True)[0]
			
			if uvSet:
				uvs = selList.getSelectionStrings(each)
				
				shellIds = cmds.polyEvaluate(uvs, uvShellIds=True, uvSetName=uvSet)
				shellIds = list(set(shellIds))
				
				for shell in shellIds:				
					uvsInShell = cmds.polyEvaluate(node, uvsInShell=shell, uvSetName=uvSet)
					shells.append(uvsInShell)
	
	return shells

def GetUVPivot(selection):
	pivot = [0, 0]
	
	if isinstance(selection, (list, tuple)):
		object = selection[0].split(".", 1)[0]
	else:
		object = selection.split(".", 1)[0]
	
	if isinstance(object, six.string_types) and cmds.objExists(object):		
		currentContext = cmds.currentCtx()
		ctxName = cmds.contextInfo(currentContext, c=True)
		
		if any(x == ctxName for x in ["texMove", "texRotate", "texScale"]):
			pivot = cmds.getAttr("{0}.uvPivot".format(object))
		else:
			uvBox = cmds.polyEvaluate(selection, boundingBoxComponent2d=True)
			pivot = [0.5 * (uvBox[0][0] + uvBox[0][1]), 0.5 * (uvBox[1][0] + uvBox[1][1])]
	
	return pivot

def UVRandomRotation(*args, **kwargs):
	# Create default args
	selection = None
	degreesMin = 0
	degreesMax = 90
	stepRotation = True
	orientation = 3
	usePivot = True
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load SelectSimilar optionVars
	if cmds.optionVar(exists="UVRR_DegreesMin") is True:
		degreesMin = cmds.optionVar(query="UVRR_DegreesMin")
	if cmds.optionVar(exists="UVRR_DegreesMax") is True:
		degreesMax = cmds.optionVar(query="UVRR_DegreesMax")
	if cmds.optionVar(exists="UVRR_StepRotations") is True:
		stepRotation = bool(cmds.optionVar(query="UVRR_StepRotations")[0])
	if cmds.optionVar(exists="UVRR_Orientation") is True:
		orientation = cmds.optionVar(query="UVRR_Orientation")
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "degreesMin" or key == "dmin":
			degreesMin = value
		elif key == "degreesMax" or key == "dmax":
			degreesMax = value
		elif key == "stepRotation" or key == "sr":
			stepRotation = value
		elif key == "orientation" or key == "ori":
			orientation = value
		elif key == "usePivot" or key == "up":
			usePivot = value

	for shell in GetUVShellList(selection):
		RandomRotation = 0
		if stepRotation:
			minRot = int((360/max(1, degreesMin))-1)
			maxRot = int((360/max(1, degreesMax))-1)
			minRot = degreesMin * random.randint(0, minRot)
			maxRot = degreesMax * random.randint(0, maxRot)
			# Randomize between min and max rotation
			if random.randint(0, 1) == 0:
				RandomRotation = minRot
			else:
				RandomRotation = maxRot
		else:
			RandomRotation = random.uniform(degreesMin, degreesMax)
		
		# Randomize clockwise / counterclockwise
		if orientation == 2:
			RandomRotation *= -1
		elif orientation == 3:
			if random.randint(-1, 1) == -1:
				RandomRotation *= -1
		
		ratio = 1.0
		texWinName = cmds.getPanel(scriptType="polyTexturePlacementPanel")
		if len(texWinName) == 1:
			ratio = cmds.textureWindow(texWinName[0], query=True, imageRatioValue=True)
		
		if usePivot:			
			pivot = GetUVPivot(shell)
		else:
			uvBox = cmds.polyEvaluate(shell, boundingBoxComponent2d=True)
			pivot = [0.5 * (uvBox[0][0] + uvBox[0][1]), 0.5 * (uvBox[1][0] + uvBox[1][1])]
		
		if isinstance(pivot, (list, tuple)) and len(pivot) >= 2:
			cmds.polyEditUV(shell, pivotU=pivot[0], pivotV=pivot[1], angle=RandomRotation, rotateRatio=ratio)

class UVRandomRotationOptions(OptionsWindow):
	def __init__(self):
		self.windowName = "UVRandomRotationOptionsWin"
		self.pfx = "UVRR_"
		kwargs = {"windowSize": [440, 200], 
		          "windowTitle": "UV Random Rotation Options", 
		          "runLabel": "Randomize", 
		          "minWindowSize": 220, 
		          "rowOffset": 143, 
				  "preview": False}
		
		super(UVRandomRotationOptions, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		UVRandomRotation()
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/bonustools-uv/#uv-random-rotation")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="UV Random Rotation Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Degrees (min)
		cmds.rowLayout(self.pfx+"DegreesMinRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Degrees (min):")
		cmds.floatSliderGrp(self.pfx+"DegreesMin", dtg=self.pfx+"DegreesMin", l="", f=True, pre=4, v=90, min=0, max=180, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Degrees (max)
		cmds.rowLayout(self.pfx+"DegreesMaxRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Degrees (max):")
		cmds.floatSliderGrp(self.pfx+"DegreesMax", dtg=self.pfx+"DegreesMax", l="", f=True, pre=4, v=90, min=0, max=180, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Step Rotations
		cmds.rowLayout(self.pfx+"StepRotationsRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"StepRotations", dtg=self.pfx+"StepRotations", l="", l1="Step Rotations", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Orientation
		cmds.rowLayout(self.pfx+"OrientationRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Orientation:")
		cmds.radioButtonGrp(self.pfx+"Orientation", dtg=self.pfx+"Orientation", l="", nrb=3, la3=("Clockwise", "Counterclockwise", "Both"), sl=3, cw4=(0, 80, 120, 80), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))