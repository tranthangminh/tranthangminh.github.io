#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds

def RemoveAllNamespaces():
	''' 
	Find all namespaces in scene and remove them
	Except for default namespaces
	'''
	defaults = ['UI', 'shared']
	namespaces = [ns for ns in cmds.namespaceInfo(listOnlyNamespaces=True, recurse=True) if ns not in defaults]
	
	# Reverse iterate through the namespace list
	for ns in reversed(namespaces):
		# Move content of namespace with root namespace
		cmds.namespace(moveNamespace=[ns, ":"], force=True)
		# Delete namespace
		cmds.namespace(removeNamespace=ns)