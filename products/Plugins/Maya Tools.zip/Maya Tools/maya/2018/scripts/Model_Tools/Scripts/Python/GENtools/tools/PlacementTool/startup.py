#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Placement Tool")
		self.scriptLoader.setToolDocumentation("/docs/placementtool-overview/")
		self.scriptLoader.setStartupFile("PlacementTool.mel")
		self.scriptLoader.setStartupFunc("PT_Startup")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Modify")
		self.scriptLoader.setMenuItemDict({"image": "create.png", "sourceType": "mel", "command": "PlacementTool"})
		self.scriptLoader.setMenuItemOptionDict({"sourceType": "mel", "command": "InteractiveCreationOptions"})
		return self.scriptLoader