#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya
import maya.mel as mel
import math as math
from collections import OrderedDict
from functools import partial

# for python 3 compatibility
import six
from six.moves import range
from six.moves import zip

from ...core.utils.infos import getMayaVersion
from ...core.gui.options import OptionsWindow, helpCmd
from ...core.general.selections import filterSelectedComponents, getComponentIds

def GetComponentsIds(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	selList = OpenMaya.MSelectionList()
	
	if selection is not None:
		# If selection is a list, add each element to selList
		if isinstance(selection, list) is True:
			try:
				for each in selection:
					selList.add(each)
			except:
				pass
		# If selection is a string, add to selList
		elif isinstance(selection, six.string_types) is True:
			try:
				selList.add(selection)
			except:
				pass
	else:
		OpenMaya.MGlobal_getActiveSelectionList(selList)
	
	componentsIds = {}
	dagPath = OpenMaya.MDagPath()
	component = OpenMaya.MObject()
	
	selIter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMeshComponent)
	while not selIter.isDone():
		# Get indexed components list in the current item
		selIter.getDagPath(dagPath, component)
		dagPath.pop() # Remove shape
		objectName = dagPath.fullPathName()
		compFn = OpenMaya.MFnSingleIndexedComponent(component)
		
		ids = OpenMaya.MIntArray()
		compFn.getElements(ids)
		componentsIds[objectName] = ids
		
		selIter.next()
	
	return componentsIds

def GetBorderEdges(*args, **kwargs):
	# Create default args
	selection = None
	flatten = False
	borderEdges = []
	borderEdgesList = OpenMaya.MSelectionList()
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "flatten" or key == "fl":
			flatten = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(te=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for edge in selection:
			selList.add(edge)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		
		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshEdgeComponent):
				dagPath.pop() # Remove shape
				node = dagPath.fullPathName()
				try:
					edge_itr = OpenMaya.MItMeshEdge(dagPath, component)
				except:
					cmds.delete(cmds.ls(cmds.listConnections("{0}.inMesh".format(node), c=False, d=False, s=True)[0], typ="transformGeometry"))
					edge_itr = OpenMaya.MItMeshEdge(dagPath, component)
				while not edge_itr.isDone():
					edgeId = edge_itr.index()
					onBoundary = edge_itr.onBoundary()
					
					if onBoundary is True:
						borderEdgesList.add(dagPath, edge_itr.currentItem())
					
					edge_itr.next()
			
			iterIndex += 1
			sel_iter.next()
		
		# Create new list and merge elements (unflatten list)
		mergedList = OpenMaya.MSelectionList()
		if borderEdgesList.isEmpty() is False:
			mergedList.merge(borderEdgesList, OpenMaya.MSelectionList.kMergeNormal)
		
		mergedList.getSelectionStrings(borderEdges)
		# Return full path strings
		if flatten is False:
			borderEdges = cmds.ls(borderEdges, l=True)
		else:
			borderEdges = cmds.ls(borderEdges, l=True, fl=True)
	return borderEdges

def GetCurrentSel(*args):
	objects = None
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects

def GetShortName(objectSel):
	dagPath = []
	shortName = objectSel
	dagPath = shortName.split("|")
	#shortName = filter(None, shortName)
	if(len(dagPath)>0):
		shortName = dagPath[len(dagPath)-1]
	return shortName

def DistanceBetweenPoints(point1, point2):
	# distance between 3D points
	if len(point1) >= 3 and len(point2) >= 3:
		return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2 + (point2[2] - point1[2])**2)
	# distance between 2D points
	else:
		return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

def ToggleAlwaysDrawOnTop(objects=None):
	if getMayaVersion() >= 2022:
		if isinstance(objects, (list, tuple)):
			curvesShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="nurbsCurve")
		else:
			curvesShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="nurbsCurve")
		curvesShapes = cmds.ls(curvesShapes, exactType="nurbsCurve")
		
		toggleState = [int(cmds.getAttr(curveShape+".alwaysDrawOnTop")) for curveShape in curvesShapes]
		
		if len(curvesShapes)/2 >= sum(toggleState):
			for curveShape in curvesShapes:
				cmds.setAttr(curveShape+".alwaysDrawOnTop", 1)
		else:
			for curveShape in curvesShapes:
				cmds.setAttr(curveShape+".alwaysDrawOnTop", 0)

def EC_getCurveParameter(curveObj=None, cvId=0):
	selList = OpenMaya.MSelectionList()
	selList.add(curveObj)
	
	selPath = OpenMaya.MDagPath()
	selComp = OpenMaya.MObject()
	selList.getDagPath(0, selPath, selComp)
	
	curveFn = OpenMaya.MFnNurbsCurve(selPath)
	cvPos = OpenMaya.MPoint()
	
	paramUtil = OpenMaya.MScriptUtil()
	paramPtr = paramUtil.asDoublePtr()
	
	curveFn.getCV(cvId, cvPos)
	curveFn.closestPoint(cvPos, paramPtr)
	
	param = paramUtil.getDouble(paramPtr)  
	return param

#EC_getCurveParameter("curve1", 0)

def deleteCurveCVs():
	cvSel = cmds.filterExpand(fp=True, sm=28)
	if(cvSel is not None):
		# Add cvs to selectionList
		sel = OpenMaya.MSelectionList()
		for i in range(len(cvSel)):
			sel.add(cvSel[i])
	
		selPath = OpenMaya.MDagPath()
		selComp = OpenMaya.MObject()
		cvs = []
		
		# Iterate over item in selectionList
		selIter = OpenMaya.MItSelectionList(sel,OpenMaya.MFn.kCurveCVComponent)
		while not selIter.isDone():
			# Get indexed components list in the current item
			selIter.getDagPath(selPath, selComp)
			selNode = selPath.fullPathName()
			compFn = OpenMaya.MFnSingleIndexedComponent(selComp)
			
			# Get curve CV count
			curveDegree = cmds.getAttr(selNode+".degree")
			curveSpans = cmds.getAttr(selNode+".spans")
			curveCVs = (curveDegree+curveSpans)
			
			# Create a list of selected CV ids
			ids = OpenMaya.MIntArray()
			compFn.getElements(ids)
			
			# If bezierCurve, keep only whole number of 3
			if cmds.objectType(selNode, isType="bezierCurve"):
				bezierIds = []
				for id in ids:
					if id not in bezierIds:
						bezierIds.append(id)
					if id > 0 and id-1 not in bezierIds:
						bezierIds.append(id-1)
					if id < curveCVs-1 and id+1 not in bezierIds:
						bezierIds.append(id+1)
				ids = [id for id in bezierIds if id % 3 == 0]
			
			# Create list of selected CVs path
			cvList = []
			for id in ids:
				currentCv = six.text_type('%s.cv[%s]' % (selNode, id))
				cvList.append(currentCv)
			
			# Get the first CV next to selected CV ids
			cvListId = [None]
			if len(ids) < curveCVs and ids:
				selCv = min(ids)
				if(selCv > 0):
					if cmds.objectType(selNode, isType="bezierCurve"):
						selCv -= 3
					else:
						selCv -= 1
				selCv = (six.text_type('%s.cv[%s]' % (selNode, selCv)))
				cvListId = [selCv]
			cvListId.append(cvList)
			
			# Create list of first CV and selected CVs
			cvs.append(cvListId)
			selIter.next()
		
		# Delete selected CVs and select first CV
		cvSel = []
		cvDelete = []
		for i in range(len(cvs)):
			if(cvs[i][0] is not None):
				cvSel.append(cvs[i][0])
			cvDelete.extend(cvs[i][1])
		#print (cvDelete)
		#print (cvSel)
		if cvDelete:
			cmds.delete(cvDelete)
		if cvSel:
			cmds.select(cvSel, r=True)

#cvSel = cmds.filterExpand(fp=1, sm=28)
#deleteCurveCVs(cvSel)

def EC_hideInOutliner(nodeName, hide):
	# Apply to all DAG nodes
	nodeName = cmds.ls(nodeName, dag=True, o=True)
	# Hide/Unhide the items
	for i in range(len(nodeName)):
		cmds.setAttr((nodeName[i]+".hiddenInOutliner"), hide)
	# Refresh any outliner editors
	eds = cmds.lsUI(editors=True)
	for i in range(len(eds)):
		if(cmds.outlinerEditor(eds[i], exists=True) is True):
			cmds.outlinerEditor(eds[i], edit=True, refresh=True)

#EC_hideInOutliner("curve1", 1)

def EC_resetBrush():
	brush = cmds.getDefaultBrush()
	newBrush = cmds.createNode("brush", ss=True)
	if(cmds.objExists(brush+".notes") is True):
		try:
			cmds.deleteAttr(brush, at="notes")
		except RuntimeError:
			errorMsg = "Could not delete dynamic attribute: ^1s.notes"
			cmds.error(cmds.format(errorMsg, s=(brush)))
	cmds.copyNode(newBrush, brush)
	cmds.delete(newBrush)
	# Now reset the default pressure settings
	cmds.dynWireCtx("dynWireCtx1", e=True,
					i1="paintEffectsTool.png", i2="vacantCell.png", i3="vacantCell.png",
					dp=1,
					bd=0.88, bm=1,
					inputSamples=4, sp=4,
					sof=0,
					pd=False, usp=True,
					pm1=5, pm2=1, pm3=0,
					ps1=0, ps2=0, ps3=0,
					px1=1, px2=1, px3=1,
					dq=100.0,
					pxm=0)

def EC_convertCurvesToStrokes(curveName, curveSamples):
	brush = cmds.getDefaultBrush()
	intermediateObject = cmds.getAttr(curveName+".io")
	# If not an intermediate object
	if(intermediateObject is False):
		EC_curveShortName = GetShortName(curveName)
		# Create a stroke
		#newStroke = cmds.stroke(seed=0, pressure=True)
		#newStroke = cmds.createNode("stroke", n=(EC_curveShortName+"_strokeShape1"), p="CurveToPolyStrokes", ss=True)
		#cmds.container("CurveToPolyStrokes", e=True, removeNode=newStroke)
		newStrokeTransform = cmds.createNode("transform", n=(EC_curveShortName+"_stroke1"), ss=True)
		newStroke = cmds.createNode("stroke", n=(EC_curveShortName+"_strokeShape1"), p=newStrokeTransform, ss=True)
		cmds.setAttr((newStroke+".isHistoricallyInteresting"), 0)
		cmds.setAttr((newStroke+".visibility"), 0)
		cmds.setAttr((newStroke+".seed"), 0)
		# Copy pressure mapping settings from the Paint Effects Tool
		'''
		cmds.setAttr((newStroke+".spm1"), 5)
		cmds.setAttr((newStroke+".spm2"), 1)
		cmds.setAttr((newStroke+".spm3"), 0)
		cmds.setAttr((newStroke+".ps1"), 0)
		cmds.setAttr((newStroke+".ps2"), 0)
		cmds.setAttr((newStroke+".ps3"), 0)
		cmds.setAttr((newStroke+".px1"), 1)
		cmds.setAttr((newStroke+".px2"), 1)
		cmds.setAttr((newStroke+".px3"), 1)
		'''
		# Create a brush
		newBrush = cmds.duplicate(brush, n=(EC_curveShortName+"_brush1"), ic=True)
		# Brush start setup
		mel.eval("brushStartSetup(\""+newBrush[0]+"\",1);")
		cmds.connectAttr((newBrush[0]+".outBrush"), (newStroke+".brush"), f=True)
		cmds.setAttr((newBrush[0]+".brushType"), 5)
		# Removes "Warning: There are no lights in the scene."
		cmds.setAttr((newBrush[0]+".realLights"), 0)
		# Set brush attributes
		attr_dict = {".brushWidth": 0, 
					 ".softness": 0, 
					 ".depth": 0, 
					 ".modifyDepth": 0, 
					 ".modifyColor": 0, 
					 ".modifyAlpha": 0, 
					 ".tubes": 1, 
					 ".tubeCompletion": 0, 
					 ".tubesPerStep": 0, 
					 ".tubeRand": 0, 
					 ".startTubes": 1, 
					 ".lengthMin": 1, 
					 ".lengthMax": 1, 
					 ".tubeDirection": 0, 
					 ".elevationMin": 0, 
					 ".elevationMax": 0, 
					 ".azimuthMin": 0, 
					 ".azimuthMax": 0, 
					 ".displacementDelay": 0, 
					 ".pathFollow": 1, 
					 ".pathAttract": 1, 
					 ".momentum": 0, 
					 ".lengthFlex": 1, 
					 ".twistRand": 0}
		for attr, value in six.iteritems(attr_dict):
			cmds.setAttr((newBrush[0]+attr), value)
		cmds.connectAttr((newBrush[0]+".tubeWidth1"), (newBrush[0]+".tubeWidth2"), f=True)
		#cmds.connectAttr(("time1.outTime"), (newBrush[0]+".time"), f=True)
		#k = cmds.getAttr(curveName+".spans")
		#k *= 6 # Scaling factor for the smoothness of the curve once converted. Currently 6 samples per span.
		cmds.setAttr((newStroke+".pathCurve[0].samples"), curveSamples)
		cmds.setAttr((newStroke+".useNormal"), 0)
		'''if(cmds.upAxis(q=True, ax=True) == "y"):
			cmds.setAttr(newStroke+".normal", 0, 1, 0)
		else:
			cmds.setAttr(newStroke+".normal", 0, 0, 1)'''
		cmds.setAttr((newStroke+".minimalTwist"), True)
		cmds.connectAttr((curveName+".ws"), (newStroke+".pathCurve[0].curve"), f=True)
		# Connect curve worldNormal to stroke normal
		cmds.connectAttr((curveName+".worldNormal[0]"), (newStroke+".normal"), f=True)
		cmds.setAttr((newStroke+".perspective"), 1)
		#cmds.hide(curveName)
		#cmds.select(newStroke)
		return [newBrush[0], newStrokeTransform, newStroke]
		
def EC_convertStrokeToPoly(stroke, parent=None):
	#cmds.setAttr((stroke+".meshVertexColorMode"), 0)
	#cmds.setAttr((stroke+".meshPolyLimit"), 0)
	cmds.setAttr((stroke+".meshQuadOutput"), 1)
	# Create transformNode
	#EC_transformNode = cmds.createNode("transform", n=(curveName+"_CurveToPoly1"), ss=True)
	EC_transformNode = cmds.createNode("transform", n="pCurve1", p=parent, ss=True)
	#curveTransform = cmds.xform(curve, q=True, ws=True, m=True)
	#cmds.xform(EC_transformNode, ws=True, m=curveTransform)
	EC_transformShortName = GetShortName(EC_transformNode)
	# Create meshNode
	EC_shapeNode = cmds.createNode("mesh", n=(EC_transformShortName[:6]+"Shape"+EC_transformShortName[6:]), p=EC_transformNode, ss=True)
	# Initialize the meshNode based on the global settings
	ival = cmds.optionVar(q="polyCreateMeshesSingleSided")
	if(ival == 1):
		ival = 0
	else:
		ival = 1
	cmds.setAttr((EC_shapeNode+".doubleSided"), ival)
	cmds.setAttr((EC_shapeNode+".tangentSpace"), cmds.optionVar(q="polyDefaultTangentSpace"))
	tsaDegrees = cmds.optionVar(q="polyDefaultTangentSmoothingAngle")
	tsa = cmds.convertUnit(tsaDegrees, f="deg")
	cmds.setAttr((EC_shapeNode+".tangentSmoothingAngle"), float(tsa))
	# Connect stroke to meshNode
	#cmds.connectAttr((stroke+".worldMainMesh[0]"), (EC_shapeNode+".inMesh"), f=True)
	cmds.sets(EC_shapeNode, e=True, forceElement="initialShadingGroup")
	'''
	# Connect Parent Inverse Matrix to transformNode
	EC_decomposeMatrix = cmds.createNode("decomposeMatrix", n=(EC_transformShortName+"_decomposeMatrix1"), ss=True)
	cmds.connectAttr((EC_transformNode+".parentInverseMatrix"), (EC_decomposeMatrix+".inputMatrix"), f=True)
	cmds.connectAttr((EC_decomposeMatrix+".outputTranslate"), (EC_transformNode+".translate"), f=True)
	cmds.connectAttr((EC_decomposeMatrix+".outputRotate"), (EC_transformNode+".rotate"), f=True)
	cmds.connectAttr((EC_decomposeMatrix+".outputScale"), (EC_transformNode+".scale"), f=True)
	cmds.connectAttr((EC_decomposeMatrix+".outputShear"), (EC_transformNode+".shear"), f=True)
	'''
	#cmds.delete(EC_shapeNode, ch=True)
	#cmds.setAttr((stroke+".visibility"), 0)
	return [EC_transformNode, EC_shapeNode]

'''
def EC_deleteHistory(stroke, brush, curveToPoly):
	cmds.delete([stroke, brush, curveToPoly])
'''

def EC_cleanHistory(objects=None, cleanAll=False):
	if cleanAll:
		objectShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		objects = cmds.listRelatives(objectShapes, fullPath=True, parent=True, noIntermediate=True, type="transform") or []
	else:
		objects = GetCurrentSel(objects)[1]
	
	nodes_to_delete = []
	for obj in objects:
		objectHistory = cmds.listHistory(obj)
		nodes_to_delete.extend(cmds.ls(objectHistory, type=["stroke", "brush", "expression"]))	
	
	# Disconnect attributes from curves
	if cleanAll:
		curvesShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="nurbsCurve")
	else:
		curvesShapes = cmds.ls(sl=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="nurbsCurve")
	# For each curve
	for curveShape in curvesShapes:
		curveTransform = next(iter(cmds.listRelatives(curveShape, fullPath=True, parent=True)), None)
		
		# Get all connected objects
		allConnectedObjects = [curveShape, curveTransform]
		checkConnectedObjects = list(allConnectedObjects)
		while len(checkConnectedObjects):
			connections = [cmds.ls(x, long=True)[0] for x in cmds.listConnections(checkConnectedObjects[0], destination=True) or [] if cmds.ls(x, long=True)[0] not in allConnectedObjects]
			connections = list(OrderedDict.fromkeys(connections))
			allConnectedObjects.extend(connections)
			checkConnectedObjects.extend(connections)
			del checkConnectedObjects[0]
		allConnectedObjects = allConnectedObjects[2:]
		
		# Check if curve is attached to a wire deformer
		skipCurve = False
		for obj in cmds.ls(allConnectedObjects, type="wire"):
			wireConnections = cmds.listConnections(obj+".outputGeometry", destination=True)
			if wireConnections and cleanAll:
				# Make sure to delete the construction history on geometry first
				cmds.delete(wireConnections, constructionHistory=True)
			else:
				skipCurve = True
				break
		# If it's attached to a wire deformer and is not a Delete All History, we skip to avoid breaking the deformer
		if skipCurve:
			continue
		
		# Cleanup brushes with no output connections
		for obj in cmds.ls(allConnectedObjects, type="brush"):
			brushConnections = cmds.listConnections(obj+".outBrush", destination=True)
			if not brushConnections:
				cmds.delete(obj)
		
		# Get curve connections
		EC_curveConnections = cmds.listConnections(curveShape, connections=True, destination=True, source=True, plugs=True) or []
		EC_curveConnections.extend(cmds.listConnections(curveTransform, connections=True, destination=True, source=True, plugs=True) or [])
		
		# Disconnect curve connections
		a = iter(EC_curveConnections)
		for c_source, c_dest in zip(a, a):
			try:
				c_src = c_source.split(".")
				if len(c_src) <= 1:
					continue
				elif c_src[1] not in ["spans", "worldNormal", "worldSpace"]:
					c_inst = c_src[1].split("[")[0]
					c_dst = c_dest.split(".")[0]
					if not (c_inst == "instObjGroups" and cmds.objectType(c_dst) == "polyTweak"):
						continue

				cmds.disconnectAttr(c_source, c_dest)
			except:
				pass
		
		# Get intermediate objects
		nodes_to_delete.extend(cmds.ls(curveTransform, dagObjects=True, objectsOnly=True, type="nurbsCurve", intermediateObjects=True))
	
	# Delete history
	cmds.delete(constructionHistory=True, all=cleanAll)
	
	# Cleanup nodes
	for n in nodes_to_delete:
		if cmds.objExists(n):
			cmds.delete(n)
	
	# Refresh attribute editor if visible
	if hasattr(cmds, "workspaceControl") and cmds.workspaceControl("AttributeEditor", query=True, visible=True) and cmds.workspaceControl("AttributeEditor", query=True, r=True):
		mel.eval("editSelected;")

def EC_curveToPoly(*args, **kwargs):
	# Create default args
	curveSel = None
	EC_radius = 3
	EC_subdivisionsAxis = 8
	EC_density = 5
	EC_hardEdges = False
	EC_smoothing = 0
	EC_flatness = 0
	EC_orientation = 0
	EC_twist = 0
	EC_taper = 0
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			curveSel = arg
	
	# Load CurveToPoly optionVars
	if cmds.optionVar(ex="EC_Radius") is True:
		EC_radius = cmds.optionVar(q="EC_Radius")
	if cmds.optionVar(ex="EC_SubdivisionsAxis") is True:
		EC_subdivisionsAxis = cmds.optionVar(q="EC_SubdivisionsAxis")
	if cmds.optionVar(ex="EC_Density") is True:
		EC_density = cmds.optionVar(q="EC_Density")
	if cmds.optionVar(ex="EC_HardEdges") is True:
		EC_hardEdges = cmds.optionVar(q="EC_HardEdges")[0]
	if cmds.optionVar(ex="EC_Smoothing") is True:
		EC_smoothing = cmds.optionVar(q="EC_Smoothing")
	if cmds.optionVar(ex="EC_Flatness") is True:
		EC_flatness = cmds.optionVar(q="EC_Flatness")
	if cmds.optionVar(ex="EC_Orientation") is True:
		EC_orientation = cmds.optionVar(q="EC_Orientation")
	if cmds.optionVar(ex="EC_Twist") is True:
		EC_twist = cmds.optionVar(q="EC_Twist")
	if cmds.optionVar(ex="EC_Taper") is True:
		EC_taper = cmds.optionVar(q="EC_Taper")
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "curveSel" or key == "sel":
			curveSel = value
		elif key == "radius" or key == "r":
			EC_radius = value
		elif key == "subdivisionsAxis" or key == "sa":
			EC_subdivisionsAxis = value
		elif key == "density" or key == "d":
			EC_density = value
		elif key == "hardEdges" or key == "he":
			EC_hardEdges = value
		elif key == "smoothing" or key == "s":
			EC_smoothing = value
		elif key == "flatness" or key == "f":
			EC_flatness = value
		elif key == "orientation" or key == "o":
			EC_orientation = value
		elif key == "twist" or key == "tw":
			EC_twist = value
		elif key == "taper" or key == "tp":
			EC_taper = value

	EC_curveSelShapes = cmds.ls(curveSel, fl=True, o=True, dag=True, g=True)
	if len(EC_curveSelShapes) <= 0:
		EC_curveSelShapes = cmds.ls(sl=True, fl=True, o=True, dag=True, g=True)
	EC_curveSelShapes = cmds.ls(EC_curveSelShapes, typ="nurbsCurve")
	EC_curveSelObjects = cmds.listRelatives(EC_curveSelShapes, f=True, p=True)
	EC_curveToPolySel = []
	# If a curve is selected
	if(EC_curveSelObjects is not None):
		# Open Undo Chunk
		cmds.undoInfo(ock=True) 
		# Create transformNode to hold stroke shapes
		'''if (cmds.objExists("CurveToPolyStrokes") is False):
			#cmds.createNode("transform", n="CurveToPolyStrokes", ss=True)
			cmds.createNode("dagContainer", n="CurveToPolyStrokes", ss=True)
			cmds.setAttr("CurveToPolyStrokes.iconName", "out_curveInfo.png", typ="string")
			EC_hideInOutliner("CurveToPolyStrokes", 1)
			#cmds.lockNode("CurveToPolyStrokes", l=True)
			cmds.setAttr("CurveToPolyStrokes.tx", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.ty", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.tz", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.rx", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.ry", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.rz", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.sx", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.sy", l=True, k=False, cb=False)
			cmds.setAttr("CurveToPolyStrokes.sz", l=True, k=False, cb=False)'''
		# Remove duplicates
		EC_curveSelObjects = list(OrderedDict.fromkeys(EC_curveSelObjects))
		# Reset Template Brush
		EC_resetBrush()
		objectsName = []
		# For each curve
		for i in range(len(EC_curveSelShapes)):
			EC_curveName = cmds.listRelatives(EC_curveSelShapes[i], f=True, p=True)
			EC_curveParent = cmds.listRelatives(EC_curveName, f=True, p=True)
			if(EC_curveParent is None):
				EC_curveParent = [None]
			# Delete curve history
			cmds.delete(EC_curveName[0], ch=True)
			# Get curve CV count
			EC_curveDegree = cmds.getAttr(EC_curveName[0]+".degree")
			EC_curveSpans = cmds.getAttr(EC_curveName[0]+".spans")
			EC_curveCVs = (EC_curveDegree+EC_curveSpans)
			
			# Convert curve to stroke
			#mel.eval("convertCurvesToStrokes")
			EC_Brush, EC_Stroke, EC_StrokeShape = EC_convertCurvesToStrokes(EC_curveName[0], EC_curveCVs)
			
			# Convert stroke to poly
			EC_Mesh, EC_Shape = EC_convertStrokeToPoly(EC_StrokeShape, EC_curveParent[0])
			objectsName.append(EC_Mesh)
			# Parent strokeShape to polyShape
			EC_StrokeShape = next(iter(cmds.parent(EC_StrokeShape, EC_Mesh, r=True, s=True)), None)
			cmds.delete(EC_Stroke) # delete transform
			cmds.select(EC_curveName[0], r=True)
			
			# Set mesh matrix to default world space matrix
			cmds.xform(EC_Mesh, ws=True, m=[1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0])
			# Match curve pivot to mesh pivot (orientation)
			EC_ParentMesh = cmds.parent(EC_Mesh, EC_curveName)
			cmds.makeIdentity(EC_ParentMesh, a=True, r=True, s=True, n=False, pn=True)
			cmds.delete(EC_ParentMesh, ch=True)
			if EC_curveParent[0] is None:
				cmds.parent(EC_ParentMesh, w=True)
			else:
				cmds.parent(EC_ParentMesh, EC_curveParent[0])
			
			# Create curveToPoly Node
			EC_curveShortName = GetShortName(EC_curveName[0])
			EC_transformShortName = GetShortName(EC_Mesh)
			EC_curveToPolyNode = cmds.createNode("polyTweak", n=(EC_curveShortName+"_curveToPoly1"), ss=True)
			cmds.addAttr(EC_curveToPolyNode, m=True, im=False, at="typed", ln="dagSetMembers", k=False, h=True)
			#cmds.addAttr(EC_curveToPolyNode, at="long", ln="inheritsTransform", dv=0, k=False, h=True)
			# Connect mesh inheritsTransform
			#cmds.connectAttr((EC_curveToPolyNode+".inheritsTransform"), (EC_Mesh+".inheritsTransform"), f=True)
			#EC_inheritsTransformExpression = cmds.expression(s=EC_Mesh+".inheritsTransform = 0", n=(EC_curveShortName+"_expression1"))
			#cmds.connectAttr((EC_curveSelShapes[i]+".inPlace"), (EC_Mesh+".inheritsTransform"), f=True)
			'''# Get connection index
			EC_curveToPolyIndex = 0
			EC_curveConnections = cmds.listConnections((EC_curveSelShapes[i]+".instObjGroups"), c=False, d=True, s=False)
			if(EC_curveConnections is not None):
				EC_curveToPolyIndex = len(EC_curveConnections)
			cmds.connectAttr((EC_curveSelShapes[i]+".instObjGroups"), (EC_curveToPolyNode+".dagSetMembers["+str(EC_curveToPolyIndex)+"]"), f=True)'''
			# INFO: Connects curve transform instead of curve shapes because it would not always appear in channel box otherwise...
			cmds.connectAttr((EC_curveName[0]+".instObjGroups"), (EC_curveToPolyNode+".dagSetMembers"), na=True, f=True)
			# Fix outputs connections order
			EC_curveConnections = cmds.listConnections((EC_curveName[0]+".instObjGroups"), c=False, d=True, s=False)
			if(EC_curveConnections is not None):
				if(len(EC_curveConnections) == 2):
					cmds.disconnectAttr((EC_curveName[0]+".instObjGroups"), (EC_curveConnections[1]+".dagSetMembers"), na=True)
					cmds.connectAttr((EC_curveName[0]+".instObjGroups"), (EC_curveConnections[1]+".dagSetMembers"), na=True, f=True)
			# Connect stroke to mesh
			cmds.connectAttr((EC_StrokeShape+".outMainMesh"), (EC_curveToPolyNode+".inputPolymesh"), f=True)
			#cmds.connectAttr((EC_curveToPolyNode+".output"), (EC_Mesh+".inMesh"), f=True)
			# Connect Parent Inverse Matrix to transformNode
			EC_transformGeometry = cmds.createNode("transformGeometry", n=(EC_transformShortName+"_transformGeometry1"), ss=True)
			cmds.connectAttr((EC_curveToPolyNode+".output"), (EC_transformGeometry+".inputGeometry"), f=True)
			#cmds.connectAttr((EC_Shape+".parentInverseMatrix"), (EC_transformGeometry+".transform"), f=True)
			cmds.connectAttr((EC_StrokeShape+".parentInverseMatrix"), (EC_transformGeometry+".transform"), f=True)
			cmds.connectAttr((EC_transformGeometry+".outputGeometry"), (EC_Shape+".inMesh"), f=True)
			# Reset mesh translation
			curveTranslation = cmds.xform(EC_curveName, q=True, ws=True, t=True)
			cmds.xform(EC_Mesh, ws=True, t=curveTranslation)
			# Match curve pivot to mesh pivot (position)
			curvePivots = cmds.xform(EC_curveName, q=True, ws=True, rp=True)
			cmds.xform(EC_Mesh, ws=True, piv=curvePivots)
			# Add Width Scale points for Taper control
			cmds.setAttr((EC_Brush+".widthScale[0].widthScale_Position"), 0)
			cmds.setAttr((EC_Brush+".widthScale[0].widthScale_FloatValue"), 1)
			cmds.setAttr((EC_Brush+".widthScale[0].widthScale_Interp"), 1)
			cmds.setAttr((EC_Brush+".widthScale[1].widthScale_Position"), 1)
			cmds.setAttr((EC_Brush+".widthScale[1].widthScale_FloatValue"), 1)
			cmds.setAttr((EC_Brush+".widthScale[1].widthScale_Interp"), 1)
			# Set Global Scale to appropriate value
			cmds.setAttr((EC_Brush+".globalScale"), 2)
			# Create brush attribute controls
			cmds.addAttr(EC_Brush, at="double", ln="orientation", smn=0, smx=360, dv=0, k=True, h=True)
			cmds.addAttr(EC_Brush, at="double", ln="taper", smn=-1, smx=1, dv=0, k=True, h=True)
			EC_orientationExpression = cmds.expression(s=EC_Brush+".twist = "+EC_Brush+".orientation/180;", n=(EC_curveShortName+"_expression1"))
			EC_taperExpression = cmds.expression(s=EC_Brush+".widthScale[0].widthScale_Position = 0;\n"+EC_Brush+".widthScale[0].widthScale_FloatValue = min(1, "+EC_Brush+".taper+1);\n"+EC_Brush+".widthScale[0].widthScale_Interp = 1;\n"+EC_Brush+".widthScale[1].widthScale_Position = 1;\n"+EC_Brush+".widthScale[1].widthScale_FloatValue = min(1, ("+EC_Brush+".taper*-1)+1);\n"+EC_Brush+".widthScale[1].widthScale_Interp = 1;")
			
			#EC_segmentsExpression = cmds.expression(s=EC_Brush+".segments = ("+EC_curveName[0]+".degree+"+EC_curveName[0]+".spans)*"+EC_StrokeShape+".sampleDensity*8;", n=(EC_curveShortName+"_expression1"))
			EC_segmentsExpression = cmds.expression(s=EC_Brush+".segments = "+EC_StrokeShape+".sampleDensity*("+EC_curveName[0]+".spans+1);", n=(EC_curveShortName+"_expression1"))
			# Create curveToPoly attribute controls
			cmds.addAttr(EC_curveToPolyNode, at="double", ln="radius", min=0, smx=100, dv=3, k=True, h=False, pxy=(EC_Brush+".tubeWidth1"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="long", ln="subdivisionsAxis", min=3, smx=64, dv=8, k=True, h=False, pxy=(EC_Brush+".tubeSections"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="double", ln="density", min=0, smx=30, dv=5, k=True, h=False, pxy=(EC_StrokeShape+".sampleDensity"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="bool", ln="hardEdges", dv=False, k=True, h=False, pxy=(EC_StrokeShape+".meshHardEdges"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="double", ln="smoothing", min=0, smx=10000, dv=0, k=True, h=False, pxy=(EC_StrokeShape+".smoothing"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="double", ln="flatness", min=0, smx=1, dv=0, k=True, h=False, pxy=(EC_Brush+".flatness1"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="double", ln="orientation", smn=0, smx=360, dv=0, k=True, h=False, pxy=(EC_Brush+".orientation"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="double", ln="twist", smn=0, smx=2, dv=0, k=True, h=False, pxy=(EC_Brush+".twistRate"), usedAsProxy=True)
			cmds.addAttr(EC_curveToPolyNode, at="double", ln="taper", smn=-1, smx=1, dv=0, k=True, h=False, pxy=(EC_Brush+".taper"), usedAsProxy=True)
			# Set curveToPoly attribute controls
			cmds.setAttr((EC_curveToPolyNode+".radius"), EC_radius)
			cmds.setAttr((EC_curveToPolyNode+".subdivisionsAxis"), EC_subdivisionsAxis)
			cmds.setAttr((EC_curveToPolyNode+".density"), EC_density)
			cmds.setAttr((EC_curveToPolyNode+".hardEdges"), EC_hardEdges)
			cmds.setAttr((EC_curveToPolyNode+".smoothing"), EC_smoothing)
			cmds.setAttr((EC_curveToPolyNode+".flatness"), EC_flatness)
			cmds.setAttr((EC_curveToPolyNode+".orientation"), EC_orientation)
			cmds.setAttr((EC_curveToPolyNode+".twist"), EC_twist)
			cmds.setAttr((EC_curveToPolyNode+".taper"), EC_taper)
			# Create stroke samples expression
			EC_samplesExpression = cmds.expression(s=EC_StrokeShape+".pathCurve[0].samples = "+EC_curveName[0]+".spans+1;", n=(EC_curveShortName+"_expression1"))
			# Create flatness expression
			EC_samplesExpression = cmds.expression(s=EC_Brush+".flatness2 = "+EC_Brush+".flatness1;", n=(EC_curveShortName+"_expression1"))
			# Hide nodes from channel box / attribute editor
			cmds.setAttr((EC_orientationExpression+".isHistoricallyInteresting"), 0)
			cmds.setAttr((EC_segmentsExpression+".isHistoricallyInteresting"), 0)
			cmds.setAttr((EC_samplesExpression+".isHistoricallyInteresting"), 0)
			cmds.setAttr((EC_Brush+".isHistoricallyInteresting"), 0)
			cmds.setAttr((EC_transformGeometry+".isHistoricallyInteresting"), 0)
			
			# Create curveToPoly scriptJob
			#cmds.scriptJob(con=[EC_curveToPolyNode+".output", 'EC_deleteHistory("'+EC_Brush+'", "'+EC_StrokeShape+'", "'+EC_curveToPolyNode+'")'], ro=True, cu=True)
			
			# Select curveToPoly Node
			#cmds.select(EC_curveToPolyNode, add=True)
			EC_curveToPolySel.append(EC_curveToPolyNode)
			EC_selectedNode = EC_curveToPolyNode
		# Close Undo Chunk
		cmds.undoInfo(cck=True)
		# Reorder CurveToPolyStrokes in Outliner
		#cmds.reorder("CurveToPolyStrokes", back=True)
		# Select curves and curveToPoly Nodes
		cmds.select(EC_curveSelObjects, r=True)
		cmds.select(EC_curveToPolySel, add=True)
		# Select attribute in channel box
		#EC_currentCtx = cmds.currentCtx()
		EC_channelBoxName = mel.eval("$EC_channelBoxName=$gChannelBoxName")
		cmds.evalDeferred('import maya.cmds as cmds;cmds.channelBox("'+EC_channelBoxName+'", e=True, s=("'+EC_selectedNode+'.radius"))')
		#cmds.evalDeferred('cmds.setToolTo("'+EC_currentCtx+'")')
		return objectsName

def EC_createCurveFromPipe(objects=None, createNewPipe=False):	
	currentSel, objects = GetCurrentSel(objects)
	if len(objects) > 0:
		curveList = []
		for object in objects:
			posList = []
			borderEdges = GetBorderEdges(cmds.polyListComponentConversion(object, te=True), fl=True)
			if len(borderEdges) > 0:
				edgesIds = list(GetComponentsIds(borderEdges).values())[0]
				edgeRing = cmds.polySelect(object, er=edgesIds[0], ns=True, ass=True)
				borderEdges = GetBorderEdges(edgeRing)
				if len(borderEdges) == 2:
					borderEdgesIds = list(GetComponentsIds(borderEdges).values())[0]
					edgeRingPath = cmds.polySelect(object, erp=borderEdgesIds, ass=False, ns=True)
					edgeRingPath = ["{0}.e[{1}]".format(object, x) for x in edgeRingPath]
					for edge in edgeRingPath:
						edgesIds = list(GetComponentsIds(edge).values())[0]
						edgeLoop = cmds.polySelect(object, elb=edgesIds, ns=True, ass=True)
						bb = cmds.exactWorldBoundingBox(edgeLoop)
						pos = ((bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2, (bb[2] + bb[5]) / 2)
						posList.append(pos)
			
			if len(posList) > 0:				
				curve = cmds.curve(ws=True, p=posList)
				
				if createNewPipe is False:
					cmds.rebuildCurve(curve, ch=False, rpo=True, rt=False, end=True, kr=False, kcp=True, kep=False, kt=False, s=6, d=3, tol=0.01)
					# Create wire deformer
					wire = cmds.wire(object, wire=curve, groupWithBase=False, dropoffDistance=[0, 999999999], envelope=1, crossingEffect=0, localInfluence=0)[0]
					# Parent baseWireShape to curve
					baseWire = cmds.listConnections("{0}.baseWire[0]".format(wire), c=False, d=False, s=True)[0]
					baseWireShape = cmds.listRelatives(baseWire, f=True, ni=True, s=True)[0]
					baseWireShape = cmds.parent(baseWireShape, curve, r=True, s=True)[0]
					#cmds.setAttr("{0}.intermediateObject".format(baseWireShape), True)
					cmds.setAttr("{0}.visibility".format(baseWireShape), False)
					cmds.setAttr("{0}.lodVisibility".format(baseWireShape), False)
					cmds.setAttr("{0}.hiddenInOutliner".format(baseWireShape), True)
					cmds.setAttr("{0}.isHistoricallyInteresting".format(baseWireShape), 0)
					cmds.setAttr("{0}.template".format(baseWireShape), True)
					# Connect wire locally
					cmds.connectAttr((baseWireShape+".local"), (wire+".baseWire[0]"), f=True)
					cmds.delete(baseWire)
					curveList.append(curve)
				else:
					curveSelShapes = cmds.ls(cmds.listHistory(object), fl=True, o=True, dag=True, g=True)
					curveSelShapes = cmds.ls(curveSelShapes, typ="nurbsCurve")
					curveSelObjects = cmds.listRelatives(curveSelShapes, f=True, p=True)
					cmds.delete([object]+curveSelShapes, ch=True)
					if len(curveSelShapes) > 0:
						try:
							EC_cleanHistory(curveSelShapes, False)
						except:
							pass
						cmds.delete(curveSelObjects)
						curve = cmds.rename(curve, GetShortName(curveSelObjects[0]))
					
					curveShape = cmds.ls(curve, fl=True, o=True, dag=True, g=True)
					curveCVs = (cmds.getAttr(curveShape[0]+".degree")+cmds.getAttr(curveShape[0]+".spans"))
					cmds.rebuildCurve(curve, ch=False, rpo=True, rt=False, end=True, kr=False, kcp=False, kep=True, kt=False, s=curveCVs, d=3, tol=0.01)
					curveRadius = 2
					curveSubdivisions = 8
					#curveDensity = len(edgeRing)/(curveCVs*8.0)

					# Find the old pipe radius & subdivisions
					vertex_loop = cmds.polyListComponentConversion(cmds.polySelect(object, edgeLoopOrBorder=0, asSelectString=True, noSelection=True), toVertex=True)
					vertex_bb = cmds.exactWorldBoundingBox(vertex_loop)
					centerPos = ((vertex_bb[0] + vertex_bb[3]) / 2, (vertex_bb[1] + vertex_bb[4]) / 2, (vertex_bb[2] + vertex_bb[5]) / 2)

					vertexDistance = 0
					all_vertex = cmds.ls(vertex_loop, long=True, flatten=True)
					if len(all_vertex) >= 3:
						curveSubdivisions = len(all_vertex)
					for vert in all_vertex:
						vertexPos = cmds.xform(vert, query=True, worldSpace=True, translation=True)
						vertexDistance += DistanceBetweenPoints(vertexPos, centerPos)
					curveRadius = vertexDistance/max(len(all_vertex), 1)

					# Create new pipe
					newObjects = EC_curveToPoly(curve, radius=curveRadius, subdivisionsAxis=curveSubdivisions, density=1)
					objectParent = cmds.listRelatives(object, f=True, p=True)
					cmds.displaySmoothness(newObjects[0], po=cmds.displaySmoothness(object, q=True, po=True)[0])
					cmds.delete(object)
					# Re-parent object
					if objectParent is not None:
						newObjects = cmds.parent(newObjects[0], objectParent[0])
					# Rename object
						newObjects = [cmds.rename(newObjects[0], GetShortName(object))]
					curveList.extend(newObjects)
			else:
				cmds.warning("Pipe geometry needs to be composed of quads only: {0}".format(object))
		
		# Select curves
		cmds.selectMode(co=True)
		cmds.selectMode(o=True)
		cmds.select(curveList, r=True)

'''
import sys
scriptDirPath = (cmds.internalVar(userScriptDir=True)+"ExtrudeCurve/")
sys.path.append(scriptDirPath)
import CurveToPolygons
reload(CurveToPolygons)
#CurveToPolygons.EC_curveToPoly()
CurveToPolygons.EC_curveToPoly(0.5, 8, 1, False, 0, 0)
'''

def getClosestNumber(number, numberList):
	return min(numberList, key=lambda x:abs(x-number))

def extrudeCurve():
	hilitedObjects = cmds.ls(hilite=True, long=True)
	# Get selected CVs
	selectedCVs = filterSelectedComponents(selection=True, componentType="cv")
	# Get curve shapes and curve transforms
	EC_curveSelShapes = cmds.ls(selection=True, objectsOnly=True, dagObjects=True, long=True, type=["nurbsCurve", "bezierCurve"])
	EC_curveSelObjects = cmds.listRelatives(EC_curveSelShapes, fullPath=True, parent=True)
	# Remove duplicates transforms
	if EC_curveSelObjects is not None:
		EC_curveSelObjects = list(OrderedDict.fromkeys(EC_curveSelObjects))
	
	if EC_curveSelShapes:
		manipMoveAxisOrientation = cmds.manipMoveContext("Move", query=True, mode=True)
		manipActiveHandle = cmds.manipMoveContext("Move", query=True, currentActiveHandle=True)
		EC_curvePointPosition = None
		curvePointRotation = None
		EC_newCVs = []
		for i, curveShape in enumerate(EC_curveSelShapes):
			EC_curveName = next(iter(cmds.listRelatives(curveShape, fullPath=True, parent=True) or []), None)
			EC_objectType = cmds.objectType(curveShape)
			if EC_objectType in ["nurbsCurve", "bezierCurve"]:
				# If curve form is open
				EC_curveForm = cmds.getAttr("{0}.form".format(EC_curveName))
				if EC_curveForm == 0:
					# Delete history
					cmds.delete(EC_curveName, constructionHistory=True)
					# Get CV count
					EC_curveDegree = cmds.getAttr("{0}.degree".format(EC_curveName))
					EC_curveSpans = cmds.getAttr("{0}.spans".format(EC_curveName))
					EC_curveCVs = EC_curveDegree + EC_curveSpans

					# Get selected CVs
					currentCVs = []
					if selectedCVs:
						for cv in list(selectedCVs):
							cName = cv.split(".")[0]
							if cName == EC_curveName:
								currentCVs.append(cv)
								selectedCVs.remove(cv)
					
					# Check if cv closest to end or beginning
					cvIds = getComponentIds(currentCVs)
					if cvIds:
						cvId = max(min(int(sum(cvIds)/len(cvIds)), EC_curveCVs-1), 0)
					else:
						cvId = EC_curveCVs-1
					cvId = getClosestNumber(cvId, [0, EC_curveCVs-1])

					# If cv closest to beginning, reverse curve
					if cvId == 0:
						cmds.reverseCurve(curveShape)

					# Get new CV position
					EC_lastCV = "{0}.cv[{1}]".format(EC_curveName, EC_curveCVs-1)
					EC_curvePointPosition = cmds.pointPosition(EC_lastCV, world=True)

					# Get rotation from tangentConstraint
					if i == len(EC_curveSelShapes) - 1:
						EC_tempLocator = next(iter(cmds.spaceLocator()))
						cmds.xform(EC_tempLocator, worldSpace=True, translation=EC_curvePointPosition)
						EC_tempConstraint = cmds.tangentConstraint(EC_curveName, EC_tempLocator, weight=1, aimVector=[0, 1, 0], upVector=[0, 0, 1], worldUpType="vector", worldUpVector=[0, 0, 1])
						curvePointRotation = cmds.xform(EC_tempLocator, query=True, worldSpace=True, rotation=True)
						cmds.delete(EC_tempLocator)
					
					# If curve was reversed, set cv id to 0
					if cvId == 0:
						EC_curveCVs = 0

					# Add CV to curve
					if cmds.objectType(curveShape, isType="bezierCurve"):
						for i in range(2):
							cmds.curve(EC_curveName, worldSpace=True, append=True, point=EC_curvePointPosition)
						if cvId != 0:
							EC_curveCVs += 2
					cmds.curve(EC_curveName, worldSpace=True, append=True, point=EC_curvePointPosition)

					# Restore curve direction
					if cvId == 0:
						cmds.reverseCurve(curveShape)

					# Add CV to array
					EC_newCVs.append("{0}.cv[{1}]".format(EC_curveName, EC_curveCVs))
		
		if EC_newCVs:
			# Select curves
			cmds.hilite(EC_curveSelObjects, hilitedObjects, replace=True)
			# Set selectMode to component mode
			cmds.selectMode(component=True)
			cmds.selectType(allComponents=False, controlVertex=True, subdivMeshPoint=True, vertex=True, latticePoint=True, particle=True)
			# Select new CVs
			cmds.select(EC_newCVs, replace=True)
			# Set tool to MoveTool
			gMove = mel.eval("$gMove = $gMove")
			cmds.setToolTo(gMove)
			# Set manipulator pivot position and rotation
			if all([EC_curvePointPosition, curvePointRotation]):
				cmds.manipPivot(position=EC_curvePointPosition, orientation=curvePointRotation)
			# Restore manipulator to world orientation
			if manipMoveAxisOrientation == 2:
				cmds.manipMoveContext("Move", edit=True, mode=2)
			cmds.manipMoveContext("Move", edit=True, currentActiveHandle=manipActiveHandle)

class EC_curveToPolyOptions(OptionsWindow):
	def __init__(self):
		self.windowName = "EC_curveToPolyWindow"
		self.pfx = "EC_"
		kwargs = {"windowSize": [540, 340], 
		          "windowTitle": "Curve to Polygons Options", 
		          "runLabel": "Create", 
		          "minWindowSize": 310, 
		          "rowOffset": 140, 
				  "preview": False}
		
		super(EC_curveToPolyOptions, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		# Query optionVar
		settings = self.querySettings()
		# Run curveToPoly
		EC_curveToPoly(None, settings[self.pfx+"Radius"], settings[self.pfx+"SubdivisionsAxis"], settings[self.pfx+"Density"], settings[self.pfx+"HardEdges"][0], settings[self.pfx+"Smoothing"], settings[self.pfx+"Flatness"], settings[self.pfx+"Orientation"], settings[self.pfx+"Twist"], settings[self.pfx+"Taper"])
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(label="Help on {0}".format(self.windowTitle), image="help.png", command=(partial(helpCmd, helpUrl="/docs/curvetopolygons-overview/")), enableCommandRepeat=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")

		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Form #1
		cmds.formLayout(self.pfx+"SettingsForm1")
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True)
		# Radius
		cmds.rowLayout(self.pfx+"RadiusRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Radius:")
		cmds.floatSliderGrp(self.pfx+"Radius", dtg=self.pfx+"Radius", l="", f=True, cw3=(0, 70, 100), min=0, max=100, fmx=100000, v=3, pre=4, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Subdivisions Axis
		cmds.rowLayout(self.pfx+"SubdivisionsAxisRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Subdivisions Axis:")
		cmds.intSliderGrp(self.pfx+"SubdivisionsAxis", dtg=self.pfx+"SubdivisionsAxis", l="", f=True, cw3=(0, 70, 100), min=4, max=64, fmx=100000, v=8, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Density
		cmds.rowLayout(self.pfx+"DensityRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Density:")
		cmds.floatSliderGrp(self.pfx+"Density", dtg=self.pfx+"Density", l="", f=True, cw3=(0, 70, 100), min=0, max=30, fmx=100000, v=5, pre=4, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Hard edges
		cmds.rowLayout(self.pfx+"HardEdgesRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Hard edges:")
		cmds.checkBoxGrp(self.pfx+"HardEdges", dtg=self.pfx+"HardEdges", ncb=1, l="", cw=(1, 1), cc=(partial(self.controlsCallback)), v1=False)
		cmds.setParent("..")
		# Smoothing
		cmds.rowLayout(self.pfx+"SmoothingRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Smoothing:")
		cmds.floatSliderGrp(self.pfx+"Smoothing", dtg=self.pfx+"Smoothing", l="", f=True, cw3=(0, 70, 100), min=0, max=10000, fmx=100000, v=0, pre=4, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Flatness
		cmds.rowLayout(self.pfx+"FlatnessRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Flatness:")
		cmds.floatSliderGrp(self.pfx+"Flatness", dtg=self.pfx+"Flatness", l="", f=True, cw3=(0, 70, 100), min=0, max=1, fmx=100000, v=0, pre=4, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# END: Settings Form #1
		cmds.setParent("..")
		cmds.setParent("..")
		
		# START: Settings Form #2
		cmds.formLayout(self.pfx+"SettingsForm2")
		cmds.columnLayout(self.pfx+"SettingsColumn2", adj=True, bgc=(0.266, 0.266, 0.266), h=2)
		# END: Settings Form #2
		cmds.setParent("..")
		cmds.setParent("..")
		
		# START: Settings Form #3
		cmds.formLayout(self.pfx+"SettingsForm3")
		cmds.columnLayout(self.pfx+"SettingsColumn3", adj=True)
		# Orientation
		cmds.rowLayout(self.pfx+"OrientationRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Orientation:")
		cmds.floatSliderGrp(self.pfx+"Orientation", dtg=self.pfx+"Orientation", l="", f=True, cw3=(0, 70, 100), min=0, max=360, fmn=-100000, fmx=100000, v=0, pre=4, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Twist
		cmds.rowLayout(self.pfx+"TwistRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Twist:")
		cmds.floatSliderGrp(self.pfx+"Twist", dtg=self.pfx+"Twist", l="", f=True, cw3=(0, 70, 100), min=0, max=2, fmn=-100000, fmx=100000, v=0, pre=4, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Taper
		cmds.rowLayout(self.pfx+"TaperRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Taper:")
		cmds.floatSliderGrp(self.pfx+"Taper", dtg=self.pfx+"Taper", l="", f=True, cw3=(0, 70, 100), min=-1, max=1, fmn=-100000, fmx=100000, v=0, pre=4, cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# END: Settings Form #3
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")

		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Settings Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsForm1", "top", 0), (self.pfx+"SettingsForm1", "left", 0), (self.pfx+"SettingsForm1", "right", 0)],
						an=(self.pfx+"SettingsForm1", "bottom"))
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						ac=(self.pfx+"SettingsForm2", "top", 0, self.pfx+"SettingsForm1"),
						af=[(self.pfx+"SettingsForm2", "left", 0), (self.pfx+"SettingsForm2", "right", 0)],
						an=(self.pfx+"SettingsForm2", "bottom"))
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						ac=(self.pfx+"SettingsForm3", "top", 0, self.pfx+"SettingsForm2"),
						af=[(self.pfx+"SettingsForm3", "left", 0), (self.pfx+"SettingsForm3", "right", 0)],
						an=(self.pfx+"SettingsForm3", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm1", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 4), (self.pfx+"SettingsColumn1", "right", 4)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		cmds.formLayout(self.pfx+"SettingsForm2", e=True,
						af=[(self.pfx+"SettingsColumn2", "top", 2), (self.pfx+"SettingsColumn2", "left", 0), (self.pfx+"SettingsColumn2", "right", 0)],
						an=(self.pfx+"SettingsColumn2", "bottom"))
		cmds.formLayout(self.pfx+"SettingsForm3", e=True,
						af=[(self.pfx+"SettingsColumn3", "top", 2), (self.pfx+"SettingsColumn3", "left", 4), (self.pfx+"SettingsColumn3", "right", 4)],
						an=(self.pfx+"SettingsColumn3", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))