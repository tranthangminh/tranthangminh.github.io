#!/usr/bin/python
# -*- coding: utf-8 -*-
import time
#import logging
from threading import Thread
try:
	from PySide2 import QtCore, QtWidgets
except ImportError:
	from PySide import QtCore
	from PySide import QtGui as QtWidgets

from pynput.mouse import Button, Listener as MouseListener
from pynput.keyboard import Listener as KeyboardListener

def maya_is_active():
	if QtWidgets.QApplication.applicationState() == QtCore.Qt.ApplicationState.ApplicationActive:
		return True
	return False

def get_maya_state():
	return QtWidgets.QApplication.applicationState()

class MayaAppState(Thread):
	def __init__(self):
		Thread.__init__(self)

		self.daemon = True
		self._isRunning = True
		self._state = get_maya_state()
		self._signals = []
	
	def is_running(self):
		return self._isRunning

	def stop(self):
		self._isRunning = False
	
	def setState(self, state):
		if self._state != state:
			self._state = state
			for s in self._signals:
				if callable(s):
					try:
						s(state)
					except:
						pass

	def addSignal(self, s):
		if s not in self._signals and callable(s):
			self._signals.append(s)
	
	def removeSignal(self, s):
		if s in self._signals:
			self._signals.remove(s)
	
	def clearSignals(self):
		self._signals = []

	def run(self):
		while True:
			if not self._isRunning:
				break
			
			try:
				self.setState(get_maya_state())
				time.sleep(0.05)
			except:
				pass
	
	def state(self):
		return self._state

class InputListener(QtCore.QObject):
	onPressSignal = QtCore.Signal(object)
	onReleaseSignal = QtCore.Signal(object)
	onClickSignal = QtCore.Signal(int, int, str, bool)

	def __init__(self):
		super(InputListener, self).__init__()

		self._mousePressed = False
		self._keyPressed = False
		self.keyboard_listener = KeyboardListener(on_press=self.on_press, on_release=self.on_release)
		self.mouse_listener = MouseListener(on_click=self.on_click)
	
	def start(self):
		try:
			self.keyboard_listener.start()
			self.mouse_listener.start()
		except:
			pass
		
	def stop(self):
		try:
			self.keyboard_listener.stop()
			self.mouse_listener.stop()
		except:
			pass

	def on_press(self, key):
		if maya_is_active():
			self._keyPressed = True
			#logging.info("Key pressed: {0}".format(key))
			self.onPressSignal.emit(key)
	
	def on_release(self, key):
		if maya_is_active():
			self._keyPressed = False
			#logging.info("Key released: {0}".format(key))
			self.onReleaseSignal.emit(key)

	def on_click(self, x, y, button, pressed):
		if maya_is_active():
			if button == Button.left:
				button = "left"
			elif button == Button.right:
				button = "right"
			elif button == Button.middle:	
				button = "middle"
			if pressed:
				self._mousePressed = True
				#logging.info("Mouse pressed at ({0}, {1}) with {2}".format(x, y, button))
			else:
				self._mousePressed = False
				#logging.info("Mouse released at ({0}, {1}) with {2}".format(x, y, button))
			self.onClickSignal.emit(x, y, button, pressed)
	
	def input_is_pressed(self):
		if any([self._mousePressed, self._keyPressed]):
			return True
		return False

	def on_move(self, x, y):
		if self.input_is_pressed():
			if not maya_is_active():
				self._mousePressed = False
				self._keyPressed = False

class MayaInputState(Thread):
	def __init__(self):
		Thread.__init__(self)

		self.daemon = True
		self._isRunning = True
		self._state = False

		self.inputListener = InputListener()
		self.inputListener.start()
	
	def is_running(self):
		return self._isRunning

	def stop(self):
		self._isRunning = False
		
		try:
			self.inputListener.stop()
		except:
			pass
	
	def setState(self, state):
		if self._state != state:
			self._state = state
	
	def run(self):
		while True:
			if not self._isRunning:
				break
			
			try:
				if self.inputListener.input_is_pressed():
					self.setState(True)
					time.sleep(0.05)
					continue
			except:
				pass
			
			self.setState(False)
			time.sleep(0.05)
	
	def state(self):
		return self._state

def mayaInputListenerExists():
	global GENtoolsInputListener
	if "GENtoolsInputListener" in globals():
		if isinstance(GENtoolsInputListener, MayaInputState):
			if GENtoolsInputListener.is_running():
				return True
	return False

def removeMayaInputListener():
	global GENtoolsInputListener
	if mayaInputListenerExists():
		GENtoolsInputListener.stop()
		del GENtoolsInputListener

def createMayaInputListener():
	global GENtoolsInputListener
	if not mayaInputListenerExists():
		GENtoolsInputListener = MayaInputState()
		GENtoolsInputListener.start()

def getMayaInputState():
	global GENtoolsInputListener
	createMayaInputListener()
	
	try:
		return GENtoolsInputListener.state()
	except:
		return False
