#!/usr/bin/python
# -*- coding: utf-8 -*-
from maya.OpenMayaUI import MQtUtil
try:
	from PySide2 import QtWidgets
	from shiboken2 import wrapInstance
except ImportError:
	from PySide import QtGui as QtWidgets
	from shiboken import wrapInstance
import os
import sys

# for python 3 compatibility
import six
try:
	from past.builtins import long
except:
	pass

from .widgets import QWindowCustom, QFrameTitleBar, QFrameUrl
from .about_ui import Ui_MainWindow as about_ui

ROOT_FILE = __file__
ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
ROOT_DIR = ROOT_DIR_RAW
if not isinstance(ROOT_FILE, six.text_type):
	try:
		ROOT_FILE = ROOT_FILE.decode(sys.getfilesystemencoding())
		ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
		ROOT_DIR = ROOT_DIR_RAW.encode(sys.getfilesystemencoding())
	except:
		pass

class GENtoolsAboutWindow(QWindowCustom):
	def __init__(self):
		# If window already exists, delete window
		self.deleteInstances()
		
		try:
			windowParent = wrapInstance(long(MQtUtil.mainWindow()), QtWidgets.QWidget)
		except Exception as e:
			windowParent = None
		
		ui_file = os.path.join(ROOT_DIR_RAW, r"about_ui.ui")
		ui_widget = about_ui
		
		customWidgets = [QFrameTitleBar, QFrameUrl]
		
		super(GENtoolsAboutWindow, self).__init__(parent=windowParent, ui_file=ui_file, ui_widget=ui_widget, customWidgets=customWidgets)
		
		# Window object name
		self.windowName = "GENtools_About"
		self.setObjectName(self.windowName)
		# Window title
		self.setWindowTitle("About")
		
		# Show UI
		self.initUI()
	
	def getStyleSheet(self):
		return ("""			
			QFrame.windowFrame{
				background-color: rgba(45, 45, 45, 80%);
				border-bottom-left-radius: 2px;
				border-bottom-right-radius: 2px;
			}
			
			QLabel.title{
				font-size: 16px;
				font-weight: bold;
				text-transform: uppercase;
			}
			
			QFrameUrl.link QLabel, QFrameUrl.artstationLink QLabel{
				color: rgba(255, 255, 255, 100%);
			}
			
			QFrameUrl.link[hover=true] QLabel, QFrameUrl.artstationLink[hover=true] QLabel{
				color: rgba(200, 200, 200, 100%);
			}
			
			QFrameUrl.artstationLink QLabel{
				font-size: 14px;
			}
			
			QFrameTitleBar.titleBar{
				background-color: rgba(15, 15, 15, 80%);
				border-bottom: 1px solid rgba(55, 55, 55, 80%);
			}
			
			QFrame.separator{
				color: rgba(45, 45, 45, 0%);
				border-top: 1px solid rgba(55, 55, 55, 100%);
				max-height: 1px;
			}
		""")
	
	def deleteInstances(self):
		global _GENtoolsAboutWinInstance
		if "_GENtoolsAboutWinInstance" in globals():
			try:
				_GENtoolsAboutWinInstance.close()
			except:
				pass
		_GENtoolsAboutWinInstance = self
	
	def setControlsProperty(self):
		if self._ui_widget:
			# UI Controls
			self._ui_widget.windowFrame.setProperty("class", "windowFrame")
			self._ui_widget.titleBar.setText("About")
			self._ui_widget.titleBar.setProperty("defaultCss", False)
			self._ui_widget.creatorsLabel.setText("Authors")
			self._ui_widget.creatorsLabel.setProperty("class", "title")
			self._ui_widget.gabrielLabel.setText("Gabriel Nadeau")
			self._ui_widget.gabrielLabel.setUrl("https://www.artstation.com/gabrielnadeau/store")
			self._ui_widget.gabrielLabel.setIcon(":/images/artstation_logo_32.png")
			self._ui_widget.gabrielLabel.setIconHover(":/images/artstation_logo_hover_32.png")
			self._ui_widget.gabrielLabel.setProperty("class", "artstationLink")
			self._ui_widget.etienneLabel.setText(u"Étienne Nadeau")
			self._ui_widget.etienneLabel.setUrl("https://www.artstation.com/etiennenadeau/store")
			self._ui_widget.etienneLabel.setIcon(":/images/artstation_logo_32.png")
			self._ui_widget.etienneLabel.setIconHover(":/images/artstation_logo_hover_32.png")
			self._ui_widget.etienneLabel.setProperty("class", "artstationLink")
			self._ui_widget.licenseAgreementLabel.setText("License Agreement")
			self._ui_widget.licenseAgreementLabel.setUrl("https://www.artstation.com/marketplace-product-eula")
			self._ui_widget.licenseAgreementLabel.setProperty("class", "link")
			self._ui_widget.separatorFrame.setProperty("class", "separator")
			
			# fix for python 3 compatibility
			shadowOpacity = 100
			if sys.version_info[0] > 2:
				shadowOpacity *= 0.8
			
			self.addWidgetShadow(self._ui_widget.windowFrame, shadowRadius=16, shadowOpacity=shadowOpacity)
		