#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Multi Automatic Mapping")
		self.scriptLoader.setStartupFile("MultiAutomaticMapping.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("UV")
		self.scriptLoader.setMenuItemDict({"image": "polyAutoProjLarge.png", "sourceType": "mel", "command": "MultiAutomaticMapping"})
		self.scriptLoader.setMenuItemOptionDict({"sourceType": "mel", "command": "MultiAutomaticMappingOptions"})
		return self.scriptLoader