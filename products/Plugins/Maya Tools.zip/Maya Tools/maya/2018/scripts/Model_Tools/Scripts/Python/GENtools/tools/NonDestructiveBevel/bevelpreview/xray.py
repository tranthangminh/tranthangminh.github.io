#!/usr/bin/python
# -*- coding: utf-8 -*-
import logging
import maya.cmds as cmds
import maya.app.renderSetup.model.override as override
import maya.app.renderSetup.model.collection as collection
import maya.app.renderSetup.model.renderLayer as renderLayer
import maya.app.renderSetup.model.renderSetup as renderSetup
import maya.app.renderSetup.model.connectionOverride as connectionOverride

from ....core.general.decorators import make_undoable

def createShader(node_type="lambert", **kwargs):
	material, sg = None, None
	try:
		material = cmds.shadingNode(node_type, asShader=True, **kwargs)
		sg = cmds.sets(name="{0}SG".format(material), empty=True, renderable=True, noSurfaceShader=True)
		cmds.connectAttr("{0}.outColor".format(material), "{0}.surfaceShader".format(sg))
	except:
		pass
	return material, sg

class xRayOverride(object):
	RENDER_LAYER_NAME = "NDB_xRay_Layer"
	SCENE_COLLECTION_NAME = "NDB_Scene_Collection"
	XRAY_COLLECTION_NAME = "NDB_xRay_Set"
	XRAY_SELECTOR_NAME = "NDB_xRay_Selector"
	MATERIAL_OVERRIDE_NAME = "NDB_xRay_Material"
	XRAY_SET_NAME = "NDB_xRaySet"
	XRAY_SHADER_NAME = "NDB_xRay_Shader"

	def __init__(self):
		pass

	@staticmethod
	def _getCollectionNames():
		return [xRayOverride.SCENE_COLLECTION_NAME, xRayOverride.XRAY_COLLECTION_NAME]
	
	@staticmethod
	def _getNodesNames():
		return [xRayOverride.SCENE_COLLECTION_NAME, xRayOverride.XRAY_COLLECTION_NAME, xRayOverride.XRAY_SELECTOR_NAME, xRayOverride.MATERIAL_OVERRIDE_NAME]

	@staticmethod
	def _clearRenderLayerNodes():
		layerNodes = list(filter(cmds.objExists, xRayOverride._getNodesNames()))
		for x in layerNodes:
			cmds.rename(x, x+"#")
		#cmds.delete(layerNodes)

	@staticmethod
	@make_undoable
	def updateOverride():
		if cmds.objExists(xRayOverride.RENDER_LAYER_NAME):
			if cmds.objectType(xRayOverride.RENDER_LAYER_NAME) != "renderSetupLayer":
				cmds.delete(xRayOverride.RENDER_LAYER_NAME)
			else:
				rs = renderSetup.instance()
				rl = rs.getRenderLayer(xRayOverride.RENDER_LAYER_NAME)

				if not rl.hasCollection(xRayOverride.SCENE_COLLECTION_NAME) or not rl.hasCollection(xRayOverride.XRAY_COLLECTION_NAME):
					renderLayer.delete(rl)
					xRayOverride._clearRenderLayerNodes()
					return False

				# Verify scene collection
				c1 = rl.getCollectionByName(xRayOverride.SCENE_COLLECTION_NAME)
				c1_s = c1.getSelector()
				if c1_s.getFilterType() != 0:
					c1_s.setFilterType(0)
				if c1_s.getPattern() != "*":
					c1_s.setPattern("*")
				
				# Cleanup childrens
				c1_childrens = c1.getChildren()
				for x in c1_childrens:
					if isinstance(x, override.Override):
						override.delete(x)
					elif isinstance(x, collection.Collection):
						collection.delete(x)

				# Verify xRay collection
				c2 = rl.getCollectionByName(xRayOverride.XRAY_COLLECTION_NAME)
				c2_s = c2.getSelector()
				if c2_s.getFilterType() != 5:
					c2_s.setFilterType(5)
				if c2_s.getPattern() != xRayOverride.XRAY_SET_NAME+"*":
					c2_s.setPattern(xRayOverride.XRAY_SET_NAME+"*")					
				
				# Cleanup collections
				r_c = rl.getCollections()
				if len(r_c) > 2:
					for x in r_c:
						if isinstance(x, collection.Collection) and x.name() not in xRayOverride._getCollectionNames():
							collection.delete(x)
				
				# Cleanup childrens
				c2_childrens = c2.getChildren()
				for x in c2_childrens:
					if isinstance(x, override.Override):
						override.delete(x)
					elif isinstance(x, collection.Collection) and x.name() != xRayOverride.XRAY_SELECTOR_NAME:
						collection.delete(x)
				
				# Verify xRay selector
				c3 = c2.getCollectionByName(xRayOverride.XRAY_SELECTOR_NAME)
				if not c3:
					c3 = c2.createCollection(xRayOverride.XRAY_SELECTOR_NAME)
					c3.getSelector().setFilterType(0)
				c3_s = c3.getSelector()
				if c3_s.getFilterType() != 0:
					c3_s.setFilterType(0)
				if c3_s.getPattern() != "*":
					c3_s.setPattern("*")	
				
				# Verify material override
				c3_overrides = c3.getChildren(cls=connectionOverride.MaterialOverride)
				if xRayOverride.MATERIAL_OVERRIDE_NAME not in [x.name() for x in c3_overrides]:
					for x in c3_overrides:
						override.delete(x)

					c3_mo1 = c3.createOverride(xRayOverride.MATERIAL_OVERRIDE_NAME, "materialOverride")
					mat, matSg = createShader(name=xRayOverride.XRAY_SHADER_NAME+"#")
					cmds.setAttr("{0}.transparency".format(mat), 0.5, 0.5, 0.5, type="double3")
					c3_mo1.setMaterial(matSg)
				
				# Cleanup childrens
				c3_childrens = c3.getChildren()
				if len(c3_childrens) > 1:
					for x in c3_childrens:
						if isinstance(x, override.Override) and x.name() != xRayOverride.MATERIAL_OVERRIDE_NAME:
							override.delete(x)
						elif isinstance(x, collection.Collection):
							collection.delete(x)

				xRayOverride.refreshDisplay(rs, rl)
				return True
		
		xRayOverride._clearRenderLayerNodes()
		return False

	@staticmethod
	@make_undoable
	def createOverride():
		if not xRayOverride.updateOverride():
			rs = renderSetup.instance()

			# Create render layer
			rl = rs.createRenderLayer(xRayOverride.RENDER_LAYER_NAME)

			# Create scene collection
			c1 = rl.createCollection(xRayOverride.SCENE_COLLECTION_NAME)
			c1.getSelector().setFilterType(0)
			c1.getSelector().setPattern("*")

			# Create xRay collection
			c2 = rl.createCollection(xRayOverride.XRAY_COLLECTION_NAME)
			c2.getSelector().setFilterType(5)
			c2.getSelector().setPattern(xRayOverride.XRAY_SET_NAME+"*")

			c3 = c2.createCollection(xRayOverride.XRAY_SELECTOR_NAME)
			c3.getSelector().setFilterType(0)
			c3.getSelector().setPattern("*")

			# Create material override
			c3_mo1 = c3.createOverride(xRayOverride.MATERIAL_OVERRIDE_NAME, "materialOverride")

			mat, matSg = createShader(name=xRayOverride.XRAY_SHADER_NAME+"#")
			cmds.setAttr("{0}.transparency".format(mat), 0.5, 0.5, 0.5, type="double3")
			c3_mo1.setMaterial(matSg)

			# Set the render layer as visible
			xRayOverride.refreshDisplay(rs, rl)
	
	@staticmethod
	@make_undoable
	def removeOverride():
		if cmds.objExists(xRayOverride.RENDER_LAYER_NAME) and cmds.objectType(xRayOverride.RENDER_LAYER_NAME) == "renderSetupLayer":
			rs = renderSetup.instance()
			rl = rs.getRenderLayer(xRayOverride.RENDER_LAYER_NAME)

			renderLayer.delete(rl)

	@staticmethod
	def setExists():
		if cmds.objExists(xRayOverride.XRAY_SET_NAME) and cmds.objectType(xRayOverride.XRAY_SET_NAME) == "objectSet":
			return True
		return False
	
	@staticmethod
	def getMembers(**kwargs):
		if xRayOverride.setExists():
			return cmds.sets(xRayOverride.XRAY_SET_NAME, query=True, **kwargs)
		return None

	@staticmethod
	def needsRefresh():
		setMembers = set(xRayOverride.getMembers(nodesOnly=True) or [])

		global NDB_xRaySetMembers
		if "NDB_xRaySetMembers" not in globals() or NDB_xRaySetMembers != setMembers:
			NDB_xRaySetMembers = setMembers
			return True
		
		return False

	@staticmethod
	def flattenSet():
		if xRayOverride.setExists():
			setItems = xRayOverride.getMembers() or []
			setMembers = xRayOverride.getMembers(nodesOnly=True) or []

			setAdd = list(filter(cmds.objExists, [x for x in setMembers if x not in setItems]))
			setRemove = list(filter(cmds.objExists, [x for x in setItems if x not in setMembers]))

			if setAdd:
				cmds.sets(setAdd, addElement=xRayOverride.XRAY_SET_NAME)
			if setRemove:
				cmds.sets(setRemove, remove=xRayOverride.XRAY_SET_NAME)

	@staticmethod
	@make_undoable
	def refreshDisplay(rs=None, rl=None):
		if not xRayOverride.needsRefresh():
			return

		if not isinstance(rs, renderSetup.RenderSetup):
			rs = renderSetup.instance()

		if not isinstance(rl, renderLayer.RenderLayer):
			if not cmds.objExists(xRayOverride.RENDER_LAYER_NAME) or cmds.objectType(xRayOverride.RENDER_LAYER_NAME) != "renderSetupLayer":
				return

			rl = rs.getRenderLayer(xRayOverride.RENDER_LAYER_NAME)

		try:
			#rs.switchToLayer(rl)
			if rl.hasCollection(xRayOverride.XRAY_COLLECTION_NAME):
				c2 = rl.getCollectionByName(xRayOverride.XRAY_COLLECTION_NAME)
				c3 = c2.getCollectionByName(xRayOverride.XRAY_SELECTOR_NAME)
				if isinstance(c3, collection.Collection):
					c3_overrides = dict((x.name(), x) for x in c3.getChildren(cls=connectionOverride.MaterialOverride))
					if xRayOverride.MATERIAL_OVERRIDE_NAME in c3_overrides:
						c3_overrides[xRayOverride.MATERIAL_OVERRIDE_NAME].unapply()
						c3_overrides[xRayOverride.MATERIAL_OVERRIDE_NAME].apply()

		except Exception as e:
			logging.exception(e)

	@staticmethod
	@make_undoable
	def addObjects(obj=[]):
		if not obj:
			return
		
		try:            
			if not cmds.objExists(xRayOverride.XRAY_SET_NAME):
				# Create set
				cmds.sets(name=xRayOverride.XRAY_SET_NAME, empty=True)
			
			elif cmds.objectType(xRayOverride.XRAY_SET_NAME) != "objectSet":
				cmds.rename(xRayOverride.XRAY_SET_NAME, xRayOverride.XRAY_SET_NAME+"#")
				# Create set
				cmds.sets(name=xRayOverride.XRAY_SET_NAME, empty=True)
			
			cmds.sets(obj, addElement=xRayOverride.XRAY_SET_NAME, noWarnings=True)

			xRayOverride.refreshDisplay()
		except Exception as e:
			logging.exception(e)

	@staticmethod
	@make_undoable
	def removeObjects(obj=[]):
		if not obj:
			return
		
		try:			
			if not xRayOverride.setExists():
				return
			
			cmds.sets(obj, remove=xRayOverride.XRAY_SET_NAME, noWarnings=True)

			xRayOverride.refreshDisplay()
		except Exception as e:
			logging.exception(e)

	@staticmethod
	@make_undoable
	def setXRay(obj=[], xRay=False):
		try:
			if xRay:
				xRayOverride.addObjects(obj)
			else:
				xRayOverride.removeObjects(obj)
		except Exception as e:
			logging.exception(e)
	
	@staticmethod
	@make_undoable
	def getXRay(obj=[]):
		if not obj:
			return False
		
		try:
			if not xRayOverride.setExists():
				return False
			
			xRayOverride.flattenSet()

			return cmds.sets(obj, isMember=xRayOverride.XRAY_SET_NAME, noWarnings=True)
		except Exception as e:
			logging.exception(e)
		
		return False
