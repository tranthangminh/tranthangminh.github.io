#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import ssl
import json
import inspect
import logging
import importlib
from glob import glob
import maya.mel as mel
import maya.cmds as cmds
from threading import Thread
from functools import partial
from collections import OrderedDict
from maya.utils import executeInMainThreadWithResult
try:
	from shiboken2 import isValid
except ImportError:
	from shiboken import isValid

# for python 3 compatibility
import six
from six.moves import range, configparser
from six.moves.urllib.error import URLError
from six.moves.urllib.request import Request, urlopen

from .core.utils.utils import strToBool
from .core.menus import GENtoolsMainMenu
from .core.utils.infos import getMayaVersion
from .core.utils.infos import getGENtoolsInstalls
from .core.gui.updates import GENtoolsUpdatesWindow
from .core.gui.options import OptionsWindow, helpCmd
from .core.config.infos import GENtools_Domain, GENtools_Root

ROOT_DIR = os.path.dirname(os.path.realpath(__file__))
MAYA_VERSION = getMayaVersion()

def checkOptionVar(optionVarName):
	if cmds.optionVar(exists=optionVarName) and len(cmds.optionVar(query=optionVarName)) == 4:
		optionVarValue = cmds.optionVar(query=optionVarName)
		if optionVarValue[0]:
			return True
	else:
		for i in range(4):
			cmds.optionVar(intValueAppend=(optionVarName, 0))
	return False

def getSupportedMayaVersion(supportedVersions):
	mayaVersion = getMayaVersion()
	if mayaVersion in supportedVersions:
		return str(mayaVersion)
	else:
		return str(min(supportedVersions, key=lambda x:abs(x-mayaVersion)))

def importOverrides(sourceDir):
	if os.path.isdir(sourceDir):
		supportedVersions = glob("{0}/*/".format(sourceDir))
		supportedVersions = [float(os.path.basename(os.path.realpath(ver))) for ver in supportedVersions]
		supportedVersions = [int(i) if i.is_integer() else i for i in supportedVersions]
		mayaVersion = getSupportedMayaVersion(supportedVersions)
		overridesDir = os.path.join(sourceDir, mayaVersion)
		overridesFiles = glob("{0}/*.mel".format(overridesDir))
		for file in overridesFiles:
			fileName = os.path.basename(file)
			print(("#		> Loading {0} file override from {1}".format(fileName, file)))
			mel.eval(r'catchQuiet(`eval("source \"{0}\"")`);'.format(fileName)) # force load to make sure it override correctly
			mel.eval(r'evalDeferred -lowestPriority ("source \"{0}\";");'.format(file.replace(os.sep, "/")))

def createMarkingMenu():
	global GENtoolsMenu
	if "GENtoolsStartup" not in globals():
		return
	GENtoolsMenu.createMarkingMenu()

def deleteMarkingMenu():
	GENtoolsMainMenu.deleteMarkingMenu()

def GENtoolsConfig():
	config_dict = OrderedDict([
					("Startup", OrderedDict([
							("CreateMenu", "True"), 
							("CreateOverrides", "True")
						])
					)
				])
	
	config_path = os.path.join(ROOT_DIR, "config.ini")

	# Create config file if it doesn't exists
	if not os.path.isfile(config_path):
		try:
			with open(config_path, "w"): pass
		except Exception as e:
			logging.exception(e)
			return config_dict
	
	# Read config file
	config = configparser.ConfigParser()
	config.optionxform = str
	config.read(config_path)

	# Add sections from config file that doesn't exists in dict
	config_sections = config.sections()
	for config_section in config_sections:
		if config_section not in config_dict:
			config_dict[config_section] = OrderedDict({})

	# Populate dict with config values, otherwise, fallbacks to default dict values
	for section_name, section_dict in six.iteritems(OrderedDict(config_dict)):
		# If section doesn't exists, add all items
		if not config.has_section(section_name):
			config.add_section(section_name)
			for item, value in six.iteritems(section_dict):
				config.set(section_name, item, str(value))
		# If section exists, get values from items that exists, otherwise, fallback to the default value from dict
		else:
			for item, value in six.iteritems(section_dict):
				if not config.has_option(section_name, item):
					config.set(section_name, item, str(value))
				else:
					value = config.get(section_name, item)
					config.set(section_name, item, value)
					config_dict[section_name][item] = value
			
			# Add items from config file that doesn't exists in dict
			section_items = config.items(section_name)
			for item, value in section_items:
				if item not in config_dict[section_name]:
					config_dict[section_name][item] = value
	
	# Write config file
	with open(config_path, "w") as configfile:
		config.write(configfile)
	
	return config_dict

def getConfigValue(section, option, fallback="", forceAdd=False):
	config_path = os.path.join(ROOT_DIR, "config.ini")

	# Create config file if it doesn't exists
	if not os.path.isfile(config_path):
		try:
			with open(config_path, "w"): pass
		except Exception as e:
			logging.exception(e)
			return
	
	# Read config file
	config = configparser.ConfigParser()
	config.optionxform = str
	config.read(config_path)

	if not config.has_section(section):
		if forceAdd:
			config.add_section(section)
		else:
			return fallback
	
	if not config.has_option(section, option):
		if forceAdd:
			config.set(section, option, str(fallback))
			# Write config file
			with open(config_path, "w") as configfile:
				config.write(configfile)
		else:
			return fallback
	
	return config.get(section, option)

def setConfigValue(section, option, value, forceAdd=False):
	config_path = os.path.join(ROOT_DIR, "config.ini")

	# Create config file if it doesn't exists
	if not os.path.isfile(config_path):
		try:
			with open(config_path, "w"): pass
		except Exception as e:
			logging.exception(e)
			return
	
	# Read config file
	config = configparser.ConfigParser()
	config.optionxform = str
	config.read(config_path)

	if not config.has_section(section):
		if forceAdd:
			config.add_section(section)
		else:
			return
	
	if not config.has_option(section, option):
		if forceAdd:
			config.set(section, option, str(value))
		else:
			return
	
	config.set(section, option, str(value))
	
	# Write config file
	with open(config_path, "w") as configfile:
		config.write(configfile)

def startUp(startup=True, forceReload=False):
	global GENtoolsStartup
	if "GENtoolsStartup" not in globals():
		GENtoolsStartup = False
	
	if cmds.optionVar(exists="GENtools_DEBUG") and cmds.optionVar(query="GENtools_DEBUG"):
		global init_modules
		if "init_modules" not in globals():
			init_modules = sys.modules.keys()
		elif forceReload:
			for m in [x for x in sys.modules.keys() if x not in init_modules]:
				del (sys.modules[m])
	
	if GENtoolsStartup and not forceReload:
		return
	
	# Read config file
	config_dict = GENtoolsConfig()

	#scriptDirPath = os.path.join(os.path.realpath(cmds.internalVar(userScriptDir=True)), "GENtools")
	toolsDirPath = os.path.join(GENtools_Root, "tools")
	toolsStartupFiles = glob(u"{0}/*/startup.py".format(toolsDirPath))
	
	print ("# ----------------------------------------------------")
	print ("#\n# GENtools Initialization...")
	
	# Create GENtools menu
	print ("#\n# Creating GENtools menu in main window...")
	global GENtoolsMenu
	GENtoolsMenu = GENtoolsMainMenu()
	
	# Iterate all startup.py files
	for file in toolsStartupFiles:
		modulePath = os.path.basename(os.path.dirname(file))
		moduleName = next(iter(os.path.basename(file).split(".")), None)
		if all([modulePath, moduleName]):
			i = importlib.import_module("GENtools.tools.{0}.{1}".format(modulePath, moduleName))
			if callable(getattr(i, "LoadScript", None)):
				loadScript = i.LoadScript()
				if callable(getattr(loadScript, "createScriptLoader", None)):
					scriptLoader = loadScript.createScriptLoader()
					if isinstance(scriptLoader, ScriptLoader):
						# Load script
						if strToBool(config_dict["Startup"]["CreateOverrides"]):
							scriptLoader.loadScript(startup=startup, forceReload=forceReload)
						else:
							scriptLoader.loadScript(startup=startup, autoLoad=False, forceReload=forceReload)
						# Add to menu
						if strToBool(config_dict["Startup"]["CreateMenu"]):
							GENtoolsMenu.addMenuItem(scriptLoader.scriptDict)
	
	# Populate GENtools menu
	try:
		if strToBool(config_dict["Startup"]["CreateMenu"]):
			GENtoolsMenu.createMenu(startup=startup)
		else:
			GENtoolsMenu.deleteMenu()
	except Exception as e:
		cmds.warning("An error occured while creating GENtools menu: {0}".format(e), noContext=True)
	
	print ("#\n# GENtools Initialization finished!\n#")
	print ("# ----------------------------------------------------")
	
	GENtoolsStartup = True

	# Check for new updates
	checkUpdates(startup=True)

class checkUpdates(object):
	def __init__(self, startup=False):
		super(checkUpdates, self).__init__()

		self.startup = startup
		self.updateWindow = None

		if not self.startup:
			self.updateWindow = GENtoolsUpdatesWindow(status="checkingUpdates")
		
		checkUpdateThread = Thread(target=self.checkUpdatesFn)
		checkUpdateThread.daemon = True
		checkUpdateThread.start()

	def checkUpdatesFn(self):
		if MAYA_VERSION < 2017:
			return
		
		if not executeInMainThreadWithResult(cmds.optionVar, exists="GENtools_Check_Updates"):
			executeInMainThreadWithResult(cmds.optionVar, intValue=("GENtools_Check_Updates", 1))

		try:
			url = GENtools_Domain+"/wp-content/uploads/GENtools_latest_versions.json"
			# Headers
			url_headers = {}
			url_headers["User-Agent"] = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.7) Gecko/2009021910 Firefox/3.0.7"
			url_headers["Content-Type"] = "application/json; charset=utf-8"
			# Request
			url_request = Request(url, headers=url_headers)
			ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
			response = urlopen(url_request, context=ssl_context, timeout=15)
			last_tools_versions = json.loads(response.read())
			update_status = "noUpdateAvailable"
		except (URLError, Exception) as e:
			logging.exception(e)
			last_tools_versions = {}
			update_status = "error"

		current_last_tools_versions = None
		show_update_notification = False
		if not self.startup:
			show_update_notification = True
		
		try:
			if last_tools_versions and isinstance(last_tools_versions, dict):
				installed_tools_version = getGENtoolsInstalls()
				if installed_tools_version and isinstance(installed_tools_version, dict):
					for tool, values in six.iteritems(installed_tools_version):
						if tool in last_tools_versions:
							if "toolVersion" in values and "toolVersion" in last_tools_versions[tool]:
								if values["toolVersion"] != last_tools_versions[tool]["toolVersion"]:
									update_status = "newUpdateAvailable"
									if executeInMainThreadWithResult(cmds.optionVar, query="GENtools_Check_Updates"):
										show_update_notification = True
									break
				
				# Check last time updates were checked
				save_path = os.path.join(ROOT_DIR, "GENtools_latest_versions.json")
				# Already checked
				if os.path.isfile(save_path):
					with open(save_path) as f:
						current_last_tools_versions = json.load(f)
					# But a new update is available
					if current_last_tools_versions != last_tools_versions:
						executeInMainThreadWithResult(cmds.optionVar, intValue=("GENtools_Check_Updates", 1))
						show_update_notification = True
						os.remove(save_path)
						with open(save_path, "w") as f:
							json.dump(last_tools_versions, f)
				# Never checked
				else:
					executeInMainThreadWithResult(cmds.optionVar, intValue=("GENtools_Check_Updates", 1))
					show_update_notification = True
					with open(save_path, "w") as f:
						json.dump(last_tools_versions, f)
		except Exception as e:
			logging.exception(e)
			update_status = "error"
		
		if show_update_notification:
			try:
				if update_status == "newUpdateAvailable":
					if self.updateWindow and isValid(self.updateWindow) and isinstance(self.updateWindow, GENtoolsUpdatesWindow):
						executeInMainThreadWithResult(self.updateWindow.setStatus, "newUpdateAvailable")
					else:
						executeInMainThreadWithResult(GENtoolsUpdatesWindow, status="newUpdateAvailable")
				elif not self.startup:
					if self.updateWindow and isValid(self.updateWindow) and isinstance(self.updateWindow, GENtoolsUpdatesWindow):
						executeInMainThreadWithResult(self.updateWindow.setStatus, update_status)
					else:
						executeInMainThreadWithResult(GENtoolsUpdatesWindow, status=update_status)
			except Exception as e:
				pass

class StartupOptionsWindow(OptionsWindow):
	def __init__(self, **kwargs):
		self.windowName = "GENtools_StartupOptionsWindow"
		self.pfx = "GENtools_"
		kwargs.update({"windowSize": [260, 130], 
		          "windowTitle": "GENtools Startup Settings", 
				  "toolbox": True, 
		          "runLabel": "Save and Close", 
				  "applyLabel": "Save", 
		          "minWindowSize": 260, 
		          "rowOffset": 130, 
				  "preview": False})
		
		self.scriptDirNames = {}
		
		super(StartupOptionsWindow, self).__init__(self.windowName, **kwargs)
	
	def resetSettings(self, *args):
		# Reset settings
		for ctl_dict in six.itervalues(self.UIDict):
			if "optionVar" in ctl_dict:		
				self.saveOptionVar(ctl_dict["optionVar"], ctl_dict["type"], False)

				if ctl_dict["optionVar"] in self.scriptDirNames:
					setConfigValue("ToolsStartup", self.scriptDirNames[ctl_dict["optionVar"]], False, forceAdd=True)

		# Update controls
		self.windowSetup()

	def controlsCallback(self, *args, **kwargs):
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		#settings = self.querySettings()

		if "setConfigValue" in kwargs and kwargs["setConfigValue"]:
			setConfigValue("ToolsStartup", kwargs["setConfigValue"], next(iter(args), False), forceAdd=True)

	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, exists=True) is True):
			cmds.deleteUI(self.windowName, window=True)
		cmds.window(self.windowName, title=self.windowTitle, menuBar=True, sizeable=True, maximizeButton=True)
		
		# Edit menu
		cmds.menu(label="Edit")
		cmds.menuItem(label="Save Settings", command=(partial(self.saveSettings, 1)), enableCommandRepeat=False)
		cmds.menuItem(label="Reset Settings", command=(partial(self.resetSettings)), enableCommandRepeat=False)
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Reset Window Size", command=(partial(self.resetWindowSize)), enableCommandRepeat=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(label="Help", helpMenu=True)
		cmds.menuItem(label="Help on {0}".format(self.windowTitle), image="help.png", command=(partial(helpCmd, helpUrl="/docs/gentools-startup-settings/")), enableCommandRepeat=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tabsVisible=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", childResizable=True, resizeCommand=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"StartupSettingsFrame", label="GENtools Startup Settings", labelIndent=5, collapsable=False, backgroundShade=True, marginHeight=4, marginWidth=0)
		cmds.formLayout(self.pfx+"StartupSettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"StartupSettingsColumn1", adjustableColumn=True, columnAttach=("left", 0))
		
		windowHeight = 105
		global GENtools_ImportedScripts
		if "GENtools_ImportedScripts" in globals():
			for value in six.itervalues(GENtools_ImportedScripts):
				if all([x in value and value[x] for x in ["toolName", "optionVarName", "startupFunc", "scriptDirName"]]):
					if cmds.optionVar(exists=value["optionVarName"]):
						windowHeight += 25
						autoLoadValue = cmds.optionVar(query=value["optionVarName"])
						if isinstance(autoLoadValue, (list, tuple)):
							autoLoadValue = next(iter(autoLoadValue))
						
						toolDocumentationUrl = ""
						toolDocumentationVisible = False
						if "toolDocumentation" in value and value["toolDocumentation"]:
							toolDocumentationUrl = value["toolDocumentation"]
							toolDocumentationVisible = True
						
						cmds.rowLayout(numberOfColumns=3, columnWidth3=(self.rowOffset, 90, 40), columnAttach=(1, "left", 10), columnAttach3=("left", "left", "left"))
						cmds.text(label="{0}:".format(value["toolName"]))
						self.scriptDirNames[value["optionVarName"]] = value["scriptDirName"]
						cmds.checkBoxGrp(value["optionVarName"], docTag=value["optionVarName"], label="", label1="Auto Load", value1=autoLoadValue, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, setConfigValue=value["scriptDirName"])))
						cmds.symbolButton(image="info.png", command=(partial(helpCmd, helpUrl=toolDocumentationUrl)), visible=toolDocumentationVisible)
						cmds.setParent("..")
		
		self.windowSize = [self.windowSize[0], max(self.windowSize[1], windowHeight)]
		
		# Separation
		cmds.rowLayout(height=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", numberOfDivisions=150)
		#cmds.iconTextButton(self.pfx+"executeButton", label=self.runLabel, command=(partial(self.buttonsCmd, True, True)), flat=False, height=26, style="textOnly", commandRepeatable=True)
		cmds.iconTextButton(self.pfx+"applyButton", label=self.applyLabel, command=(partial(self.buttonsCmd, True, False)), flat=False, height=26, style="textOnly", commandRepeatable=True)
		cmds.iconTextButton(self.pfx+"closeButton", label="Close", command=(partial(self.buttonsCmd, False, True)), flat=False, height=26, style="textOnly", commandRepeatable=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, edit=True,
						attachForm=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						attachControl=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, edit=True,
						attachNone=(self.pfx+"ButtonForm", "top"),
						attachForm=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", edit=True,
						attachForm=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, edit=True,
						attachForm=[(self.pfx+"StartupSettingsFrame", "top", 0), (self.pfx+"StartupSettingsFrame", "left", 0), (self.pfx+"StartupSettingsFrame", "right", 0)],
						attachNone=(self.pfx+"StartupSettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"StartupSettingsForm", edit=True,
						attachForm=[(self.pfx+"StartupSettingsColumn1", "top", 0), (self.pfx+"StartupSettingsColumn1", "left", 0), (self.pfx+"StartupSettingsColumn1", "right", 0)],
						attachNone=(self.pfx+"StartupSettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", edit=True,
						attachForm=(self.pfx+"applyButton", "top", 0),
						attachPosition=[(self.pfx+"applyButton", "left", 0, 0), (self.pfx+"applyButton", "right", 2, 75)],
						attachNone=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", edit=True,
						attachForm=(self.pfx+"closeButton", "top", 0),
						attachPosition=[(self.pfx+"closeButton", "left", 2, 75), (self.pfx+"closeButton", "right", 0, 150)],
						attachNone=(self.pfx+"closeButton", "bottom"))

class RegisteredObject(object):
	def __new__(cls, *args, **kwargs):
		#new_instance = super(RegisteredObject, cls).__new__(cls, *args, **kwargs)
		new_instance = super(RegisteredObject, cls).__new__(cls)
		stack_trace = inspect.stack()
		created_at = os.path.realpath("{0}".format(stack_trace[1][1]))
		new_instance.created_at = created_at 
		return new_instance

	def getObjectCreationDir(self):
		return self.created_at

class ScriptLoader(RegisteredObject):
	def __init__(self, **kwargs):
		#super(ScriptLoader, self).__init__(**kwargs)
		super(ScriptLoader, self).__init__()
		
		# Default args
		self._toolName = ""
		self._toolDocumentation = ""
		self._scriptDirPath = ""
		self._scriptDirName = ""
		self._optionVarName = ""
		self._startupFile = ""
		self._startupFunc = ""
		self._menuCategory = ""
		self._menuCheckBoxDict = {}
		self._subMenuName = ""
		self._menuItemDict = {}
		self._menuItemOptionDict = {}
		self._menuItemFunc = None
		
		# Load keyworded arguments
		for key, value in six.iteritems(kwargs):
			if key == "toolName" or key == "tn":
				self.setToolName(value)
			elif key == "toolDocumentation" or key == "td":
				self.setToolDocumentation(value)
			elif key == "scriptDirPath" or key == "sdp":
				self.setScriptDirPath(value)
			elif key == "scriptDirName" or key == "sdn":
				self.setScriptDirName(value)
			elif key == "optionVarName" or key == "ovn":
				self.setOptionVarName(value)
			elif key == "startupFile" or key == "sf":
				self.setStartupFile(value)
			elif key == "startupFunc" or key == "sfn":
				self.setStartupFunc(value)
			elif key == "menuCategory" or key == "mc":
				self.setMenuCategory(value)
			elif key == "menuCheckBoxDict" or key == "mcbd":
				self.setMenuCheckBoxDict(value)
			elif key == "subMenuName" or key == "smn":
				self.setSubMenuName(value)
			elif key == "menuItemDict" or key == "mid":
				self.setMenuItemDict(value)
			elif key == "menuItemOptionDict" or key == "miod":
				self.setMenuItemOptionDict(value)
			elif key == "menuItemFunc" or key == "mif":
				self.setMenuItemFunc(value)
	
	def loadScript(self, **kwargs):
		GENtoolsScriptLoader(**self.scriptDict).loadScript(**kwargs)
	
	def setToolName(self, toolName):
		'''For setting the tool name in the Menu'''
		if toolName and isinstance(toolName, six.string_types):
			self._toolName = toolName
	
	def setToolDocumentation(self, toolDocumentation):
		'''For setting the tool documentation URL in the Startup Settings'''
		if toolDocumentation and isinstance(toolDocumentation, six.string_types):
			self._toolDocumentation = toolDocumentation
	
	def setScriptDirPath(self, scriptDirPath):
		if scriptDirPath and isinstance(scriptDirPath, six.string_types):
			self._scriptDirPath = scriptDirPath
	
	def setScriptDirName(self, scriptDirName):
		if scriptDirName and isinstance(scriptDirName, six.string_types):
			self._scriptDirName = scriptDirName

	def setOptionVarName(self, optionVarName):
		if optionVarName and isinstance(optionVarName, six.string_types):
			self._optionVarName = optionVarName
	
	def setStartupFile(self, startupFile):
		'''For setting the main MEL file that contains the runtime commands'''
		if startupFile and isinstance(startupFile, six.string_types):
			self._startupFile = startupFile
	
	def setStartupFunc(self, startupFunc):
		'''For setting a startup function to run from the main MEL file'''
		if startupFunc and isinstance(startupFunc, six.string_types):
			self._startupFunc = startupFunc
	
	def setMenuCategory(self, menuCategory):
		'''For setting a category inside the Menu'''
		if menuCategory and isinstance(menuCategory, six.string_types):
			self._menuCategory = menuCategory
	
	def setMenuCheckBoxDict(self, menuCheckBoxDict):
		'''For setting the menuItem as a checkbox'''
		if menuCheckBoxDict and isinstance(menuCheckBoxDict, dict):
			self._menuCheckBoxDict = menuCheckBoxDict
	
	def setSubMenuName(self, subMenuName):
		'''For setting a sub-category inside the Menu'''
		if subMenuName and isinstance(subMenuName, six.string_types):
			self._subMenuName = subMenuName
	
	def setMenuItemDict(self, menuItemDict):
		'''For setting the menuItem parameters'''
		if menuItemDict and isinstance(menuItemDict, dict):
			self._menuItemDict = menuItemDict
	
	def setMenuItemOptionDict(self, menuItemOptionDict):
		'''For adding an optionBox and binding it to a function'''
		if menuItemOptionDict and isinstance(menuItemOptionDict, dict):
			self._menuItemOptionDict = menuItemOptionDict
	
	def setMenuItemFunc(self, menuItemFunc):
		'''For setting a function that creates a sub-menu structure'''
		if menuItemFunc and callable(menuItemFunc):
			self._menuItemFunc = menuItemFunc
	
	def getScriptDirPath(self):
		if self.scriptDirPath:
			return self.scriptDirPath
		else:
			return os.path.dirname(self.getObjectCreationDir())
	
	def getScriptDirName(self):
		if self.scriptDirPath:
			return os.path.basename(self.scriptDirPath)
		else:
			return os.path.basename(self.getScriptDirPath())

	@property
	def toolName(self):
		return self._toolName
	
	@property
	def toolDocumentation(self):
		return self._toolDocumentation
	
	@property
	def scriptDirPath(self):
		return self._scriptDirPath
	
	@property
	def scriptDirName(self):
		return self._scriptDirName

	@property
	def optionVarName(self):
		# if no valid optionVar, generate one from the toolName
		if not self._optionVarName and isinstance(self.toolName, six.string_types) and self.toolName:
			self.setOptionVarName("GENtools_{0}_Startup".format(self.toolName.replace(" ", "")))
		return self._optionVarName
	
	@property
	def startupFile(self):
		return self._startupFile
	
	@property
	def startupFunc(self):
		return self._startupFunc
	
	@property
	def menuCategory(self):
		return self._menuCategory
	
	@property
	def menuCheckBoxDict(self):
		return self._menuCheckBoxDict
	
	@property
	def subMenuName(self):
		return self._subMenuName
	
	@property
	def menuItemDict(self):
		return self._menuItemDict
	
	@property
	def menuItemOptionDict(self):
		return self._menuItemOptionDict
	
	@property
	def menuItemFunc(self):
		return self._menuItemFunc
	
	@property
	def scriptDict(self):
		return {"toolName": self.toolName, 
				"toolDocumentation": self.toolDocumentation, 
				"scriptDirPath": self.getScriptDirPath(), 
				"scriptDirName": self.getScriptDirName(), 
				"optionVarName": self.optionVarName, 
				"startupFile": self.startupFile, 
				"startupFunc": self.startupFunc, 
				"menuCategory": self.menuCategory, 
				"menuCheckBoxDict": self.menuCheckBoxDict, 
				"subMenuName": self.subMenuName, 
				"menuItemDict": self.menuItemDict, 
				"menuItemOptionDict": self.menuItemOptionDict, 
				"menuItemFunc": self.menuItemFunc}

class GENtoolsScriptLoader(ScriptLoader):
	def __init__(self, **kwargs):
		super(GENtoolsScriptLoader, self).__init__(**kwargs)
		
		global GENtools_ImportedScripts
		if "GENtools_ImportedScripts" not in globals():
			GENtools_ImportedScripts = OrderedDict()
		
		global GENtools_LoadedScripts
		if "GENtools_LoadedScripts" not in globals():
			GENtools_LoadedScripts = {}
	
	def loadScript(self, startup=False, autoLoad=True, forceReload=False, **kwargs):
		# Get mel file path
		filePath = self.scriptDirPath
		toolName = self.toolName
		if self.startupFile: 
			filePath = os.path.join(filePath, self.startupFile)

		# Check if optionVar exists and is True
		if startup:
			print(("#\n# Importing {0}...".format(toolName)))
			if self.optionVarName and self.startupFunc:
				
				optionVarValue = checkOptionVar(self.optionVarName)
				scriptDirName = self.scriptDirName
				configValue = strToBool(getConfigValue("ToolsStartup", scriptDirName, fallback=optionVarValue, forceAdd=True))
				if configValue != optionVarValue:
					optionVarValue = configValue
					cmds.optionVar(intValue=(self.optionVarName, configValue))
					for i in range(3):
						cmds.optionVar(intValueAppend=(self.optionVarName, 0))

				if optionVarValue and autoLoad:
					print(("#	> Auto Load is enabled".format(toolName)))
				else:
					print(("#	> Auto Load is disabled".format(toolName)))
					autoLoad = False
		
		# Import mel startup file
		global GENtools_ImportedScripts
		if forceReload or filePath not in GENtools_ImportedScripts:
			GENtools_ImportedScripts[filePath] = self.scriptDict
			
			if os.path.isfile(filePath):
				print(("#	> Importing {0} from {1}".format(os.path.basename(filePath), filePath)))
				mel.eval('source "{0}";'.format(filePath.replace(os.sep, "/")))
			elif self.startupFile:
				cmds.warning("Cannot find file {0}".format(filePath), noContext=True)
		
		# Import overrides and run script startup function
		global GENtools_LoadedScripts
		if autoLoad and (forceReload or filePath not in GENtools_LoadedScripts):
			GENtools_LoadedScripts[filePath] = self.scriptDict
			
			# Run mel startup function
			if self.startupFunc:
				if mel.eval('$GENtools_startup_tmp = (`exists {0}`);'.format(self.startupFunc)):
					mel.eval('{0}();'.format(self.startupFunc))
					print(("#	> Executing {0} startup function".format(toolName)))
				else:
					cmds.warning("Cannot start {0}".format(toolName), noContext=True)
			
			# Import overrides
			overridesDir = os.path.join(os.path.dirname(filePath), "overrides")
			importOverrides(overridesDir)