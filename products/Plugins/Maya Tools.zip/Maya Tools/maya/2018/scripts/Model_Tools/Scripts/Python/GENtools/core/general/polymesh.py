#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds

# for python 3 compatibility
import six

def applySmoothMeshPreview(*args, **kwargs):
	# Create default args
	objects = None
	selection = True
	convertedAtLeastOne = False
	objectShapes = []

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
			selection = False

	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
			selection = False
	
	if objects:
		objectShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
	elif selection:
		objectShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")

	if objectShapes:
		# Store current selection
		currentSel = cmds.ls(selection=True, long=True)

		for objShape in objectShapes:
			displayStyle = cmds.getAttr("{0}.displaySmoothMesh".format(objShape))
			if displayStyle == 0:
				continue

			smoothMeshPreviewDict = {}
			for (attr, flag) in [("smoothLevel", "divisions"), 
								 ("continuity", "continuity"), 
								 ("smoothUVs", "smoothUVs"), 
								 ("keepBorder", "keepBorder"), 
								 ("keepHardEdge", "keepHardEdge"), 
								 ("keepMapBorders", "keepMapBorders"), 
								 ("boundaryRule", "boundaryRule"), 
								 ("smoothDrawType", "subdivisionType")]:
				smoothMeshPreviewDict[flag] = cmds.getAttr("{0}.{1}".format(objShape, attr))

			smoothMeshPreviewDict["constructionHistory"] = cmds.constructionHistory(query=True, toggle=True)

			for (attr, value) in [("displaySmoothMesh", 0), ("smoothLevel", 2)]:
				cmds.setAttr("{0}.{1}".format(objShape, attr), value)
			
			cmds.polySmooth(objShape, method=0, **smoothMeshPreviewDict)

			convertedAtLeastOne = True
		
		# Restore selection
		if convertedAtLeastOne and currentSel:
			cmds.select(currentSel)
	
	if selection:
		if not objectShapes:
			cmds.warning("No polygonal objects selected.", noContext=True)
		elif not convertedAtLeastOne:
			cmds.warning("No polygonal objects selected were in smooth preview mode.", noContext=True)

def disablePolyBaseCache(*args, **kwargs):
	# Create default args
	objects = None
	selection = True
	polyBaseNodes = []

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
			selection = False

	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
			selection = False
	
	if objects:
		objects = cmds.ls(objects)
	elif selection:
		objects = cmds.ls(selection=True)

	if objects:
		polyBaseNodes = cmds.ls(cmds.listHistory(objects, pruneDagObjects=True, interestLevel=1), type="polyBase", long=True)
		polyBaseNodes = list(dict.fromkeys(polyBaseNodes))

	if polyBaseNodes:
		for pb in polyBaseNodes:
			if cmds.getAttr("{0}.caching".format(pb)):
				cmds.setAttr("{0}.caching".format(pb), False)