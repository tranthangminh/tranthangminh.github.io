#!/usr/bin/python
# -*- coding: utf-8 -*-
import math
import maya.mel as mel
import maya.cmds as cmds
from functools import partial
import maya.api.OpenMaya as om
import maya.OpenMaya as OpenMaya
from collections import OrderedDict

# for python 3 compatibility
import six
from six.moves import range, zip

from ...core.gui.options import OptionsWindow, helpCmd
from ...core.general.selections import getCurrentSel, componentListDifference, filterSelectedComponents, componentListIntersection, flattenList, createComponentOrderedDict, getSelectionString

CUT_THROUGH_FACES_DEFAULT = 2

def SCT_GetComponentType(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	selList = OpenMaya.MSelectionList()
	
	if selection is not None:
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
	else:
		OpenMaya.MGlobal_getActiveSelectionList(selList)
	
	filterDict = []
	filterDict.append(("v", OpenMaya.MFn.kMeshVertComponent))
	#filterDict.append(("eg", OpenMaya.MFn.kMeshEdgeComponent))
	#filterDict.append(("fc", OpenMaya.MFn.kMeshPolygonComponent))
	#filterDict.append(("puv", OpenMaya.MFn.kMeshMapComponent))
	#filterDict.append(("pvf", OpenMaya.MFn.kMeshVtxFaceComponent))
	#filterDict.append(("cv", OpenMaya.MFn.kCurveCVComponent))
	filterDict = OrderedDict(filterDict)
	
	for key, filter in six.iteritems(filterDict):
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		try:
			if sel_iter.hasComponents() is True:
				return key
		except:
			pass
	
	return None
	
def SCT_ConnectComponents_Vertex(*args, **kwargs):
	constructionHistory = cmds.constructionHistory(query=True, toggle=True)

	vertex = None
	insertWithEdgeFlow = 0
	cutThroughFaces = CUT_THROUGH_FACES_DEFAULT
	
	for i in range(len(args)):
		if i == 0:
			vertex = args[i]
		#elif i == 1:
			#insertWithEdgeFlow = args[i]
	
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			vertex = value
		elif key == "insertWithEdgeFlow" or key == "ief":
			insertWithEdgeFlow = value
		elif key == "cutThroughFaces" or key == "ctf":
			cutThroughFaces = int(value)
	
	if vertex is None:
		vertex = cmds.filterExpand(expand=False, fullPath=True, selectionMask=31)
		
	newEdgeList = []
	connectByPath = []
	
	vertexList = om.MSelectionList()
	for i in range(len(vertex)):
		vertexList.add(vertex[i])
		
	sel_iter = om.MItSelectionList(vertexList, OpenMaya.MFn.kMeshVertComponent)
	currentSel = cmds.ls(orderedSelection=True, long=True)
	
	while not sel_iter.isDone():
		dagPath, component = sel_iter.getComponent()
		dagPath.pop() # Remove shape
		node = dagPath.fullPathName()
		
		objectEdges = cmds.polyEvaluate(node, edge=True)
		
		# Add current components to selectionList
		compList = om.MSelectionList()
		compList.add([dagPath, component])
		
		# Create new list and merge elements (unflatten list)
		##mergedList = om.MSelectionList()
		##if compList.isEmpty() is False:
			##mergedList.merge(compList, om.MSelectionList.kMergeNormal)
		# Get selection strings
		vertexSel = compList.getSelectionStrings()
		# Return full path strings
		vertexSel = cmds.ls(vertexSel, long=True)

		# Get an ordered and flat list of the selected vertices
		vertexSel = flattenList(componentListIntersection(currentSel, vertexSel, orderedList=True), orderedList=True)
		checkedFaces = []
		sharingFaces = False
		for i, vertex in enumerate(list(vertexSel)):
			vert1_faces = cmds.polyListComponentConversion(vertex, toFace=True)

			# Make sure at least a pair of vertices are sharing a face, otherwise cannot connect components
			if not sharingFaces:
				for face in flattenList(vert1_faces):
					if face not in checkedFaces:
						checkedFaces.append(face)
					else:
						sharingFaces = True
						break

			if i == len(vertexSel)-1:
				break
			
			if cutThroughFaces > 1:
				vertices = [vertex, vertexSel[i+1]]
				vert2_faces = cmds.polyListComponentConversion(vertices[1], toFace=True)
				if not componentListIntersection(vert1_faces, vert2_faces):
					connectByPath.extend(vertices)
		
		if sharingFaces:
			connectNode = cmds.polyConnectComponents(vertexSel, constructionHistory=constructionHistory, insertWithEdgeFlow=insertWithEdgeFlow, adjustEdgeFlow=1)
		
			objectEdgesMax = cmds.polyEvaluate(node, edge=True)
			if objectEdges == objectEdgesMax:
				cmds.delete(connectNode)
			else:
				newEdges = "{0}.e[{1}:{2}]".format(node, objectEdges, objectEdgesMax-1)
				newEdgeList.append(newEdges)
				cmds.polySoftEdge(newEdges, angle=180, constructionHistory=constructionHistory)

		sel_iter.next()
	
	if connectByPath and (cutThroughFaces == 3 or not newEdgeList):
		# Add previously connected edges to a temporary set
		newEdgeSet = None
		if newEdgeList:
			newEdgeSet = cmds.sets(newEdgeList)
		# Connect by path
		newEdgeList = connectShortestPath(connectByPath, selectionSequence=True)
		# Add previously connected edges to the newEdgeList
		if newEdgeSet:
			newEdgeList.extend(cmds.sets(newEdgeSet, query=True) or [])
			cmds.delete(newEdgeSet)
	
	return newEdgeList

def SCT_ConnectComponents_Edge(*args, **kwargs):
	constructionHistory = cmds.constructionHistory(query=True, toggle=True)

	edges = None
	insertWithEdgeFlow = 0

	for i in range(len(args)):
		if i == 0:
			edges = args[i]
		#elif i == 1:
			#insertWithEdgeFlow = args[i]
	
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			edges = value
		elif key == "insertWithEdgeFlow" or key == "ief":
			insertWithEdgeFlow = value
	
	if edges is None:
		edges = cmds.filterExpand(ex=False, fp=True, sm=32)
		
	newEdgeList = []
	
	edgeList = OpenMaya.MSelectionList()
	for i in range(len(edges)):
		edgeList.add(edges[i])
	
	dagPath = OpenMaya.MDagPath()
	component = OpenMaya.MObject()
	compList = OpenMaya.MSelectionList()
	
	sel_iter = OpenMaya.MItSelectionList(edgeList, OpenMaya.MFn.kMeshEdgeComponent)
	
	# For each object
	while not sel_iter.isDone():
		sel_iter.getDagPath(dagPath, component)
		dagPath.pop() # Remove shape
		node = dagPath.fullPathName()
		
		# Add current components to selectionList
		compList.clear()
		compList.add(dagPath, component)
		
		# Create new list and merge elements (unflatten list)
		##mergedList = OpenMaya.MSelectionList()
		##if compList.isEmpty() is False:
			##mergedList.merge(compList, OpenMaya.MSelectionList.kMergeNormal)
		# Get selection strings
		edgeSel = []
		compList.getSelectionStrings(edgeSel)
		# Return full path strings
		edgeSel = cmds.ls(edgeSel, l=True)		
		
		# Get edge count
		edgeCount = cmds.polyEvaluate(node, e=True)
		# Create set of selected edges
		edgeSelSet = cmds.sets(edgeSel)
		# Connect components
		cmds.polyConnectComponents(edgeSel, ch=constructionHistory, insertWithEdgeFlow=insertWithEdgeFlow, adjustEdgeFlow=1)
		# Get new edge count
		newEdgeCount = cmds.polyEvaluate(node, e=True)
		if edgeCount == newEdgeCount:
			# Delete set
			cmds.delete(edgeSelSet)
			# Add new edges to list
			newEdgeList.extend(edgeSel)
		else:
			# Create set of new edges
			newEdges = "{0}.e[{1}:*]".format(node, edgeCount)
			edgesSet = cmds.sets(newEdges)
			# Remove selected edges from set
			cmds.sets(cmds.sets(edgeSelSet, q=True), rm=edgesSet)
			newEdges = cmds.sets(edgesSet, q=True)
			# Delete sets
			cmds.delete([edgesSet, edgeSelSet])
			# Soften new edges
			cmds.polySoftEdge(newEdges, a=180, ch=constructionHistory)
			# Add new edges to list
			newEdgeList.extend(newEdges)
		
		sel_iter.next()
	return newEdgeList

def SmartConnectTool(*args, **kwargs):
	# Default args
	insertWithEdgeFlow = 0
	connectType = 0
	cutThroughFaces = CUT_THROUGH_FACES_DEFAULT

	# Load optionVars
	if cmds.optionVar(exists="SCT_CutThroughFaces") is True:
		cutThroughFaces = cmds.optionVar(query="SCT_CutThroughFaces")

	# Load keyworded arguments (override optionsVars)
	for key, value in six.iteritems(kwargs):
		if key == "connectType" or key == "ct":
			connectType = value
		elif key == "insertWithEdgeFlow" or key == "ief":
			insertWithEdgeFlow = value
		elif key == "cutThroughFaces" or key == "ctf":
			cutThroughFaces = int(value)
	
	currentSel = cmds.ls(selection=True, long=True)
	if connectType == 0:
		selectType = SCT_GetComponentType()
		if selectType == "v":
			if len(cmds.ls(currentSel, flatten=True)) <= 1:
				return
			edgeSel = SCT_ConnectComponents_Vertex(currentSel, insertWithEdgeFlow=insertWithEdgeFlow, cutThroughFaces=cutThroughFaces)
			cmds.select(edgeSel, replace=True)
			#mel.eval('ConnectComponents();')
			#cmds.select(currentSel, r=True)
		else:
			mel.eval('dR_DoCmd("connectTool");')
	else:
		if len(cmds.ls(currentSel, flatten=True)) <= 1:
			return
		edgeSel = SCT_ConnectComponents_Edge(currentSel, insertWithEdgeFlow=insertWithEdgeFlow)
		cmds.select(edgeSel, replace=True)

def isClose(a, b, rt=0.000000001, at=0):
	return abs(a-b) <= max(rt * max(abs(a), abs(b)), at)

def normalizeVector(v1=[1, 0, 0]):
	if isinstance(v1, (list, tuple)) is True and len(v1) >= 3:
		v1 = om.MVector(v1[0], v1[1], v1[2])
		v1.normalize()
		v1 = [v1.x+0, v1.y+0, v1.z+0]
	return v1

def crossProduct(v1, v2, useOpenMaya=True):
	if useOpenMaya is True:
		v1 = om.MVector(*v1) ^ om.MVector(*v2)
		return [v1.x+0, v1.y+0, v1.z+0]
	else:
		return [(v1[1]*v2[2] - v1[2]*v2[1])+0,
				(v1[2]*v2[0] - v1[0]*v2[2])+0,
				(v1[0]*v2[1] - v1[1]*v2[0])+0]

def vectorBetweenPoints(point1, point2):
	return normalizeVector([point2[i] - point1[i] for i in range(len(point1))])

def getOrientationFromVectors(normal, tangent):
	binormal = normalizeVector(crossProduct(normal, tangent))
	
	position = [0, 0, 0]
	
	if cmds.upAxis(query=True, axis=True) == "z":
		tMatrix = tangent + [0] + binormal + [0] + normal + [0] + position + [1]
	else:
		tMatrix = tangent + [0] + normal + [0] + binormal + [0] + position + [1]
	mMatrix = om.MMatrix(tMatrix)
	tmMatrix = om.MTransformationMatrix(mMatrix)
	rotate = tmMatrix.rotation(False).reorder(om.MEulerRotation.kXYZ)
	rotate = [x + 0 for x in list(rotate)[:3]]
	
	return [math.degrees(rotate[0]), math.degrees(rotate[1]), math.degrees(rotate[2])]

def getAverageFaceNormals(faces):
	averageNormal = [0, 0, 0]

	if faces:
		# get average face normal
		selList = om.MSelectionList()
		for face in faces:
			try:
				selList.add(face)
			except:
				pass
		
		facesNum = 0
		for each in range(selList.length()):
			dagPath, component = selList.getComponent(each)
			fnMesh = om.MFnMesh(dagPath)
			face_ids = om.MFnSingleIndexedComponent(component).getElements()
			facesNum += len(face_ids)
			for face_id in face_ids:
				averageNormal = [sum(x) for x in zip(averageNormal, fnMesh.getPolygonNormal(face_id))]

		averageNormal = [x / facesNum for x in averageNormal]
		averageNormal = normalizeVector(averageNormal)
	
	return averageNormal

def filterEdgesByLength(edges, minLength=0.001):
	validEdges = om.MSelectionList()

	if edges:
		# get average face normal
		selList = om.MSelectionList()
		for edge in edges:
			try:
				selList.add(edge)
			except:
				pass
		
		for each in range(selList.length()):
			dagPath, component = selList.getComponent(each)
			edgeIter = om.MItMeshEdge(dagPath, component)
			while not edgeIter.isDone():
				if not isClose(edgeIter.length(), 0, at=0.001):
					validEdges.add([dagPath, edgeIter.currentItem()])
				edgeIter.next()
	
	return validEdges.getSelectionStrings()

def connectShortestPath(*args, **kwargs):
	# Default args
	orientation = 0
	if cmds.upAxis(query=True, axis=True) == "z":
		orientation = 90
	selection = False
	selectionSequence = False

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = True
			if isinstance(arg, (tuple, list)):
				currentSel = arg
			else:
				currentSel = [arg]
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = True
			if isinstance(value, (tuple, list)):
				currentSel = value
			else:
				currentSel = [value]
		elif key == "orientation" or key == "ori":
			orientation = value
		elif key == "selectionSequence" or key == "selseq":
			selectionSequence = value

	if not selection:
		currentSel, currentHl, objects = getCurrentSel(orderedSelection=True)
	currentVertices = filterSelectedComponents(currentSel, componentType=["v"])
	currentVertices = flattenList(componentListIntersection(currentSel, currentVertices, orderedList=True), orderedList=True)
	if selectionSequence:
		currentVertices = [x for x in currentSel if x in currentVertices]
	currentSelDict = createComponentOrderedDict(currentSel, removeDuplicates=not selectionSequence)
	createdEdges = cmds.sets(empty=True)

	for objName, compDict in six.iteritems(currentSelDict):
		objPolyCountDict = cmds.polyEvaluate(objName, edge=True, face=True, vertex=True)
		objCutNodes = []
		objectSel = getSelectionString(objName, compDict, orderedList=True)

		currentVertices = filterSelectedComponents(objectSel, componentType=["v"])
		currentVertices = flattenList(componentListIntersection(objectSel, currentVertices, orderedList=True), orderedList=True)
		if selectionSequence:
			objectSel = flattenList(objectSel, orderedList=True, removeDuplicates=not selectionSequence)
			currentVertices = [x for x in objectSel if x in currentVertices]

		if len(currentVertices) > 1:
			cuttersDict = []
			newEdges = cmds.sets(empty=True)
			extraEdges = cmds.sets(empty=True)

			if selectionSequence:
				currentVertices = zip(currentVertices[0::2], currentVertices[1::2])

			for i, vertex in enumerate(currentVertices):
				if not selectionSequence and i == len(currentVertices)-1:
					break
				
				if selectionSequence:
					vertices = list(vertex)
				else:
					vertices = [vertex, currentVertices[i+1]]
				objectShapes = cmds.ls(vertices, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")

				if len(objectShapes) == 1:
					#currentEdges = cmds.ls(cmds.polyListComponentConversion(vertices, toEdge=True), long=True)
					currentEdges = []
					vertices_ids = [int(x.split("[", 1)[-1][:-1]) for x in vertices]
					shortestEdgePath = cmds.ls(cmds.polySelect(objectShapes[0], query=True, shortestEdgePath=vertices_ids, asSelectString=True), long=True)
					facesBetweenVertices = cmds.ls(cmds.polyListComponentConversion(componentListDifference(shortestEdgePath, currentEdges), toFace=True), long=True)

					# get average vertex normal
					'''averageNormal = [0, 0, 0]

					selList = om.MSelectionList()
					selList.add(objName)

					dagPath = selList.getDagPath(0)
					fnMesh = om.MFnMesh(dagPath)
					for vertex_id in vertices_ids:
						averageNormal = [sum(x) for x in zip(averageNormal, fnMesh.getVertexNormal(vertex_id, True, space=om.MSpace.kWorld))]

					averageNormal = [x / len(vertices) for x in averageNormal]
					averageNormal = normalizeVector(averageNormal)'''

					# get average face normal
					#averageNormal = getAverageFaceNormals(facesBetweenVertices)

					# get vertices positions
					verticesPosition = [cmds.pointPosition(x, world=True) for x in vertices]
					#verticesPosition =  cmds.xform(vertices, query=True, translation=True, worldSpace=True)

					# get average normal
					averageNormal = [0, 0, 0]

					selList = om.MSelectionList()
					selList.add(objName)

					dagPath = selList.getDagPath(0)
					fnMesh = om.MFnMesh(dagPath)
					'''for vertexPosition in verticesPosition:
						averageNormal = [sum(x) for x in zip(averageNormal, fnMesh.getClosestNormal(om.MPoint(vertexPosition), space=om.MSpace.kWorld)[0])]
					#averageNormal = [x / len(vertices) for x in averageNormal]
					averageNormal = normalizeVector(averageNormal)'''

					for vertexId in vertices_ids:
						averageNormal = [sum(x) for x in zip(averageNormal, fnMesh.getVertexNormal(vertexId, True, space=om.MSpace.kWorld))]
					#averageNormal = [x / len(vertices) for x in averageNormal]
					averageNormal = normalizeVector(averageNormal)

					# get direction vector between vertices
					verticesVector = vectorBetweenPoints(*verticesPosition[:2])

					cutPosition = cmds.pointPosition(vertices[0], world=True)
					cutOrientation = getOrientationFromVectors(averageNormal, verticesVector)
					cutOrientation[0] += orientation
					#cutOrientation[0] = 0

					#cmds.polyCut(facesBetweenVertices, cutPlaneCenter=cutPosition, cutPlaneRotate=cutOrientation)
					facesSet = cmds.sets(facesBetweenVertices, facets=True)
					verticesSet = cmds.sets(vertices)
					cuttersDict.append({"facesSet": facesSet, "position": cutPosition, "orientation": cutOrientation, "objectShape": objectShapes[0], "verticesSet": verticesSet, "verticesVector": verticesVector})

			mergeVerticesSet = cmds.sets(empty=True)

			# find created edges
			for cDict in cuttersDict:
				vertices = flattenList(cmds.sets(cDict["verticesSet"], query=True))
				vertices_ids = [int(x.split("[", 1)[-1][:-1]) for x in vertices]
				if vertices:
					cmds.sets(vertices, edit=True, forceElement=mergeVerticesSet)

				# isolate face that should be cutted
				'''facesBetweenVertices = cmds.sets(cDict["facesSet"], query=True)
				edgesSet = cmds.sets(cmds.polyListComponentConversion(facesBetweenVertices, toEdge=True))
				polyCut = next(iter(cmds.polyCut(facesBetweenVertices, cutPlaneCenter=cDict["position"], cutPlaneRotate=cDict["orientation"])))'''
				edgesSet = cmds.sets(cmds.polyListComponentConversion(objName, toEdge=True))

				# create cutter
				polyCut = next(iter(cmds.polyCut(cmds.polyListComponentConversion(objName, toFace=True), cutPlaneCenter=cDict["position"], cutPlaneRotate=cDict["orientation"])))
				objCutNodes.append(polyCut)

				# improve polyCut orientation
				#shortestEdgePath = cmds.polySelect(cDict["objectShape"], query=True, shortestEdgePath=vertices_ids, asSelectString=True)
				#averageNormal = getAverageFaceNormals(cmds.polyListComponentConversion(shortestEdgePath, toFace=True))
				#cutOrientation = getOrientationFromVectors(averageNormal, cDict["verticesVector"])
				#cutOrientation[0] += 90
				#cmds.setAttr("{0}.cutPlaneRotate".format(polyCut), *cutOrientation[:3])
				
				# add new edges to set
				'''currentEdges = cmds.polyListComponentConversion(cmds.sets(cDict["facesSet"], query=True), toEdge=True)
				currentEdges = componentListDifference(currentEdges, cmds.sets(edgesSet, query=True))
				if currentEdges:
					cmds.sets(currentEdges, edit=True, forceElement=newEdges)'''

				#cmds.select(currentEdges)
				#cmds.polySelectConstraint(type=0x8000, propagate=6)
				#cmds.sets(componentListDifference(currentEdges, cmds.ls(selection=True)), edit=True, forceElement=extraEdges)

				# add extra edges to set to delete later
				shortestEdgePath = cmds.polySelect(cDict["objectShape"], query=True, shortestEdgePath=vertices_ids, asSelectString=True)

				# add new edges to set
				#currentEdges = cmds.polySelect(cDict["objectShape"], query=True, edgeLoop=getComponentIds(shortestEdgePath)[-1], asSelectString=True)
				#currentEdges = componentListDifference(currentEdges, cmds.sets(edgesSet, query=True))
				currentEdges = componentListDifference(cmds.polyListComponentConversion(objName, toEdge=True), cmds.sets(edgesSet, query=True))
				if currentEdges:
					cmds.sets(currentEdges, edit=True, forceElement=newEdges)
				
				shortestEdgePathDifference = componentListDifference(currentEdges, shortestEdgePath)
				if shortestEdgePathDifference:
					cmds.sets(shortestEdgePathDifference, edit=True, forceElement=extraEdges)

				# cleanup sets
				cmds.delete(cDict["facesSet"], cDict["verticesSet"], edgesSet)

			# merge vertices
			#cmds.polyMergeVertex(cmds.polyListComponentConversion(cmds.sets(newEdges, query=True), toVertex=True), cmds.sets(mergeVerticesSet, query=True))

			# delete extra edges
			extraEdgesSel = cmds.sets(extraEdges, query=True)
			extraEdgesSel = filterEdgesByLength(extraEdgesSel)
			if extraEdgesSel:
				objCutNodes.extend(cmds.polyDelEdge(extraEdgesSel, cleanVertices=True))
			
			# merge vertices
			#cmds.polyMergeVertex(cmds.polyListComponentConversion(cmds.sets(newEdges, query=True), toVertex=True), cmds.sets(mergeVerticesSet, query=True))
			objCutNodes.extend(cmds.polyMergeVertex(cmds.polyListComponentConversion(cmds.polyListComponentConversion(cmds.sets(newEdges, query=True), cmds.sets(mergeVerticesSet, query=True), toFace=True), toVertex=True), distance=0.001))
			
			# if object polycount didn't change, revert cuts
			if cmds.polyEvaluate(objName, edge=True, face=True, vertex=True) == objPolyCountDict:
				cmds.delete(objCutNodes)
			# otherwise, add created edges to set
			else:
				newEdgesSel = cmds.sets(newEdges, query=True)
				if newEdgesSel:
					cmds.sets(newEdgesSel, edit=True, forceElement=createdEdges)
		
			# delete sets
			cmds.delete(newEdges, extraEdges, mergeVerticesSet)

	# restore selection
	createdEdgesSel = cmds.sets(createdEdges, query=True)
	if createdEdgesSel:
		cmds.select(createdEdgesSel)
	else:
		cmds.select(currentSel)
	
	cmds.delete(createdEdges)

	return createdEdgesSel or []

class SmartConnectToolOptions(OptionsWindow):
	def __init__(self):
		self.windowName = "SmartConnectToolWin"
		self.pfx = "SCT_"
		kwargs = {"windowSize": [380, 140], 
		          "windowTitle": "Smart Connect Tool Options", 
		          "runLabel": "Connect", 
		          "minWindowSize": 180, 
		          "rowOffset": 110, 
				  "preview": False}
		
		super(SmartConnectToolOptions, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		SmartConnectTool()
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(l="Help on {0}".format(self.windowTitle), i="help.png", c=(partial(helpCmd, helpUrl="/docs/smart-connect-tool/")), ecr=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Smart Connect Tool Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Cut Through Faces
		cmds.rowLayout(self.pfx+"CutThroughFacesRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Cut Through Faces:")
		#cmds.checkBoxGrp(self.pfx+"CutThroughFaces", dtg=self.pfx+"CutThroughFaces", l="", l1="Cut Through Faces", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.radioButtonGrp(self.pfx+"CutThroughFaces", docTag=self.pfx+"CutThroughFaces", numberOfRadioButtons=3, columnWidth4=(0, 70, 90, 80), label="", labelArray3=("Never", "Automatic", "Always"), onCommand=(partial(self.controlsCallback)), select=CUT_THROUGH_FACES_DEFAULT)
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")		
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))

'''
import sys
scriptDirPath = (cmds.internalVar(userScriptDir=True)+"SmartConnectTool/")
sys.path.append(scriptDirPath)
import SmartConnectTool
reload(SmartConnectTool)
SmartConnectTool.SmartConnectTool()
'''