#!/usr/bin/python
# -*- coding: utf-8 -*-
import math
#import time
#import logging
import maya.mel as mel
import maya.cmds as cmds
#from threading import Thread
import maya.api.OpenMaya as om
import maya.OpenMaya as OpenMaya
from collections import OrderedDict
from collections import defaultdict
#from multiprocessing.pool import ThreadPool
#from maya.utils import executeInMainThreadWithResult

# for python 3 compatibility
import six
from six.moves import range, zip

from ...core.general.selections import getCurrentSel, componentListDifference, flattenList, getComponentType, filterSelectedComponents, componentListUnion

# Create logger
'''logging.basicConfig(level=logging.DEBUG)

# Set logging handler
from maya.utils import MayaGuiLogHandler
handler = MayaGuiLogHandler()
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter("%(asctime)s %(message)s")
handler.setFormatter(formatter)
logging.root.handlers = []
logging.getLogger("").addHandler(handler)'''

'''class ProgressBarThread(Thread):
	def __init__(self, progressBar):
		Thread.__init__(self)

		self._stopThread = False
		self._isCancelled = False
		self.setProgressBar(progressBar)

	def setProgressBar(self, progessBar):
		self._progressBar = progessBar

	def isCancelled(self, value=None):
		if value is not None:
			self._isCancelled = value
		logging.info(self._isCancelled)
		return self._isCancelled

	def stop(self):
		self._stopThread = True
		try:
			#executeInMainThreadWithResult(cmds.progressBar, self._progressBar, edit=True, endProgress=True)
			pass
		except Exception as e:
			logging.exception(e)
	
	def run(self):
		while True:
			if self._stopThread:
				break
			try:
				if not self.isCancelled():
					isCancelled = executeInMainThreadWithResult(cmds.progressBar, self._progressBar, query=True, isCancelled=True)
					if isCancelled:
						self.isCancelled(True)
				time.sleep(0.25)
			except Exception as e:
				logging.exception(e)'''

def fixHangingProgressBar(progressBar):
	# Fix for hanging previous progress
	if cmds.progressBar(progressBar, query=True, isCancelled=True):
		cmds.progressBar(progressBar, edit=True, endProgress=True)
		cmds.progressBar(progressBar, edit=True, beginProgress=True, isInterruptable=True, status="UV Mapping in progress...")
	cmds.progressBar(progressBar, edit=True, step=1)
	cmds.progressBar(progressBar, edit=True, step=-1)

def currentUnitString(angle=False):
	if angle:
		unitType = cmds.currentUnit(query=True, angle=True)
		if unitType in ["deg", "degree"]:
			unitText = "°"
		elif unitType in ["rad", "radian"]:
			unitText = "<sup>c</sup>"
	else:
		unitType = cmds.currentUnit(query=True, linear=True)
		if unitType in ["mm", "millimeter"]:
			unitText = "mm"
		elif unitType in ["cm", "centimeter"]:
			unitText = "cm"
		elif unitType in ["m", "meter"]:
			unitText = "m"
		elif unitType in ["km", "kilometer"]:
			unitText = "km"
		elif unitType in ["in", "inch"]:
			unitText = "in"
		elif unitType in ["ft", "foot"]:
			unitText = "ft"
		elif unitType in ["yd", "yard"]:
			unitText = "yd"
		elif unitType in ["mi", "mile"]:
			unitText = "mi"
	
	return unitText

def cmToCurrentUnit(x):
	unitText = currentUnitString()
	
	if unitText == "mm":
		x *= 10.0
	elif unitText == "m":
		x /= 100.0
	elif unitText == "m":
		x /= 100000.0
	elif unitText == "in":
		x /= 2.54
	elif unitText == "ft":
		x /= 30.48
	elif unitText == "yd":
		x /= 91.44
	elif unitText == "mi":
		x /= 160934.0
	
	return x

def GetIsolatedObjects():
	isolatedObjects = None
	activeModelPanel = cmds.getPanel(wf=True)
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is False:
		activeModelPanel = "modelPanel4"
	
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is True:
		if cmds.isolateSelect(activeModelPanel, q=True, s=True) is True:
			isolatedObjects = cmds.ls(cmds.sets(cmds.isolateSelect(activeModelPanel, q=True, vo=True), q=True), l=True)
	
	return isolatedObjects

def SoftSelectionToSelection(removeSel=None, objectConstraint=None, includeCurveCVs=True):
	fnList = [OpenMaya.MFn.kMeshVertComponent]
	if includeCurveCVs:
		fnList.append(OpenMaya.MFn.kCurveCVComponent)

	selList = OpenMaya.MSelectionList()
	softSelection = OpenMaya.MRichSelection()
	OpenMaya.MGlobal.getRichSelection(softSelection)
	softSelection.getSelection(selList)

	dagPath = OpenMaya.MDagPath()
	component = OpenMaya.MObject()
	compList = OpenMaya.MSelectionList()
	removeList = OpenMaya.MSelectionList()

	sel_iter = OpenMaya.MItSelectionList(selList)
	while not sel_iter.isDone():
		sel_iter.getDagPath(dagPath, component)

		if not any([component.hasFn(x) for x in fnList]):
			sel_iter.next()
			continue
		#if not [component.hasFn(OpenMaya.MFn.kMeshVertComponent) or component.hasFn(OpenMaya.MFn.kCurveCVComponent)]:
			#sel_iter.next()
			#continue

		dagPath.pop() # Remove shape
		
		if objectConstraint is not None:
			if dagPath.fullPathName() not in objectConstraint:
				sel_iter.next()
				continue

		# Add current components to selectionList
		compList.add(dagPath, component)

		sel_iter.next()
	
	if removeSel is not None:
		selList = OpenMaya.MSelectionList()
		for each in removeSel:
			selList.add(each)
		
		sel_iter = OpenMaya.MItSelectionList(selList)
		while not sel_iter.isDone():
			sel_iter.getDagPath(dagPath, component)
			dagPath.pop() # Remove shape

			if not any([component.hasFn(x) for x in fnList]):
				sel_iter.next()
				continue
			#if not [component.hasFn(OpenMaya.MFn.kMeshVertComponent) or component.hasFn(OpenMaya.MFn.kCurveCVComponent)]:
				#sel_iter.next()
				#continue

			# Add current components to selectionList
			removeList.add(dagPath, component)

			sel_iter.next()
	
	# Remove elements if any
	if removeList.isEmpty() is False:
		compList.merge(removeList, OpenMaya.MSelectionList.kRemoveFromList)
	# Get selection strings
	elements = []
	compList.getSelectionStrings(elements)
	# Return full path strings
	elements = cmds.ls(elements, long=True)
		
	return elements

def GetClosestVertex(sourceVertex, targetVertices, maxDistance):
	# Create sourceVertex selectionList
	cvSel = om.MSelectionList()
	try:
		cvSel.add(sourceVertex)
	except:
		return []
	
	cvPath, cvComp = cvSel.getComponent(0)
	# Get sourceVertex index
	cvCompFn = om.MFnSingleIndexedComponent(cvComp)
	cvIds = cvCompFn.getElements()
	cvIndex = cvIds[0]
	# Get sourceVertex position

	if cvPath.hasFn(om.MFn.kMesh):
		cvMesh = om.MFnMesh(cvPath)
		cvPos = cvMesh.getPoint(cvIndex, om.MSpace.kWorld)
		#print [cvPos.x, cvPos.y, cvPos.z]
	elif cvPath.hasFn(om.MFn.kNurbsCurve):
		cvMesh = om.MFnNurbsCurve(cvPath)
		cvPos = cvMesh.cvPosition(cvIndex, om.MSpace.kWorld)
	else:
		return []
	
	# Create targetVertices selectionList
	tvSel = om.MSelectionList()		
	for vertex in targetVertices:
		try:
			tvSel.add(vertex)
		except:
			pass
	
	# Define variables
	closestVertex = []
	closestDist = maxDistance+1
	
	# Iterate over the items in the targetVertices selectionList
	tvIter = om.MItSelectionList(tvSel)
	while not tvIter.isDone():
		# Get indexed components list in the current item
		tvPath, tvComp = tvIter.getComponent()

		if not [tvComp.hasFn(OpenMaya.MFn.kMeshVertComponent) or tvComp.hasFn(OpenMaya.MFn.kCurveCVComponent)]:
			tvIter.next()
			continue

		tvPath.pop() # Remove shape
		tvNode = tvPath.fullPathName()

		tvCompFn = om.MFnSingleIndexedComponent(tvComp)
		if tvPath.hasFn(om.MFn.kMesh):
			tvMesh = om.MFnMesh(tvPath)
		elif tvPath.hasFn(om.MFn.kNurbsCurve):
			tvMesh = om.MFnNurbsCurve(tvPath)
		else:
			tvIter.next()
			continue
		
		# For each indexed components
		for id in tvCompFn.getElements():
			#tvSelArray = []
			#tvIter.getStrings(tvSelArray)
			#vertexSel = cmds.ls(tvSelArray, l=True, fl=True)
			
			# Get distance between sourceVertex and current item
			if tvPath.hasFn(om.MFn.kMesh):
				tvPos = tvMesh.getPoint(id, om.MSpace.kWorld)
			elif tvPath.hasFn(om.MFn.kNurbsCurve):
				tvPos = tvMesh.cvPosition(id, om.MSpace.kWorld)
			dist = cvPos.distanceTo(tvPos)
			
			# If distance is the closest found so far and under the maxDistance
			if dist <= maxDistance and dist < closestDist:
				# Set the value as the new closest distance
				closestDist = dist
				# Return full path of the vertex (include shape)
				#closestVertex = ("%s.vtx[%s]" % (tvNode, id))
				closestVertex = [(six.text_type("%s.vtx[%s]" % (tvNode, id)))]
				closestVertex.extend((six.text_type(tvPos.x),six.text_type(tvPos.y),six.text_type(tvPos.z)))
			
		tvIter.next()
	
	return closestVertex
	
def convertListToMelStringArr(pyList):
    pyList = str([str(x) for x in pyList])
    pyList = pyList.replace("'", "\"")
    pyList = pyList[1:-1]
    pyList = ("{%s}" % (pyList))
    return pyList

def MatchUVs(maxDistance=1, source=None, target=None):
	currentUVsTargetPosition = {}

	if source is not None or target is not None:
		if source is None or target is None:
			return currentUVsTargetPosition
		currentUVs = cmds.ls(cmds.polyListComponentConversion(source, toUV=True), long=True)
		otherUVs = cmds.ls(cmds.polyListComponentConversion(target, toUV=True), long=True)
	else:
		currentSel, currentHl, objects = getCurrentSel()
		currentUVs = cmds.ls(cmds.polyListComponentConversion(currentSel, toUV=True), long=True)
		otherUVs = cmds.ls(cmds.polyListComponentConversion(objects, toUV=True), long=True)
		otherUVs = componentListDifference(otherUVs, currentUVs)
	
	currentUVsPosition = cmds.polyEditUV(currentUVs, query=True)
	otherUVsPosition = cmds.polyEditUV(otherUVs, query=True)
	if not currentUVsPosition or len(currentUVsPosition) < 2 or not otherUVsPosition or len(otherUVsPosition) < 2:
		return currentUVsTargetPosition
	
	currentUVsPosition = zip(currentUVsPosition[0::2], currentUVsPosition[1::2])
	otherUVsPosition = zip(otherUVsPosition[0::2], otherUVsPosition[1::2])

	currentUVsPositionDict = {x[0]: x[1] for x in zip(flattenList(currentUVs), currentUVsPosition)}
	otherUVsPositionDict = {x[0]: x[1] for x in zip(flattenList(otherUVs), otherUVsPosition)}

	# Progress bar
	#iterableSize = (len(currentUVsPositionDict) * len(otherUVsPositionDict)) + len(currentUVsPositionDict)
	iterableSize = len(currentUVsPositionDict) * 2
	progressStep = (iterableSize/100.0)
	progressCounter = progressStep
	if iterableSize < 100:
		progressMax = iterableSize
	else:
		progressMax = 100
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	cmds.progressBar(gMainProgressBar, edit=True, beginProgress=True, isInterruptable=True, status="Matching UVs in progress...", maxValue=progressMax)
	fixHangingProgressBar(gMainProgressBar)
	#progressBarThread = ProgressBarThread(gMainProgressBar)
	#progressBarThread.daemon = True
	#progressBarThread.start()

	i = 0
	for cuv, cuvPos in six.iteritems(currentUVsPositionDict):
		if cmds.progressBar(gMainProgressBar, query=True, isCancelled=True):
			cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)
			return
		
		minDist = None
		for ouvPos in six.itervalues(otherUVsPositionDict):
			#if progressBarThread.isCancelled():
				#progressBarThread.stop()
				#return

			if len(cuvPos) > 1 and len(ouvPos) > 1:
				dist = math.hypot(ouvPos[0]-cuvPos[0], ouvPos[1]-cuvPos[1])
				if (dist <= maxDistance or maxDistance <= 0) and (minDist is None or dist < minDist):
					minDist = dist
					#currentUVsTargetPosition[cuv] = {"u": ouvPos[0], "v": ouvPos[1]}
					currentUVsTargetPosition[cuv] = ouvPos

		# Progress bar
		if i > progressCounter:
			progressCounter += progressStep
			cmds.progressBar(gMainProgressBar, edit=True, step=1, status="Matching UVs in progress...")
		i += 1
	
	#uPos = [x["u"] for x in six.itervalues(currentUVsTargetPosition)]
	#vPos = [x["v"] for x in six.itervalues(currentUVsTargetPosition)]
	#cmds.polyEditUV(list(currentUVsTargetPosition.keys()), uValue=uPos, vValue=vPos, relative=False)
	for cuv in six.iterkeys(currentUVsPositionDict):
		if cmds.progressBar(gMainProgressBar, query=True, isCancelled=True):
			cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)
			return
		#if progressBarThread.isCancelled():
			#progressBarThread.stop()
			#return
		
		if cuv in currentUVsTargetPosition:
			cmds.polyEditUV(cuv, uValue=currentUVsTargetPosition[cuv][0], vValue=currentUVsTargetPosition[cuv][1], relative=False)
		
		# Progress bar
		if i > progressCounter:
			progressCounter += progressStep
			cmds.progressBar(gMainProgressBar, edit=True, step=1, status="Moving UVs in progress...")
		i += 1
	
	cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)
	#progressBarThread.stop()

	return currentUVsTargetPosition

def GetUVDistance(maxDistance, cuvPos, ouvPos):
	uvDist = None
	if len(cuvPos) > 1 and len(ouvPos) > 1:
		dist = math.hypot(ouvPos[0]-cuvPos[0], ouvPos[1]-cuvPos[1])
		if dist <= maxDistance or maxDistance <= 0:
			uvDist = dist
			#if isinstance(output, dict) and dist not in output[cuv]:
				#if not output[cuv].keys() or dist < min(output[cuv].keys()):
				#output[cuv][dist] = ouvPos

	return uvDist

def GetTargetUVsPositions(maxDistance=1, source=None, target=None):
	matchUVPositions = defaultdict(dict)

	if source is not None or target is not None:
		if source is None or target is None:
			return matchUVPositions
		currentUVs = cmds.ls(cmds.polyListComponentConversion(source, toUV=True), long=True)
		otherUVs = cmds.ls(cmds.polyListComponentConversion(target, toUV=True), long=True)
	else:
		currentSel, currentHl, objects = getCurrentSel()
		currentUVs = cmds.ls(cmds.polyListComponentConversion(currentSel, toUV=True), long=True)
		otherUVs = cmds.ls(cmds.polyListComponentConversion(objects, toUV=True), long=True)
		otherUVs = componentListDifference(otherUVs, currentUVs)
	
	currentUVsPosition = cmds.polyEditUV(currentUVs, query=True)
	otherUVsPosition = cmds.polyEditUV(otherUVs, query=True)
	if not currentUVsPosition or len(currentUVsPosition) < 2 or not otherUVsPosition or len(otherUVsPosition) < 2:
		return matchUVPositions
	
	currentUVsPosition = zip(currentUVsPosition[0::2], currentUVsPosition[1::2])
	otherUVsPosition = zip(otherUVsPosition[0::2], otherUVsPosition[1::2])

	currentUVsPositionDict = {x[0]: x[1] for x in zip(flattenList(currentUVs), currentUVsPosition)}
	otherUVsPositionDict = {x[0]: x[1] for x in zip(flattenList(otherUVs), otherUVsPosition)}

	# Progress bar
	iterableSize = (len(currentUVsPositionDict) * len(otherUVsPositionDict)) + len(currentUVsPositionDict)
	progressStep = (iterableSize/100.0)
	progressCounter = progressStep
	if iterableSize < 100:
		progressMax = iterableSize
	else:
		progressMax = 100
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	cmds.progressBar(gMainProgressBar, edit=True, beginProgress=True, isInterruptable=True, status="Matching UVs in progress...", maxValue=progressMax)
	fixHangingProgressBar(gMainProgressBar)

	i = 0
	for cuv, cuvPos in six.iteritems(currentUVsPositionDict):
		for ouvPos in six.itervalues(otherUVsPositionDict):
			if cmds.progressBar(gMainProgressBar, query=True, isCancelled=True):
				cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)
				return

			dist = GetUVDistance(maxDistance, cuvPos, ouvPos)
			if dist and dist not in matchUVPositions:
				matchUVPositions[cuv][dist] = ouvPos
			
			# Progress bar
			if i > progressCounter:
				progressCounter += progressStep
				cmds.progressBar(gMainProgressBar, edit=True, step=1, status="Matching UVs in progress...")
			i += 1
	
	for cuv in six.iterkeys(currentUVsPositionDict):
		if cmds.progressBar(gMainProgressBar, query=True, isCancelled=True):
			cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)
			return
		
		if cuv in matchUVPositions:
			uvPosList = matchUVPositions[cuv]
			cuvPos = uvPosList[min(uvPosList.keys())]
			matchUVPositions[cuv] = cuvPos
			cmds.polyEditUV(cuv, uValue=cuvPos[0], vValue=cuvPos[1], relative=False)

		# Progress bar
		if i > progressCounter:
			progressCounter += progressStep
			cmds.progressBar(gMainProgressBar, edit=True, step=1, status="Moving UVs in progress...")
		i += 1

	cmds.progressBar(gMainProgressBar, edit=True, endProgress=True)

	return matchUVPositions

'''def GetUVDistanceThreaded(args):
	if isinstance(args, (list, tuple)) and len(args) >= 5:
		otherUVsPositionDict, maxDistance, cuv, cuvPos, matchUVPositions = args
		for ouvPos in six.itervalues(otherUVsPositionDict):
			dist = GetUVDistance(maxDistance, cuvPos, ouvPos)
			if dist and dist not in matchUVPositions:
				matchUVPositions[cuv][dist] = ouvPos

def MatchUVsThreaded(maxDistance=1, source=None, target=None):
	matchUVPositions = defaultdict(dict)

	if source is not None or target is not None:
		if source is None or target is None:
			return matchUVPositions
		currentUVs = cmds.ls(cmds.polyListComponentConversion(source, toUV=True), long=True)
		otherUVs = cmds.ls(cmds.polyListComponentConversion(target, toUV=True), long=True)
	else:
		currentSel, currentHl, objects = getCurrentSel()
		currentUVs = cmds.ls(cmds.polyListComponentConversion(currentSel, toUV=True), long=True)
		otherUVs = cmds.ls(cmds.polyListComponentConversion(objects, toUV=True), long=True)
		otherUVs = componentListDifference(otherUVs, currentUVs)
	
	currentUVsPosition = cmds.polyEditUV(currentUVs, query=True)
	otherUVsPosition = cmds.polyEditUV(otherUVs, query=True)
	if not currentUVsPosition or len(currentUVsPosition) < 2 or not otherUVsPosition or len(otherUVsPosition) < 2:
		return matchUVPositions
	
	currentUVsPosition = zip(currentUVsPosition[0::2], currentUVsPosition[1::2])
	otherUVsPosition = zip(otherUVsPosition[0::2], otherUVsPosition[1::2])

	currentUVsPositionDict = {x[0]: x[1] for x in zip(flattenList(currentUVs), currentUVsPosition)}
	otherUVsPositionDict = {x[0]: x[1] for x in zip(flattenList(otherUVs), otherUVsPosition)}

	executorTasks = []
	for cuv, cuvPos in six.iteritems(currentUVsPositionDict):
		executorTasks.append([otherUVsPositionDict, maxDistance, cuv, cuvPos, matchUVPositions])
	executor = ThreadPool(50)
	executor.map(GetUVDistanceThreaded, executorTasks)'''

def MoveToClosestVertex(maxDistance=1, preserveUVs=1, includeCurveCVs=1, suspendRefresh=1):
	#mel.eval("global string $targetVerticesArray[];")
	#mel.eval("global string $sourceVerticesArray[];")
	#maxDistance = cmds.optionVar(q="MTCV_threshold_default")
	targetVerticesArray = []
	sourceVerticesArray = []
	
	# Get isolated objects
	isolatedObjects = GetIsolatedObjects()
	isolatedObjects = cmds.ls(isolatedObjects, l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
	isolatedObjects = cmds.listRelatives(isolatedObjects, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	isolatedObjects = cmds.ls(isolatedObjects, l=True, ni=True)
	# Remove duplicates objects
	isolatedObjects = list(OrderedDict.fromkeys(isolatedObjects))
	if len(isolatedObjects) <= 0:
		isolatedObjects = None
	
    # Get current selected vertices
	currentSel = cmds.ls(selection=True, long=True)
	#vertexSel = cmds.ls(cmds.polyListComponentConversion(currentSel, toVertex=True), long=True, flatten=True)
	vertexSel = getSelectedVertices(currentSel, includeCurveCVs=includeCurveCVs)
	
	# If no vertex are selected, stop script
	if len(vertexSel) <= 0:
		return
	
	# Progress bar
	progressStep = (len(vertexSel)/100.0)
	progressCounter = progressStep
	if len(vertexSel) < 100:
		progressMax = len(vertexSel)
	else:
		progressMax = 100
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Moving vertex in progress...", max=progressMax)
	# For each selected vertex
	for i in range(len(vertexSel)):
		if cmds.progressBar(gMainProgressBar, q=True, ic=True):
			break
		# Find vertices located inside the maximum distance radius
		cmds.select(vertexSel[i])
		cmds.softSelect(e=True, sse=1)
		nearVertices = SoftSelectionToSelection(vertexSel, isolatedObjects, includeCurveCVs)
		##nearVertices = [e for e in nearVertices if e not in vertexSel]
		cmds.softSelect(e=True, sse=0)
		# Get closest vertex string and position
		closestVertex = GetClosestVertex(vertexSel[i], nearVertices, maxDistance)
		if (len(closestVertex) == 4):
			# Move to closest vertex
			#preserveUVs = cmds.optionVar(q="MTCV_preserveUVs_default")
			if (preserveUVs == 1):
				cmds.move(str(closestVertex[1])+"cm", str(closestVertex[2])+"cm", str(closestVertex[3])+"cm", vertexSel[i], puv=True, ws=True)
			else:
				cmds.move(str(closestVertex[1])+"cm", str(closestVertex[2])+"cm", str(closestVertex[3])+"cm", vertexSel[i], ws=True)
			# If sourceObject matches targetObject, add targetVertices to global array
			if vertexSel[i].split(".")[0] == closestVertex[0].split(".")[0]:
				targetVerticesArray.append(closestVertex[0])
			sourceVerticesArray.append(vertexSel[i])
			#mel.eval("stringArrayInsertAtIndex(size($targetVerticesArray), $targetVerticesArray, "%s");" % (closestVertex[0]))
			#mel.eval("stringArrayInsertAtIndex(size($sourceVerticesArray), $sourceVerticesArray, "%s");" % (vertexSel[i]))
			if suspendRefresh == 0:
				cmds.refresh(cv=True)
		if i > progressCounter:
			progressCounter += progressStep
			cmds.progressBar(gMainProgressBar, e=True, s=1, st="Moving vertex in progress...")
	mel.eval("$targetVerticesArray = %s;" % (convertListToMelStringArr(targetVerticesArray)))
	mel.eval("$sourceVerticesArray = %s;" % (convertListToMelStringArr(sourceVerticesArray)))

def MatchUVsSourceTarget(maxDistance, type):
	mel.eval("global string $selectedVerticesArray[];")
	selectedVerticesArray = mel.eval("$selectedVerticesArray = $selectedVerticesArray")
	if type == 0:
		MatchUVs(maxDistance/100, source=selectedVerticesArray, target=cmds.ls(selection=True, long=True))
	else:
		MatchUVs(maxDistance/100, source=cmds.ls(selection=True, long=True), target=selectedVerticesArray)

def nurbsListComponentConversion():
	currentSel = cmds.ls(selection=True, long=True)
	currentSel = filterSelectedComponents(currentSel, componentType="cv")
	currentObjects = cmds.ls(currentSel, long=True, dagObjects=True, type=["nurbsCurve", "bezierCurve"])

	selectedNurbs = cmds.ls(selection=True, long=True, dagObjects=True, type=["nurbsCurve", "bezierCurve"])
	selectedNurbs = [x for x in selectedNurbs if x not in currentObjects]

	if selectedNurbs:
		selList = om.MSelectionList()
		for n in selectedNurbs:
			try:
				selList.add(n)
			except:
				pass

		cvList = om.MSelectionList()
		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			fnNurbs = om.MFnNurbsCurve(dagPath)
			if fnNurbs.numCVs > 0:
				cvList.add((dagPath, fnNurbs.cvs(0, fnNurbs.numCVs-1)))

		currentCVs = cmds.ls(cvList.getSelectionStrings(), long=True)
		currentSel = componentListUnion(currentSel, currentCVs)

	return currentSel

def getSelectedVertices(currentSel=None, includeCurveCVs=True):
	if currentSel is None:
		currentSel = cmds.ls(selection=True, long=True)
	sel = cmds.ls(cmds.polyListComponentConversion(currentSel, toVertex=True), long=True, flatten=True)
	# Add CVs to selection
	if includeCurveCVs:
		sel.extend(cmds.ls(nurbsListComponentConversion(), long=True, flatten=True))
	return sel

def getLoadedVertices(includeCurveCVs=True):
	componentType = ["v"]
	if includeCurveCVs:
		componentType.append("cv")
	
	mel.eval("global string $selectedVerticesArray[];")
	selectedVerticesArray = mel.eval("$selectedVerticesArray = $selectedVerticesArray")

	sel = cmds.ls(filterSelectedComponents(selectedVerticesArray, componentType=componentType), long=True, flatten=True)
	return sel

def LoadVertices(includeCurveCVs=True):
	currentSel = cmds.ls(selection=True, long=True)
	selType = getComponentType(currentSel)

	if "v" in selType or "puv" not in selType:
		sel = getSelectedVertices(currentSel, includeCurveCVs)
		selType = "v"
	else:
		sel = cmds.ls(cmds.polyListComponentConversion(currentSel, toUV=True), long=True)
		selType = "puv"
	
	mel.eval('global string $selectedVerticesArray[];')
	mel.eval('$selectedVerticesArray = {0};'.format(convertListToMelStringArr(sel)))
	mel.eval('global string $selectedArrayType;')
	mel.eval('$selectedArrayType = "{0}";'.format(selType))