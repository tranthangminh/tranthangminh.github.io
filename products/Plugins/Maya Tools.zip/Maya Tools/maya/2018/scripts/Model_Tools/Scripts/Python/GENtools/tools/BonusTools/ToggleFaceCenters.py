#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya
import maya.OpenMayaUI as OpenMayaUI
from collections import OrderedDict

def lsFromScreen(x, y, x_rect=None, y_rect=None):	
	# Get current selection
	sel = OpenMaya.MSelectionList()
	OpenMaya.MGlobal.getActiveSelectionList(sel)

	# Select from screen
	args = [x, y]
	if x_rect!=None and y_rect!=None:
		OpenMaya.MGlobal.selectFromScreen(x, y, x_rect, y_rect, OpenMaya.MGlobal.kReplaceList, OpenMaya.MGlobal.kWireframeSelectMethod)
	else:
		OpenMaya.MGlobal.selectFromScreen(x, y, OpenMaya.MGlobal.kReplaceList, OpenMaya.MGlobal.kWireframeSelectMethod)
	objects = OpenMaya.MSelectionList()
	OpenMaya.MGlobal.getActiveSelectionList(objects)

	# Restore selection
	OpenMaya.MGlobal.setActiveSelectionList(sel, OpenMaya.MGlobal.kReplaceList)
	
	# Return the objects as strings
	fromScreen = []
	objects.getSelectionStrings(fromScreen)
	# Return full path strings
	fromScreen = cmds.ls(fromScreen, l=True)
	return fromScreen

def toggleFaceCenters():
	if cmds.optionVar(ex="ToggleFaceCenters") is False:
		cmds.optionVar(iv=("ToggleFaceCenters", False))
	if cmds.optionVar(q="ToggleFaceCenters") == 1:
		cmds.polyOptions(np=False, gl=True, dc=False)
		cmds.optionVar(iv=("ToggleFaceCenters", False))
	else:
		currentSel = cmds.ls(sl=True, l=True)
		currentHl = cmds.ls(hl=True, l=True)
		currentLiveObjects = cmds.ls(l=True, lv=True)
		cmds.makeLive(none=True)
		#selectionMode = OpenMaya.MGlobal.selectionMode()
		#OpenMaya.MGlobal.setSelectionMode(OpenMaya.MGlobal.kSelectTemplateMode)
		
		componentMode = cmds.selectMode(q=True, co=True)
		cmds.selectMode(co=True)
		cmds.selectMode(o=True)
		# Set polyMesh Selection Priority
		polymeshPriority = cmds.selectPriority(q=True, p=True)
		cmds.selectPriority(p=100000)
		
		currentView = OpenMayaUI.M3dView.active3dView()
		currentViewSel = lsFromScreen(0, 0, currentView.portWidth(), currentView.portHeight())
		
		# Get selected objects
		objectShapes = cmds.ls(currentViewSel, l=True, dag=True, ni=True, o=True, typ="mesh")
		objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
		# Remove intermediate objects
		objects = cmds.ls(objects, l=True, ni=True)
		# Remove duplicates objects
		if objects is not None:
			objects = list(OrderedDict.fromkeys(objects))
		
		cmds.polyOptions(objects, np=False, gl=False, dc=True) 
		cmds.optionVar(iv=("ToggleFaceCenters", True))
		
		#OpenMaya.MGlobal.setSelectionMode(selectionMode)
		if componentMode is True or len(currentHl) > 0:
			cmds.selectMode(co=True)
		cmds.selectPriority(p=polymeshPriority)
		
		if len(currentLiveObjects) > 0:
			cmds.makeLive(currentLiveObjects[0])
		# Restore selection
		cmds.select(currentSel)