#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds

# for python 3 compatibility
import six
from six.moves import range

def matchTransform(*args, **kwargs):
	# Create default args
	sourceObjects = []
	targetObject = None
	pivots = False
	position = True
	rotation = True
	scale = True
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			if isinstance(arg, six.string_types) is True and cmds.objExists(arg):
				sourceObjects = [arg]
			elif isinstance(arg, (list, tuple)):
				sourceObjects = list(filter(cmds.objExists, arg))
		elif i == 1:
			if isinstance(arg, six.string_types) is True and cmds.objExists(arg):
				targetObject = arg
			elif isinstance(arg, (list, tuple)):
				sourceObjects += list(filter(cmds.objExists, arg))
	
	if not sourceObjects:
		return
	
	if not targetObject:
		targetObject = sourceObjects[-1]
		sourceObjects.pop()
	
	if not sourceObjects or not targetObject:
		return
	
	if "pivots" in kwargs or "piv" in kwargs:
		position = False
		rotation = False
		scale = False
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "pivots" or key == "piv":
			pivots = value
		elif key == "position" or key == "pos":
			position = value
		elif key == "rotation" or key == "rot":
			rotation = value
		elif key == "scale" or key == "scl":
			scale = value
	
	# Get target transforms
	#targetMatrix = cmds.xform(targetObject, query=True, matrix=True, worldSpace=True)
	targetTranslate = cmds.xform(targetObject, query=True, translation=True, worldSpace=True)
	targetRotation = cmds.xform(targetObject, query=True, rotation=True, worldSpace=True)
	targetScale = cmds.xform(targetObject, query=True, scale=True, worldSpace=True)
	targetPivot = cmds.xform(targetObject, query=True, pivots=True, worldSpace=True)[:3]
	targetTranslateDiff = [targetPivot[i] - targetTranslate[i] for i in range(3)]
	
	# Match transforms
	for srcObj in sourceObjects:
		if position:
			srcPivot = cmds.xform(srcObj, query=True, pivots=True, worldSpace=True)[:3]
			srcTranslate = cmds.xform(srcObj, query=True, translation=True, worldSpace=True)[:3]
			srcTranslateDiff = [srcPivot[i] - srcTranslate[i] - targetTranslateDiff[i] for i in range(3)]
		
		# Match all transforms
		#if all([position, rotation, scale]):
			#print ("all")
			#cmds.xform(srcObj, absolute=True, matrix=targetMatrix, worldSpace=True)
		#else:
		
		# Match translation
		if position:
			value = [targetTranslate[i] - srcTranslateDiff[i] for i in range(3)]
			cmds.xform(srcObj, absolute=True, translation=value, worldSpace=True)
		
		# Match rotation
		if rotation:
			cmds.xform(srcObj, absolute=True, rotation=targetRotation, worldSpace=True)
		
		# Match scale
		if scale:
			cmds.xform(srcObj, absolute=True, scale=targetScale, worldSpace=True)
		
		# Match pivot
		if not position and pivots:
			cmds.xform(srcObj, absolute=True, pivots=targetPivot, worldSpace=True)
