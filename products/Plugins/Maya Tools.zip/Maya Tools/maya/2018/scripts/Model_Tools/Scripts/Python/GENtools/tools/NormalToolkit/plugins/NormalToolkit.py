#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.api.OpenMaya as om

def maya_useNewAPI():
	pass

class CreateReorderedObject(om.MPxCommand):
	kCommandName = "createReorderedObject"
	kVerticesFlag = "-v"
	kVerticesLongFlag = "-vertices"
	kPolygonCountsFlag = "-pct"
	kPolygonCountsLongFlag = "-polygonCounts"
	kPolygonConnectsFlag = "-pcn"
	kPolygonConnectsLongFlag = "-polygonConnects"
	kEdgeSmoothingsFlag = "-es"
	kEdgeSmoothingsLongFlag = "-edgeSmoothings"

	def __init__(self):
		om.MPxCommand.__init__(self)

	def doIt(self, args):
		vertices, polygonCounts, polygonConnects, edgeSmoothings = [], [], [], []

		try:
			argData = om.MArgDatabase(self.syntax(), args)
			if argData.isFlagSet(self.kVerticesFlag):
				flagCount = argData.numberOfFlagUses(self.kVerticesFlag)
				vertices = [argData.getFlagArgumentList(self.kVerticesFlag, x).asPoint(0) for x in range(flagCount)]
			
			if argData.isFlagSet(self.kPolygonCountsFlag):
				flagCount = argData.numberOfFlagUses(self.kPolygonCountsFlag)
				polygonCounts = [argData.getFlagArgumentList(self.kPolygonCountsFlag, x).asInt(0) for x in range(flagCount)]
			
			if argData.isFlagSet(self.kPolygonConnectsFlag):
				flagCount = argData.numberOfFlagUses(self.kPolygonConnectsFlag)
				polygonConnects = [argData.getFlagArgumentList(self.kPolygonConnectsFlag, x).asInt(0) for x in range(flagCount)]
			
			if argData.isFlagSet(self.kEdgeSmoothingsFlag):
				flagCount = argData.numberOfFlagUses(self.kEdgeSmoothingsFlag)
				edgeSmoothings = [argData.getFlagArgumentList(self.kEdgeSmoothingsFlag, x).asBool(0) for x in range(flagCount)]
		except Exception as e:
			om.MGlobal.displayWarning("cmds.{0}: Error retrieving default arguments".format(CreateReorderedObject.kCommandName))
			return

		if all([vertices, polygonCounts, polygonConnects]):
			# This MDagModifier object will allow us to undo and redo the creation of DAG nodes in our command.
			self.dagModifier = om.MDagModifier()
			
			# We first create the required MObjects using the MDagModifer assigned to self.dagModifier.
			self.meshTransformObj = self.dagModifier.createNode('transform')

			# Create the function set for operating on the mesh
			meshFn = om.MFnMesh()
			self.meshShapeObj = meshFn.create(vertices, polygonCounts, polygonConnects, parent=self.meshTransformObj)

			# Set edge smoothings
			if edgeSmoothings:
				meshFn.setEdgeSmoothings(range(len(edgeSmoothings)), edgeSmoothings)
				#meshFn.cleanupEdgeSmoothing()
			
			# Update surface
			#meshFn.updateSurface()
			
			# Invoke the command's redoIt() function to actually create and manipulate these objects.
			self.redoIt()

	def redoIt(self):
		#Manipulate the objects created in doIt(). This function is also called by Maya when
		#the user re-does the operation after undoing it.
		
		# Perform the operations enqueued within our reference to MDagModifier.
		#self.dagModifier.doIt()
		
		# Get the object dagPath
		dagNode = om.MFnDagNode(self.meshTransformObj)
		dagPath = dagNode.getPath()

		# The DAG path of the mesh shape node will be used to apply a material.
		#dagshapeNodeFn = om.MFnDagNode(self.meshShapeObj)
		#meshShapeDagPath = dagshapeNodeFn.getPath()
		
		# Include our mesh shape in the shading group we have defined in this command's doIt() function.
		#self.dagModifier.commandToExecute('sets -e -forceElement initialShadingGroup {0}'.format(meshShapeDagPath.fullPathName()))
		
		# Execute the queued MEL command.
		self.dagModifier.doIt()
		
		# Return object name
		#self.clearResult()
		self.setResult(dagPath.fullPathName())

	def undoIt(self):
		# This call to MDagModifier.undoIt() undoes all the operations within the MDagModifier.
		# Observe that the number of calls to MDagModifier.undoIt() does not need to match the number of calls to MDagModifier.doIt().
		self.dagModifier.undoIt()
	
	def isUndoable(self):
		return True
	
	@classmethod
	def cmdCreator(cls):
		return CreateReorderedObject()
	
	@classmethod
	def syntaxCreator(cls):
		syntax = om.MSyntax()
		syntax.addFlag(cls.kVerticesFlag, cls.kVerticesLongFlag, (om.MSyntax.kDouble, om.MSyntax.kDouble, om.MSyntax.kDouble, om.MSyntax.kDouble))
		syntax.makeFlagMultiUse(cls.kVerticesFlag)
		syntax.addFlag(cls.kPolygonCountsFlag, cls.kPolygonCountsLongFlag, om.MSyntax.kLong)
		syntax.makeFlagMultiUse(cls.kPolygonCountsFlag)
		syntax.addFlag(cls.kPolygonConnectsFlag, cls.kPolygonConnectsLongFlag, om.MSyntax.kLong)
		syntax.makeFlagMultiUse(cls.kPolygonConnectsFlag)
		syntax.addFlag(cls.kEdgeSmoothingsFlag, cls.kEdgeSmoothingsLongFlag, om.MSyntax.kBoolean)
		syntax.makeFlagMultiUse(cls.kEdgeSmoothingsFlag)
		return syntax

class SetFaceVertexNormals(om.MPxCommand):
	kCommandName = "setFaceVertexNormals"
	kVertexNormalsFlag = "-vn"
	kVertexNormalsLongFlag = "-vertexNormals"
	kFaceIdsFlag = "-fi"
	kFaceIdsLongFlag = "-faceIds"
	kVertexIdsFlag = "-vi"
	kVertexIdsLongFlag = "-vertexIds"

	def __init__(self):
		om.MPxCommand.__init__(self)

		self.meshFn = None
		self.currentNormals = []
		self.unlockedNormalFaces = []
		self.unlockedNormalVertices = []
		self.vertexNormals, self.faceIds, self.vertexIds = [], [], []

	def doIt(self, args):
		try:
			argData = om.MArgDatabase(self.syntax(), args)

			self.objectString = argData.commandArgumentString(0)

			if argData.isFlagSet(self.kVertexNormalsFlag):
				flagCount = argData.numberOfFlagUses(self.kVertexNormalsFlag)
				self.vertexNormals = [argData.getFlagArgumentList(self.kVertexNormalsFlag, x).asVector(0) for x in range(flagCount)]
			
			if argData.isFlagSet(self.kFaceIdsFlag):
				flagCount = argData.numberOfFlagUses(self.kFaceIdsFlag)
				self.faceIds = [argData.getFlagArgumentList(self.kFaceIdsFlag, x).asInt(0) for x in range(flagCount)]
			
			if argData.isFlagSet(self.kVertexIdsFlag):
				flagCount = argData.numberOfFlagUses(self.kVertexIdsFlag)
				self.vertexIds = [argData.getFlagArgumentList(self.kVertexIdsFlag, x).asInt(0) for x in range(flagCount)]
		
		except Exception as e:
			om.MGlobal.displayWarning("cmds.{0}: Error retrieving default arguments".format(SetFaceVertexNormals.kCommandName))
			return
		
		if self.objectString:
			selList = om.MSelectionList()
			try:
				selList.add(self.objectString)
			except:
				om.MGlobal.displayWarning("Cannot set normals on invalid object: {0}".format(self.objectString))
				return

			dagPath = selList.getDagPath(0)
			if dagPath.isValid():
				self.meshFn = om.MFnMesh(dagPath)
				self.currentNormals = self.meshFn.getNormals(om.MSpace.kObject)

				polygonVertCount, polygonNormalIds = self.meshFn.getNormalIds()
				polygonVertCount, polygonVertexIds = self.meshFn.getVertices()

				for faceId, vertCount in enumerate(polygonVertCount):
					connectStart = sum(polygonVertCount[:faceId])
					connectEnd = connectStart + vertCount
					vertexIds = polygonVertexIds[connectStart:connectEnd]
					normalIds = polygonNormalIds[connectStart:connectEnd]

					for i, normalId in enumerate(normalIds):
						if not self.meshFn.isNormalLocked(normalId):
							self.unlockedNormalFaces.append(faceId)
							self.unlockedNormalVertices.append(vertexIds[i])
		
			# Invoke the command's redoIt() function to actually create and manipulate these objects.
			self.redoIt()

	def redoIt(self):
		if all([self.meshFn, self.vertexNormals, self.faceIds, self.vertexIds]):
			try:
				self.meshFn.setFaceVertexNormals(self.vertexNormals, self.faceIds, self.vertexIds, om.MSpace.kObject)
				self.meshFn.updateSurface()
			except:
				om.MGlobal.displayWarning("Cannot set normals on object: {0}".format(self.objectString))

	def undoIt(self):
		if all([self.meshFn, self.currentNormals]):
			try:
				self.meshFn.setNormals(self.currentNormals, om.MSpace.kObject)
				self.meshFn.unlockFaceVertexNormals(self.unlockedNormalFaces, self.unlockedNormalVertices)
				self.meshFn.updateSurface()
			except:
				om.MGlobal.displayWarning("Cannot set normals on object: {0}".format(self.objectString))
	
	def isUndoable(self):
		return True
	
	@classmethod
	def cmdCreator(cls):
		return SetFaceVertexNormals()

	@classmethod
	def syntaxCreator(cls):
		syntax = om.MSyntax()
		syntax.addArg(om.MSyntax.kString)
		syntax.addFlag(cls.kVertexNormalsFlag, cls.kVertexNormalsLongFlag, (om.MSyntax.kDouble, om.MSyntax.kDouble, om.MSyntax.kDouble))
		syntax.makeFlagMultiUse(cls.kVertexNormalsFlag)
		syntax.addFlag(cls.kFaceIdsFlag, cls.kFaceIdsLongFlag, om.MSyntax.kLong)
		syntax.makeFlagMultiUse(cls.kFaceIdsFlag)
		syntax.addFlag(cls.kVertexIdsFlag, cls.kVertexIdsLongFlag, om.MSyntax.kLong)
		syntax.makeFlagMultiUse(cls.kVertexIdsFlag)
		return syntax

def initializePlugin(mobject):
	mplugin = om.MFnPlugin(mobject, "GENtools", "1.0.0.0")

	try:
		for n in [CreateReorderedObject, SetFaceVertexNormals]:
			commandName = n.kCommandName
			mplugin.registerCommand(commandName, n.cmdCreator, n.syntaxCreator)
	except Exception as e:
		raise Exception("Failed to register command: {0}".format(commandName))

def uninitializePlugin(mobject):
	mplugin = om.MFnPlugin(mobject, "GENtools", "1.0.0.0")
	commandName = None

	try:
		for n in [CreateReorderedObject, SetFaceVertexNormals]:
			commandName = n.kCommandName
			mplugin.deregisterCommand(commandName)
	except Exception as e:
		raise Exception("Failed to deregister command: {0}".format(commandName))
