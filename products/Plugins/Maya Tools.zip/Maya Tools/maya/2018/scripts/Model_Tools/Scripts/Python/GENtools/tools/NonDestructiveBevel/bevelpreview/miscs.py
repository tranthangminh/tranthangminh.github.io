#!/usr/bin/python
# -*- coding: utf-8 -*-
import logging
import maya.cmds as cmds
import maya.api.OpenMaya as om

# for python 3 compatibility
import six
from six.moves import range

from ....core.general.decorators import make_undoable

def getObjectsWithBevelPreview(objects=None, searchAll=False):
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return {}

	bevelPreviewObjects = {}

	if objects:
		selectedShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	else:
		selectedShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")

	if not selectedShapes and not selectedBevelPreview:
		if searchAll:
			selectedShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
			selectedBevelPreview = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
		else:
			return bevelPreviewObjects
	
	if selectedShapes:
		selList = om.MSelectionList()
		for x in selectedShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			outMeshPlug = dependencyNode.findPlug("outMesh", False)
			dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtBevelPreview":
					
					# remove from selectedBevelPreview list to avoid processing twice
					bevelPreviewDagPath = om.MDagPath.getAPathTo(currentItem)
					if bevelPreviewDagPath.fullPathName() in selectedBevelPreview:
						selectedBevelPreview.remove(bevelPreviewDagPath.fullPathName())
					
					# Add to dictionary
					dagPath.pop()
					bevelPreviewObjects[dagPath.fullPathName()] = {"name": bevelPreviewDagPath.fullPathName(), "dependencyNode": currentDependencyNode}
					
					break

				dependencyGraph.next()
	
	if selectedBevelPreview:
		selList = om.MSelectionList()
		for x in selectedBevelPreview:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())

			inMeshPlug = dependencyNode.findPlug("inMesh", False)
			dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtDynamicBevel":
					inputMeshPlug = currentDependencyNode.findPlug("inputMesh", False)
					inputPlugArray = inputMeshPlug.connectedTo(True, False)
					for p in inputPlugArray:
						dNode = om.MFnDependencyNode(p.node())
						if dNode.typeName == "mesh":
							# Add to dictionary
							meshDagPath = om.MDagPath.getAPathTo(p.node())
							meshDagPath.pop()
							bevelPreviewObjects[meshDagPath.fullPathName()] = {"name": dagPath.fullPathName(), "dependencyNode": dependencyNode}

							break

					break

				dependencyGraph.next()
	
	return bevelPreviewObjects

def getDynamicBevelFromObject(obj, attrName="outMesh", nodeType="gtDynamicBevel"):
	dynamicBevel = None

	if not cmds.objectType(tagFromType="gtDynamicBevel"):
		return dynamicBevel
	
	if isinstance(obj, six.string_types) and cmds.objExists(obj or ""):
		selList = om.MSelectionList()
		selList.add(obj)
		dagPath = selList.getDagPath(0)
		obj = dagPath.node()
	
	if not isinstance(obj, om.MObject):
		return dynamicBevel

	dependencyNode = om.MFnDependencyNode(obj)
	if dependencyNode.hasAttribute(attrName):
		outMeshPlug = dependencyNode.findPlug(attrName, False)
		dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
		while not dependencyGraph.isDone():
			currentItem = dependencyGraph.currentNode()
			currentDependencyNode = om.MFnDependencyNode(currentItem)
			if currentDependencyNode.typeName == nodeType:
				dynamicBevel = currentDependencyNode			
				break

			dependencyGraph.next()
	
	return dynamicBevel

@make_undoable
def setDisplaySurface(*args, **kwargs):
	# Create default args
	targetObject = None

	if args and cmds.objExists(args[0] or ""):
		targetObject = args[0]

	if targetObject:
		try:
			cmds.displaySurface(*args, **kwargs)
		except Exception as e:
			logging.exception(e)