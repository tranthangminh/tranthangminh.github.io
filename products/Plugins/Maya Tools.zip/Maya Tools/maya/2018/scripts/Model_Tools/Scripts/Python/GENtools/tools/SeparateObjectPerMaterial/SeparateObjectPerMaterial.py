#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya
from collections import OrderedDict
from maya.mel import eval as melEval

# for python 3 compatibility
import six
from six.moves import range

def GetValidSelection(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
		
		# Create new list and merge elements (unflatten list)
		##mergedList = OpenMaya.MSelectionList()
		##if selList.isEmpty() is False:
			##mergedList.merge(selList, OpenMaya.MSelectionList.kMergeNormal)
		
		# Get selection strings
		selection = []
		selList.getSelectionStrings(selection)
		# Return full path strings
		selection = cmds.ls(selection, l=True)
		
	return selection

def GetLockedVertices(*args, **kwargs):
	# Create default args
	selection = None
	locked = True
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			locked = bool(arg)
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "locked" or key == "l":
			locked = bool(value)
	
	selList = OpenMaya.MSelectionList()
	
	if selection is None:
		selection = SOPM_GetCurrentSel()[1]
		
	if isinstance(selection, six.string_types) is True:
		selection = [selection]
	for each in selection:
		try:
			selList.add(each)
		except:
			pass
	
	lockedObjects = []
	compList = OpenMaya.MSelectionList()
	dagPath = OpenMaya.MDagPath()
	# Iterate over selList
	sel_iter = OpenMaya.MItSelectionList(selList)
	iterIndex = 0
	while not sel_iter.isDone():
		selList.getDagPath(iterIndex, dagPath)
		
		fnMesh = OpenMaya.MFnMesh(dagPath)
		#dagPath.pop() # Remove shape
		
		# Get object name
		objectName = dagPath.fullPathName()
		
		compList.clear()
		ids = set()
		vertexList = set()
		
		'''
		normalCount = OpenMaya.MIntArray()
		normalIds = OpenMaya.MIntArray()
		fnMesh.getNormalIds(normalCount, normalIds)
		faceId = 0
		normalIndex = 0
		for i in normalCount:
			currentNormals = normalIds[normalIndex:normalIndex+i]
			lockedNormals = [fnMesh.isNormalLocked(normal) for normal in currentNormals]
			print "{}.f[{}]: {} {}".format(objectName, faceId, currentNormals, lockedNormals)
			faceId += 1
			normalIndex += i
		'''
		
		for i in range(fnMesh.numNormals()):
			if fnMesh.isNormalLocked(i) is bool(locked):
				ids.add(i)
		
		faceVert_itr = OpenMaya.MItMeshFaceVertex(dagPath)
		while not faceVert_itr.isDone():
			if faceVert_itr.normalId() in ids:
				compList.add("{}.vtx[{}]".format(objectName, faceVert_itr.vertId()))
			
			faceVert_itr.next()
		
		# Get selection strings
		objComponents = []
		compList.getSelectionStrings(objComponents)
		if len(objComponents) > 0:
			# Return full path strings
			lockedObjects.append(cmds.ls(objComponents, l=True))
		
		iterIndex += 1
		sel_iter.next()
	
	return lockedObjects

def GetSoftEdges(*args, **kwargs):
	# Create default args
	selection = None
	softEdges = []
	softEdgesList = OpenMaya.MSelectionList()
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(te=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for edge in selection:
			selList.add(edge)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		
		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshEdgeComponent):
				dagPath.pop() # Remove shape
				edge_itr = OpenMaya.MItMeshEdge(dagPath, component)
				while not edge_itr.isDone():
					edgeId = edge_itr.index()
					smoothEdge = edge_itr.isSmooth()
					node = dagPath.fullPathName()
					
					if smoothEdge is True:
						softEdgesList.add(dagPath, edge_itr.currentItem())
					
					edge_itr.next()
			
			iterIndex += 1
			sel_iter.next()
		
		# Create new list and merge elements (unflatten list)
		mergedList = OpenMaya.MSelectionList()
		if softEdgesList.isEmpty() is False:
			mergedList.merge(softEdgesList, OpenMaya.MSelectionList.kMergeNormal)
		
		mergedList.getSelectionStrings(softEdges)
		# Return full path strings
		softEdges = cmds.ls(softEdges, l=True)
	return softEdges

def SOPM_GetCurrentSel(*args):
	objects = None
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects

def SOPM_GetShortName(objectSel):
	dagPath = []
	shortName = objectSel
	dagPath = shortName.split("|")
	#shortName = filter(None, shortName)
	if(len(dagPath)>0):
		shortName = dagPath[len(dagPath)-1]
	return shortName

def SOPM_ResetMainProgressBar():
	# Fix for hanging previous progress
	gMainProgressBar = melEval("$gMainProgressBar = $gMainProgressBar")
	cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True)
	if cmds.progressBar(gMainProgressBar, q=True, ic=True):
		cmds.progressBar(gMainProgressBar, e=True, ep=True)
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True)
	cmds.progressBar(gMainProgressBar, e=True, s=1)
	cmds.progressBar(gMainProgressBar, e=True, s=-1)

def SOPM_FixObjectMaterials(objects=None):
	currentSel, objects = SOPM_GetCurrentSel(objects)
	
	if len(objects) > 0:
		# Create progress bar
		SOPM_ResetMainProgressBar()
		gMainProgressBar = melEval("$gMainProgressBar = $gMainProgressBar")
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Fixing materials in progress...", max=len(objects))
		
		for object in objects:
			if cmds.progressBar(gMainProgressBar, q=True, ic=True):
				break
			
			# Store object matrix
			objectMatrix = cmds.xform(object, q=True, m=True, ws=True)
			
			# Store object parent
			objectParent = cmds.listRelatives(object, f=True, p=True)
			
			# Reset object matrix
			cmds.xform(object, m=[1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0], ws=True)
			
			# Create polyCube
			cubeTemp = cmds.polyCube()[0]
			
			# Combine object with polyCube
			newObject = cmds.polyUnite([cubeTemp, object], objectPivot=True)[0]
			
			# Delete polyCube faces
			cmds.delete(newObject+".f[0:5]")
			
			# Re-parent object
			if objectParent is not None:
				cmds.parent(newObject, objectParent[0])	
			
			# Delete history
			cmds.delete(newObject, ch=True)
			
			# Delete old object
			try:
				cmds.delete(object)
			except:
				pass
			
			# Restore object's matrix
			cmds.xform(newObject, m=objectMatrix, ws=True)
			
			# Rename object
			object = cmds.rename(newObject, SOPM_GetShortName(object))
			
			# Progress bar
			cmds.progressBar(gMainProgressBar, e=True, s=1, st="Fixing materials in progress...")
		
		# Restore selection
		cmds.select(currentSel, r=True)
		
		# End progress bar
		cmds.progressBar(gMainProgressBar, e=True, ep=True)

def SOPM_SeparateObjectPerMaterial(objects=None):	
	currentSel, objects = SOPM_GetCurrentSel(objects)
	
	if len(objects) > 0:
		
		# Fix objects that turns green when undoing
		cmds.ogs(reset=True)
		
		if bool(cmds.optionVar(q="SOPM_FixMaterials")) is True:
			SOPM_FixObjectMaterials(objects)
		
		# Get progress bar length
		progressBarMax = 0
		for object in objects:
			objectShape = cmds.listRelatives(object, f=True, ni=True, s=True)
			shadingGroups = cmds.listConnections(objectShape, t="shadingEngine")
			# Remove duplicates
			shadingGroups = list(OrderedDict.fromkeys(shadingGroups))
			progressBarMax += len(shadingGroups)
		
		# Create progress bar
		SOPM_ResetMainProgressBar()
		gMainProgressBar = melEval("$gMainProgressBar = $gMainProgressBar")
		cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Mesh extraction in progress...", max=progressBarMax)
		
		# List new objects
		#restoreSelection = list(currentSel)
		
		# Open undo chunk
		cmds.undoInfo(ock=True)
		
		# For each objects
		for object in objects:
			objectShape = cmds.listRelatives(object, f=True, ni=True, s=True)
			shadingGroups = cmds.listConnections(objectShape, t="shadingEngine")
			# Remove duplicates
			shadingGroups = list(OrderedDict.fromkeys(shadingGroups))
			if len(shadingGroups) > 1:
				separatedObjects = []
				# Create empty group at same hierarchy level than the object
				objectParent = cmds.listRelatives(object, f=True, p=True)
				if objectParent is not None:
					objectTransform = cmds.group(em=True, p=objectParent[0])
				else:
					objectTransform = cmds.group(em=True, w=True)
				cmds.copyAttr(object, objectTransform, v=True, ic=True, ksc=True, oc=True)
				
				# For each materials
				for shadingGroupName in shadingGroups:
					if cmds.progressBar(gMainProgressBar, q=True, ic=True):
						break
					materialName = cmds.ls(cmds.listConnections(shadingGroupName), mat=True)[0]
					# Duplicate source object
					duplicatedObject = cmds.duplicate(object)[0]
					duplicatedObject = cmds.rename(duplicatedObject, (SOPM_GetShortName(object)+"_"+materialName))
					separatedObjects.append(duplicatedObject)
					tempSet = cmds.sets(duplicatedObject+".f[*]")
					setIntersection = cmds.sets(tempSet, int=shadingGroupName)
					if len(setIntersection) > 0:
						cmds.sets(setIntersection, rm=tempSet)
						if bool(cmds.optionVar(q="SOPM_LockNormals")) is True:
							vertexSel = cmds.polyListComponentConversion(setIntersection, ff=True, tv=True, bo=True)
							if len(vertexSel) > 0:
								# Get soft edges
								softEdges = GetSoftEdges(cmds.polyListComponentConversion(duplicatedObject, te=True))
								
								# Lock border vertex normals
								cmds.polyNormalPerVertex(vertexSel, fn=True)
								
								unlockedVertices = GetLockedVertices(duplicatedObject, locked=False)
								unlockedVertices = [item for sublist in unlockedVertices for item in sublist]
								#unlockedSet = cmds.sets(duplicatedObject+".vtx[*]")
								#cmds.sets(vertexSel, rm=unlockedSet)
								#unlockedVertices = cmds.sets(unlockedSet, q=True)
								#cmds.delete(unlockedSet)
								# Fix normals display in viewport 2.0
								cmds.transferAttributes(object, duplicatedObject, pos=0, nml=1, uvs=0, clb=0, col=0, spa=4, sm=3)
								if unlockedVertices:
									cmds.polyNormalPerVertex(unlockedVertices, ufn=True)
								
								# Re-soften edges
								if len(softEdges) > 0:
									cmds.polySoftEdge(softEdges, a=180, ch=True)
								
						cmds.delete(cmds.sets(tempSet, q=True))
					cmds.delete(tempSet)
					cmds.sets(duplicatedObject, e=True, forceElement=shadingGroupName)
					# Progress bar
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Mesh extraction in progress...")
				
				#if object in restoreSelection:
					#restoreSelection.remove(object)
					#restoreSelection.extend(separatedObjects)
				# Delete source object
				cmds.delete(object)
				
				# Parent separated objects
				cmds.parent(separatedObjects, objectTransform)
				cmds.rename(objectTransform, SOPM_GetShortName(object))
			
		# Restore selection
		#cmds.select(restoreSelection, r=True)
		cmds.select(currentSel, r=True)
		
		# Close undo chunk
		cmds.undoInfo(cck=True)
		
		# End progress bar
		cmds.progressBar(gMainProgressBar, e=True, ep=True)