#!/usr/bin/python
# -*- coding: utf-8 -*-
from functools import partial

class rpartial(partial):
	def __init__(self, *args, **kwargs):
		self._func = args[0]
		self._args = tuple(args[1:])
		self._kwargs = dict(**kwargs)
		self.commandLabel = None

		for key in ["partialLabel", "pl"]:
			if key in self._kwargs:
				self.commandLabel = self._kwargs[key]
				del self._kwargs[key]
	
	def __call__(self, *args, **kwargs):
		args = tuple(self._args, *args)
		kwargs = dict(self._kwargs, **kwargs)
		return self.func(*args, **kwargs)

	def __repr__(self):
		if self.commandLabel:
			return self.commandLabel
		return self

'''
class rpartial(partial):
	def __new__(cls, *args, **kwargs):
		if not args:
			raise TypeError("descriptor '__new__' of partial needs an argument")
		if len(args) < 1:
			raise TypeError("type 'partial' takes at least one argument")

		func = args[0]
		args = args[1:] or ()

		if not callable(func):
			raise TypeError("the first argument must be callable")

		# Assign instance variables by determining their avialability
		if hasattr(func, "func"):
			args = func.args + args
			# This is pretty awesome, the passed in func keywords are copied
			# The func keywords is then updated with the instance keywords
			# Keywords is then overwritten with the temporary keywords
			# The memory is then released for temporary keywords
			tmp_kw = func.keywords.copy()
			tmp_kw.update(kwargs)
			kwargs = tmp_kw
			del tmp_kw
			func = func.func
		
		self = super(rpartial, cls).__new__(cls, func, *args, **kwargs)
		self._func = func
		self._args = args
		self._kwargs = kwargs
		self.commandLabel = None

		for key in ["partialLabel", "pl"]:
			if key in self._kwargs:
				self.commandLabel = self._kwargs[key]
				del self._kwargs[key]

		return self

	def __call__(self, *args, **kwargs):
		arguments = tuple(self._args, *args)

		keywords = self._kwargs.copy()
		keywords.update(kwargs)
		
		return self.func(*arguments, **keywords)

	def __repr__(self):
		if self.commandLabel:
			return self.commandLabel
		return self
'''