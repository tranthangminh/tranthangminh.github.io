#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.api.OpenMaya as om

# for python 3 compatibility
from six.moves import range

def GetUVBorderEdges(objects=None, border=True):
    edges_list = om.MSelectionList()

    if objects is None:
        selList = om.MGlobal.getActiveSelectionList()
    else:
        selList = om.MSelectionList()
        for obj in objects:
            selList.add(obj)

    for i in range(selList.length()):
        dagPath, component = selList.getComponent(i)
        
        # Create dictionary with face uv indexes
        face_uv_indexes = {}
        face_vertex_iter = om.MItMeshFaceVertex(dagPath)
        while not face_vertex_iter.isDone():
            if face_vertex_iter.faceId() not in face_uv_indexes:
                face_uv_indexes[face_vertex_iter.faceId()] = {face_vertex_iter.getUVIndex()}
            else:
                face_uv_indexes[face_vertex_iter.faceId()].add(face_vertex_iter.getUVIndex())
            
            face_vertex_iter.next()

        # Iterate through all edges and create uv border list
        edge_iter = om.MItMeshEdge(dagPath, component)
        while not edge_iter.isDone():
            faces = edge_iter.getConnectedFaces()[:]                
            if len(faces) == 2:            
                if len(face_uv_indexes[faces[0]].intersection(face_uv_indexes[faces[1]])) > 1:
                    pass
                else:
                    # UV shell edge, add to list
                    edges_list.add((dagPath, edge_iter.currentItem()), True)
            elif border:
                # Border edge, add to list
                edges_list.add((dagPath, edge_iter.currentItem()), True)
            
            edge_iter.next()

    return edges_list.getSelectionStrings()

def SelectUVBorderEdges(objects=None):
	shell_borders = GetUVBorderEdges(objects)
	if len(shell_borders) > 0:
		cmds.selectMode(component=True)
		cmds.selectType(edge=True)
		cmds.select(shell_borders, replace=True)