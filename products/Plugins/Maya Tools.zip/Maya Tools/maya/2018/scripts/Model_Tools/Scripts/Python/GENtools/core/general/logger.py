#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
#import datetime
import maya.mel as mel
import maya.cmds as cmds
from functools import partial

from ..config.infos import GENtools_Root

def loggerScriptEditorSettings():
	# Set script editor settings 
	cmds.commandEcho(state=True)
	cmds.commandEcho(lineNumbers=True)
	mel.eval("stackTrace -state on;")
	cmds.scriptEditorInfo(suppressErrors=False, suppressWarnings=False, suppressInfo=False, suppressResults=False, suppressStackWindow=False)

def startScriptEditorLogger():
	loggerScriptEditorSettings()
	cmds.evalDeferred(partial(loggerScriptEditorSettings)) # Make sure settings does not get changed after initialization

	# Get timestamp
	#currentTime = datetime.datetime.now()
	#timestamp = currentTime - datetime.timedelta(microseconds=currentTime.microsecond)

	# Create logger filepath
	#scriptEditorLogPath = os.path.join(GENtools_Root, "{0} - GENtools_log.txt".format(timestamp))
	scriptEditorLogPath = os.path.join(GENtools_Root, "GENtools_log.txt")

	# Delete log file if it already exists
	if os.path.isfile(scriptEditorLogPath):
		try:
			os.remove(scriptEditorLogPath)
		except:
			pass

	# Record script editor
	cmds.scriptEditorInfo(historyFilename=scriptEditorLogPath, writeHistory=True)
	#cmds.evalDeferred("cmds.commandEcho(state=False)", lowestPriority=True)

def stopScriptEditorLogger():
	# Stop recording script editor
	cmds.scriptEditorInfo(writeHistory=False)

	# Reset script editor settings
	cmds.commandEcho(state=False)