#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import logging
from glob import glob
import maya.mel as mel
import maya.cmds as cmds
from textwrap import dedent
from ast import literal_eval
from functools import partial
import maya.api.OpenMaya as om
from collections import defaultdict, OrderedDict, Counter
try:
	from PySide2 import QtCore, QtWidgets
	from shiboken2 import isValid
except ImportError:
	from PySide import QtCore
	from PySide import QtGui as QtWidgets
	from shiboken import isValid

# for python 3 compatibility
import six
from six.moves import range

from ...core.general.nodes import MayaNode
from ...core.utils.overrides import rpartial
#from ...core.general.panels import hideInOutliner
from ...core.general.decorators import make_undoable
from ...core.general.materials import getMainMaterial
from ...core.gui.options import OptionsWindow, helpCmd
from .bevelpreview.MarkingMenu import QPieMenu, getSpinBoxName
from .bevelpreview.MarkingMenu_ui import Ui_CentralWidget
from .bevelpreview.callbacks import createViewportCallback, removeViewportCallback, createSelectionCallback, removeSelectionCallback
from .bevelpreview.miscs import getObjectsWithBevelPreview, setDisplaySurface, getDynamicBevelFromObject
try:
	from ..NormalToolkit.NormalToolkit import NT_SmartBevel
except:
	NT_SmartBevel = None

ROOT_FILE = __file__
ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
ROOT_DIR = ROOT_DIR_RAW
if not isinstance(ROOT_FILE, six.text_type):
	try:
		ROOT_FILE = ROOT_FILE.decode(sys.getfilesystemencoding())
		ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
		ROOT_DIR = ROOT_DIR_RAW.encode(sys.getfilesystemencoding())
	except:
		pass

def getPluginPath():
	pluginName = "NonDestructiveBevel.py"
	pluginDirPath = os.path.join(ROOT_DIR, "plugins")
	pluginFilePath = os.path.join(pluginDirPath, pluginName)
	if os.path.isdir(pluginDirPath) and os.path.isfile(pluginFilePath):
		return (pluginName, pluginDirPath, pluginFilePath)
	
	return (None, None, None)

def getModulePath():
	moduleDirPath = os.path.join(ROOT_DIR, "modules")
	moduleFilePath = os.path.join(moduleDirPath, "NonDestructiveBevel.mod")
	if os.path.isdir(moduleDirPath) and os.path.isfile(moduleFilePath):
		return (moduleDirPath, moduleFilePath)
	
	return (None, None)

def loadTempModule():
	try:
		# Find module directory
		scriptDir = os.path.realpath(cmds.internalVar(userScriptDir=True))
		mayaVersionDir = os.path.dirname(scriptDir)
		modulesDir = os.path.join(mayaVersionDir, "modules")
		if not os.path.exists(modulesDir):
			os.makedirs(modulesDir)
		
		# Create module file
		moduleFilePath = os.path.join(modulesDir, "NonDestructiveBevel.mod")
		with open(moduleFilePath, "w+") as f:
			f.write(dedent("""\
				+ PLATFORM:win64 NonDestructiveBevel 1.0.0.0 ..\\scripts\\GENtools\\tools\\NonDestructiveBevel
				plug-ins: plugins"""))
		# Load module
		cmds.loadModule(load="NonDestructiveBevel")

		# Delete module file
		os.remove(moduleFilePath)
		if not os.listdir(modulesDir):
			os.rmdir(modulesDir)
	except:
		pass

def loadPlugin():
	pluginDirPath, pluginFilePath = getPluginPath()[-2:]

	'''
	moduleDirPath, moduleFilePath = getModulePath()
	if moduleDirPath and moduleFilePath:
		# Add module directory to MAYA_MODULE_PATH
		MAYA_MODULE_PATH = os.getenv("MAYA_MODULE_PATH", moduleDirPath)
		if MAYA_MODULE_PATH:
			MAYA_MODULE_PATH += ";"+moduleDirPath
			temp_module_path = moduleDirPath+";" + MAYA_MODULE_PATH
		os.environ["MAYA_MODULE_PATH"] = temp_module_path
		# load module
		cmds.loadModule(load="NonDestructiveBevel")
		os.environ["MAYA_MODULE_PATH"] = MAYA_MODULE_PATH
	'''

	if pluginDirPath and pluginFilePath:
		# Add plugin directory to MAYA_PLUG_IN_PATH
		MAYA_PLUG_IN_PATH = os.getenv("MAYA_PLUG_IN_PATH", pluginDirPath)
		if MAYA_PLUG_IN_PATH:
			MAYA_PLUG_IN_PATH += ";"+pluginDirPath
		os.environ["MAYA_PLUG_IN_PATH"] = MAYA_PLUG_IN_PATH

		# Load plugin
		if not cmds.pluginInfo(pluginFilePath, query=True, loaded=True):
			#cmds.unloadPlugin(pluginFilePath, force=True)
			cmds.loadPlugin(pluginFilePath)
		
		# Create viewport callback
		createViewportCallback(startup=True)
		createSelectionCallback(startup=True)
	
	# Load all AETemplates files in directory
	AEtemplateDirPath = os.path.join(ROOT_DIR, "AETemplates")
	if os.path.isdir(AEtemplateDirPath):
		AEtemplateFiles = glob("{0}/*.mel".format(AEtemplateDirPath))
		if AEtemplateFiles:
			sourcedFile = 0
			for file in AEtemplateFiles:
				# Check if file has already been sourced
				try:
					fileName = os.path.basename(file)
					cmdName = next(iter(os.path.splitext(fileName)))
					if mel.eval("int $NDB_MelCmdExists = `exists {0}`;".format(cmdName)):
						continue
				except Exception as e:
					pass

				mel.eval('source "{0}";'.format(file.replace(os.sep, "/")))
				sourcedFile += 1
			
			# Refresh attribute editor
			if sourcedFile:
				mel.eval("refreshEditorTemplates;refreshAE;")

def unloadPlugin():
	pluginName, pluginDirPath, pluginFilePath = getPluginPath()
	if pluginDirPath and pluginFilePath:
		# Unload plugin
		if cmds.pluginInfo(pluginFilePath, query=True, loaded=True):
			cmds.unloadPlugin(pluginName, force=True)
		
		# Create viewport callback
		removeViewportCallback()
		removeSelectionCallback()

def getShortName(objectSel):
	return objectSel.split("|")[-1]

def getCurrentSel(*args, **kwargs):
	objects = None
	allParents = False
	allDescendents = False

	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
		elif i == 1:
			allParents = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "allParents" or key == "ap":
			allParents = value
		elif key == "allDescendents" or key == "ad":
			allDescendents = True

	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	if not allDescendents:
		objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	else:
		objectShapes = cmds.ls(cmds.listRelatives(allDescendents=True, fullPath=True, typ="mesh"), long=True, noIntermediate=True)
	if not allParents:
		objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	else:
		objects = cmds.listRelatives(objectShapes, f=True, ap=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects

def safeConnect(plugSource, plugTarget, **kwargs):
	try:
		if not cmds.isConnected(plugSource, plugTarget):
			cmds.connectAttr(plugSource, plugTarget, **kwargs)
	except Exception as e:
		logging.exception(e)

def createDynamicBevelNode():
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return (None, None, None)

	dynamicBevelNode = None
	polyBevelNode = None
	bevelPreviewShape = None

	pluginFilePath = getPluginPath()[2]
	if pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True):

		# Create nodes
		bevelPreview = cmds.createNode("transform", skipSelect=True, name="bevelPreview#")
		bevelPreviewShape = cmds.createNode("gtBevelPreview", skipSelect=True, parent=bevelPreview, name="bevelPreviewShape#")
		weightedNormalsShape = cmds.createNode("mesh", skipSelect=True, parent=bevelPreview, name="weightedNormalsShape#")
		weightedBevelShape = cmds.createNode("mesh", skipSelect=True, parent=bevelPreview, name="weightedBevelShape#")
		weightedBevelNode = cmds.createNode("polyBevel3", skipSelect=True, name="weightedBevel#")
		polyBevelNode = cmds.createNode("polyBevel3", skipSelect=True, name="polyBevel#")
		getHardEdgesNode = cmds.createNode("gtGetHardEdges", skipSelect=True)
		dynamicBevelNode = cmds.createNode("gtDynamicBevel", skipSelect=True)
		transformGeometry = cmds.createNode("transformGeometry", skipSelect=True)
		networkNode = cmds.createNode("network", skipSelect=True)

		# Connect nodes
		# Intermediate Shapes inMesh connections are locked to prevent Maya from randomly modifying the connections
		# Must turn off undos temporarily otherwise the locked connections prevents from undoing the command
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		try:
			cmds.connectAttr(bevelPreviewShape+".outMesh", weightedNormalsShape+".inMesh", lock=True) 
			cmds.connectAttr(polyBevelNode+".output", bevelPreviewShape+".inMesh")
			cmds.connectAttr(polyBevelNode+".angleTolerance", weightedBevelNode+".angleTolerance")
			cmds.connectAttr(polyBevelNode+".chamfer", weightedBevelNode+".chamfer")
			cmds.connectAttr(polyBevelNode+".depth", weightedBevelNode+".depth")
			cmds.connectAttr(polyBevelNode+".forceParallel", weightedBevelNode+".forceParallel")
			cmds.connectAttr(polyBevelNode+".miterAlong", weightedBevelNode+".miterAlong")
			cmds.connectAttr(polyBevelNode+".mitering", weightedBevelNode+".mitering")
			cmds.connectAttr(polyBevelNode+".segments", weightedBevelNode+".segments")
			cmds.connectAttr(polyBevelNode+".subdivideNgons", weightedBevelNode+".subdivideNgons")
			cmds.connectAttr(polyBevelNode+".smoothingAngle", weightedBevelNode+".smoothingAngle")
			cmds.connectAttr(polyBevelNode+".roundness", weightedBevelNode+".roundness")
			cmds.connectAttr(polyBevelNode+".autoFit", weightedBevelNode+".autoFit")
			cmds.connectAttr(polyBevelNode+".mergeVertexTolerance", weightedBevelNode+".mergeVertexTolerance")
			cmds.connectAttr(weightedBevelShape+".outMesh", bevelPreviewShape+".sourceMesh")
			cmds.connectAttr(weightedBevelNode+".output", weightedBevelShape+".inMesh", lock=True)
			cmds.connectAttr(getHardEdgesNode+".componentList", polyBevelNode+".inputComponents")
			cmds.connectAttr(getHardEdgesNode+".componentList", weightedBevelNode+".inputComponents")
			cmds.connectAttr(dynamicBevelNode+".output", transformGeometry+".inputGeometry")
			cmds.connectAttr(dynamicBevelNode+".scaleMatrix", transformGeometry+".transform")
			cmds.connectAttr(dynamicBevelNode+".reverseNormals", transformGeometry+".reverseNormals")
			cmds.connectAttr(dynamicBevelNode+".outputMatrix", polyBevelNode+".manipMatrix")
			cmds.connectAttr(dynamicBevelNode+".outputMatrix", weightedBevelNode+".manipMatrix")
			cmds.connectAttr(dynamicBevelNode+".outputTranslate", bevelPreview+".translate")
			cmds.connectAttr(dynamicBevelNode+".outputRotate", bevelPreview+".rotate")
			cmds.connectAttr(dynamicBevelNode+".outputScale", bevelPreview+".scale")
			cmds.connectAttr(dynamicBevelNode+".outputShear", bevelPreview+".shear")
			cmds.connectAttr(transformGeometry+".outputGeometry", getHardEdgesNode+".inMesh")
			cmds.connectAttr(transformGeometry+".outputGeometry", polyBevelNode+".inputPolymesh")
			cmds.connectAttr(transformGeometry+".outputGeometry", weightedBevelNode+".inputPolymesh")
			cmds.connectAttr(networkNode+".affects[0]", dynamicBevelNode+".keepNodeAlive")
		except Exception as e:
			logging.exception(e)
		finally:
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)

		# Create bevel attributes dictionary
		bevelAttributes = {"polyBevelOffsetAsFraction": {"attr": ".offsetAsFraction", "invert": True, "value": 1}, 
						"polyBevelOffsetWorld": {"attr": ".worldSpace", "invert": True, "value": 0}, 
						"polyBevelOffset": {"attr": ".offset", "value": 1}, 
						"polyBevelFraction": {"attr": ".fraction", "value": 0.5}, 
						"polyBevelDepth": {"attr": ".depth", "value": 1}, 
						"polyBevelSegment": {"attr": ".segments", "value": 1}, 
						"polyBevelMitering": {"attr": ".mitering", "value": 1}, 
						"polyBevelMiterAlong": {"attr": ".miterAlong", "value": 0}, 
						"polyBevelChamfer": {"attr": ".chamfer", "value": 1}, 
						"polyBevelAutofit": {"attr": ".autoFit", "value": 1}, 
						"polyBevelForceParallel": {"attr": ".forceParallel", "value": 0}, 
						"polyBevelSmoothingAngle": {"attr": ".smoothingAngle", "value": 60}, 
						"polyBevelRound": {"attr": ".roundness", "value": 0.5},
						"polyBevelAngleTolerance": {"attr": ".angleTolerance", "value": 180}, 
						"polyBevelMergeVertexTolerance": {"attr": ".mergeVertexTolerance", "value": 0}, 
						"polyBevelSubdivideNgons": {"attr": ".subdivideNgons", "value": 1}}
		# Set bevel attributes values from optionVar
		for option, attribute in six.iteritems(bevelAttributes):
			# Get saved value from optionVar
			if cmds.optionVar(exists=option) is True:
				if isinstance(cmds.optionVar(query=option), list):
					value = cmds.optionVar(query=option)[0]
				else:
					value = cmds.optionVar(query=option)
				if "invert" in attribute and attribute["invert"] is True:
					value = (0 == value)
			# Get default value
			else:
				value = attribute["value"]
			# Set the value if the attribute exists
			if cmds.attributeQuery(attribute["attr"][1:], node=polyBevelNode, exists=True):
				# Force offsetAsFraction off
				if option == "polyBevelOffsetAsFraction":
					cmds.setAttr(polyBevelNode+attribute["attr"], 0)
				else:
					cmds.setAttr(polyBevelNode+attribute["attr"], value)	

		# Add attributes
		cmds.addAttr(polyBevelNode, longName="transformLink", attributeType="message", writable=True, readable=False, hidden=True)
		cmds.addAttr(dynamicBevelNode, longName="wireColorRGB", attributeType="float3", writable=True, readable=True, usedAsColor=True)
		cmds.addAttr(dynamicBevelNode, longName="wireColorR", attributeType="float", writable=True, readable=True, parent="wireColorRGB", defaultValue=cmds.getAttr(bevelPreviewShape+".wireColorR"))
		cmds.addAttr(dynamicBevelNode, longName="wireColorG", attributeType="float", writable=True, readable=True, parent="wireColorRGB", defaultValue=cmds.getAttr(bevelPreviewShape+".wireColorG"))
		cmds.addAttr(dynamicBevelNode, longName="wireColorB", attributeType="float", writable=True, readable=True, parent="wireColorRGB", defaultValue=cmds.getAttr(bevelPreviewShape+".wireColorB"))
		cmds.addAttr(dynamicBevelNode, longName="wireframeOpacity", attributeType="float", writable=True, readable=True, hidden=False, keyable=True, minValue=0, maxValue=1, defaultValue=cmds.getAttr(bevelPreviewShape+".wireframeOpacity"))
		cmds.addAttr(dynamicBevelNode, longName="realTime", attributeType="bool", writable=True, readable=True, hidden=False, keyable=True, defaultValue=cmds.getAttr(bevelPreviewShape+".realTime"))
		cmds.addAttr(dynamicBevelNode, longName="weightedNormals", attributeType="bool", writable=True, readable=True, hidden=False, keyable=True, defaultValue=cmds.getAttr(bevelPreviewShape+".weightedNormals"))

		# Connect attributes
		cmds.connectAttr(dynamicBevelNode+".wireColorRGB", bevelPreviewShape+".wireColorRGB")
		cmds.connectAttr(dynamicBevelNode+".wireframeOpacity", bevelPreviewShape+".wireframeOpacity")
		cmds.connectAttr(dynamicBevelNode+".realTime", bevelPreviewShape+".realTime")
		cmds.connectAttr(dynamicBevelNode+".weightedNormals", bevelPreviewShape+".weightedNormals")

		# Set attributes
		cmds.setAttr(bevelPreview+".inheritsTransform", False, lock=True)
		cmds.setAttr(weightedBevelNode+".worldSpace", True, lock=True)
		cmds.setAttr(weightedBevelNode+".offsetAsFraction", False, lock=True)
		cmds.setAttr(weightedBevelNode+".mergeVertices", False, lock=True)
		cmds.setAttr(weightedBevelNode+".fraction", 0)
		cmds.setAttr(weightedBevelNode+".offset", 0.001, lock=True)
		#cmds.setAttr(weightedBevelNode+".smoothingAngle", 180)
		cmds.setAttr(polyBevelNode+".mergeVertices", False, lock=True)
		cmds.setAttr(polyBevelNode+".smoothingAngle", 180)
		cmds.setAttr(weightedBevelShape+".intermediateObject", True)
		#cmds.setAttr(bevelPreviewShape+".inMesh", lock=True)
		#cmds.setAttr(bevelPreviewShape+".overrideEnabled", True)
		#cmds.setAttr(bevelPreviewShape+".overrideDisplayType", 2)
		#cmds.setAttr(dynamicBevel+".useOutlinerColor", True)
		#cmds.setAttr(dynamicBevel+".outlinerColor", *cmds.colorIndex(5, query=True))
		cmds.setAttr(weightedNormalsShape+".intermediateObject", True)
		cmds.setAttr(weightedNormalsShape+".isHistoricallyInteresting", 0)
		cmds.setAttr(weightedBevelShape+".isHistoricallyInteresting", 0)
		#cmds.setAttr(bevelPreviewShape+".isHistoricallyInteresting", 0)
		cmds.setAttr(getHardEdgesNode+".isHistoricallyInteresting", 0)
		cmds.setAttr(weightedBevelNode+".isHistoricallyInteresting", 0)
		cmds.setAttr(transformGeometry+".isHistoricallyInteresting", 0)

		#cmds.sets(bevelPreviewShape, edit=True, forceElement="initialShadingGroup")
		#hideInOutliner(bevelPreview, True)

	return (dynamicBevelNode, polyBevelNode, bevelPreviewShape)

def createDynamicBevel(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the Non-Destructive Bevel plugin first.", noContext=True)
		return
	
	# Create default args
	objects = None
	selectBevelNode = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "selectBevelNode" or key == "sbn":
			selectBevelNode = value
	
	if objects:
		if isinstance(objects, six.string_types):
			objects = [objects]
	else:
		objects = getCurrentSel()[1]
	
	objectsWithBP = getObjectsWithBevelPreview(objects)
	objects = [x for x in objects if x not in objectsWithBP.keys()]
	polyBevelNodes = []

	# Create
	if objects:
		cmds.undoInfo(openChunk=True, chunkName="createDynamicBevel")
		#cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 0))
		try:
			for obj in objects:
				objectTransform = None
				objectShape = None
				if cmds.objExists(obj):
					if cmds.objectType(obj) == "transform":
						objectTransform = obj
						objectShape = next(iter(cmds.listRelatives(obj, fullPath=True, noIntermediate=True, shapes=True) or []), None)
					elif cmds.objectType(obj) == "mesh":
						objectTransform = next(iter(cmds.listRelatives(obj, fullPath=True, parent=True) or []), None)
						objectShape = obj
					
					if objectTransform and objectShape:
						dynamicBevelNode, polyBevelNode, bevelPreviewShape = createDynamicBevelNode()
						polyBevelNodes.append(polyBevelNode)
						cmds.connectAttr(objectShape+".outMesh", dynamicBevelNode+".inputMesh")
						cmds.connectAttr(objectShape+".worldMatrix", dynamicBevelNode+".inputMatrix")
						cmds.connectAttr(objectShape+".intermediateObject", dynamicBevelNode+".intermediateObject")
						cmds.connectAttr(objectTransform+".message", dynamicBevelNode+".transformLink")
						cmds.connectAttr(objectTransform+".message", polyBevelNode+".transformLink")
						#cmds.connectAttr(objectTransform+".message", bevelPreviewShape+".transformLink")

						# Assign material
						materialsDict = getMainMaterial(objectTransform)
						if objectTransform in materialsDict:
							shadingGroup = materialsDict[objectTransform]
							cmds.sets(bevelPreviewShape, edit=True, forceElement=shadingGroup)

			if polyBevelNodes:
				# deselect polyBase and select polyBevels
				cmds.select(cmds.ls(selection=True, long=True, type="polyBase"), deselect=True)
				if selectBevelNode:
					cmds.select(polyBevelNodes, add=True)
					cmds.setToolTo("ShowManips")
		except Exception as e:
			logging.exception(e)
		finally:
			#cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))
			cmds.undoInfo(closeChunk=True)
		# refresh menus
		updateExistingMenus()

	# Recompute
	if objectsWithBP:
		for BP_dict in six.itervalues(objectsWithBP):
			if "dependencyNode" in BP_dict:
				forceComputePlug = BP_dict["dependencyNode"].findPlug("forceCompute", False)
				forceComputePlug.setBool(not forceComputePlug.asBool())

def deleteDynamicBevel(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the Non-Destructive Bevel plugin first.", noContext=True)
		return
	
	# Create default args
	objects = None
	clear = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "clear" or key == "c":
			clear = True
	
	objectsWithBP = {}
	selectedBevelPreview = []
	if clear:
		objects = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		bevelPreview = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
		bevelPreview = cmds.listRelatives(bevelPreview, fullPath=True, parent=True, type="transform")
		if bevelPreview:
			for bp in bevelPreview:
				objectsWithBP[bp] = {"name": bp}
	elif objects:
		if isinstance(objects, six.string_types):
			objects = [objects]
	else:
		objects = getCurrentSel()[1]
	
	if not clear:
		objectsWithBP = getObjectsWithBevelPreview(objects)
		bevelPreviewShapes = [x["name"] for x in objectsWithBP.values()]
		selectedBevelPreview = [x for x in cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview") if x not in bevelPreviewShapes]
		selectedBevelPreview = cmds.listRelatives(selectedBevelPreview, fullPath=True, parent=True)
	
	if objectsWithBP or selectedBevelPreview:
		cmds.undoInfo(openChunk=True, chunkName="deleteDynamicBevel")
		currentSel = cmds.ls(selection=True, long=True)
		try:
			for BP_dict in six.itervalues(objectsWithBP):
				if "name" in BP_dict:
					obj = None
					if cmds.objectType(BP_dict["name"]) == "gtBevelPreview":
						obj = next(iter(cmds.listRelatives(BP_dict["name"], fullPath=True, parent=True, type="transform") or []), None)
					elif cmds.objectType(BP_dict["name"]) == "transform":
						obj = BP_dict["name"]
					if obj:
						cmds.delete(obj)
			
			# Delete selected & unconnected bevelPreview
			if selectedBevelPreview:
				cmds.delete(selectedBevelPreview)

			cmds.setToolTo("selectSuperContext")
			# Restore selection
			currentSel = list(filter(cmds.objExists, currentSel))
			cmds.select(currentSel)
		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=True)
		# refresh menus
		updateExistingMenus()
		# clear doesn't update menu when undoing so we create a scriptJob
		if clear:
			clearUndoScriptJob()

class clearUndoScriptJob(object):
	def __init__(self):
		self._jobNum = cmds.scriptJob(event=("Undo", self.clearUndo), parent="MayaWindow", protected=True)

	def clearUndo(self):
		redoName = cmds.undoInfo(query=True, redoName=True)
		
		if redoName in ["NDB_Clear", "deleteDynamicBevel"]:
			updateExistingMenus()
			if self._jobNum:
				cmds.evalDeferred(partial(cmds.scriptJob, kill=self._jobNum, force=True))

def bakeDynamicBevel(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the Non-Destructive Bevel plugin first.", noContext=True)
		return
	
	# Create default args
	objects = None
	bakeAll = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "bakeAll" or key == "ba":
			bakeAll = True
	
	currentSel = getCurrentSel()[1]

	if bakeAll:
		objects = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
	elif objects:
		if isinstance(objects, six.string_types):
			objects = [objects]
	else:
		objects = currentSel
	
	objectsWithBP = getObjectsWithBevelPreview(objects)
	currentBP = [v["name"] for v in objectsWithBP.values() if "name" in v]
	currentBP = [x for x in cmds.ls(selection=not bakeAll, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview") if x not in currentBP]
	if objectsWithBP or currentBP:
		cmds.undoInfo(openChunk=True, chunkName="bakeDynamicBevel")
		try:
			# Bake objectsWithBP
			for objName, BP_dict in six.iteritems(objectsWithBP):
				bevelShapeName = None
				# Bake bevelPreviewShape
				if "dependencyNode" in BP_dict:
					outMeshPlug = BP_dict["dependencyNode"].findPlug("outMesh", False)
					outMeshPlugArray = outMeshPlug.connectedTo(False, True)
					if len(outMeshPlugArray) > 0:
						outputMObject = outMeshPlugArray[0].node()
						if outputMObject.hasFn(om.MFn.kMesh):
							# Delete object's history and shape
							cmds.delete(objName, constructionHistory=True)
							shapeName = next(iter(cmds.listRelatives(objName, fullPath=True, noIntermediate=True, shapes=True) or []), None)
							# Parent intermediate shape to object
							meshDagPath = om.MDagPath.getAPathTo(outputMObject)
							bevelShapeName = next(iter(cmds.ls(cmds.parent(meshDagPath.fullPathName(), objName, absolute=True, shape=True), long=True)), None)
				# Delete bevelPreview nodes
				if "name" in BP_dict:
					obj = None
					if cmds.objectType(BP_dict["name"]) == "gtBevelPreview":
						obj = next(iter(cmds.listRelatives(BP_dict["name"], fullPath=True, parent=True, type="transform") or []), None)
					elif cmds.objectType(BP_dict["name"]) == "transform":
						obj = BP_dict["name"]
					if obj:
						cmds.delete(obj)
				# Transfer shading to intermediate shape
				if bevelShapeName:
					#cmds.sets(bevelShapeName, edit=True, forceElement="initialShadingGroup")
					cmds.transferShadingSets(objName, bevelShapeName, sampleSpace=0, searchMethod=3)
					cmds.setAttr(bevelShapeName+".intermediateObject", False)
					if shapeName:
						cmds.delete(shapeName)
					cmds.rename(bevelShapeName, getShortName(shapeName))
			# Bake bevelPreview
			selList = om.MSelectionList()
			for x in currentBP:
				selList.add(x)
			for each in range(selList.length()):
				bevelShapeName = None
				dagPath = selList.getDagPath(each)
				dagParent = next(iter(cmds.listRelatives(dagPath.fullPathName(), fullPath=True, parent=True, type="transform") or []), None)
				dependencyNode = om.MFnDependencyNode(dagPath.node())
				outMeshPlug = dependencyNode.findPlug("outMesh", False)
				outMeshPlugArray = outMeshPlug.connectedTo(False, True)
				if len(outMeshPlugArray) > 0:
					outputMObject = outMeshPlugArray[0].node()
					if outputMObject.hasFn(om.MFn.kMesh):
						# Create new transform
						bevelTransformName = cmds.createNode("transform", skipSelect=True)
						# If parent exists, match matrix
						if dagParent:
							cmds.xform(bevelTransformName, matrix=cmds.xform(dagParent, query=True, matrix=True, worldSpace=True), worldSpace=True)
						# Parent intermediate shape to new transform
						meshDagPath = om.MDagPath.getAPathTo(outputMObject)
						bevelShapeName = next(iter(cmds.ls(cmds.parent(meshDagPath.fullPathName(), bevelTransformName, absolute=True, shape=True), long=True)), None)
				# Delete bevelPreview nodes
				if dagParent:
					cmds.delete(dagParent)
				else:
					cmds.delete(dagPath.fullPathName())
				# Transfer shading to intermediate shape
				if bevelShapeName:
					cmds.setAttr(bevelShapeName+".intermediateObject", False)
					bevelShapeName = cmds.rename(bevelShapeName, "polySurfaceShape#")
					cmds.sets(bevelShapeName, edit=True, forceElement="initialShadingGroup")

			# Restore selection
			currentSel = list(filter(cmds.objExists, currentSel))
			cmds.select(currentSel)
		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=True)
		# refresh menus
		updateExistingMenus()

def convertDynamicBevel(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the Non-Destructive Bevel plugin first.", noContext=True)
		return

	if not callable(NT_SmartBevel):
		#cmds.warning("You need the Normal Toolkit to use this function.", noContext=True)
		bakeDynamicBevel(*args, **kwargs)
		return
	
	# Create default args
	objects = None
	bakeAll = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "bakeAll" or key == "ba":
			bakeAll = True
	
	currentSel = getCurrentSel()[1]

	if bakeAll:
		objects = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
	elif objects:
		if isinstance(objects, six.string_types):
			objects = [objects]
	else:
		objects = currentSel
	
	objectsWithBP = getObjectsWithBevelPreview(objects)
	currentBP = [v["name"] for v in objectsWithBP.values() if "name" in v]
	currentBP = [x for x in cmds.ls(selection=not bakeAll, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview") if x not in currentBP]
	if objectsWithBP:
		cmds.undoInfo(openChunk=True, chunkName="convertDynamicBevel")
		try:
			# Bake objectsWithBP
			for objName, BP_dict in six.iteritems(objectsWithBP):
				# Bake bevelPreviewShape
				if "dependencyNode" in BP_dict:
					inMeshPlug = BP_dict["dependencyNode"].findPlug("inMesh", False)
					inMeshPlugArray = inMeshPlug.connectedTo(True, False)
					if len(inMeshPlugArray) > 0:
						inMeshMObject = inMeshPlugArray[0].node()

						if inMeshMObject.apiType() in [om.MFn.kPolyBevel, om.MFn.kPolyBevel2, om.MFn.kPolyBevel3]:
							polyBevelNode = inMeshPlugArray[0].name().split(".")[0]

							# Get polyBevel attributes
							_polyBevelDict = {}
							attributeList = cmds.listAttr(polyBevelNode, write=True, settable=True, keyable=True)
							for attr in attributeList:
								_polyBevelDict[attr] = cmds.getAttr(polyBevelNode+"."+attr)
							
							# Get beveled edges
							beveledEdges = [objName+"."+x for x in cmds.getAttr(polyBevelNode+".inputComponents")]

							# Delete bevelPreview nodes
							if "name" in BP_dict:
								obj = None
								if cmds.objectType(BP_dict["name"]) == "gtBevelPreview":
									obj = next(iter(cmds.listRelatives(BP_dict["name"], fullPath=True, parent=True, type="transform") or []), None)
								elif cmds.objectType(BP_dict["name"]) == "transform":
									obj = BP_dict["name"]
								if obj:
									cmds.delete(obj)

							# Delete history
							cmds.delete(objName, constructionHistory=True)

							# makeIdentity that does nothing... but it prevents inverted bevels with negative scaled objects
							cmds.makeIdentity(objName, apply=True, translate=False, rotate=False, scale=False, normal=False, preserveNormals=True)

							# Create Smart Bevel
							NT_SmartBevel(beveledEdges, weightedNormals=True, selectBevelFaces=False, addToSelectionSet=True, **_polyBevelDict)

							# If no materials found, assign initialShadingGroup
							objShape = next(iter(cmds.listRelatives(objName, fullPath=True, noIntermediate=True, shapes=True) or []), None)
							if objShape and not cmds.listConnections(objShape, type="shadingEngine"):
								cmds.sets(objShape, edit=True, forceElement="initialShadingGroup")
							
			# Restore selection
			#cmds.select(cmds.ls(selection=True, long=True, type="polyBase"), deselect=True)
			cmds.select(currentSel)
		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=True)
		# refresh menus
		updateExistingMenus()
	
	if currentBP:
		bakeDynamicBevel(currentBP)

def bakeConvertDynamicBevel(*args, **kwargs):
	value = setBakeOption()
	if value:
		convertDynamicBevel(*args, **kwargs)
	else:
		bakeDynamicBevel(*args, **kwargs)

def reconnectDynamicBevel(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the Non-Destructive Bevel plugin first.", noContext=True)
		return
	
	# Create default args
	objects = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
	
	if objects:
		if isinstance(objects, six.string_types):
			objects = [objects]
	else:
		objects = getCurrentSel()[1]

	if not objects:
		cmds.warning("Cannot reconnect bevel, no object is selected.", noContext=True)
		return
	
	objectsWithBP = getObjectsWithBevelPreview(objects)
	unconnectedBP = getUnconnectedBevelPreview()
	objects = [x for x in objects if x not in objectsWithBP.keys()]

	if objects and unconnectedBP:
		cmds.undoInfo(openChunk=True, chunkName="reconnectDynamicBevel")
		try:
			for i, v in enumerate(unconnectedBP.values()):
				if i >= len(objects):
					break
				
				objectTransform = objects[i]
				objShape = next(iter(cmds.listRelatives(objectTransform, fullPath=True, shapes=True, noIntermediate=True) or []), None)
				if objShape:
					safeConnect(objShape+".outMesh", v["dynamicBevelNode"]+".inputMesh", force=True)
					safeConnect(objShape+".worldMatrix", v["dynamicBevelNode"]+".inputMatrix", force=True)
					safeConnect(objShape+".intermediateObject", v["dynamicBevelNode"]+".intermediateObject", force=True)
					safeConnect(objectTransform+".message", v["dynamicBevelNode"]+".transformLink", force=True)
					safeConnect(objectTransform+".message", v["polyBevelNode"]+".transformLink", force=True)

					# Assign material
					materialsDict = getMainMaterial(objectTransform)
					if objectTransform in materialsDict:
						shadingGroup = materialsDict[objectTransform]
						bevelPreviewShape = dynamicBevelToBevelPreview(v["dynamicBevelNode"])
						cmds.sets(bevelPreviewShape, edit=True, forceElement=shadingGroup)

		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=True)
		# refresh menus
		updateExistingMenus()
	
	elif objects and objectsWithBP:
		cmds.undoInfo(openChunk=True, chunkName="reconnectDynamicBevel")
		try:
			for i, v in enumerate(objectsWithBP.values()):
				if i >= len(objects):
					break

				dynamicBevelNode = None
				polyBevelNode = None

				dependencyNode = v["dependencyNode"]
				inMeshPlug = dependencyNode.findPlug("inMesh", False)
				dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
				while not dependencyGraph.isDone():
					currentItem = dependencyGraph.currentNode()
					currentDependencyNode = om.MFnDependencyNode(currentItem)
					if currentDependencyNode.typeName == "gtDynamicBevel":
						dynamicBevelNode = currentDependencyNode.name()
						if polyBevelNode:
							break
					
					if currentDependencyNode.typeName in ["polyBevel", "polyBevel2", "polyBevel3"]:
						polyBevelNode = currentDependencyNode.name()
						if dynamicBevelNode:
							break

					dependencyGraph.next()

				objectTransform = objects[i]
				objShape = next(iter(cmds.listRelatives(objectTransform, fullPath=True, shapes=True, noIntermediate=True) or []), None)
				if objShape:
					safeConnect(objShape+".outMesh", dynamicBevelNode+".inputMesh", force=True)
					safeConnect(objShape+".worldMatrix", dynamicBevelNode+".inputMatrix", force=True)
					safeConnect(objShape+".intermediateObject", dynamicBevelNode+".intermediateObject", force=True)
					safeConnect(objectTransform+".message", dynamicBevelNode+".transformLink", force=True)
					safeConnect(objectTransform+".message", polyBevelNode+".transformLink", force=True)

					# Assign material
					materialsDict = getMainMaterial(objectTransform)
					if objectTransform in materialsDict:
						shadingGroup = materialsDict[objectTransform]
						bevelPreviewShape = dynamicBevelToBevelPreview(dynamicBevelNode)
						cmds.sets(bevelPreviewShape, edit=True, forceElement=shadingGroup)

		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=True)

def editDynamicBevel(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the Non-Destructive Bevel plugin first.", noContext=True)
		return
	
	# Create default args
	objects = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
	
	currentSel = getCurrentSel()[1]

	if objects:
		if isinstance(objects, six.string_types):
			objects = [objects]
	else:
		objects = currentSel	
	
	bevelNodes = getObjectsPreviewBevelNodes(objects)
	if bevelNodes:
		cmds.undoInfo(openChunk=True, chunkName="editDynamicBevel")
		try:
			cmds.select(bevelNodes, add=True)
			cmds.setToolTo("ShowManips")

			pieMenu = BevelPreviewPieMenu.getPieMenu()
			if pieMenu and pieMenu.isVisible():
				pieMenu.setVisibility(False)
		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=True)

def transferBevelSettings(*args, **kwargs):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		cmds.warning("You need to load the Non-Destructive Bevel plugin first.", noContext=True)
		return
	
	# Create default args
	objects = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
	
	currentSel = getCurrentSel()[1]

	if objects:
		if isinstance(objects, six.string_types):
			objects = [objects]
	else:
		objects = currentSel	
	
	bevelNodes = getObjectsPreviewBevelNodes(objects)
	if bevelNodes and len(bevelNodes) > 1:
		cmds.undoInfo(openChunk=True, chunkName="transferBevelSettings")
		try:
			_polyBevelDict = {}
			attributeList = cmds.listAttr(bevelNodes[0], write=True, settable=True, keyable=True)
			for attr in attributeList:
				_polyBevelDict[attr] = cmds.getAttr(bevelNodes[0]+"."+attr)
			
			for bNode in bevelNodes[1:]:
				for attr in attributeList:
					if cmds.attributeQuery(attr, node=bNode, exists=True) and cmds.getAttr(bNode+"."+attr) != _polyBevelDict[attr]:
						cmds.setAttr(bNode+"."+attr, _polyBevelDict[attr])
		except Exception as e:
			logging.exception(e)
		finally:
			cmds.undoInfo(closeChunk=True)

def toggleDynamicBevelSettings(settingName=""):
	pluginFilePath = getPluginPath()[2]
	if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		return

	# Set menu controls value
	settingsDict = getBevelPreviewSelectionSettings()[0]
	if settingsDict and isinstance(settingsDict, dict):
		if settingName == "visibility" and "visibility" in settingsDict:
			setBevelPreviewSettings(settingsDict={"visibility": not settingsDict["visibility"], "cageDisplay": settingsDict["cageDisplay"]})
		elif settingName == "xRay" and "xRay" in settingsDict:
			setBevelPreviewSettings(settingsDict={"xRay": not settingsDict["xRay"]})
		elif settingName == "shading" and "shading" in settingsDict:
			setBevelPreviewSettings(settingsDict={"shading": not settingsDict["shading"]})
		elif settingName == "weightedNormals" and "weightedNormals" in settingsDict:
			setBevelPreviewSettings(settingsDict={"weightedNormals": not settingsDict["weightedNormals"]})
		elif settingName == "realTime" and "realTime" in settingsDict:
			setBevelPreviewSettings(settingsDict={"realTime": not settingsDict["realTime"]})

def dynamicBevelToBevelPreview(dynamicBevel):
	if dynamicBevel and cmds.objectType(dynamicBevel) == "gtDynamicBevel":
		selList = om.MSelectionList()
		selList.add(dynamicBevel)

		dynamicBevelObj = selList.getDependNode(0)
		dependencyNode = om.MFnDependencyNode(dynamicBevelObj)
		outMeshPlug = dependencyNode.findPlug("output", False)
		dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
		while not dependencyGraph.isDone():
			currentItem = dependencyGraph.currentNode()
			currentDependencyNode = om.MFnDependencyNode(currentItem)
			if currentDependencyNode.typeName == "gtBevelPreview":
				targetDag = om.MDagPath.getAPathTo(currentItem)
				targetDag.pop()
				return targetDag.fullPathName()

			dependencyGraph.next()
	
	return None

@make_undoable
def getUnconnectedBevelPreview(objects=None):
	unconnectedBevels = defaultdict(dict)

	if objects:
		bevelPreviewShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	else:
		bevelPreviewShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	if not bevelPreviewShapes:
		bevelPreviewShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")

	if bevelPreviewShapes:
		selList = om.MSelectionList()
		for x in bevelPreviewShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			inMeshPlug = dependencyNode.findPlug("inMesh", False)

			inMeshPlugArray = inMeshPlug.connectedTo(True, False)
			for p in inMeshPlugArray:
				dNode = om.MFnDependencyNode(p.node())
				if dNode.typeName in ["polyBevel", "polyBevel2", "polyBevel3"]:
					# Add polyBevel node to dict
					unconnectedBevels[dagPath.fullPathName()]["polyBevelNode"] = dNode.name()
					break

			dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtDynamicBevel":
					# add dynamicBevel node to dict
					unconnectedBevels[dagPath.fullPathName()]["dynamicBevelNode"] = currentDependencyNode.name()

					inputMeshPlug = currentDependencyNode.findPlug("inputMesh", False)
					inputPlugArray = inputMeshPlug.connectedTo(True, False)
					for p in inputPlugArray:
						dNode = om.MFnDependencyNode(p.node())
						if dNode.typeName == "mesh":
							# ??? whats the use for this if using previous dagPath?
							if dagPath.fullPathName() in unconnectedBevels:
								del unconnectedBevels[dagPath.fullPathName()]
							break
					
					break

				dependencyGraph.next()
			
			# Keep in dictionary only if both dynamicBevelNode and polyBevel are found
			if dagPath.fullPathName() in unconnectedBevels:
				if not ("dynamicBevelNode" in unconnectedBevels[dagPath.fullPathName()] and "polyBevelNode" in unconnectedBevels[dagPath.fullPathName()]):
					del unconnectedBevels[dagPath.fullPathName()]

	return unconnectedBevels

@make_undoable
def getObjectsPreviewBevelNodes(objects=None, searchAll=False):
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return []
	
	polyBevelNodes = []

	if objects:
		selectedShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	else:
		selectedShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")

	if not selectedShapes and not selectedBevelPreview:
		if searchAll:
			selectedShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
			selectedBevelPreview = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
		else:
			return polyBevelNodes
	
	if selectedShapes:
		selList = om.MSelectionList()
		for x in selectedShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			outMeshPlug = dependencyNode.findPlug("outMesh", False)
			dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtBevelPreview":
					
					inputMeshPlug = currentDependencyNode.findPlug("inMesh", False)
					inputPlugArray = inputMeshPlug.connectedTo(True, False)
					for p in inputPlugArray:
						dNode = om.MFnDependencyNode(p.node())
						if dNode.typeName in ["polyBevel", "polyBevel2", "polyBevel3"]:
							polyBevelNodes.append(dNode.name())
							break

					# remove from selectedBevelPreview list to avoid processing twice
					bevelPreviewDagPath = om.MDagPath.getAPathTo(currentItem)
					if bevelPreviewDagPath.fullPathName() in selectedBevelPreview:
						selectedBevelPreview.remove(bevelPreviewDagPath.fullPathName())
					
					break

				dependencyGraph.next()
	
	if selectedBevelPreview:
		selList = om.MSelectionList()
		for x in selectedBevelPreview:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())

			inMeshPlug = dependencyNode.findPlug("inMesh", False)
			dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName in ["polyBevel", "polyBevel2", "polyBevel3"]:
					polyBevelNodes.append(currentDependencyNode.name())

					break

				dependencyGraph.next()
	
	return polyBevelNodes

@make_undoable
def getBevelPreviewSelectionSettings(objects=None):
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return {}, []

	settingsDict = {}

	if objects:
		selectedShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type=["mesh", "gtBevelPreview"], tail=1)
	else:
		selectedShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type=["mesh", "gtBevelPreview"], tail=1)
	if not selectedShapes:
		selectedShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type=["mesh", "gtBevelPreview"], tail=1)
	
	if not selectedShapes:
		return settingsDict, []

	if cmds.objectType(selectedShapes) == "mesh":
		selList = om.MSelectionList()
		for x in selectedShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			outMeshPlug = dependencyNode.findPlug("outMesh", False)
			dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtBevelPreview":

					#visibilityPlug = currentDependencyNode.findPlug("visibility", False)
					#lodVisibilityPlug = currentDependencyNode.findPlug("lodVisibility", False)
					realTimePlug = currentDependencyNode.findPlug("realTime", False)
					weightedNormalsPlug = currentDependencyNode.findPlug("weightedNormals", False)
					wireframeOpacityPlug = currentDependencyNode.findPlug("wireframeOpacity", False)
					wireframeColorPlug = currentDependencyNode.findPlug("wireColorRGB", False)

					'''if not visibilityPlug.asBool() or not lodVisibilityPlug.asBool():
						settingsDict["visibility"] = False
					else:
						settingsDict["visibility"] = True'''
					
					settingsDict["realTime"] = realTimePlug.asBool()
					settingsDict["weightedNormals"] = weightedNormalsPlug.asBool()
					settingsDict["wireframeOpacity"] = wireframeOpacityPlug.asFloat()
					settingsDict["wireframeColor"] = wireframeColorPlug.asMDataHandle().asFloat3()

					inMeshPlug = currentDependencyNode.findPlug("inMesh", False)
					inMeshPlugArray = inMeshPlug.connectedTo(True, False)
					if len(inMeshPlugArray) > 0:
						inMeshMObject = inMeshPlugArray[0].node()
						if inMeshMObject.apiType() in [om.MFn.kPolyBevel, om.MFn.kPolyBevel2, om.MFn.kPolyBevel3]:
							dNode = om.MFnDependencyNode(inMeshMObject)
							offsetPlug = dNode.findPlug("offset", False)
							settingsDict["offset"] = offsetPlug.asFloat()

				elif currentDependencyNode.typeName == "gtDynamicBevel":
					enableBevelDisplayPlug = currentDependencyNode.findPlug("enableBevelDisplay", False)
					xRayPlug = currentDependencyNode.findPlug("enableXRay", False)
					shadingPlug = currentDependencyNode.findPlug("enableShading", False)

					settingsDict["visibility"] = enableBevelDisplayPlug.asBool()
					settingsDict["xRay"] = xRayPlug.asBool()
					settingsDict["shading"] = shadingPlug.asBool()

				dependencyGraph.next()
	
	elif cmds.objectType(selectedShapes) == "gtBevelPreview":
		selList = om.MSelectionList()
		for x in selectedShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())

			#visibilityPlug = dependencyNode.findPlug("visibility", False)
			#lodVisibilityPlug = dependencyNode.findPlug("lodVisibility", False)
			realTimePlug = dependencyNode.findPlug("realTime", False)
			weightedNormalsPlug = dependencyNode.findPlug("weightedNormals", False)
			wireframeOpacityPlug = dependencyNode.findPlug("wireframeOpacity", False)
			wireframeColorPlug = dependencyNode.findPlug("wireColorRGB", False)

			'''if not visibilityPlug.asBool() or not lodVisibilityPlug.asBool():
				settingsDict["visibility"] = False
			else:
				settingsDict["visibility"] = True'''
	
			settingsDict["realTime"] = realTimePlug.asBool()
			settingsDict["weightedNormals"] = weightedNormalsPlug.asBool()
			settingsDict["wireframeOpacity"] = wireframeOpacityPlug.asFloat()
			settingsDict["wireframeColor"] = wireframeColorPlug.asMDataHandle().asFloat3()
			
			inMeshPlug = dependencyNode.findPlug("inMesh", False)
			dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtDynamicBevel":
					enableBevelDisplayPlug = currentDependencyNode.findPlug("enableBevelDisplay", False)
					xRayPlug = currentDependencyNode.findPlug("enableXRay", False)
					shadingPlug = currentDependencyNode.findPlug("enableShading", False)

					settingsDict["visibility"] = enableBevelDisplayPlug.asBool()
					settingsDict["xRay"] = xRayPlug.asBool()
					settingsDict["shading"] = shadingPlug.asBool()

					if "offset" in settingsDict:
						break

				if currentDependencyNode.typeName in ["polyBevel", "polyBevel2", "polyBevel3"]:
					offsetPlug = currentDependencyNode.findPlug("offset", False)

					settingsDict["offset"] = offsetPlug.asFloat()

					if all(k in settingsDict for k in ["xRay", "shading"]):
						break

				dependencyGraph.next()
	
	if not settingsDict:
		selectedShapes = []

	return settingsDict, selectedShapes

def setBevelPreviewSettings(objects=None, settingsDict={}, pieMenuCallback=False):
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return
	
	if not (settingsDict and isinstance(settingsDict, dict)):
		return

	if objects:
		selectedShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	else:
		#selectedShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		#selectedBevelPreview = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
		selectedShapes = list(getObjectsWithBevelPreview(searchAll=True).keys())
		selectedShapes = cmds.ls(selectedShapes, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = []
	
	if not selectedShapes and not selectedBevelPreview:
		#selectedShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		#selectedBevelPreview = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
		selectedShapes = list(getObjectsWithBevelPreview().keys())
		selectedShapes = cmds.ls(selectedShapes, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = []

	if selectedShapes:
		selList = om.MSelectionList()
		for x in selectedShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			outMeshPlug = dependencyNode.findPlug("outMesh", False)
			dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				plugDict = {}
				if currentDependencyNode.typeName == "gtBevelPreview":
					for attr in ["weightedNormals", "realTime", "wireframeOpacity", "wireColorRGB"]:	
						if attr not in plugDict and currentDependencyNode.hasAttribute(attr):
							p = currentDependencyNode.findPlug(attr, False)
							if p.isFreeToChange() == om.MPlug.kFreeToChange:
								plugDict[attr] = p
							elif p.isConnected and p.isDestination:
								p = p.source()
								if p.isFreeToChange() == om.MPlug.kFreeToChange:
									plugDict[attr] = p

					if "weightedNormals" in settingsDict and "weightedNormals" in plugDict:
						plugDict["weightedNormals"].setBool(settingsDict["weightedNormals"])
					if "realTime" in settingsDict and "realTime" in plugDict:
						plugDict["realTime"].setBool(settingsDict["realTime"])
					if "wireframeOpacity" in settingsDict and "wireframeOpacity" in plugDict:
						plugDict["wireframeOpacity"].setFloat(settingsDict["wireframeOpacity"])
					if "wireframeColor" in settingsDict and "wireColorRGB" in plugDict:
						dataHandle = plugDict["wireColorRGB"].asMDataHandle().set3Float(*settingsDict["wireframeColor"])
						plugDict["wireColorRGB"].setMDataHandle(dataHandle)

					'''visibilityPlug = currentDependencyNode.findPlug("visibility", False)
					lodVisibilityPlug = currentDependencyNode.findPlug("lodVisibility", False)
					
					if "visibility" in settingsDict:
						visibilityPlug.setBool(settingsDict["visibility"])
						lodVisibilityPlug.setBool(settingsDict["visibility"])

						# When "Enable Bevel Display" is turned off while in Component Mode, make sure xRay is disabled
						if not settingsDict["visibility"]:
							if next(iter(cmds.displaySurface(dagPath.fullPathName(), query=True, xRay=True) or [])):
								#setDisplaySurface(dNodeDagPath.fullPathName(), xRay=False)
								cmds.evalDeferred(partial(setDisplaySurface, dagPath.fullPathName(), xRay=False), lowestPriority=True)'''
					
					# remove from selectedBevelPreview list to avoid processing twice
					bevelPreviewDagPath = om.MDagPath.getAPathTo(currentItem)
					if bevelPreviewDagPath.fullPathName() in selectedBevelPreview:
						selectedBevelPreview.remove(bevelPreviewDagPath.fullPathName())

				elif currentDependencyNode.typeName == "gtDynamicBevel":
					for attr in ["enableBevelDisplay", "enableXRay", "enableShading", "weightedNormals", "realTime", "wireframeOpacity", "wireColorRGB"]:
						if attr not in plugDict and currentDependencyNode.hasAttribute(attr):
							p = currentDependencyNode.findPlug(attr, False)
							if p.isFreeToChange() == om.MPlug.kFreeToChange:
								plugDict[attr] = p
							elif p.isConnected and p.isDestination:
								p = p.source()
								if p.isFreeToChange() == om.MPlug.kFreeToChange:
									plugDict[attr] = p

					if "visibility" in settingsDict and "enableBevelDisplay" in plugDict:
						plugDict["enableBevelDisplay"].setBool(settingsDict["visibility"])
					if "xRay" in settingsDict and "enableXRay" in plugDict:
						plugDict["enableXRay"].setBool(settingsDict["xRay"])
					if "shading" in settingsDict and "enableShading" in plugDict:
						plugDict["enableShading"].setBool(settingsDict["shading"])
					if "weightedNormals" in settingsDict and "weightedNormals" in plugDict:
						plugDict["weightedNormals"].setBool(settingsDict["weightedNormals"])
					if "realTime" in settingsDict and "realTime" in plugDict:
						plugDict["realTime"].setBool(settingsDict["realTime"])
					if "wireframeOpacity" in settingsDict and "wireframeOpacity" in plugDict:
						plugDict["wireframeOpacity"].setFloat(settingsDict["wireframeOpacity"])
					if "wireframeColor" in settingsDict and "wireColorRGB" in plugDict:
						dataHandle = plugDict["wireColorRGB"].asMDataHandle().set3Float(*settingsDict["wireframeColor"])
						plugDict["wireColorRGB"].setMDataHandle(dataHandle)
					
					# if "Enable Bevel Display" is off and Cage Display in "Component Mode", turn object visibility back on 
					'''if "visibility" in settingsDict and "cageDisplay" in settingsDict and settingsDict["cageDisplay"] == 3:
						inputMeshPlug = currentDependencyNode.findPlug("inputMesh", False)
						inputPlugArray = inputMeshPlug.connectedTo(True, False)
						for p in inputPlugArray:
							dNode = om.MFnDependencyNode(p.node())
							if dNode.typeName == "mesh":
								if dNode.hasAttribute("overrideVisibility"):
									dPlug = dNode.findPlug("overrideVisibility", False)
									if dPlug.asBool() == settingsDict["visibility"]:
										dNodeDagPath = om.MDagPath.getAPathTo(p.node())
										currentHl = cmds.ls(hilite=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
										xRayState = next(iter(cmds.displaySurface(dNodeDagPath.fullPathName(), query=True, xRay=True) or []))
										# If object is hilited, ignore, because it should always be visible
										if dNodeDagPath.fullPathName() not in currentHl:
											dPlug.setBool(not dPlug.asBool())
											if xRayState:
												#setDisplaySurface(dNodeDagPath.fullPathName(), xRay=False)
												cmds.evalDeferred(partial(setDisplaySurface, dNodeDagPath.fullPathName(), xRay=False), lowestPriority=True)
										# And if object is hilited, check if xRay should be turned on
										elif not xRayState and "enableXRay" in plugDict and plugDict["enableXRay"].asBool():
												#setDisplaySurface(dNodeDagPath.fullPathName(), xRay=False)
												cmds.evalDeferred(partial(setDisplaySurface, dNodeDagPath.fullPathName(), xRay=True), lowestPriority=True)'''
				
				dependencyGraph.next()
	
	if selectedBevelPreview:
		selList = om.MSelectionList()
		for x in selectedBevelPreview:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())

			plugDict = {}
			for attr in ["weightedNormals", "realTime", "wireframeOpacity", "wireColorRGB"]:	
				if attr not in plugDict and dependencyNode.hasAttribute(attr):
					p = dependencyNode.findPlug(attr, False)
					if p.isFreeToChange() == om.MPlug.kFreeToChange:
						plugDict[attr] = p
					elif p.isConnected and p.isDestination:
						p = p.source()
						if p.isFreeToChange() == om.MPlug.kFreeToChange:
							plugDict[attr] = p

			if "weightedNormals" in settingsDict and "weightedNormals" in plugDict:
				plugDict["weightedNormals"].setBool(settingsDict["weightedNormals"])
			if "realTime" in settingsDict and "realTime" in plugDict:
				plugDict["realTime"].setBool(settingsDict["realTime"])
			if "wireframeOpacity" in settingsDict and "wireframeOpacity" in plugDict:
				plugDict["wireframeOpacity"].setFloat(settingsDict["wireframeOpacity"])
			if "wireframeColor" in settingsDict and "wireColorRGB" in plugDict:
				dataHandle = plugDict["wireColorRGB"].asMDataHandle().set3Float(*settingsDict["wireframeColor"])
				plugDict["wireColorRGB"].setMDataHandle(dataHandle)

			'''visibilityPlug = dependencyNode.findPlug("visibility", False)
			lodVisibilityPlug = dependencyNode.findPlug("lodVisibility", False)

			if "visibility" in settingsDict:
				visibilityPlug.setBool(settingsDict["visibility"])
				lodVisibilityPlug.setBool(settingsDict["visibility"])

				# When "Enable Bevel Display" is turned off while in Component Mode, make sure xRay is disabled
				if not settingsDict["visibility"]:
					if next(iter(cmds.displaySurface(dagPath.fullPathName(), query=True, xRay=True) or [])):
						#setDisplaySurface(dNodeDagPath.fullPathName(), xRay=False)
						cmds.evalDeferred(partial(setDisplaySurface, dagPath.fullPathName(), xRay=False), lowestPriority=True)'''

			inMeshPlug = dependencyNode.findPlug("inMesh", False)
			dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtDynamicBevel":
					for attr in ["enableBevelDisplay", "enableXRay", "enableShading", "weightedNormals", "realTime", "wireframeOpacity", "wireColorRGB"]:
						if attr not in plugDict and currentDependencyNode.hasAttribute(attr):
							p = currentDependencyNode.findPlug(attr, False)
							if p.isFreeToChange() == om.MPlug.kFreeToChange:
								plugDict[attr] = p
							elif p.isConnected and p.isDestination:
								p = p.source()
								if p.isFreeToChange() == om.MPlug.kFreeToChange:
									plugDict[attr] = p

					if "visibility" in settingsDict and "enableBevelDisplay" in plugDict:
						plugDict["enableBevelDisplay"].setBool(settingsDict["visibility"])
					if "xRay" in settingsDict and "enableXRay" in plugDict:
						plugDict["enableXRay"].setBool(settingsDict["xRay"])
					if "shading" in settingsDict and "enableShading" in plugDict:
						plugDict["enableShading"].setBool(settingsDict["shading"])
					if "weightedNormals" in settingsDict and "weightedNormals" in plugDict:
						plugDict["weightedNormals"].setBool(settingsDict["weightedNormals"])
					if "realTime" in settingsDict and "realTime" in plugDict:
						plugDict["realTime"].setBool(settingsDict["realTime"])
					if "wireframeOpacity" in settingsDict and "wireframeOpacity" in plugDict:
						plugDict["wireframeOpacity"].setFloat(settingsDict["wireframeOpacity"])
					if "wireframeColor" in settingsDict and "wireColorRGB" in plugDict:
						dataHandle = plugDict["wireColorRGB"].asMDataHandle().set3Float(*settingsDict["wireframeColor"])
						plugDict["wireColorRGB"].setMDataHandle(dataHandle)
					
					# if "Enable Bevel Display" is off and Cage Display in "Component Mode", turn object visibility back on 
					'''if "visibility" in settingsDict and "cageDisplay" in settingsDict and settingsDict["cageDisplay"] == 3:
						inputMeshPlug = currentDependencyNode.findPlug("inputMesh", False)
						inputPlugArray = inputMeshPlug.connectedTo(True, False)
						for p in inputPlugArray:
							dNode = om.MFnDependencyNode(p.node())
							if dNode.typeName == "mesh":
								if dNode.hasAttribute("overrideVisibility"):
									dPlug = dNode.findPlug("overrideVisibility", False)
									if dPlug.asBool() == settingsDict["visibility"]:
										dNodeDagPath = om.MDagPath.getAPathTo(p.node())
										currentHl = cmds.ls(hilite=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
										xRayState = next(iter(cmds.displaySurface(dNodeDagPath.fullPathName(), query=True, xRay=True) or []))
										# If object is hilited, ignore, because it should always be visible
										if dNodeDagPath.fullPathName() not in currentHl:
											dPlug.setBool(not dPlug.asBool())
											if xRayState:
												#setDisplaySurface(dNodeDagPath.fullPathName(), xRay=False)
												cmds.evalDeferred(partial(setDisplaySurface, dNodeDagPath.fullPathName(), xRay=False), lowestPriority=True)
										# And if object is hilited, check if xRay should be turned on
										elif not xRayState and "enableXRay" in plugDict and plugDict["enableXRay"].asBool():
												#setDisplaySurface(dNodeDagPath.fullPathName(), xRay=False)
												cmds.evalDeferred(partial(setDisplaySurface, dNodeDagPath.fullPathName(), xRay=True), lowestPriority=True)'''

					break

				dependencyGraph.next()
	
	if selectedShapes or selectedBevelPreview:
		# refresh menus
		updateExistingMenus(pieMenuCallback=pieMenuCallback)

def setPolyBevelSettings(objects=None, settingsDict={}, pieMenuCallback=False):
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return

	if not (settingsDict and isinstance(settingsDict, dict)):
		return

	if objects:
		selectedShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	else:
		#selectedShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		#selectedBevelPreview = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
		selectedShapes = list(getObjectsWithBevelPreview(searchAll=True).keys())
		selectedShapes = cmds.ls(selectedShapes, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = []
	
	if not selectedShapes and not selectedBevelPreview:
		#selectedShapes = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		#selectedBevelPreview = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
		selectedShapes = list(getObjectsWithBevelPreview().keys())
		selectedShapes = cmds.ls(selectedShapes, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = []
	
	if selectedShapes:
		selList = om.MSelectionList()
		for x in selectedShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			outMeshPlug = dependencyNode.findPlug("outMesh", False)
			dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtBevelPreview":

					inMeshPlug = currentDependencyNode.findPlug("inMesh", False)
					inMeshPlugArray = inMeshPlug.connectedTo(True, False)
					if len(inMeshPlugArray) > 0:
						inMeshMObject = inMeshPlugArray[0].node()

						if inMeshMObject.apiType() in [om.MFn.kPolyBevel, om.MFn.kPolyBevel2, om.MFn.kPolyBevel3]:
							#polyBevelNode = inMeshPlugArray[0].name().split(".")[0]
							dNode = om.MFnDependencyNode(inMeshMObject)
							offsetPlug = dNode.findPlug("offset", False)

							if "offset" in settingsDict:
								offsetPlug.setFloat(settingsDict["offset"])
							
					break
				
				dependencyGraph.next()
	
	if selectedBevelPreview:
		selList = om.MSelectionList()
		for x in selectedBevelPreview:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())

			inMeshPlug = dependencyNode.findPlug("inMesh", False)
			inMeshPlugArray = inMeshPlug.connectedTo(True, False)
			if len(inMeshPlugArray) > 0:
				inMeshMObject = inMeshPlugArray[0].node()

				if inMeshMObject.apiType() in [om.MFn.kPolyBevel, om.MFn.kPolyBevel2, om.MFn.kPolyBevel3]:
					#polyBevelNode = inMeshPlugArray[0].name().split(".")[0]
					dNode = om.MFnDependencyNode(inMeshMObject)
					offsetPlug = dNode.findPlug("offset", False)

					if "offset" in settingsDict:
						offsetPlug.setBool(settingsDict["offset"])
	
	if selectedShapes or selectedBevelPreview:
		# refresh menus
		updateExistingMenus(pieMenuCallback=pieMenuCallback)

def getBevelPreviewSelectionSettingsAverage():
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return
	
	settingsDict = defaultdict(list)

	# Get all bevelPreview settings
	bevelPreviews = cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	for bevelPreview in bevelPreviews:
		bevelPreviewDict = getBevelPreviewSelectionSettings(bevelPreview)[0]
		settingsDict = {key: settingsDict[key] + [value] for key, value in six.iteritems(bevelPreviewDict)}

	# Keep the most common settings for each setting
	for key, value in six.iteritems(settingsDict):
		# For list, convert temporarily to string
		is_list = False
		if isinstance(next(iter(value)), list):
			value = [str(x) for x in value]
			is_list = True
		
		try:
			most_common_item, item_count = Counter(value).most_common(1)[0]
		except Exception as e:
			del settingsDict[key]
			continue
		
		if is_list:
			most_common_item = literal_eval(most_common_item)
		settingsDict[key] = most_common_item
	
	return settingsDict

class BevelPreviewPieMenu(QtCore.QObject):
	def __init__(self):
		super(BevelPreviewPieMenu, self).__init__()
		self.pieMenu = None
		self.selectionChangeScriptJob = None
		self._lastSelected = None

		global BP_PieMenu
		BP_PieMenu = self

		self.createPieMenu()
	
	@QtCore.Slot()
	def controlsCallback(self, obj):
		if isinstance(obj, QtWidgets.QWidget):
			#logging.info("pieMenu controlsCallback")
			objName = obj.objectName()
			if not objName:
				objName = getSpinBoxName(obj)
			if objName == "BP_ToggleBevelDisplay":
				setBevelPreviewSettings(settingsDict={"visibility": obj.isActivated(), "cageDisplay": self.pieMenu.getControlValue("cageDisplay")}, pieMenuCallback=True)
			elif objName == "BP_TogglexRay":
				setBevelPreviewSettings(settingsDict={"xRay": obj.isActivated()}, pieMenuCallback=True)
			elif objName == "BP_ToggleShading":
				setBevelPreviewSettings(settingsDict={"shading": obj.isActivated()}, pieMenuCallback=True)
			elif objName == "BP_WeightedNormals":
				setBevelPreviewSettings(settingsDict={"weightedNormals": obj.isActivated()}, pieMenuCallback=True)
			elif objName == "BP_RealTime":
				setBevelPreviewSettings(settingsDict={"realTime": obj.isActivated()}, pieMenuCallback=True)
			elif objName == "BP_WireframeOpacityValue":
				setBevelPreviewSettings(settingsDict={"wireframeOpacity": obj.value()}, pieMenuCallback=True)
			elif objName == "BP_BevelOffsetValue":
				setPolyBevelSettings(settingsDict={"offset": obj.value()}, pieMenuCallback=True)
			#elif objName == "BP_ContextShading":
				#createViewportCallback(setValue=obj.isActivated())
				# refresh menus
				#updateExistingMenus(pieMenuCallback=True)
			elif objName == "BP_CageDisplayValue":
				cmds.optionVar(intValue=("BP_CageDisplayValue", obj.currentIndex()))
				cmds.optionVar(intValue=("NDB_CageDisplay", obj.currentIndex()))
				if obj.currentIndex() == 1:
					createViewportCallback(setValue=False)
					createSelectionCallback(setValue=False)
				elif obj.currentIndex() == 2:
					createViewportCallback(setValue=True)
					createSelectionCallback(setValue=False)
				elif obj.currentIndex() == 3:
					createViewportCallback(setValue=False)
					createSelectionCallback(setValue=True)
				# refresh menus
				updateExistingMenus(pieMenuCallback=True)
			elif objName == "BP_Create":
				createDynamicBevel()
			elif objName == "BP_Reconnect":
				reconnectDynamicBevel()
			elif objName == "BP_Remove":
				deleteDynamicBevel()
			elif objName == "BP_Clear":
				deleteDynamicBevel(clear=True)
			elif objName == "BP_BakeSelected":
				bakeConvertDynamicBevel()
			elif objName == "BP_BakeAll":
				bakeConvertDynamicBevel(bakeAll=True)
			elif objName == "BP_EditBevel":
				editDynamicBevel()
			elif objName == "BP_TransferBevelSettings":
				transferBevelSettings()

	def updatePieMenuControls(self, pieMenuCallback=False):
		#if self.pieMenu and self.pieMenu.isVisible():
		if self.pieMenu:
			#logging.info("updatePieMenuControls {0}".format(pieMenuCallback))

			pluginFilePath = getPluginPath()[2]
			if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
				self.pieMenu.setControlsValue({}, enabled=False)
				return

			if not pieMenuCallback:

				if cmds.optionVar(exists="NDB_CageDisplay"):
					if cmds.optionVar(query="NDB_CageDisplay") != self.pieMenu.getControlValue("cageDisplay"):
						self.pieMenu.setControlsValue(["cageDisplay", cmds.optionVar(query="NDB_CageDisplay")])

				polyBaseSel = cmds.ls(selection=True, long=True, type="polyBase")
				if polyBaseSel:
					cmds.evalDeferred(partial(self.pieMenu.setVisibility, False))
					cmds.setToolTo("ShowManips")
					return
			
			# Set pieMenu controls value
			settingsDict, selectedShapes = getBevelPreviewSelectionSettings()
			if settingsDict or not self._lastSelected:
				self._lastSelected = next(iter(selectedShapes or []), None)
			# if no bevelPreview, disable controls
			if not settingsDict and not cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview"):
				self.pieMenu.setControlsValue({}, enabled=False)
				self._lastSelected = None
			else:
				if not settingsDict:
					# If nothing is selected, get most common settings from all the bevelPreviews						
					if not cmds.objExists(self._lastSelected or ""):
						settingsDict = getBevelPreviewSelectionSettingsAverage()
					
					elif all([self._lastSelected, cmds.objExists(self._lastSelected or "")]):
						settingsDict = getBevelPreviewSelectionSettings(self._lastSelected)[0]
				
				self.pieMenu.setControlsValue(settingsDict)

	def visibilityCallback(self, visibility):
		# create selectionChange scriptJob
		if visibility:
			self.updatePieMenuControls(pieMenuCallback=True)
			if not (self.selectionChangeScriptJob and cmds.scriptJob(exists=self.selectionChangeScriptJob)):
				self.selectionChangeScriptJob = cmds.scriptJob(event=("SelectionChanged", partial(updateExistingMenus)), parent=self.pieMenu.objectName(), replacePrevious=True, force=True, protected=True)
		# delete selectionChange scriptJob
		else:
			if self.selectionChangeScriptJob and cmds.scriptJob(exists=self.selectionChangeScriptJob):
				cmds.scriptJob(kill=self.selectionChangeScriptJob, force=True)

	def createPieMenu(self):
		self.pieMenu = None

		# Create PieMenu
		ui_file_name = os.path.join(ROOT_DIR_RAW, r"bevelpreview\MarkingMenu_ui.ui")

		if os.path.isfile(ui_file_name):
			self.pieMenu = QPieMenu(ui_file=ui_file_name)
		else:
			self.pieMenu = QPieMenu(ui_widget=Ui_CentralWidget())
		
		if self.pieMenu and isValid(self.pieMenu) and isinstance(self.pieMenu, QPieMenu):
			self.pieMenu.controlsCallbackSignal.connect(partial(self.controlsCallback))
			self.pieMenu.visibilitySignal.connect(partial(self.visibilityCallback))
		
		return self.pieMenu

	@staticmethod
	def getPieMenu():
		global BP_PieMenu

		# Create PieMenu
		if "BP_PieMenu" not in globals() or not isValid(BP_PieMenu):
			BP_PieMenu = BevelPreviewPieMenu()
		
		if BP_PieMenu and isinstance(BP_PieMenu.pieMenu, QPieMenu):
			return BP_PieMenu.pieMenu
		
		del BP_PieMenu
		return None

def showManipulators(setValue=None, toggle=False, manipTool=False):
	if setValue is not None:
		cmds.optionVar(intValue=("BP_ShowManips_Value", setValue))
		# refresh menus
		updateExistingMenus()
		return
	elif not cmds.optionVar(exists="BP_ShowManips_Value"):
		cmds.optionVar(intValue=("BP_ShowManips_Value", False))

	if toggle:
		cmds.optionVar(intValue=("BP_ShowManips_Value", not cmds.optionVar(query="BP_ShowManips_Value")))
		# refresh menus
		updateExistingMenus()
		return

	pluginFilePath = getPluginPath()[2]
	if (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
		if cmds.optionVar(query="BP_ShowManips_Value"):
			pieMenu = BevelPreviewPieMenu.getPieMenu()
			if pieMenu:
				polyBaseSel = cmds.ls(selection=True, long=True, type="polyBase")
				currentTool = cmds.contextInfo(cmds.currentCtx(), c=True)
				if pieMenu.isVisible():
					pieMenu.setVisibility(False)
					if not polyBaseSel:
						return
				else:
					#shapeSel = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type=["mesh", "gtBevelPreview"])
					#if not polyBaseSel and shapeSel:
					if not polyBaseSel or currentTool == "showManip":
						# Make sure a modelPanel is under pointer
						panel = cmds.getPanel(underPointer=True)
						if panel not in cmds.getPanel(type="modelPanel") or cmds.modelEditor(panel, query=True, exists=True) is False:
							return
						# Set pieMenu controls value
						'''settingsDict = getBevelPreviewSelectionSettings()[0]
						# if no bevelPreview, disable controls
						if not settingsDict and not cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview"):
							pieMenu.setControlsValue({}, enabled=False)
						else:
							pieMenu.setControlsValue(settingsDict)
						
						if cmds.optionVar(exists="NDB_CageDisplay"):
							if cmds.optionVar(query="NDB_CageDisplay") != pieMenu.getControlValue("cageDisplay"):
								pieMenu.setControlsValue(["cageDisplay", cmds.optionVar(query="NDB_CageDisplay")])'''

						# Show pieMenu
						pieMenu.setVisibility(True)
						cmds.setToolTo("selectSuperContext")
						return
	
	if manipTool:
		mel.eval("global string $gShowManip;setToolTo $gShowManip;")
	else:
		cmds.setToolTo("ShowManips")

def togglePieMenu():
	pieMenu = BevelPreviewPieMenu.getPieMenu()
	if pieMenu:
		# Make sure a modelPanel is under pointer
		panel = cmds.getPanel(underPointer=True)
		if panel not in cmds.getPanel(type="modelPanel") or cmds.modelEditor(panel, query=True, exists=True) is False:
			return False
		# Set pieMenu controls value
		if not pieMenu.isVisible():
			cmds.setToolTo("selectSuperContext")
			cmds.select(cmds.ls(selection=True, long=True, type="polyBase"), deselect=True)

			pluginFilePath = getPluginPath()[2]
			if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
				pieMenu.setControlsValue({}, enabled=False)
			'''else:
				settingsDict = getBevelPreviewSelectionSettings()[0]
				# if no bevelPreview, disable controls
				if not settingsDict and not cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview"):
					pieMenu.setControlsValue({}, enabled=False)
				else:
					pieMenu.setControlsValue(settingsDict)
				
				if cmds.optionVar(exists="NDB_CageDisplay"):
					if cmds.optionVar(query="NDB_CageDisplay") != pieMenu.getControlValue("cageDisplay"):
						pieMenu.setControlsValue(["cageDisplay", cmds.optionVar(query="NDB_CageDisplay")])'''
		
		# Toggle PieMenu visibility
		pieMenu.toggleVisibility()
		return True
	
	return False

def updateExistingMenus(pieMenuCallback=False):
	#logging.info("updateExistingMenus")
	global BP_PieMenu
	if "BP_PieMenu" in globals() and isValid(BP_PieMenu) and isinstance(BP_PieMenu, BevelPreviewPieMenu):
		BP_PieMenu.updatePieMenuControls(pieMenuCallback=pieMenuCallback)
	
	global NDB_Window
	if "NDB_Window" in globals() and isinstance(NDB_Window, NT_BevelPreviewWin):
		if cmds.window(NDB_Window.windowName, exists=True):
			NDB_Window.updateMenuControls()

def setBakeOption(value=None):
	if value is not None:
		cmds.optionVar(intValue=("BP_BakeOption", value))
	else:
		if not callable(NT_SmartBevel):
			value = None
			cmds.optionVar(remove="BP_BakeOption")
		else:
			if cmds.optionVar(exists="BP_BakeOption"):
				value = cmds.optionVar(query="BP_BakeOption")
			else:
				value = True
				cmds.optionVar(intValue=("BP_BakeOption", value))
	
	return value

def toggleCageDisplay():
	viewportCallback = False
	selectionCallback = False
	if cmds.optionVar(exists="BP_ContextViewportCallback"):
		viewportCallback = cmds.optionVar(query="BP_ContextViewportCallback")
	if cmds.optionVar(exists="BP_ContextSelectionCallback"):
		selectionCallback = cmds.optionVar(query="BP_ContextSelectionCallback")

	if all([not viewportCallback, not selectionCallback]):
		createViewportCallback(setValue=True)
		createSelectionCallback(setValue=False)
		if cmds.optionMenuGrp("NDB_CageDisplay", query=True, exists=True):
			cmds.optionMenuGrp("NDB_CageDisplay", edit=True, select=2)
		cmds.optionVar(intValue=("BP_CageDisplayValue", 2))
		cmds.optionVar(intValue=("NDB_CageDisplay", 2))

	elif viewportCallback:
		createViewportCallback(setValue=False)
		createSelectionCallback(setValue=True)
		if cmds.optionMenuGrp("NDB_CageDisplay", query=True, exists=True):
			cmds.optionMenuGrp("NDB_CageDisplay", edit=True, select=3)
		cmds.optionVar(intValue=("BP_CageDisplayValue", 3))
		cmds.optionVar(intValue=("NDB_CageDisplay", 3))

	elif selectionCallback:
		createViewportCallback(setValue=False)
		createSelectionCallback(setValue=False)
		if cmds.optionMenuGrp("NDB_CageDisplay", query=True, exists=True):
			cmds.optionMenuGrp("NDB_CageDisplay", edit=True, select=1)
		cmds.optionVar(intValue=("BP_CageDisplayValue", 1))
		cmds.optionVar(intValue=("NDB_CageDisplay", 1))

	# refresh menus
	updateExistingMenus()

class NT_BevelPreviewWin(OptionsWindow):
	def __init__(self):
		self.windowName = "NT_BevelPreviewWin"
		self.pfx = "NDB_"
		kwargs = {"windowSize": [275, 470], 
				  "windowTitle": "Non-Destructive Bevel", 
				  "minWindowSize": 260, 
				  "rowOffset": 110, 
				  "sizeable": False, 
				  "preview": False}
		
		self.initDone = False
		super(NT_BevelPreviewWin, self).__init__(self.windowName, **kwargs)

		# create selectionChange scriptJob
		#self.selectionChangeScriptJob = cmds.scriptJob(event=("SelectionChanged", partial(updateExistingMenus)), protected=True)

		# add global variable
		cmds.evalDeferred(partial(self.setGlobalVar))

		self._lastSelected = False

		# update controls
		self.updateMenuControls()

	def setGlobalVar(self):
		global NDB_Window
		NDB_Window = self

	def closeEvent(self):
		# delete selectionChange scriptJob
		if self.selectionChangeScriptJob and cmds.scriptJob(exists=self.selectionChangeScriptJob):
			cmds.scriptJob(kill=self.selectionChangeScriptJob, force=True)
		# delete global variable
		global NDB_Window
		if "NDB_Window" in globals():
			del NDB_Window

	def postInit(self):
		cmds.scriptJob(uiDeleted=(self.windowName, partial(self.closeEvent)), runOnce=True, protected=True)
		self.selectionChangeScriptJob = cmds.scriptJob(event=("SelectionChanged", partial(updateExistingMenus)), parent=self.windowName, replacePrevious=True, force=True, protected=True)
		self.initDone = True

	def resetSettings(self, *args):
		cmds.optionVar(remove="BP_BakeOption")
		# Reset settings
		self.saveSettings(2)
		# Update controls
		self.windowSetup()

	def controlsCallback(self, commandName="", value=None, *args):
		#logging.info("menu controlsCallback")
		self.bakeOptionCallback()

		if not self.initDone:
			return
		
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		settings = self.querySettings()

		if commandName == "enableBevelDisplay":
			setBevelPreviewSettings(settingsDict={"visibility": value, "cageDisplay": settings[self.pfx+"CageDisplay"]})
		elif commandName == "enablexRay":
			setBevelPreviewSettings(settingsDict={"xRay": value})
		elif commandName == "enableShading":
			setBevelPreviewSettings(settingsDict={"shading": value})
		elif commandName == "weightedNormals":
			setBevelPreviewSettings(settingsDict={"weightedNormals": value})
		elif commandName == "realTime":
			setBevelPreviewSettings(settingsDict={"realTime": value})
		elif commandName == "wireframeColor":
			value = settings[self.pfx+"WireframeColor"]
			setBevelPreviewSettings(settingsDict={"wireframeColor": value})
		elif commandName == "wireframeOpacity":
			setBevelPreviewSettings(settingsDict={"wireframeOpacity": value})
		elif commandName == "bevelOffset":
			setPolyBevelSettings(settingsDict={"offset": value})
		elif commandName == "cageDisplay":
			value = settings[self.pfx+"CageDisplay"]
			cmds.optionVar(intValue=("NDB_CageDisplay", value))
			#cmds.optionVar(intValue=("BP_ContextShadingValue", value))
			if value == 1:
				createViewportCallback(setValue=False)
				createSelectionCallback(setValue=False)
			elif value == 2:
				createViewportCallback(setValue=True)
				createSelectionCallback(setValue=False)
			elif value == 3:
				createViewportCallback(setValue=False)
				createSelectionCallback(setValue=True)
			# refresh menus
			updateExistingMenus()
		elif commandName == "showManips":
			showManipulators(setValue=value)
		else:
			settingsDict = {"realTime": next(iter(settings[self.pfx+"RealTime"])), 
							"visibility": next(iter(settings[self.pfx+"EnableBevelDisplay"])), 
							"xRay": next(iter(settings[self.pfx+"EnablexRay"])), 
							"wireframeOpacity": settings[self.pfx+"WireframeOpacity"], 
							"offset": settings[self.pfx+"BevelOffset"], 
							"shading": next(iter(settings[self.pfx+"EnableShading"])), 
							"weightedNormals": next(iter(settings[self.pfx+"WeightedNormals"])), 
							"wireframeColor": settings[self.pfx+"WireframeColor"]}
			if settings[self.pfx+"CageDisplay"] == 1:
				createViewportCallback(setValue=False)
				createSelectionCallback(setValue=False)
			elif settings[self.pfx+"CageDisplay"] == 2:
				createViewportCallback(setValue=True)
				createSelectionCallback(setValue=False)
			elif settings[self.pfx+"CageDisplay"] == 3:
				createViewportCallback(setValue=False)
				createSelectionCallback(setValue=True)
			setPolyBevelSettings(settingsDict=settingsDict)
			showManipulators(setValue=next(iter(settings[self.pfx+"OverrideShowManips"])))
			setBevelPreviewSettings(settingsDict=settingsDict)
	
	def bakeOptionCallback(self, value=None):
		value = setBakeOption(value)

		if value is None:
			cmds.iconTextButton(self.pfx+"Bake_Button", edit=True, image=self.getIconPath("NDB_BakeSelected_Button.png"))
			cmds.iconTextButton(self.pfx+"BakeAll_Button", edit=True, image=self.getIconPath("NDB_BakeAll_Button.png"))
		elif value:
			cmds.iconTextButton(self.pfx+"Bake_Button", edit=True, image=self.getIconPath("NDB_ConvertSelected_Button.png"))
			cmds.iconTextButton(self.pfx+"BakeAll_Button", edit=True, image=self.getIconPath("NDB_ConvertAll_Button.png"))
			if cmds.menuItem(self.pfx+"ConvertSelectedBevel", query=True, exists=True):
				cmds.menuItem(self.pfx+"ConvertSelectedBevel", edit=True, checkBox=True)
			if cmds.menuItem(self.pfx+"ConvertAllBevel", query=True, exists=True):
				cmds.menuItem(self.pfx+"ConvertAllBevel", edit=True, checkBox=True)
		else:
			cmds.iconTextButton(self.pfx+"Bake_Button", edit=True, image=self.getIconPath("NDB_BakeSelected_Button2.png"))
			cmds.iconTextButton(self.pfx+"BakeAll_Button", edit=True, image=self.getIconPath("NDB_BakeAll_Button2.png"))
			if cmds.menuItem(self.pfx+"ConvertSelectedBevel", query=True, exists=True):
				cmds.menuItem(self.pfx+"ConvertSelectedBevel", edit=True, checkBox=False)
			if cmds.menuItem(self.pfx+"ConvertAllBevel", query=True, exists=True):
				cmds.menuItem(self.pfx+"ConvertAllBevel", edit=True, checkBox=False)

	def updateMenuControls(self):
		pluginFilePath = getPluginPath()[2]
		if not (pluginFilePath and cmds.pluginInfo(pluginFilePath, query=True, loaded=True)):
			self.setControlsValue({}, enabled=False)
			return

		#if cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview"):
			#return
		# Set menu controls value
		settingsDict, selectedShapes = getBevelPreviewSelectionSettings()
		if settingsDict or not self._lastSelected:
			self._lastSelected = next(iter(selectedShapes or []), None)
		# if no bevelPreview, disable controls
		if not settingsDict and not cmds.ls(long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview"):
			self.setControlsValue({}, enabled=False)
			self._lastSelected = False
		else:
			if not settingsDict:
				# If nothing is selected, get most common settings from all the bevelPreviews						
				if not cmds.objExists(self._lastSelected or ""):
					settingsDict = getBevelPreviewSelectionSettingsAverage()
				
				elif all([self._lastSelected, cmds.objExists(self._lastSelected or "")]):
					settingsDict = getBevelPreviewSelectionSettings(self._lastSelected)[0]

			self.setControlsValue(settingsDict)
		
		# Query optionVar
		settings = self.querySettings()
		pieMenu = BevelPreviewPieMenu.getPieMenu()
		if pieMenu and pieMenu.isVisible():
			if cmds.optionVar(exists="BP_CageDisplayValue"):
				#if cmds.optionVar(query="BP_ContextShadingValue") != settings[self.pfx+"CageDisplay"]:
				self.setControlsValue(["cageDisplay", cmds.optionVar(query="BP_CageDisplayValue")])
		if cmds.optionVar(exists="BP_ShowManips_Value"):
			if cmds.optionVar(query="BP_ShowManips_Value") != settings[self.pfx+"OverrideShowManips"]:
				self.setControlsValue(["showManips", cmds.optionVar(query="BP_ShowManips_Value")])
		
		self.saveSettings(1)
	
	def setDisabledControls(self):
		if not cmds.checkBoxGrp(self.pfx+"EnableBevelDisplay", query=True, value1=True):
			cmds.checkBoxGrp(self.pfx+"EnablexRay", edit=True, enable=False)
			cmds.checkBoxGrp(self.pfx+"EnableShading", edit=True, enable=False)
		elif not cmds.checkBoxGrp(self.pfx+"EnableShading", query=True, value1=True):
			cmds.checkBoxGrp(self.pfx+"EnablexRay", edit=True, enable=False)

	def setControlsValue(self, settingsDict, enabled=True):
		if isinstance(settingsDict, dict):
			cmds.checkBoxGrp(self.pfx+"EnableBevelDisplay", edit=True, enable=True)
			cmds.checkBoxGrp(self.pfx+"EnablexRay", edit=True, enable=True)
			cmds.checkBoxGrp(self.pfx+"EnableShading", edit=True, enable=True)
			cmds.checkBoxGrp(self.pfx+"WeightedNormals", edit=True, enable=True)
			cmds.checkBoxGrp(self.pfx+"RealTime", edit=True, enable=True)
			cmds.floatSliderGrp(self.pfx+"WireframeOpacity", edit=True, enable=True)
			cmds.colorSliderGrp(self.pfx+"WireframeColor", edit=True, enable=True)
			cmds.floatSliderGrp(self.pfx+"BevelOffset", edit=True, enable=True)

			if "visibility" in settingsDict:
				cmds.checkBoxGrp(self.pfx+"EnableBevelDisplay", edit=True, value1=settingsDict["visibility"])
			elif not enabled:
				cmds.checkBoxGrp(self.pfx+"EnableBevelDisplay", edit=True, enable=False, value1=False)
			
			if "xRay" in settingsDict:
				cmds.checkBoxGrp(self.pfx+"EnablexRay", edit=True, value1=settingsDict["xRay"])
			elif not enabled:
				cmds.checkBoxGrp(self.pfx+"EnablexRay", edit=True, enable=False, value1=False)

			if "shading" in settingsDict:
				cmds.checkBoxGrp(self.pfx+"EnableShading", edit=True, value1=settingsDict["shading"])
			elif not enabled:
				cmds.checkBoxGrp(self.pfx+"EnableShading", edit=True, enable=False, value1=False)

			if "weightedNormals" in settingsDict:
				cmds.checkBoxGrp(self.pfx+"WeightedNormals", edit=True, value1=settingsDict["weightedNormals"])
			elif not enabled:
				cmds.checkBoxGrp(self.pfx+"WeightedNormals", edit=True, enable=False, value1=False)

			if "realTime" in settingsDict:
				cmds.checkBoxGrp(self.pfx+"RealTime", edit=True, value1=settingsDict["realTime"])
			elif not enabled:
				cmds.checkBoxGrp(self.pfx+"RealTime", edit=True, enable=False, value1=False)

			if "wireframeOpacity" in settingsDict:
				cmds.floatSliderGrp(self.pfx+"WireframeOpacity", edit=True, value=settingsDict["wireframeOpacity"])
			elif not enabled:
				cmds.floatSliderGrp(self.pfx+"WireframeOpacity", edit=True, enable=False, value=0)

			if "wireframeColor" in settingsDict:
				cmds.colorSliderGrp(self.pfx+"WireframeColor", edit=True, rgbValue=settingsDict["wireframeColor"])
			elif not enabled:
				cmds.colorSliderGrp(self.pfx+"WireframeColor", edit=True, enable=False, rgbValue=(0, 0, 0))
			
			if "offset" in settingsDict:
				cmds.floatSliderGrp(self.pfx+"BevelOffset", edit=True, value=settingsDict["offset"])
			elif not enabled:
				cmds.floatSliderGrp(self.pfx+"BevelOffset", edit=True, enable=False, value=0)

			if enabled:
				self.setDisabledControls()

		elif isinstance(settingsDict, (list, tuple)) and len(settingsDict) > 1:
			if settingsDict[0] == "cageDisplay":
				#cmds.checkBoxGrp(self.pfx+"ContextShading", edit=True, value1=settingsDict[1])
				cmds.optionMenuGrp(self.pfx+"CageDisplay", edit=True, select=settingsDict[1])
			if settingsDict[0] == "showManips":
				cmds.checkBoxGrp(self.pfx+"OverrideShowManips", edit=True, value1=settingsDict[1])

	def bevelPreviewCmd(self, commandName):
		if commandName == "create":
			createDynamicBevel(selectBevelNode=True)
			#self.updateMenuControls()
		elif commandName == "reconnect":
			reconnectDynamicBevel()
			#self.updateMenuControls()
		elif commandName == "remove":
			deleteDynamicBevel()
			#self.updateMenuControls()
		elif commandName == "clear":
			deleteDynamicBevel(clear=True)
			#self.updateMenuControls()
		elif commandName == "bake":
			bakeConvertDynamicBevel()
			#self.updateMenuControls()
		elif commandName == "bakeAll":
			bakeConvertDynamicBevel(bakeAll=True)
			#self.updateMenuControls()
		elif commandName == "editBevel":
			editDynamicBevel()
		elif commandName == "transferBevel":
			transferBevelSettings()

	def resetWindowSize(self, *args):
		windowHeight = self.windowSize[1]
		MNDBForm_Height = cmds.formLayout(self.pfx+"MNDBForm", query=True, height=True)+4
		NDBSForm_Height = cmds.formLayout(self.pfx+"NDBSForm", query=True, height=True)+8

		if cmds.frameLayout(self.pfx+"MNDBFrame", query=True, collapse=True):
			windowHeight -= MNDBForm_Height
		
		if cmds.frameLayout(self.pfx+"NDBSFrame", query=True, collapse=True):
			windowHeight -= NDBSForm_Height
		
		windowHeight = max(windowHeight, 140)

		cmds.window(self.windowName, edit=True, widthHeight=[self.windowSize[0], windowHeight], resizeToFitChildren=True, sizeable=self.sizeable)

	def getIconPath(self, iconName):
		return os.path.join(ROOT_DIR, os.path.join("icons", iconName))

	def createUI(self):
		# If window already opened, delete it
		if cmds.window(self.windowName, exists=True):
			cmds.deleteUI(self.windowName, window=True)
		cmds.window(self.windowName, title=self.windowTitle, menuBar=True, maximizeButton=False)
		
		# Edit menu
		cmds.menu(label="Edit")
		cmds.menuItem(label="Save Settings", command=(partial(self.saveSettings, 1)), enableCommandRepeat=False)
		cmds.menuItem(label="Reset Settings", command=(partial(self.resetSettings)), enableCommandRepeat=False)
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Reset Window Size", command=(partial(self.resetWindowSize)), enableCommandRepeat=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(label="Help", helpMenu=True)
		cmds.menuItem(label="Help on {0}".format(self.windowTitle), image="help.png", command=(partial(helpCmd, helpUrl="/docs/nondestructivebevel-overview/")), enableCommandRepeat=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tabsVisible=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", childResizable=True, resizeCommand=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"MNDBFrame", label="Manage", labelIndent=0, collapsable=True, backgroundShade=False, marginHeight=2, marginWidth=0, collapseCommand=partial(self.resetWindowSize), expandCommand=partial(self.resetWindowSize))
		cmds.formLayout(self.pfx+"MNDBForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"MNDBColumn1", adjustableColumn=True, columnAttach=("left", 0))

		cmds.formLayout(self.pfx+"Create_Form", numberOfDivisions=100)
		#cmds.iconTextButton(self.pfx+"Create_Button", style="textOnly", label="Create / Recompute", annotation="Create Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "create", partialLabel="NDB_Create"), flat=False, height=32)
		cmds.iconTextButton(self.pfx+"Create_Button", image=self.getIconPath("NDB_Create_Button.png"), style="iconOnly", annotation="Create Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "create", partialLabel="NDB_Create"), height=34)
		cmds.setParent("..")

		cmds.formLayout(self.pfx+"Reconnect_Form", numberOfDivisions=100)
		#cmds.iconTextButton(self.pfx+"Reconnect_Button", style="textOnly", label="Reconnect", annotation="Reconnect Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "reconnect", partialLabel="NDB_Reconnect"), flat=False, height=23)
		cmds.iconTextButton(self.pfx+"Reconnect_Button", image=self.getIconPath("NDB_Reconnect_Button.png"), style="iconOnly", annotation="Reconnect Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "reconnect", partialLabel="NDB_Reconnect"), height=25)
		cmds.setParent("..")

		cmds.formLayout(self.pfx+"Remove_Form", numberOfDivisions=100)
		#cmds.iconTextButton(self.pfx+"Remove_Button", style="textOnly", label="Remove", annotation="Remove Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "remove", partialLabel="NDB_Remove"), flat=False, height=23)
		#cmds.iconTextButton(self.pfx+"Clear_Button", style="textOnly", label="Clear", annotation="Clear All Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "clear", partialLabel="NDB_Clear"), flat=False, height=23)
		cmds.iconTextButton(self.pfx+"Remove_Button", image=self.getIconPath("NDB_Remove_Button.png"), style="iconOnly", annotation="Remove Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "remove", partialLabel="NDB_Remove"), height=25)
		cmds.iconTextButton(self.pfx+"Clear_Button", image=self.getIconPath("NDB_Clear_Button.png"), style="iconOnly", annotation="Clear All Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "clear", partialLabel="NDB_Clear"), height=25)
		cmds.setParent("..")

		cmds.formLayout(self.pfx+"Bake_Form", numberOfDivisions=100)
		#cmds.iconTextButton(self.pfx+"Bake_Button", style="textOnly", label="Bake Selected", annotation="Bake Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "bake", partialLabel="NDB_BakeSelected"), flat=False, height=23)
		#cmds.iconTextButton(self.pfx+"BakeAll_Button", style="textOnly", label="Bake All", annotation="Bake All Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "bakeAll", partialLabel="NDB_BakeAll"), flat=False, height=23)
		cmds.iconTextButton(self.pfx+"Bake_Button", image=self.getIconPath("NDB_BakeSelected_Button.png"), style="iconOnly", annotation="Bake Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "bake", partialLabel="NDB_BakeSelected"), height=25)
		cmds.iconTextButton(self.pfx+"BakeAll_Button", image=self.getIconPath("NDB_BakeAll_Button.png"), style="iconOnly", annotation="Bake All Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "bakeAll", partialLabel="NDB_BakeAll"), height=25)
		cmds.setParent("..")

		cmds.formLayout(self.pfx+"Bevel_Form", numberOfDivisions=100)
		#cmds.iconTextButton(self.pfx+"EditBevel_Button", style="textOnly", label="Edit Bevel", annotation="Edit Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "editBevel", partialLabel="NDB_EditBevel"), flat=False, height=23)
		#cmds.iconTextButton(self.pfx+"TransferBevel_Button", style="textOnly", label="Transfer Settings", annotation="Transfer Selected Non-Destructive Bevels Settings", command=rpartial(self.bevelPreviewCmd, "transferBevel", partialLabel="NDB_TransferBevelSettings"), flat=False, height=23)
		cmds.iconTextButton(self.pfx+"EditBevel_Button", image=self.getIconPath("NDB_EditBevel_Button.png"), style="iconOnly", annotation="Edit Selected Non-Destructive Bevels", command=rpartial(self.bevelPreviewCmd, "editBevel", partialLabel="NDB_EditBevel"), height=25)
		cmds.iconTextButton(self.pfx+"TransferBevel_Button", image=self.getIconPath("NDB_TransferBevelSettings_Button.png"), style="iconOnly", annotation="Transfer Selected Non-Destructive Bevels Settings", command=rpartial(self.bevelPreviewCmd, "transferBevel", partialLabel="NDB_TransferBevelSettings"), height=25)
		cmds.setParent("..")

		# Separation
		cmds.rowLayout(height=3)
		cmds.setParent("..")

		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")

		# START: Settings Frame
		cmds.frameLayout(self.pfx+"NDBSFrame", label="Settings", labelIndent=0, collapsable=True, backgroundShade=True, marginHeight=4, marginWidth=0, collapseCommand=partial(self.resetWindowSize), expandCommand=partial(self.resetWindowSize))
		cmds.formLayout(self.pfx+"NDBSForm")

		# START: Settings Column #2
		cmds.columnLayout(self.pfx+"NDBSColumn1", adjustableColumn=True, columnAttach=("left", 0))

		# Override ShowManip
		cmds.rowLayout(self.pfx+"NDBSRow1", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"), adjustableColumn=2)
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"OverrideShowManips", docTag=self.pfx+"OverrideShowManips", label="", label1="Show Manips", value1=False, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, "showManips")))
		cmds.setParent("..")

		# Context Shading
		cmds.rowLayout(self.pfx+"NDBSRow2", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"), adjustableColumn=2)
		cmds.text(l="Cage Display:")
		#cmds.checkBoxGrp(self.pfx+"ContextShading", docTag=self.pfx+"ContextShading", label="", label1="Context Shading", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, "contextShading")))
		cmds.optionMenuGrp(self.pfx+"CageDisplay", docTag=self.pfx+"CageDisplay", label="", columnWidth2=(0, 140))
		cmds.menuItem(label="Default") #1
		cmds.menuItem(label="Context Shading") #2
		cmds.menuItem(label="Component Mode") #3
		cmds.optionMenuGrp(self.pfx+"CageDisplay", edit=True, select=2, changeCommand=(partial(self.controlsCallback, "cageDisplay")))
		cmds.setParent("..")

		self.separationRow(3, 2, 3)

		cmds.rowLayout(self.pfx+"NDBSRow3", numberOfColumns=4, columnWidth4=(5, 96, 5, 96), columnAttach=(1, "right", 0), columnAttach4=("left", "left", "left", "left"))
		# Real-Time
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"RealTime", docTag=self.pfx+"RealTime", label="", label1="Real Time", value1=False, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, "realTime")))
		# Enable Bevel Display
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"EnableBevelDisplay", docTag=self.pfx+"EnableBevelDisplay", label="", label1="Enable Bevel Display", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, "enableBevelDisplay")))
		cmds.setParent("..")
		
		cmds.rowLayout(self.pfx+"NDBSRow4", numberOfColumns=4, columnWidth4=(5, 96, 5, 96), columnAttach=(1, "right", 0), columnAttach4=("left", "left", "left", "left"))
		# Enable xRay
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"EnablexRay", docTag=self.pfx+"EnablexRay", label="", label1="Enable xRay", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, "enablexRay")))
		# Enable Shading
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"EnableShading", docTag=self.pfx+"EnableShading", label="", label1="Enable Shading", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, "enableShading")))
		cmds.setParent("..")

		# Wireframe Color
		cmds.rowLayout(self.pfx+"WireframeColor_Row", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"), adjustableColumn=2)
		cmds.text(label="Wireframe Color:")
		cmds.colorSliderGrp(self.pfx+"WireframeColor", docTag=self.pfx+"WireframeColor", label="", rgbValue=(0, 0, 0), columnWidth3=(1, 60, 1), columnAttach3=("left", "both", "right"), columnOffset3=(0, 1, 0), changeCommand=partial(self.controlsCallback, "wireframeColor"), dragCommand=partial(self.controlsCallback, "wireframeColor"))
		cmds.setParent("..")
		
		# Wireframe Opacity
		cmds.rowLayout(self.pfx+"WireframeOpacity_Row", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"), adjustableColumn=2)
		cmds.text(label="Wireframe Opacity:")
		cmds.floatSliderGrp(self.pfx+"WireframeOpacity", docTag=self.pfx+"WireframeOpacity", label="", field=True, precision=4, value=0.2, minValue=0, maxValue=1, columnWidth3=(1, 60, 1), changeCommand=partial(self.controlsCallback, "wireframeOpacity"), dragCommand=partial(self.controlsCallback, "wireframeOpacity"))
		cmds.setParent("..")

		self.separationRow(4, 2, 4)

		# Bevel Offset
		cmds.rowLayout(self.pfx+"BevelOffset_Row", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"), adjustableColumn=2)
		cmds.text(label="Bevel Offset:")
		cmds.floatSliderGrp(self.pfx+"BevelOffset", docTag=self.pfx+"BevelOffset", label="", field=True, precision=4, value=1, minValue=0, maxValue=5, fieldMaxValue=1000000, columnWidth3=(1, 60, 1), changeCommand=partial(self.controlsCallback, "bevelOffset"), dragCommand=partial(self.controlsCallback, "bevelOffset"))
		cmds.setParent("..")

		# Weighted Normals
		cmds.rowLayout(self.pfx+"WeightedNormals_Row", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"), adjustableColumn=2)
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"WeightedNormals", docTag=self.pfx+"WeightedNormals", label="", label1="Weighted Normals", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback, "weightedNormals")))
		cmds.setParent("..")

		# Separation
		cmds.rowLayout(height=1)
		cmds.setParent("..")

		# END: Settings Column #2
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", numberOfDivisions=100)
		cmds.iconTextButton(self.pfx+"closeButton", label="Close", command=(partial(self.buttonsCmd, False, True)), flat=False, height=26, style="textOnly", commandRepeatable=False)
		cmds.setParent("..")

		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, edit=True,
						attachForm=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						attachControl=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, edit=True,
						attachNone=(self.pfx+"ButtonForm", "top"),
						attachForm=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", edit=True,
						attachForm=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, edit=True,
						attachForm=[(self.pfx+"MNDBFrame", "top", 0), (self.pfx+"MNDBFrame", "left", 0), (self.pfx+"MNDBFrame", "right", 0)],
						attachNone=(self.pfx+"MNDBFrame", "bottom"))
		cmds.formLayout(self.scrollForm, edit=True,
						attachControl=(self.pfx+"NDBSFrame", "top", 0, self.pfx+"MNDBFrame"),
						attachForm=[(self.pfx+"NDBSFrame", "left", 0), (self.pfx+"NDBSFrame", "right", 0)],
						attachNone=(self.pfx+"NDBSFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"MNDBForm", edit=True,
						attachForm=[(self.pfx+"MNDBColumn1", "top", 0), (self.pfx+"MNDBColumn1", "left", 0), (self.pfx+"MNDBColumn1", "right", 0)],
						attachNone=(self.pfx+"MNDBColumn1", "bottom"))
		cmds.formLayout(self.pfx+"NDBSForm", edit=True,
						attachForm=[(self.pfx+"NDBSColumn1", "top", 0), (self.pfx+"NDBSColumn1", "left", 0), (self.pfx+"NDBSColumn1", "right", 0)],
						attachNone=(self.pfx+"NDBSColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"Create_Form", edit=True,
						attachForm=(self.pfx+"Create_Button", "top", -1),
						attachPosition=[(self.pfx+"Create_Button", "left", 0, 0), (self.pfx+"Create_Button", "right", 0, 100)],
						attachNone=(self.pfx+"Create_Button", "bottom"))
		
		cmds.formLayout(self.pfx+"Reconnect_Form", edit=True,
						attachForm=(self.pfx+"Reconnect_Button", "top", 1),
						attachPosition=[(self.pfx+"Reconnect_Button", "left", 0, 0), (self.pfx+"Reconnect_Button", "right", 0, 100)],
						attachNone=(self.pfx+"Reconnect_Button", "bottom"))

		cmds.formLayout(self.pfx+"Remove_Form", edit=True,
						attachForm=(self.pfx+"Remove_Button", "top", 1),
						attachPosition=[(self.pfx+"Remove_Button", "left", 1, 0), (self.pfx+"Remove_Button", "right", 0, 50)],
						attachNone=(self.pfx+"Remove_Button", "bottom"))
		cmds.formLayout(self.pfx+"Remove_Form", edit=True,
						attachForm=(self.pfx+"Clear_Button", "top", 1),
						attachPosition=[(self.pfx+"Clear_Button", "left", 1, 50), (self.pfx+"Clear_Button", "right", 0, 100)],
						attachNone=(self.pfx+"Clear_Button", "bottom"))
		
		cmds.formLayout(self.pfx+"Bake_Form", edit=True,
						attachForm=(self.pfx+"Bake_Button", "top", 1),
						attachPosition=[(self.pfx+"Bake_Button", "left", 1, 0), (self.pfx+"Bake_Button", "right", 0, 50)],
						attachNone=(self.pfx+"Bake_Button", "bottom"))
		cmds.formLayout(self.pfx+"Bake_Form", edit=True,
						attachForm=(self.pfx+"BakeAll_Button", "top", 1),
						attachPosition=[(self.pfx+"BakeAll_Button", "left", 1, 50), (self.pfx+"BakeAll_Button", "right", 0, 100)],
						attachNone=(self.pfx+"BakeAll_Button", "bottom"))

		cmds.formLayout(self.pfx+"Bevel_Form", edit=True,
						attachForm=(self.pfx+"EditBevel_Button", "top", 1),
						attachPosition=[(self.pfx+"EditBevel_Button", "left", 1, 0), (self.pfx+"EditBevel_Button", "right", 0, 50)],
						attachNone=(self.pfx+"EditBevel_Button", "bottom"))
		cmds.formLayout(self.pfx+"Bevel_Form", edit=True,
						attachForm=(self.pfx+"TransferBevel_Button", "top", 1),
						attachPosition=[(self.pfx+"TransferBevel_Button", "left", 1, 50), (self.pfx+"TransferBevel_Button", "right", 0, 100)],
						attachNone=(self.pfx+"TransferBevel_Button", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", edit=True,
						attachForm=(self.pfx+"closeButton", "top", 0),
						attachPosition=[(self.pfx+"closeButton", "left", 0, 0), (self.pfx+"closeButton", "right", 0, 100)],
						attachNone=(self.pfx+"closeButton", "bottom"))

		if callable(NT_SmartBevel):
			cmds.popupMenu(parent=self.pfx+"Bake_Button")
			cmds.menuItem(self.pfx+"ConvertSelectedBevel", label="Convert To Smart Bevel", checkBox=False, command=(partial(self.bakeOptionCallback)))
			cmds.setParent("..")

			cmds.popupMenu(parent=self.pfx+"BakeAll_Button")
			cmds.menuItem(self.pfx+"ConvertAllBevel", label="Convert To Smart Bevel", checkBox=False, command=(partial(self.bakeOptionCallback)))
			cmds.setParent("..")