#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import math
import maya.cmds as cmds
from collections import defaultdict
from maya.OpenMayaUI import MQtUtil
try:
	from PySide2 import QtCore, QtGui, QtWidgets, QtUiTools
	from shiboken2 import wrapInstance
except ImportError:
	from PySide import QtCore, QtGui, QtUiTools
	from PySide import QtGui as QtWidgets
	from shiboken import wrapInstance

# for python 3 compatibility
import six
from six.moves import range
try:
	from past.builtins import long
except:
	pass

from ....core.utils.listeners import InputListener

def clamp(val, minv, maxv):
    return minv if val < minv else maxv if val > maxv else val

def angleFromPoints(p1=None, p2=None):
	if isinstance(p1, QtCore.QPoint):
		p1 = [p1.x(), p1.y()]
	if isinstance(p2, QtCore.QPoint):
		p2 = [p2.x(), p2.y()]
	
	radians = math.atan2(p2[1]-p1[1], p2[0]-p1[0])
	degrees = math.degrees(radians)
	if degrees < 0.0:
		degrees += 360.0
	return degrees

def currentUnitString(angle=False):
	if angle:
		unitType = cmds.currentUnit(query=True, angle=True)
		if unitType in ["deg", "degree"]:
			unitText = u"°"
		elif unitType in ["rad", "radian"]:
			unitText = u"<sup>c</sup>"
	else:
		unitType = cmds.currentUnit(query=True, linear=True)
		if unitType in ["mm", "millimeter"]:
			unitText = "mm"
		elif unitType in ["cm", "centimeter"]:
			unitText = "cm"
		elif unitType in ["m", "meter"]:
			unitText = "m"
		elif unitType in ["km", "kilometer"]:
			unitText = "km"
		elif unitType in ["in", "inch"]:
			unitText = "in"
		elif unitType in ["ft", "foot"]:
			unitText = "ft"
		elif unitType in ["yd", "yard"]:
			unitText = "yd"
		elif unitType in ["mi", "mile"]:
			unitText = "mi"
	
	return unitText

def getSpinBoxName(obj):
	if isinstance(obj, QFrameSpinBox):
		return obj.objectName()
	elif isinstance(obj, CustomSpinBox):
		return obj.parent().objectName()
	
	return None

def isChildWidget(childWidget, parentWidget):
	if all(isinstance(x, QtWidgets.QWidget) for x in [childWidget, parentWidget]):
		while childWidget is not None and childWidget is not parentWidget:
			childWidget = childWidget.parent()
		
		if childWidget:
			return True
		
		return False

class QFrameSpinBox(QtWidgets.QFrame):
	def __init__(self, parent=None):
		super(QFrameSpinBox, self).__init__(parent)
		
		layout = QtWidgets.QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.setSpacing(0)
		self.leftArrow = QLabelPixmap(":/nudgeLeft.png", 0.7, self)
		self.leftArrow.setMaximumWidth(12)
		self.leftArrow.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignVCenter)
		
		self.spinBox = CustomSpinBox(self)
		
		self.rightArrow = QLabelPixmap(":/nudgeRight.png", 0.7, self)
		self.rightArrow.setMaximumWidth(12)
		self.rightArrow.setAlignment(QtCore.Qt.AlignHCenter|QtCore.Qt.AlignVCenter)
		
		layout.addWidget(self.leftArrow)
		layout.addWidget(self.spinBox)
		layout.addWidget(self.rightArrow)
		
		self.lastModifiers = None
		self.pressPosition = QtCore.QPoint(0,0)
		self.ignoreDoubleClick = False
		self.sidesWidth = 16
		self.setDragState()
		
		# Set focus policy
		self.setFocusPolicy(QtCore.Qt.StrongFocus)
	
	def setDragState(self):
		self.editState = False
		#self.setReadOnly(True)
		self.setCursor(QtGui.QCursor(QtCore.Qt.SizeHorCursor))
		#self.selectionChanged.connect(self.selectionEvent)
		self.spinBox.setDragState()
		#self.setFocus()
		#self.leftArrow.setPixmapOpacity(0.7)
		#self.rightArrow.setPixmapOpacity(0.7)
	
	def setEditState(self):
		self.editState = True
		#self.setReadOnly(False)
		self.setCursor(QtGui.QCursor(QtCore.Qt.IBeamCursor))
		#self.selectionChanged.disconnect()
		self.spinBox.setEditState()
		#self.leftArrow.setPixmapOpacity(1)
		#self.rightArrow.setPixmapOpacity(1)
	
	def wheelEvent(self, event):
		self.spinBox.scrollEvent(event)
		
		super(QFrameSpinBox, self).wheelEvent(event)
	
	def mousePressEvent(self, event):
		#self.setFocus()
		self.ignoreDoubleClick = False
		#position = QtGui.QCursor.pos()
		#self.pressPosition = self.mapFromGlobal(position)
		self.pressPosition = event.pos()
		
		if self.editState is False:
			#self.setFocus()
			if event.buttons() in [QtCore.Qt.LeftButton, QtCore.Qt.MidButton, QtCore.Qt.RightButton]:
				self.spinBox.dragging = True
				self.value_at_press = self.spinBox.value()
				self.pos_at_press = event.pos()
				self.setDragState()
				return
		
		super(QFrameSpinBox, self).mousePressEvent(event)
	
	def mouseReleaseEvent(self, event):
		if self.editState is False:
			if event.button() in [QtCore.Qt.LeftButton, QtCore.Qt.MidButton, QtCore.Qt.RightButton]:
				self.spinBox.dragging = False
				
				if event.button() == QtCore.Qt.LeftButton:
					if abs(event.pos().x() - self.pos_at_press.x()) < 3:
						if self.pressPosition.x() <= self.sidesWidth:
							self.spinBox.incrementValue(event, 1)
							self.ignoreDoubleClick = True
							self.window().setFocus()
							return
						elif self.pressPosition.x() >= self.geometry().width() - self.sidesWidth:
							self.spinBox.incrementValue(event, 0)
							self.ignoreDoubleClick = True
							self.window().setFocus()
							return
					else:
						# Set value to emit signal after mouse drag
						self.spinBox.setValue(self.spinBox.value())
				
				self.window().setFocus()
				self.value_at_press = None
				self.pos_at_press = None
				return
			
		self.window().setFocus()
		super(QFrameSpinBox, self).mouseReleaseEvent(event)
	
	def mouseMoveEvent(self, event):
		if self.editState is False:
			if self.pos_at_press is None:
				return
			
			if event.buttons() == QtCore.Qt.LeftButton:
				if self.lastModifiers is None:
					self.lastModifiers = event.modifiers()
				elif self.lastModifiers != event.modifiers():
					self.lastModifiers = event.modifiers()
					self.value_at_press = self.spinBox.value()
					self.pos_at_press = event.pos()
				
				steps_mult = self.spinBox.getStepsMultiplier(event)

				delta = event.pos().x() - self.pos_at_press.x()
				delta /= 6  # Make movement less sensitive.
				delta *= self.spinBox.steps * steps_mult

				value = self.value_at_press + delta
				self.spinBox.setValue(value)
		
		super(QFrameSpinBox, self).mouseMoveEvent(event)
	
	def mouseDoubleClickEvent(self, event):
		if self.editState is False and self.ignoreDoubleClick is False:
			if event.button() == QtCore.Qt.LeftButton:
				self.setEditState()
				#self.spinBox.setFocus()
				#self.spinBox.selectAll()
				#self.setCursorPosition(self.pos_at_press.x())
		
		super(QFrameSpinBox, self).mouseDoubleClickEvent(event)
	
	def enterEvent(self, event):
		if self.isEnabled():
			self.leftArrow.setPixmapOpacity(1)
			self.rightArrow.setPixmapOpacity(1)
		self.setProperty("hover", True)
		self.setStyle(self.style())
		
		super(QFrameSpinBox, self).enterEvent(event)
	
	def leaveEvent(self, event):
		if self.isEnabled():
			self.leftArrow.setPixmapOpacity(0.7)
			self.rightArrow.setPixmapOpacity(0.7)
		self.setProperty("hover", False)
		self.setStyle(self.style())
		
		super(QFrameSpinBox, self).leaveEvent(event)
	
	def setEnabled(self, event):
		if not self.property("hover"):
			if event:
				self.leftArrow.setPixmapOpacity(0.7)
				self.rightArrow.setPixmapOpacity(0.7)
				self.spinBox.setReadOnly(not event) # for stylesheet
			else:
				self.leftArrow.setPixmapOpacity(0.5)
				self.rightArrow.setPixmapOpacity(0.5)
				self.spinBox.setReadOnly(not event) # for stylesheet
		
		super(QFrameSpinBox, self).setEnabled(event)

class CustomListView(QtWidgets.QListView):
	def __init__(self):
		super(CustomListView, self).__init__()
		
		self._padding = 0
		self.setPadding(self._padding)
		
		self.setMouseTracking(True)
		self.entered.connect(self.hoverEvent)
		
		self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
	
	def setPadding(self, padding):
		self.window().setContentsMargins(padding, padding, padding, padding)
		self._padding = padding
	
	def hoverEvent(self):
		if self.currentIndex().row() == self.model().rowCount() - 1:
			self.setProperty("class", "last")
			self.setStyle(self.style())
		else:
			self.setProperty("class", None)
			self.setStyle(self.style())
	
	def showEvent(self, event):
		self.hoverEvent()
		
		windowSize = self.window().size()
		self.window().resize(windowSize.width()+(self._padding*2)+1, windowSize.height())
		self.window().move(self.window().x()-self._padding-1, self.window().y()-self._padding)
		
		super(CustomListView, self).showEvent(event)

class QPieMenuComboBox(QtWidgets.QComboBox):
	def __init__(self, parent=None):
		super(QPieMenuComboBox, self).__init__(parent)
		
		self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
		
		self._view = CustomListView()
		self.setView(self._view)
		
		window_flags = QtCore.Qt.Popup | QtCore.Qt.FramelessWindowHint
		if hasattr(QtCore.Qt, "NoDropShadowWindowHint"):
			window_flags |= QtCore.Qt.NoDropShadowWindowHint
		self._view.window().setWindowFlags(window_flags)
		self._view.window().setAttribute(QtCore.Qt.WA_TranslucentBackground)
		
		self.setItemDelegate(QtWidgets.QStyledItemDelegate())
		
		self._arrowOpacity = 0.7
		
		# Disable focus
		self.setFocusPolicy(QtCore.Qt.NoFocus)
	
	def setPadding(self, padding):
		self._view.setPadding(padding)
	
	def setArrowOpacity(self, opacity):
		self._arrowOpacity = opacity
	
	def paintEvent(self, event):		
		painter = QtWidgets.QStylePainter(self)
		opt = QtWidgets.QStyleOptionComboBox()
		self.initStyleOption(opt)
		
		# Draw frame
		#painter.drawComplexControl(QtWidgets.QStyle.CC_ComboBox, opt)
		painter.drawPrimitive(QtWidgets.QStyle.PE_PanelButtonCommand, opt)
		
		# Draw label
		painter.setPen(self.palette().color(QtGui.QPalette.Text))
		painter.drawControl(QtWidgets.QStyle.CE_ComboBoxLabel, opt)
		
		# Draw down-arrow
		r = self.style().subControlRect(QtWidgets.QStyle.CC_ComboBox, opt, QtWidgets.QStyle.SC_ComboBoxArrow)
		opt.rect = QtCore.QRect(r.x()-2, r.y(), r.width(), r.height()) # need to subtract padding of QPieMenuComboBox.menuItemRight
		painter.setOpacity(self._arrowOpacity)
		painter.drawPrimitive(QtWidgets.QStyle.PE_IndicatorArrowDown, opt)
		
		painter.end()
	
	def showPopup(self):
		self.setProperty("activated", True)
		self.setStyle(self.style())
		if self.isEnabled():
			self.setArrowOpacity(1)
		
		super(QPieMenuComboBox, self).showPopup()
	
	def hidePopup(self):
		self.setProperty("activated", False)
		self.setStyle(self.style())
		if self.isEnabled():
			self.setArrowOpacity(0.7)
		
		super(QPieMenuComboBox, self).hidePopup()
	
	def currentIndex(self):		
		return super(QPieMenuComboBox, self).currentIndex()+1
	
	def setCurrentIndex(self, value):		
		return super(QPieMenuComboBox, self).setCurrentIndex(value-1)
	
	def enterEvent(self, event):
		self.setProperty("hover", True)
		self.setStyle(self.style())
		
		if not self._view.isVisible() and self.isEnabled():
			self.setArrowOpacity(1)
		
		super(QPieMenuComboBox, self).enterEvent(event)
	
	def leaveEvent(self, event):
		self.setProperty("hover", False)
		self.setStyle(self.style())
		
		if not self._view.isVisible() and self.isEnabled():
			self.setArrowOpacity(0.7)
		
		super(QPieMenuComboBox, self).leaveEvent(event)
	
	def setEnabled(self, event):
		if event:
			self.setArrowOpacity(0.7)
		else:
			self.setArrowOpacity(0.5)
		
		super(QPieMenuComboBox, self).setEnabled(event)

class QFrameLabel(QtWidgets.QFrame):
	def __init__(self, parent=None):
		super(QFrameLabel, self).__init__(parent)
		
		layout = QtWidgets.QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		self.label = QtWidgets.QLabel(self)
		spacerItem = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
		layout.addWidget(self.label)
		layout.addItem(spacerItem)
	
	def setText(self, text):
		self.label.setText(text)

class QFrameToggleButton(QtWidgets.QFrame):
	stateChanged = QtCore.Signal()
	
	def __init__(self, parent=None):
		super(QFrameToggleButton, self).__init__(parent)
		
		self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
		self.activated = False
		
		layout = QtWidgets.QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		self.label = QtWidgets.QLabel(self)
		spacerItem = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
		self.button = QtWidgets.QLabel(self)
		layout.addWidget(self.label)
		layout.addItem(spacerItem)
		layout.addWidget(self.button)
		self.setActivated(self.activated)
	
	def setText(self, text):
		self.label.setText(text)
	
	def toggleActivated(self):
		if self.activated is False:
			self.setActivated(True)
		else:
			self.setActivated(False)
	
	def isActivated(self):
		return self.activated

	def setActivated(self, value=False):
		value = bool(value)
		if value is False:
			self.activated = False
			self.setProperty("activated", False)
			self.label.setProperty("activated", False)
			self.button.setProperty("activated", False)
			self.button.setText("Off")
			self.setStyle(self.style())
			self.label.setStyle(self.label.style())
			self.button.setStyle(self.button.style())
		else:
			self.activated = True
			self.setProperty("activated", True)
			self.label.setProperty("activated", True)
			self.button.setProperty("activated", True)
			self.button.setText("On")
			self.setStyle(self.style())
			self.label.setStyle(self.label.style())
			self.button.setStyle(self.button.style())
		self.stateChanged.emit()
	
	def mousePressEvent(self, event):
		if event.buttons() == QtCore.Qt.LeftButton:
			self.toggleActivated()
		
		super(QFrameToggleButton, self).mousePressEvent(event)
	
	def enterEvent(self, event):
		self.setProperty("hover", True)
		self.label.setProperty("hover", True)
		self.button.setProperty("hover", True)
		self.setStyle(self.style())
		self.label.setStyle(self.label.style())
		self.button.setStyle(self.button.style())
		
		super(QFrameToggleButton, self).enterEvent(event)
		
	def leaveEvent(self, event):
		self.setProperty("hover", False)
		self.label.setProperty("hover", False)
		self.button.setProperty("hover", False)
		self.setStyle(self.style())
		self.label.setStyle(self.label.style())
		self.button.setStyle(self.button.style())
		
		super(QFrameToggleButton, self).leaveEvent(event)

class QFrameButton(QtWidgets.QFrame):
	clicked = QtCore.Signal()
	_is_pressed = False
	
	def __init__(self, parent=None):
		super(QFrameButton, self).__init__(parent)
		
		#self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
		self.activated = False
		
		layout = QtWidgets.QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		spacerLeft = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
		self.label = QtWidgets.QLabel(self)
		spacerRight = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
		layout.addItem(spacerLeft)
		layout.addWidget(self.label)
		layout.addItem(spacerRight)
	
	def setText(self, text):
		self.label.setText(text)
	
	def mouseReleaseEvent(self, event):
		if event.button() == QtCore.Qt.LeftButton:
			# Check if cursor still inside widget
			cursorPos = self.mapFromGlobal(QtGui.QCursor.pos())
			widgetSize = self.size()
			if not any([cursorPos.x() > widgetSize.width(), cursorPos.x() < 0, cursorPos.y() > widgetSize.height(), cursorPos.y() < 0]):
				if self.underMouse():
					self.clicked.emit()
			
			self._is_pressed = False
			self.setProperty("pressed", False)
			self.setStyle(self.style())
		
		super(QFrameButton, self).mouseReleaseEvent(event)

	def mousePressEvent(self, event):
		if event.button() == QtCore.Qt.LeftButton:
			self._is_pressed = True
			self.setProperty("pressed", True)
			self.setStyle(self.style())

		super(QFrameButton, self).mousePressEvent(event)

	def enterEvent(self, event):
		if self.isEnabled():
			self.setProperty("hover", True)
			self.setStyle(self.style())
		
		super(QFrameButton, self).enterEvent(event)

	def leaveEvent(self, event):
		if self.isEnabled():
			self.setProperty("hover", False)
			self.setStyle(self.style())
		
		super(QFrameButton, self).leaveEvent(event)

	def mouseMoveEvent(self, event):
		if event.buttons() == QtCore.Qt.LeftButton:
			# Check if cursor still inside widget
			cursorPos = self.mapFromGlobal(QtGui.QCursor.pos())
			widgetSize = self.size()
			if any([cursorPos.x() > widgetSize.width(), cursorPos.x() < 0, cursorPos.y() > widgetSize.height(), cursorPos.y() < 0]):
				self.setProperty("hover", False)
				self.setProperty("pressed", False)
				self.setStyle(self.style())
			else:
				self.setProperty("hover", True)
				if self._is_pressed:
					self.setProperty("pressed", True)
				self.setStyle(self.style())
		
		super(QFrameButton, self).mouseMoveEvent(event)
	
	def enterEvent(self, event):
		self.setProperty("hover", True)
		self.label.setProperty("hover", True)
		self.setStyle(self.style())
		self.label.setStyle(self.label.style())
		
		super(QFrameButton, self).enterEvent(event)
		
	def leaveEvent(self, event):
		self.setProperty("hover", False)
		self.label.setProperty("hover", False)
		self.setStyle(self.style())
		self.label.setStyle(self.label.style())
		
		super(QFrameButton, self).leaveEvent(event)

class CustomIntValidator(QtGui.QIntValidator):
	def __init__(self, parent=None):
		super(CustomIntValidator, self).__init__(parent)
		
		self.value = None
	
	def validate(self, text, pos):
		if self.value:
			text = str(self.value)
			self.value = None
		
		return super(CustomIntValidator, self).validate(text, pos)
	
	def fixup(self, value):
		if hasattr(self.parent(), "last_valid"):
			self.value = self.parent().last_valid
			return self.parent().last_valid
		
		return super(CustomIntValidator, self).fixup(value)

class CustomDoubleValidator(QtGui.QDoubleValidator):
	def __init__(self, parent=None):
		super(CustomDoubleValidator, self).__init__(parent)
		
		self.value = None
	
	def validate(self, text, pos):
		if self.value:
			text = str(self.value)
			self.value = None
		
		return super(CustomDoubleValidator, self).validate(text, pos)
	
	def fixup(self, value):
		if hasattr(self.parent(), "last_valid"):
			self.value = self.parent().last_valid
			return self.parent().last_valid
		
		return super(CustomDoubleValidator, self).fixup(value)

class CustomSpinBox(QtWidgets.QLineEdit):
	valueChanged = QtCore.Signal()
	def __init__(self, parent=None):
		super(CustomSpinBox, self).__init__(parent)
		
		self.dragging = False
		self.decimals = 2
		self.min = None
		self.max = None
		self.steps = 1
		self.spinbox_type = None
		
		self.insertUnit = False
		self.suffixLabel = QtWidgets.QLabel(self.parent())
		
		self.setSpinBoxType(CustomSpinBox.DoubleSpinBox)
		
		self.setValue(0)
		self.editingFinished.connect(self.editingFinishedEvent)
		self.setProperty("enabledStyle", True)
	
	def changeEvent(self, event):
		if self.insertUnit is False:
			self.setSpinBoxUnit(None)
		
		super(CustomSpinBox, self).changeEvent(event)
	
	def insertSpinBoxUnit(self):
		unitText = None
		if self.spinbox_unit == CustomSpinBox.LinearSpinBox:
			unitText = currentUnitString()
			
		elif self.spinbox_unit == CustomSpinBox.AngularSpinBox:
			unitText = currentUnitString(angle=True)
		
		if unitText:
			self.suffixLabel.setText(unitText)
		
		if self.insertUnit is False:
			self.insertUnit = True
			widgetIndex = 0
			for i in range(self.parent().layout().count()):
				if self.parent().layout().itemAt(i).widget() == self:
					break
				widgetIndex += 1
			self.parent().layout().insertWidget(widgetIndex+1, self.suffixLabel)

	@property
	def IntSpinBox():
		return 0
	
	@property
	def DoubleSpinBox():
		return 1
	
	@property
	def LinearSpinBox():
		return 0
	
	@property
	def AngularSpinBox():
		return 1
	
	def setDragState(self):
		self.setEnabled(False)
		
		#self.setProperty("enabledStyle", True)
		self.setProperty("activated", False)
		self.setStyle(self.style())
	
	def setEditState(self):
		self.setEnabled(True)
		self.setFocus()
		self.selectAll()
		
		#self.setProperty("enabledStyle", True)
		self.setProperty("activated", True)
		self.setStyle(self.style())
	
	def setSpinBoxType(self, type):
		self.spinbox_type = type
		if type == CustomSpinBox.IntSpinBox:
			self.setValidator(CustomIntValidator(parent=self))
		else:
			self.setValidator(CustomDoubleValidator(parent=self))
	
	def setSpinBoxUnit(self, unit):
		if unit in [None, CustomSpinBox.LinearSpinBox, CustomSpinBox.AngularSpinBox]:
			self.spinbox_unit = unit
			self.insertSpinBoxUnit()
	
	def setDecimals(self, decimals=2):
		self.decimals = decimals
	
	def setMinimum(self, value):
		self.min = value

	def setMaximum(self, value):
		self.max = value
	
	def setSteps(self, steps):
		if self.spinbox_type == CustomSpinBox.IntSpinBox:
			self.steps = max(steps, 1)
		else:
			self.steps = steps

	def setProperty(self, property, value):
		if property == "value" and not self.isEnabled():
			self.setValue(value)
		super(CustomSpinBox, self).setProperty(property, value)
	
	def value(self):
		if self.spinbox_type == CustomSpinBox.IntSpinBox:
			try:
				return int(self.text())
			except:
				return self.last_valid
		else:
			try:
				return float(self.text())
			except:
				return self.last_valid

	def setValue(self, value):
		if self.min is not None:
			value = max(value, self.min)

		if self.max is not None:
			value = min(value, self.max)

		if self.spinbox_type == CustomSpinBox.IntSpinBox:
			try:
				self.last_valid = int(value + 0)
			except:
				pass
			self.setText(str(self.last_valid))
		else:
			try:
				self.last_valid = float(value + 0)
			except:
				pass
			self.setText("{0:.{d}f}".format(self.last_valid, d=self.decimals))
	
	def setText(self, value):
		if self.dragging is False:
			self.valueChanged.emit()
		
		super(CustomSpinBox, self).setText(value)
	
	def incrementValue(self, event, operation=0):
		#self.dragging = False
		steps_mult = self.getStepsMultiplier(event)
		
		delta = self.steps * steps_mult
		if operation == 1:
			delta *= -1

		value = self.value() + delta
		
		self.setValue(value)
	
	def getStepsMultiplier(self, event):
		steps_mult = 1

		if event.modifiers() == QtCore.Qt.SHIFT:
			steps_mult = 10
		elif event.modifiers() == QtCore.Qt.CTRL:
			steps_mult = 0.1

		return steps_mult
	
	def scrollEvent(self, event):
		if event.delta() > 0:
			self.incrementValue(event, 0)
		else:
			self.incrementValue(event, 1)
	
	def editingFinishedEvent(self):
		if QtWidgets.QApplication.focusWidget() == self.parent():
			self.setFocus()
			return
		self.setValue(self.value())
		self.parent().setDragState()
		self.window().setFocus()
	
	def keyPressEvent(self, event):
		if event.key() == QtCore.Qt.Key_Escape:
			self.editingFinishedEvent()
			return

		super(CustomSpinBox, self).keyPressEvent(event)

class QLabelPixmap(QtWidgets.QLabel):
	def __init__(self, image, opacity=1, parent=None):
		super(QLabelPixmap, self).__init__(parent)
		
		self.image = image
		self.setPixmapOpacity(opacity)
	
	def setPixmapOpacity(self, opacity=1):
		#if not self.isEnabled():
			#opacity = 0.5
		
		self.opacity = opacity
		
		input = QtGui.QPixmap(self.image)
		output = QtGui.QPixmap(input.size())
		output.fill(QtCore.Qt.transparent)
		painter = QtGui.QPainter(output)
		painter.setOpacity(self.opacity)
		painter.drawPixmap(0, 0, input)
		painter.end()
		
		self.setPixmap(output)

class RadialRing(QtWidgets.QWidget):
	def __init__(self, windowParent):
		super(RadialRing, self).__init__(windowParent)
		
		#self.setMouseTracking(True)
		self._oldPos = QtCore.QPoint(self.window().x(), self.window().y())
		self.setCursor(QtGui.QCursor(QtCore.Qt.SizeAllCursor))
		
		# Radial Ring Settings
		self.ring_size = 13
		self.ring_width = 5
		self.ring_outline = 1
		self.arc_length = 72 # (0-360)
		self.ring_color = QtGui.QColor(40, 40, 40, 204)
		self.arc_color = QtGui.QColor(82, 133, 166, 255)

		# Main painter
		self.painter = QtGui.QPainter(self)
	
	def paintEvent(self, event):
		try:
			# init painter - QPainting on self does not work outside this method
			self.painter.begin(self)
			
			#self.painter.setRenderHint(QtGui.QPainter.Antialiasing)
			self.painter.setRenderHints(QtGui.QPainter.HighQualityAntialiasing)
			
			cursor_pos = self.mapFromGlobal(QtGui.QCursor.pos())
			center_pos = self.mapTo(self, self.rect().center())
			angle = (180 - (self.arc_length / 2)) - angleFromPoints(cursor_pos, center_pos)
			
			# Draw Ring Outline
			self.painter.setPen(QtGui.QPen(self.ring_color.darker(200), (self.ring_width + (self.ring_outline * 2)), QtCore.Qt.SolidLine))
			self.painter.drawEllipse(center_pos, self.ring_size, self.ring_size)
			
			# Draw Ring Background
			self.painter.setPen(QtGui.QPen(self.ring_color, self.ring_width, QtCore.Qt.SolidLine))
			self.painter.drawEllipse(center_pos, self.ring_size, self.ring_size)
			
			# Draw Arc
			ring_center = round(self.ring_size - (self.ring_width / 2))
			# Draw Arc if mouse is not inside the ring
			if all([center_pos.x()-ring_center < cursor_pos.x() < center_pos.x()+ring_center, center_pos.y()-ring_center < cursor_pos.y() < center_pos.y()+ring_center]) is False:
				self.painter.setPen(QtGui.QPen(self.arc_color, self.ring_width, QtCore.Qt.SolidLine))
				self.painter.drawArc(QtCore.QRectF(QtCore.QPoint(center_pos.x()-self.ring_size, center_pos.y()-self.ring_size), QtCore.QSize(self.ring_size*2, self.ring_size*2)), (angle*16), (self.arc_length*16))
			
			self.painter.end()
		except Exception as e:
			pass
	
	def mousePressEvent(self, event):
		self._oldPos = event.globalPos()

	def mouseMoveEvent(self, event):
		delta = QtCore.QPoint(event.globalPos() - self._oldPos)
		self.window().move(self.window().x() + delta.x(), self.window().y() + delta.y())
		self._oldPos = event.globalPos()

class QPieMenu(QtWidgets.QMainWindow):
	controlsCallbackSignal = QtCore.Signal(object)
	cursorMoveSignal = QtCore.Signal(object)
	visibilitySignal = QtCore.Signal(object)
	
	try:
		parentObject = wrapInstance(long(MQtUtil.mainWindow()), QtWidgets.QWidget)
	except:
		parentObject = None
	
	def __init__(self, windowParent=parentObject, ui_widget=None, ui_file=None):
		super(QPieMenu, self).__init__(windowParent)

		# If window already exists, delete window
		global BP_PieMenuInstance
		if "BP_PieMenuInstance" in globals():
			try:
				BP_PieMenuInstance.close()
			except:
				pass
		BP_PieMenuInstance = self
		
		self._window = None
		self._ui_file_name = None
		if ui_widget and isinstance(ui_widget, object):
			self._window = ui_widget
		elif isinstance(ui_file, six.string_types) and os.path.isfile(ui_file) and ui_file.endswith(".ui"):
			self._ui_file_name = ui_file
		
		self.windowName = "BevelPreview_PieMenu"
		# self.currentDir = path.dirname(path.realpath(__file__))
		# self._windowExists = True
		# self._closeWindow = False
		
		# Window object name
		self.setObjectName(self.windowName)
		# Window title
		#self.setWindowTitle("QPieMenu")
		# Window type
		window_flags = QtCore.Qt.Tool | QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint
		if hasattr(QtCore.Qt, "NoDropShadowWindowHint"):
			window_flags |= QtCore.Qt.NoDropShadowWindowHint
		self.setWindowFlags(window_flags)
		# Widget attributes
		self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
		self.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents)
		self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
		# Stylesheet
		self.bc = 30
		self.setStyleSheet(self.getStyleSheet())
		# Set focus policy
		#self.setFocusPolicy(QtCore.Qt.StrongFocus)
		
		self._ignoreControlsCallback = False
		self._lastCursorPos = None
		self.cursorMoveSignal.connect(self.cursorMoveEvent)
		self._pollCursorTimer = QtCore.QTimer(self)
		self._pollCursorTimer.setInterval(int(1000/60))
		self._pollCursorTimer.timeout.connect(self.pollCursor)
		self.createInputListener()

		# Create UI
		self.createUI()
		
		# Create UI Dictionary
		self.createUIDict()
		
		# Setup UI controls
		self.windowSetup()
		
		# Show UI
		self.initUI()
	
	def pollCursor(self):
		pos = QtGui.QCursor.pos()
		if pos != self._lastCursorPos:
			self._lastCursorPos = pos
			self.cursorMoveSignal.emit(pos)

		# If application is no longer active, disable visibility
		if not QtWidgets.QApplication.activeWindow():
			self.setVisibility(False)

	def cursorMoveEvent(self, pos):
		if self._window:
			self._window.RadialRing.update()

	def setMouseTracker(self, enable):
		self._lastCursorPos = None
		if enable:
			self._pollCursorTimer.start()
		else:
			self._pollCursorTimer.stop()

	def createInputListener(self):
		self._inputListener = InputListener()
		self._pressedKey = None
		self._inputListener.onPressSignal.connect(self.on_press)
		self._inputListener.onReleaseSignal.connect(self.on_release)
		self._inputListener.onClickSignal.connect(self.on_click)

	def getInputListener(self):
		return self._inputListener
	
	def startInputListener(self):
		if isinstance(self._inputListener, InputListener):
			self._inputListener.start()
	
	def stopInputListener(self):
		if isinstance(self._inputListener, InputListener):
			self._inputListener.stop()
		self.createInputListener()
	
	def on_press(self, key):
		if not QtWidgets.QApplication.focusWidget() or QtWidgets.QApplication.focusWidget() == self or QtWidgets.QApplication.focusWidget().window() != self:
			if str(key) == "Key.esc":
				if self.isVisible():
					self.setVisibility(False)
		
		self._pressedKey = key
	
	def on_release(self, key):
		self._pressedKey = None

	def on_click(self, x, y, button, pressed):
		if not QtWidgets.QApplication.focusWidget() or QtWidgets.QApplication.focusWidget() == self or QtWidgets.QApplication.focusWidget().window() != self:
			if all([button == "right", pressed, not self._pressedKey]):
				if self.isVisible():
					self.setVisibility(False)

	def getStyleSheet(self):
		# Set stylesheet according to background color
		backgroundValue = int(round(cmds.displayRGBColor("background", query=True, hueSaturationValue=True)[2] * 255))
		self.bc = min(backgroundValue - 15, 30)
		return ("""
			QWidget:disabled{
				color: rgba(90, 90, 90, 100%%);
			}
			
			QWidget, CustomSpinBox:!read-only{
				color: rgba(210, 210, 210, 100%%);
			}
			
			QLabel[activated=true]{
				color: rgba(255, 255, 255, 100%%);
			}

			CustomSpinBox{
				background-color: rgba(0, 0, 0, 0%%);
				border: none;
			}
			
			QFrame.menuItem, QFrame.menuItemMiddle, QFrame.menuItemLeft, QFrame.menuItemRight, QPieMenuComboBox.menuItemRight{
				border: 1px solid rgba(%(bc)s, %(bc)s, %(bc)s, 80%%);
				background-color: rgba(82, 82, 82, 80%%);
				padding: 4 8 4 8px;
			}
			
			QFrame.menuItem:disabled, QFrame.menuItemMiddle:disabled, QFrame.menuItemLeft:disabled, QFrame.menuItemRight:disabled, QPieMenuComboBox.menuItemRight:disabled{
				background-color: rgba(64, 64, 64, 80%%);
			}
			
			QFrame.menuItem:enabled[activated=true], QFrame.menuItemMiddle:enabled[activated=true], QFrame.menuItemLeft:enabled[activated=true], QFrame.menuItemRight:enabled[activated=true]{
				/*background-color: rgba(82, 133, 166, 80%%);*/
				background-color: qlineargradient(x1: 0,
					y1: 0,
					x2: 1,
					y2: 0,
					stop: 0 rgba(82, 133, 166, 80%%),
					stop: 1 rgba(82, 133, 166, 80%%));
			}
			
			QFrame.menuItem:enabled[hover=true], QFrame.menuItemMiddle:enabled[hover=true], QFrame.menuItemLeft:enabled[hover=true], QFrame.menuItemRight:enabled[hover=true]{
				background-color: rgba(91, 91, 91, 80%%);
			}
			
			QFrame.menuItem:enabled[activated=true][hover=true], QFrame.menuItemMiddle:enabled[activated=true][hover=true], QFrame.menuItemLeft:enabled[activated=true][hover=true], QFrame.menuItemRight:enabled[activated=true][hover=true]{
				background-color: rgba(91, 148, 186, 80%%);
			}
			
			QFrame.menuItemRight CustomSpinBox[activated=true]{
				background-color: rgba(43, 43, 43, 100%%);
			}

			QFrameSpinBox.menuItemRight, QFrameButton.menuItem, QFrameButton.menuItemMiddle, QFrameButton.menuItemLeft, QFrameButton.menuItemRight, QPieMenuComboBox.menuItemRight{
				background-color: rgba(64, 64, 64, 80%%);
			}

			QFrameSpinBox.menuItemRight:enabled[hover=true], QFrameButton.menuItem:enabled[hover=true], QFrameButton.menuItemMiddle:enabled[hover=true], QFrameButton.menuItemLeft:enabled[hover=true], QFrameButton.menuItemRight:enabled[hover=true], QPieMenuComboBox.menuItemRight:enabled[hover=true]{
				background-color: rgba(73, 73, 73, 80%%);
			}

			QFrameButton.menuItem:enabled[pressed=true], QFrameButton.menuItemMiddle:enabled[pressed=true], QFrameButton.menuItemLeft:enabled[pressed=true], QFrameButton.menuItemRight:enabled[pressed=true]{
				background-color: rgba(46, 46, 46, 80%%);
			}
			
			QFrame.menuItem{
				border-radius: 6px;
			}

			QFrame.menuItemMiddle{
				border-left: 0px;
			}
			
			QFrame.menuItemLeft{
				border-top-left-radius: 6px;
				border-bottom-left-radius: 6px;
			}
			
			QFrame.menuItemRight, QPieMenuComboBox.menuItemRight{
				border-top-right-radius: 6px;
				border-bottom-right-radius: 6px;
				border-left: 0px;
				padding: 4 2 4 2px;
			}
			
			QPieMenuComboBox.menuItemRight{
				padding: 0 0 0 4px;
			}
			
			QPieMenuComboBox.menuItemRight[activated=true]{
				border-bottom-right-radius: 0px;
			}
			
			QPieMenuComboBox:on{
				background-color: rgba(64, 64, 64, 80%%);
			}

			QPieMenuComboBox::drop-down{
				border: none;
				padding: 0 4 0 0px;
				subcontrol-origin: padding;
				subcontrol-position: top right;
			}

			QPieMenuComboBox::down-arrow{
				image: url(:/nudgeDown.png);
			}
			
			QPieMenuComboBox QAbstractItemView{
				outline: none;
				border: 1px solid rgba(%(bc)s, %(bc)s, %(bc)s, 80%%);
				background-color: rgba(82, 82, 82, 80%%);
				padding: 0px;
				border-bottom-left-radius: 6px;
				border-bottom-right-radius: 6px;
			}
			
			QPieMenuComboBox QAbstractItemView::item{
				border: none;
				padding: 4px;
			}
			
			QPieMenuComboBox QAbstractItemView::item:selected{
				background-color: rgba(82, 133, 166, 80%%);
			}
			
			QPieMenuComboBox QAbstractItemView.last::item{
				border-bottom-left-radius: 5px;
				border-bottom-right-radius: 5px;
			}
		""" % {"bc": self.bc})
	
	def addWidgetShadow(self, target, shadowRadius=8, shadowOpacity=70):
		shadowEffect = QtWidgets.QGraphicsDropShadowEffect(self)
		shadowEffect.setBlurRadius(shadowRadius)
		shadowEffect.setXOffset(0)
		shadowEffect.setYOffset(0)
		shadowEffect.setColor(QtGui.QColor(0, 0, 0, int(round(255/100*shadowOpacity))))
		target.setGraphicsEffect(shadowEffect)
	
	def createUIDict(self):
		default_factory = (lambda: defaultdict(dict))
		self.UIDict = defaultdict(default_factory)
		for widget in self.findChildren(QtWidgets.QWidget):
			if isinstance(widget, QFrameToggleButton):
				self.UIDict[widget]["type"] = QFrameToggleButton
				self.UIDict[widget]["value"] = widget.activated
				self.UIDict[widget]["optionVar"] = widget.objectName()
			elif isinstance(widget, QFrameSpinBox):
				self.UIDict[widget]["type"] = QFrameSpinBox
				self.UIDict[widget]["value"] = widget.spinBox.value()
				self.UIDict[widget]["optionVar"] = widget.objectName()
			elif isinstance(widget, QPieMenuComboBox):
				self.UIDict[widget]["type"] = QPieMenuComboBox
				self.UIDict[widget]["value"] = widget.currentIndex()
				self.UIDict[widget]["optionVar"] = widget.objectName()
	
	def windowSetup(self):
		# Query optionVar
		settings = self.querySettings()
		for widget, widgetDict in six.iteritems(self.UIDict):
			if isinstance(widget, QFrameToggleButton):
				widget.setActivated(settings[widgetDict["optionVar"]])
			elif isinstance(widget, QFrameSpinBox):
				widget.spinBox.setProperty("value", settings[widgetDict["optionVar"]])
			elif isinstance(widget, QPieMenuComboBox):
				widget.setCurrentIndex(settings[widgetDict["optionVar"]])
		# Update controls
		#self.controlsCallback()
	
	def saveOptionVar(self, name, type, value, refresh=0):
		# int
		if type in [QFrameToggleButton, QPieMenuComboBox]:
			cmds.optionVar(intValue=(name, value))
		# float
		elif type in [QFrameSpinBox]:
			cmds.optionVar(floatValue=(name, value))
		if refresh == 1:
			self.windowSetup()
	
	def saveSettings(self, save):
		for widget, widgetDict in six.iteritems(self.UIDict):
			if "optionVar" in widgetDict and "value" in widgetDict:
				# Create non-existing optionVar / Reset
				if (cmds.optionVar(exists=widgetDict["optionVar"]) is False or save == 2):					
					self.saveOptionVar(widgetDict["optionVar"], widgetDict["type"], widgetDict["value"])
				# Save
				if save == 1:
					if widgetDict["type"] == QFrameToggleButton:
						controlValue = widget.activated
					elif widgetDict["type"] == QFrameSpinBox:
						controlValue = widget.spinBox.value()
					elif widgetDict["type"] == QPieMenuComboBox:
						controlValue = widget.currentIndex()
					if "controlValue" in locals():
						self.saveOptionVar(widgetDict["optionVar"], widgetDict["type"], controlValue)
	
	def resetSettings(self):
		# Reset settings
		self.saveSettings(2)
		# Update controls
		self.windowSetup()
	
	def querySettings(self):
		# Create non-existing optionVar
		self.saveSettings(0)
		queryDict = defaultdict()
		for widgetDict in six.itervalues(self.UIDict):
			if "optionVar" in widgetDict:
				queryDict[widgetDict["optionVar"]] = cmds.optionVar(query=widgetDict["optionVar"])
		return queryDict
	
	def controlsCallback(self):
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		#settings = self.querySettings()
		
		if not self._ignoreControlsCallback:
			self.controlsCallbackSignal.emit(self.sender())
	
	def setDisabledControls(self):
		if not self.getControlValue("visibility"):
			self._window.BP_TogglexRay.setEnabled(False)
			self._window.BP_TogglexRay.setActivated(False)
			self._window.BP_ToggleShading.setEnabled(False)
			self._window.BP_ToggleShading.setActivated(False)

		elif not self.getControlValue("shading"):
			self._window.BP_TogglexRay.setEnabled(False)
			self._window.BP_TogglexRay.setActivated(False)

	def setControlsValue(self, settingsDict, enabled=True):
		if not self._window:
			return
		
		self._ignoreControlsCallback = True
		try:
			if isinstance(settingsDict, dict):
				self._window.BP_RealTime.setEnabled(True)
				self._window.BP_WireframeOpacityValue.setEnabled(True)
				self._window.BP_BevelOffsetValue.setEnabled(True)
				self._window.BP_ToggleShading.setEnabled(True)
				self._window.BP_TogglexRay.setEnabled(True)
				self._window.BP_ToggleBevelDisplay.setEnabled(True)
				self._window.BP_WeightedNormals.setEnabled(True)

				if "visibility" in settingsDict:
					self._window.BP_ToggleBevelDisplay.setActivated(settingsDict["visibility"])
				elif not enabled:
					self._window.BP_ToggleBevelDisplay.setEnabled(False)
					self._window.BP_ToggleBevelDisplay.setActivated(False)
				
				if "xRay" in settingsDict:
					self._window.BP_TogglexRay.setActivated(settingsDict["xRay"])
				elif not enabled:
					self._window.BP_TogglexRay.setEnabled(False)
					self._window.BP_TogglexRay.setActivated(False)

				if "shading" in settingsDict:
					self._window.BP_ToggleShading.setActivated(settingsDict["shading"])
				elif not enabled:
					self._window.BP_ToggleShading.setEnabled(False)
					self._window.BP_ToggleShading.setActivated(False)

				if "realTime" in settingsDict:
					self._window.BP_RealTime.setActivated(settingsDict["realTime"])
				elif not enabled:
					self._window.BP_RealTime.setEnabled(False)
					self._window.BP_RealTime.setActivated(False)
				
				if "weightedNormals" in settingsDict:
					self._window.BP_WeightedNormals.setActivated(settingsDict["weightedNormals"])
				elif not enabled:
					self._window.BP_WeightedNormals.setEnabled(False)
					self._window.BP_WeightedNormals.setActivated(False)

				if "wireframeOpacity" in settingsDict:
					self._window.BP_WireframeOpacityValue.spinBox.setProperty("value", settingsDict["wireframeOpacity"])
				elif not enabled:
					self._window.BP_WireframeOpacityValue.setEnabled(False)
					self._window.BP_WireframeOpacityValue.spinBox.setProperty("value", 0)
				
				if "offset" in settingsDict:
					self._window.BP_BevelOffsetValue.spinBox.setProperty("value", settingsDict["offset"])
				elif not enabled:
					self._window.BP_BevelOffsetValue.setEnabled(False)
					self._window.BP_BevelOffsetValue.spinBox.setProperty("value", 0)
				
				if enabled:
					self.setDisabledControls()
			
			elif isinstance(settingsDict, (list, tuple)) and len(settingsDict) > 1:
				if settingsDict[0] == "cageDisplay":
					#self._window.BP_ContextShading.setActivated(settingsDict[1])
					self._window.BP_CageDisplayValue.setCurrentIndex(settingsDict[1])
					
		finally:
			self._ignoreControlsCallback = False

	def getControlValue(self, controlName):
		if not self._window:
			return
		
		if controlName == "visibility":
			return self._window.BP_ToggleBevelDisplay.isActivated()
		
		if controlName == "xRay":
			return self._window.BP_TogglexRay.isActivated()

		if controlName == "shading":
			return self._window.BP_ToggleShading.isActivated()
		
		if controlName == "weightedNormals":
			return self._window.BP_WeightedNormals.isActivated()

		if controlName == "realTime":
			return self._window.BP_RealTime.isActivated()

		if controlName == "wireframeOpacity":
			return self._window.BP_WireframeOpacityValue.spinBox.value()
		
		if controlName == "bevelOffset":
			return self._window.BP_BevelOffsetValue.spinBox.value()
	
		if controlName == "cageDisplay":
			#return self._window.BP_ContextShading.isActivated()
			return self._window.BP_CageDisplayValue.currentIndex()

	def createUI(self):	
		# Load window from .py
		if self._window:
			CentralWidget = QtWidgets.QWidget(self)
			CentralWidget.setObjectName("CentralWidget")
			self._window.setupUi(CentralWidget)
			self.setCentralWidget(CentralWidget)
		
		# Load window from .ui file
		elif self._ui_file_name:				
			# Create .ui loader
			loader = QtUiTools.QUiLoader()
			for customWidget in [RadialRing, QFrameButton, QFrameToggleButton, QFrameSpinBox, QFrameLabel, QPieMenuComboBox]:
				loader.registerCustomWidget(customWidget)
			
			# Load .ui file
			ui_file = QtCore.QFile(self._ui_file_name)
			if not ui_file.exists():
				return
			
			ui_file.open(QtCore.QFile.ReadOnly)
			self._window = loader.load(ui_file)
			ui_file.close()
			
			# Attach window to QMainWindow
			self.setCentralWidget(self._window)
		
		else:
			return
		
		# UI Controls
		self._window.BP_Create.setText("Create / Recompute")
		self._window.BP_Reconnect.setText("Reconnect")
		self._window.BP_Remove.setText("Remove")
		self._window.BP_Clear.setText("Clear")
		self._window.BP_BakeLabel.setText("Bake:")
		self._window.BP_BakeSelected.setText("Selected")
		self._window.BP_BakeAll.setText("All")
		self._window.BP_BevelLabel.setText("Bevel:")
		self._window.BP_EditBevel.setText("Edit")
		self._window.BP_TransferBevelSettings.setText("Transfer")
		self._window.BP_ToggleBevelDisplay.setText("Enable Bevel Display:")
		self._window.BP_TogglexRay.setText("Enable xRay:")
		self._window.BP_ToggleShading.setText("Enable Shading:")
		self._window.BP_WireframeOpacity.setText("Wireframe Opacity:")
		self._window.BP_BevelOffset.setText("Bevel Offset:")
		self._window.BP_RealTime.setText("Real-Time:")
		self._window.BP_CageDisplay.setText("Cage Display:")
		self._window.BP_CageDisplayValue.addItems(["Default", "Context Shading", "Component Mode"])
		self._window.BP_WeightedNormals.setText("Weighted Normals:")
		
		self._window.BP_WireframeOpacityValue.spinBox.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
		self._window.BP_WireframeOpacityValue.spinBox.setDecimals(3)
		self._window.BP_WireframeOpacityValue.spinBox.setMinimum(0.0)
		self._window.BP_WireframeOpacityValue.spinBox.setMaximum(1.0)
		self._window.BP_WireframeOpacityValue.spinBox.setSteps(0.01)
		self._window.BP_WireframeOpacityValue.spinBox.setProperty("value", 0.2)
		#self._window.BP_WireframeOpacityValue.spinBox.setSpinBoxUnit(CustomSpinBox.LinearSpinBox)
		
		self._window.BP_BevelOffsetValue.spinBox.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
		self._window.BP_BevelOffsetValue.spinBox.setDecimals(3)
		self._window.BP_BevelOffsetValue.spinBox.setMinimum(0.0)
		#self._window.BP_BevelOffsetValue.spinBox.setMaximum(5.0)
		self._window.BP_BevelOffsetValue.spinBox.setSteps(0.05)
		self._window.BP_BevelOffsetValue.spinBox.setProperty("value", 1)
		self._window.BP_BevelOffsetValue.spinBox.setSpinBoxUnit(CustomSpinBox.LinearSpinBox)

		self._window.BP_CageDisplayValue.setPadding(5)

		self._window.BP_Create.setProperty("class", "menuItem")
		self._window.BP_Reconnect.setProperty("class", "menuItem")
		self._window.BP_Remove.setProperty("class", "menuItemLeft")
		self._window.BP_Clear.setProperty("class", "menuItemRight")
		self._window.BP_BakeLabel.setProperty("class", "menuItemLeft")
		self._window.BP_BakeSelected.setProperty("class", "menuItemMiddle")
		self._window.BP_BakeAll.setProperty("class", "menuItemRight")
		self._window.BP_BevelLabel.setProperty("class", "menuItemLeft")
		self._window.BP_EditBevel.setProperty("class", "menuItemMiddle")
		self._window.BP_TransferBevelSettings.setProperty("class", "menuItemRight")
		self._window.BP_ToggleBevelDisplay.setProperty("class", "menuItem")
		self._window.BP_TogglexRay.setProperty("class", "menuItem")
		self._window.BP_ToggleShading.setProperty("class", "menuItem")
		self._window.BP_WeightedNormals.setProperty("class", "menuItem")
		self._window.BP_RealTime.setProperty("class", "menuItem")
		self._window.BP_CageDisplay.setProperty("class", "menuItemLeft")
		self._window.BP_CageDisplayValue.setProperty("class", "menuItemRight")
		self._window.BP_WireframeOpacity.setProperty("class", "menuItemLeft")
		self._window.BP_WireframeOpacityValue.setProperty("class", "menuItemRight")
		self._window.BP_BevelOffset.setProperty("class", "menuItemLeft")
		self._window.BP_BevelOffsetValue.setProperty("class", "menuItemRight")
		
		# fix for python 3 compatibility
		shadowOpacity = 70
		if sys.version_info[0] > 2:
			shadowOpacity *= 0.8
		
		self.addWidgetShadow(self._window.RadialRing, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_Create, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_Reconnect, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_Remove_Frame, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_Bake_Frame, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_ToggleBevelDisplay, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_TogglexRay, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_ToggleShading, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_WeightedNormals, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_WireframeOpacity_Frame, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_RealTime, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_CageDisplay_Frame, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_Bevel_Frame, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_BevelOffset_Frame, shadowOpacity=shadowOpacity)
		self.addWidgetShadow(self._window.BP_CageDisplayValue.view().window(), shadowOpacity=shadowOpacity)		
		
		self._window.BP_ToggleBevelDisplay.stateChanged.connect(self.controlsCallback)
		self._window.BP_TogglexRay.stateChanged.connect(self.controlsCallback)
		self._window.BP_ToggleShading.stateChanged.connect(self.controlsCallback)
		self._window.BP_WeightedNormals.stateChanged.connect(self.controlsCallback)
		self._window.BP_RealTime.stateChanged.connect(self.controlsCallback)
		#self._window.BP_ContextShading.stateChanged.connect(self.controlsCallback)
		self._window.BP_CageDisplayValue.currentIndexChanged.connect(self.controlsCallback)
		self._window.BP_BevelOffsetValue.spinBox.textChanged.connect(self.controlsCallback)
		self._window.BP_WireframeOpacityValue.spinBox.textChanged.connect(self.controlsCallback)
		self._window.BP_Create.clicked.connect(self.controlsCallback)
		self._window.BP_Reconnect.clicked.connect(self.controlsCallback)
		self._window.BP_Remove.clicked.connect(self.controlsCallback)
		self._window.BP_Clear.clicked.connect(self.controlsCallback)
		self._window.BP_BakeSelected.clicked.connect(self.controlsCallback)
		self._window.BP_BakeAll.clicked.connect(self.controlsCallback)
		self._window.BP_EditBevel.clicked.connect(self.controlsCallback)
		self._window.BP_TransferBevelSettings.clicked.connect(self.controlsCallback)
		
		# Window size
		self.resize(self.sizeHint())
	
	def setVisibility(self, visibility=True):
		if not self._window:
			return
		
		if visibility is True:
			# Enable cursor tracker
			self.setMouseTracker(True)

			# Show window
			self.show()
			
			# Move window position
			cursorPos = QtGui.QCursor.pos()
			centerPosition = self._window.RadialRing.mapTo(self, self._window.RadialRing.rect().center())

			# Get offset from left spacer (variable is not accessible for unknown reasons)
			for i in range(self._window.BP_RealTime_MainLayout.count()):
				item = self._window.BP_RealTime_MainLayout.itemAt(i)
				if isinstance(item, QtWidgets.QSpacerItem):
					leftOffset = item.geometry().width()
					break

			# Get current screen size
			screen = QtWidgets.QApplication.desktop().screenNumber(cursorPos)
			screenSize = QtWidgets.QApplication.desktop().screenGeometry(screen)

			# Calculate min/max screen position for window
			screenMinX = screenSize.x()+centerPosition.x() - leftOffset
			screenMinY = screenSize.y()+centerPosition.y()
			screenMaxX = screenSize.x()+screenSize.width() - (self.width()-centerPosition.x())
			screenMaxY = screenSize.y()+screenSize.height() - (self.height()-centerPosition.y())
			cursorPosX, cursorPosY = clamp(cursorPos.x(), screenMinX, screenMaxX), clamp(cursorPos.y(), screenMinY, screenMaxY)
			
			# Offset window from center
			posX, posY = cursorPosX-centerPosition.x(), cursorPosY-centerPosition.y()
			
			# Set window position
			self.move(posX, posY)
			
			# Turn window visibility on
			self.setWindowOpacity(1)
			
			# Enable focus
			self.setFocusPolicy(QtCore.Qt.StrongFocus)
			self.setFocus()

			# Start input listener
			self.startInputListener()
		
		else:
			# Disable cursor tracker
			self.setMouseTracker(False)

			# Hide window
			self.hide()
			# Turn window visibility off
			self.setWindowOpacity(0)
			
			# Disable focus
			self.setFocusPolicy(QtCore.Qt.NoFocus)
			self.clearFocus()

			# Stop input listener
			self.stopInputListener()

		self.visibilitySignal.emit(visibility)

	def toggleVisibility(self):
		if self.isVisible() is False:
			self.setVisibility(True)
		else:
			self.setVisibility(False)
	
	def initUI(self):
		# Show window
		if self._window:
			# Disable focus
			self.setFocusPolicy(QtCore.Qt.NoFocus)
			# Turn window visibility off
			self.setWindowOpacity(0)
			# Show window
			self.show()
			# Hide Window
			self.hide()
