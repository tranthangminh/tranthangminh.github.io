#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds
import os

ROOT_DIR = os.path.dirname(os.path.realpath(__file__))

class LoadScript(object):
	def getIconPath(self, iconName):
		return os.path.join(ROOT_DIR, os.path.join("icons", iconName))

	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Normal Toolkit")
		self.scriptLoader.setToolDocumentation("/docs/normaltoolkit-overview/")
		self.scriptLoader.setStartupFile("NormalToolkit.mel")
		self.scriptLoader.setStartupFunc("NT_Startup")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Mesh Tools")
		self.scriptLoader.setMenuItemDict({"image": self.getIconPath("NormalT_mainIcon.png"), "subMenu": True, "tearOff": True})
		self.scriptLoader.setMenuItemFunc(self.createMenuItem)
		return self.scriptLoader
	
	def createMenuItem(self):
		cmds.menuItem(label="Normal Toolkit", image=self.getIconPath("NormalT_mainIcon.png"), sourceType="mel", command="NormalToolkit")
		# Edit Mesh
		cmds.menuItem(divider=True, dividerLabel="Edit Mesh")
		cmds.menuItem(label="Smart Bevel", image="polyBevel.png", sourceType="mel", command="SmartBevel", dragDoubleClickCommand="SmartBevelOptions")
		cmds.menuItem(image="polyBevel.png", optionBox=True, sourceType="mel", command="SmartBevelOptions")
		# Mesh Display
		cmds.menuItem(divider=True, dividerLabel="Mesh Display")
		cmds.menuItem(label="Process Normals", image="polyNormalAverage.png", sourceType="mel", command="ProcessNormals", dragDoubleClickCommand="ProcessNormalsOptions")
		cmds.menuItem(image="polyNormalAverage.png", optionBox=True, sourceType="mel", command="ProcessNormalsOptions")
		cmds.menuItem(label="Reset Normals", image="polyNormalUnlock.png", sourceType="mel", command="ResetNormals")
		cmds.menuItem(label="Lock Normals", image="polyNormalLock.png", sourceType="mel", command="gLockNormals")
		cmds.menuItem(label="Display Normals", image="polyNormalsPropagate.png", sourceType="mel", command="DisplayNormals")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Fix Weighted Normals", image="polySetVertexNormal.png", sourceType="mel", command="FixWeightedNormals")
		cmds.menuItem(label="Transfer Normals Tool", image="polyTransferAttributes.png", sourceType="mel", command="TransferNormalsTool")
		# Soften/Harden Edges
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Soften Edge Only", image="polySoftEdge.png", sourceType="mel", command="SoftenEdgeOnly")
		cmds.menuItem(label="Harden Edge Only", image="polyHardEdge.png", sourceType="mel", command="HardenEdgeOnly")
		# Selection Set
		cmds.menuItem(divider=True, dividerLabel="Selection Set")
		cmds.menuItem(label="View Bevel Set", image="highlightSelect.png", sourceType="mel", command="ViewBevelSet")
		cmds.menuItem(label="Add To Bevel Set", image="setEdAddCmd.png", sourceType="mel", command="AddToBevelSet")
		cmds.menuItem(label="Remove From Bevel Set", image="setEdRemoveCmd.png", sourceType="mel", command="RemoveFromBevelSet")
		cmds.menuItem(label="Clear Bevel Set", image="clearCanvas.png", sourceType="mel", command="ClearBevelSet")
		cmds.menuItem(divider=True)
		cmds.menuItem(label="View Fillet Set", image="highlightSelect.png", sourceType="mel", command="ViewFilletSet")
		cmds.menuItem(label="Add To Fillet Set", image="setEdAddCmd.png", sourceType="mel", command="AddToFilletSet")
		cmds.menuItem(label="Remove From Fillet Set", image="setEdRemoveCmd.png", sourceType="mel", command="RemoveFromFilletSet")
		cmds.menuItem(label="Clear Fillet Set", image="clearCanvas.png", sourceType="mel", command="ClearFilletSet")
		# Select
		cmds.menuItem(divider=True, dividerLabel="Select")
		cmds.menuItem(label="Triplanar Selection", image="polySelectUsingConstraints.png", sourceType="mel", command="TriplanarSelection", dragDoubleClickCommand="TriplanarSelectionOptions")
		cmds.menuItem(image="polySelectUsingConstraints.png", optionBox=True, sourceType="mel", command="TriplanarSelectionOptions")
		cmds.menuItem(label="Select Bevel Faces", image="polySelectFacePath.png", sourceType="mel", command="SelectBevelFaces")
		# Select Soft/Hard Edges
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Convert To Soft Edges", image="polyConvertToContainedEdges.png", sourceType="mel", command="ConvertToSoftEdges")
		cmds.menuItem(label="Select All Soft Edges", image="polyConvertToContainedEdges.png", sourceType="mel", command="SelectAllSoftEdges")
		cmds.menuItem(label="Convert To Hard Edges", image="polyConvertToShellBorder.png", sourceType="mel", command="ConvertToHardEdges")
		cmds.menuItem(label="Select All Hard Edges", image="polyConvertToShellBorder.png", sourceType="mel", command="SelectAllHardEdges")