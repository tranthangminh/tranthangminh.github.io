#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
from collections import OrderedDict, defaultdict

# for python 3 compatibility
import six

from .selections import getCurrentSel, componentListIntersection, getComponentCount

def getObjectMaterials(*args, **kwargs):
	# Create default args
	objects = []
	getObjectsFromSel = True
	objectMaterialsDict = defaultdict(dict)
	
	# Load arguments (override default args)
	for arg in args:
		if isinstance(arg, (list, tuple)):
			objects.extend(arg)
			getObjectsFromSel = False
		elif isinstance(arg, six.string_types):
			objects.append(arg)
			getObjectsFromSel = False
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			if isinstance(value, (list, tuple)):
				objects = value
				getObjectsFromSel = False
			elif isinstance(value, six.string_types):
				objects = [value]
				getObjectsFromSel = False
	
	if not objects and getObjectsFromSel:
		objects = getCurrentSel()[2]
	else:
		objects = cmds.ls(objects, long=True)
    
	if objects:
		# For each objects
		for obj in objects:
			if cmds.objectType(obj) == "transform":
				objectTransform = obj
				objectShape = next(iter(cmds.listRelatives(obj, fullPath=True, noIntermediate=True, shapes=True) or []), None)
			elif cmds.objectType(obj) == "mesh":
				objectTransform = next(iter(cmds.listRelatives(obj, fullPath=True, parent=True) or []), None)
				objectShape = obj

			if not objectShape:
				continue
			
			shadingGroups = cmds.listConnections(objectShape, type="shadingEngine", source=False, destination=True) or []
			shadingGroups = list(OrderedDict.fromkeys(shadingGroups)) # Remove duplicates
			
			if shadingGroups:
				# For each materials
				for shadingGroupName in shadingGroups:
					#materialName = cmds.ls(cmds.listConnections(shadingGroupName), materials=True)[0]
					materialFaces = []

					tempSet = "{0}.f[*]".format(objectShape)
					intersectionSet = []
					for x in cmds.ls(cmds.sets(shadingGroupName, query=True), long=True):
						xs = x.split(".", 1)
						if len(xs) > 1:
							if xs[0] == objectTransform:
								intersectionSet.append("{0}.{1}".format(objectShape, xs[-1]))
							elif xs[0] == objectShape:
								intersectionSet.append(x)

					if intersectionSet:
						materialFaces = componentListIntersection(tempSet, intersectionSet)
					elif len(shadingGroups) == 1:
						materialFaces = ["{0}.f[0:{1}]".format(objectShape, cmds.polyEvaluate(objectShape, face=True)-1)]

					if materialFaces:
						if shadingGroupName in objectMaterialsDict[objectTransform]:
							objectMaterialsDict[objectTransform][shadingGroupName].extend(materialFaces)
						else:
							objectMaterialsDict[objectTransform][shadingGroupName] = materialFaces
	
	return objectMaterialsDict

def getMainMaterial(*args, **kwargs):
	objectMaterialsDict = getObjectMaterials(*args, **kwargs)
	mainMaterialsDict = {}
    
	if objectMaterialsDict:
		# For each objects
		for obj, matDict in six.iteritems(objectMaterialsDict):			
			maxMatCount = 0

			for shadingGroupName, materialFaces in six.iteritems(matDict):
				materialCount = getComponentCount(materialFaces)
				
				if materialCount > maxMatCount:
					maxMatCount = materialCount
					mainMaterialsDict[obj] = shadingGroupName
	
	return mainMaterialsDict