# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'MarkingMenu_ui.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

try:
    from PySide2.QtCore import *
    from PySide2.QtGui import *
    from PySide2.QtWidgets import *
except:
    from PySide.QtCore import *
    from PySide.QtGui import *

from .MarkingMenu import RadialRing
from .MarkingMenu import QFrameButton
from .MarkingMenu import QFrameSpinBox
from .MarkingMenu import QFrameLabel
from .MarkingMenu import QPieMenuComboBox
from .MarkingMenu import QFrameToggleButton


class Ui_CentralWidget(object):
    def setupUi(self, CentralWidget):
        if not CentralWidget.objectName():
            CentralWidget.setObjectName(u"CentralWidget")
        CentralWidget.resize(542, 413)
        self.CentralLayout = QVBoxLayout(CentralWidget)
        self.CentralLayout.setSpacing(5)
        self.CentralLayout.setObjectName(u"CentralLayout")
        self.CentralLayout.setContentsMargins(5, 5, 5, 5)
        self.CentralWidget_SpacerTop = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.CentralLayout.addItem(self.CentralWidget_SpacerTop)

        self.BP_Create_MainLayout = QHBoxLayout()
        self.BP_Create_MainLayout.setSpacing(0)
        self.BP_Create_MainLayout.setObjectName(u"BP_Create_MainLayout")
        self.BP_Create_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Create_MainLayout.addItem(self.BP_Create_SpacerLeft)

        self.BP_Create = QFrameButton(CentralWidget)
        self.BP_Create.setObjectName(u"BP_Create")
        self.BP_Create.setMinimumSize(QSize(180, 24))
        self.BP_Create.setMaximumSize(QSize(180, 24))
        self.BP_Create_Layout = QHBoxLayout(self.BP_Create)
        self.BP_Create_Layout.setSpacing(0)
        self.BP_Create_Layout.setObjectName(u"BP_Create_Layout")
        self.BP_Create_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Create_MainLayout.addWidget(self.BP_Create)

        self.BP_Create_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Create_MainLayout.addItem(self.BP_Create_SpacerRight)


        self.CentralLayout.addLayout(self.BP_Create_MainLayout)

        self.BP_Reconnect_MainLayout = QHBoxLayout()
        self.BP_Reconnect_MainLayout.setSpacing(0)
        self.BP_Reconnect_MainLayout.setObjectName(u"BP_Reconnect_MainLayout")
        self.BP_Reconnect_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Reconnect_MainLayout.addItem(self.BP_Reconnect_SpacerLeft)

        self.BP_Reconnect = QFrameButton(CentralWidget)
        self.BP_Reconnect.setObjectName(u"BP_Reconnect")
        self.BP_Reconnect.setMinimumSize(QSize(180, 24))
        self.BP_Reconnect.setMaximumSize(QSize(180, 24))
        self.BP_Reconnect_Layout = QHBoxLayout(self.BP_Reconnect)
        self.BP_Reconnect_Layout.setSpacing(0)
        self.BP_Reconnect_Layout.setObjectName(u"BP_Reconnect_Layout")
        self.BP_Reconnect_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Reconnect_MainLayout.addWidget(self.BP_Reconnect)

        self.BP_Reconnect_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Reconnect_MainLayout.addItem(self.BP_Reconnect_SpacerRight)


        self.CentralLayout.addLayout(self.BP_Reconnect_MainLayout)

        self.BP_Remove_MainLayout = QHBoxLayout()
        self.BP_Remove_MainLayout.setSpacing(0)
        self.BP_Remove_MainLayout.setObjectName(u"BP_Remove_MainLayout")
        self.BP_Remove_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Remove_MainLayout.addItem(self.BP_Remove_SpacerLeft)

        self.BP_Remove_Frame = QFrame(CentralWidget)
        self.BP_Remove_Frame.setObjectName(u"BP_Remove_Frame")
        self.BP_Remove_Frame.setMinimumSize(QSize(180, 24))
        self.BP_Remove_Frame.setMaximumSize(QSize(180, 24))
        self.BP_Remove_FrameLayout = QHBoxLayout(self.BP_Remove_Frame)
        self.BP_Remove_FrameLayout.setSpacing(0)
        self.BP_Remove_FrameLayout.setObjectName(u"BP_Remove_FrameLayout")
        self.BP_Remove_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.BP_Remove = QFrameButton(self.BP_Remove_Frame)
        self.BP_Remove.setObjectName(u"BP_Remove")
        self.BP_Remove_Layout = QHBoxLayout(self.BP_Remove)
        self.BP_Remove_Layout.setSpacing(0)
        self.BP_Remove_Layout.setObjectName(u"BP_Remove_Layout")
        self.BP_Remove_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Remove_FrameLayout.addWidget(self.BP_Remove)

        self.BP_Clear = QFrameButton(self.BP_Remove_Frame)
        self.BP_Clear.setObjectName(u"BP_Clear")
        self.BP_Clear_Layout = QHBoxLayout(self.BP_Clear)
        self.BP_Clear_Layout.setSpacing(0)
        self.BP_Clear_Layout.setObjectName(u"BP_Clear_Layout")
        self.BP_Clear_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Remove_FrameLayout.addWidget(self.BP_Clear)


        self.BP_Remove_MainLayout.addWidget(self.BP_Remove_Frame)

        self.BP_Remove_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Remove_MainLayout.addItem(self.BP_Remove_SpacerRight)


        self.CentralLayout.addLayout(self.BP_Remove_MainLayout)

        self.BP_Bake_MainLayout = QHBoxLayout()
        self.BP_Bake_MainLayout.setSpacing(0)
        self.BP_Bake_MainLayout.setObjectName(u"BP_Bake_MainLayout")
        self.BP_Bake_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Bake_MainLayout.addItem(self.BP_Bake_SpacerLeft)

        self.BP_Bake_Frame = QFrame(CentralWidget)
        self.BP_Bake_Frame.setObjectName(u"BP_Bake_Frame")
        self.BP_Bake_Frame.setMinimumSize(QSize(180, 24))
        self.BP_Bake_Frame.setMaximumSize(QSize(180, 24))
        self.BP_Bake_FrameLayout = QHBoxLayout(self.BP_Bake_Frame)
        self.BP_Bake_FrameLayout.setSpacing(0)
        self.BP_Bake_FrameLayout.setObjectName(u"BP_Bake_FrameLayout")
        self.BP_Bake_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.BP_BakeLabel = QFrameLabel(self.BP_Bake_Frame)
        self.BP_BakeLabel.setObjectName(u"BP_BakeLabel")
        self.BP_BakeLabel.setMinimumSize(QSize(50, 24))
        self.BP_BakeLabel.setMaximumSize(QSize(50, 24))
        self.BP_BakeLabel_Layout = QHBoxLayout(self.BP_BakeLabel)
        self.BP_BakeLabel_Layout.setSpacing(0)
        self.BP_BakeLabel_Layout.setObjectName(u"BP_BakeLabel_Layout")
        self.BP_BakeLabel_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Bake_FrameLayout.addWidget(self.BP_BakeLabel)

        self.BP_BakeSelected = QFrameButton(self.BP_Bake_Frame)
        self.BP_BakeSelected.setObjectName(u"BP_BakeSelected")
        self.BP_BakeSelected_Layout = QHBoxLayout(self.BP_BakeSelected)
        self.BP_BakeSelected_Layout.setSpacing(0)
        self.BP_BakeSelected_Layout.setObjectName(u"BP_BakeSelected_Layout")
        self.BP_BakeSelected_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Bake_FrameLayout.addWidget(self.BP_BakeSelected)

        self.BP_BakeAll = QFrameButton(self.BP_Bake_Frame)
        self.BP_BakeAll.setObjectName(u"BP_BakeAll")
        self.BP_BakeAll_Layout = QHBoxLayout(self.BP_BakeAll)
        self.BP_BakeAll_Layout.setSpacing(0)
        self.BP_BakeAll_Layout.setObjectName(u"BP_BakeAll_Layout")
        self.BP_BakeAll_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Bake_FrameLayout.addWidget(self.BP_BakeAll)


        self.BP_Bake_MainLayout.addWidget(self.BP_Bake_Frame)

        self.BP_Bake_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Bake_MainLayout.addItem(self.BP_Bake_SpacerRight)


        self.CentralLayout.addLayout(self.BP_Bake_MainLayout)

        self.BP_Bevel_MainLayout = QHBoxLayout()
        self.BP_Bevel_MainLayout.setSpacing(0)
        self.BP_Bevel_MainLayout.setObjectName(u"BP_Bevel_MainLayout")
        self.BP_Bevel_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Bevel_MainLayout.addItem(self.BP_Bevel_SpacerLeft)

        self.BP_Bevel_Frame = QFrame(CentralWidget)
        self.BP_Bevel_Frame.setObjectName(u"BP_Bevel_Frame")
        self.BP_Bevel_Frame.setMinimumSize(QSize(180, 24))
        self.BP_Bevel_Frame.setMaximumSize(QSize(180, 24))
        self.BP_Bevel_FrameLayout = QHBoxLayout(self.BP_Bevel_Frame)
        self.BP_Bevel_FrameLayout.setSpacing(0)
        self.BP_Bevel_FrameLayout.setObjectName(u"BP_Bevel_FrameLayout")
        self.BP_Bevel_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.BP_BevelLabel = QFrameLabel(self.BP_Bevel_Frame)
        self.BP_BevelLabel.setObjectName(u"BP_BevelLabel")
        self.BP_BevelLabel.setMinimumSize(QSize(50, 24))
        self.BP_BevelLabel.setMaximumSize(QSize(50, 24))
        self.BP_BevelLabel_Layout = QHBoxLayout(self.BP_BevelLabel)
        self.BP_BevelLabel_Layout.setSpacing(0)
        self.BP_BevelLabel_Layout.setObjectName(u"BP_BevelLabel_Layout")
        self.BP_BevelLabel_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Bevel_FrameLayout.addWidget(self.BP_BevelLabel)

        self.BP_EditBevel = QFrameButton(self.BP_Bevel_Frame)
        self.BP_EditBevel.setObjectName(u"BP_EditBevel")
        self.BP_EditBevel_Layout = QHBoxLayout(self.BP_EditBevel)
        self.BP_EditBevel_Layout.setSpacing(0)
        self.BP_EditBevel_Layout.setObjectName(u"BP_EditBevel_Layout")
        self.BP_EditBevel_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Bevel_FrameLayout.addWidget(self.BP_EditBevel)

        self.BP_TransferBevelSettings = QFrameButton(self.BP_Bevel_Frame)
        self.BP_TransferBevelSettings.setObjectName(u"BP_TransferBevelSettings")
        self.BP_TransferBevelSettings_Layout = QHBoxLayout(self.BP_TransferBevelSettings)
        self.BP_TransferBevelSettings_Layout.setSpacing(0)
        self.BP_TransferBevelSettings_Layout.setObjectName(u"BP_TransferBevelSettings_Layout")
        self.BP_TransferBevelSettings_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_Bevel_FrameLayout.addWidget(self.BP_TransferBevelSettings)


        self.BP_Bevel_MainLayout.addWidget(self.BP_Bevel_Frame)

        self.BP_Bevel_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_Bevel_MainLayout.addItem(self.BP_Bevel_SpacerRight)


        self.CentralLayout.addLayout(self.BP_Bevel_MainLayout)

        self.Middle_MainLayout = QHBoxLayout()
        self.Middle_MainLayout.setSpacing(0)
        self.Middle_MainLayout.setObjectName(u"Middle_MainLayout")
        self.Middle_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.Middle_MainLayout.addItem(self.Middle_SpacerLeft)

        self.Middle_FrameRight = QFrame(CentralWidget)
        self.Middle_FrameRight.setObjectName(u"Middle_FrameRight")
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Middle_FrameRight.sizePolicy().hasHeightForWidth())
        self.Middle_FrameRight.setSizePolicy(sizePolicy)
        self.Middle_FrameRight_Layout = QVBoxLayout(self.Middle_FrameRight)
        self.Middle_FrameRight_Layout.setSpacing(0)
        self.Middle_FrameRight_Layout.setObjectName(u"Middle_FrameRight_Layout")
        self.Middle_FrameRight_Layout.setContentsMargins(0, 0, 10, 0)
        self.Middle_FrameRight_SpacerTop = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameRight_Layout.addItem(self.Middle_FrameRight_SpacerTop)

        self.BP_RealTime_MainLayout = QHBoxLayout()
        self.BP_RealTime_MainLayout.setSpacing(0)
        self.BP_RealTime_MainLayout.setObjectName(u"BP_RealTime_MainLayout")
        self.BP_RealTime_MainLayout.setContentsMargins(5, 5, 5, 5)
        self.BP_RealTime_SpacerLeft = QSpacerItem(80, 0, QSizePolicy.MinimumExpanding, QSizePolicy.Minimum)

        self.BP_RealTime_MainLayout.addItem(self.BP_RealTime_SpacerLeft)

        self.BP_RealTime = QFrameToggleButton(self.Middle_FrameRight)
        self.BP_RealTime.setObjectName(u"BP_RealTime")
        self.BP_RealTime.setMinimumSize(QSize(140, 24))
        self.BP_RealTime.setMaximumSize(QSize(140, 24))
        self.BP_RealTime_Layout = QHBoxLayout(self.BP_RealTime)
        self.BP_RealTime_Layout.setSpacing(0)
        self.BP_RealTime_Layout.setObjectName(u"BP_RealTime_Layout")
        self.BP_RealTime_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_RealTime_MainLayout.addWidget(self.BP_RealTime)


        self.Middle_FrameRight_Layout.addLayout(self.BP_RealTime_MainLayout)

        self.Middle_FrameRight_SpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameRight_Layout.addItem(self.Middle_FrameRight_SpacerBottom)


        self.Middle_MainLayout.addWidget(self.Middle_FrameRight)

        self.RadialRing = RadialRing(CentralWidget)
        self.RadialRing.setObjectName(u"RadialRing")
        self.RadialRing.setMinimumSize(QSize(50, 50))
        self.RadialRing.setMaximumSize(QSize(50, 50))

        self.Middle_MainLayout.addWidget(self.RadialRing)

        self.Middle_FrameLeft = QFrame(CentralWidget)
        self.Middle_FrameLeft.setObjectName(u"Middle_FrameLeft")
        sizePolicy.setHeightForWidth(self.Middle_FrameLeft.sizePolicy().hasHeightForWidth())
        self.Middle_FrameLeft.setSizePolicy(sizePolicy)
        self.Middle_FrameLeft_Layout = QVBoxLayout(self.Middle_FrameLeft)
        self.Middle_FrameLeft_Layout.setSpacing(0)
        self.Middle_FrameLeft_Layout.setObjectName(u"Middle_FrameLeft_Layout")
        self.Middle_FrameLeft_Layout.setContentsMargins(10, 0, 0, 0)
        self.Middle_FrameLeft_SpacerTop = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameLeft_Layout.addItem(self.Middle_FrameLeft_SpacerTop)

        self.BP_CageDisplay_MainLayout = QHBoxLayout()
        self.BP_CageDisplay_MainLayout.setSpacing(0)
        self.BP_CageDisplay_MainLayout.setObjectName(u"BP_CageDisplay_MainLayout")
        self.BP_CageDisplay_MainLayout.setContentsMargins(5, 5, 5, 5)
        self.BP_CageDisplay_Frame = QFrame(self.Middle_FrameLeft)
        self.BP_CageDisplay_Frame.setObjectName(u"BP_CageDisplay_Frame")
        self.BP_CageDisplay_Frame.setMinimumSize(QSize(220, 24))
        self.BP_CageDisplay_Frame.setMaximumSize(QSize(220, 24))
        self.BP_CageDisplay_FrameLayout = QHBoxLayout(self.BP_CageDisplay_Frame)
        self.BP_CageDisplay_FrameLayout.setSpacing(0)
        self.BP_CageDisplay_FrameLayout.setObjectName(u"BP_CageDisplay_FrameLayout")
        self.BP_CageDisplay_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.BP_CageDisplay = QFrameLabel(self.BP_CageDisplay_Frame)
        self.BP_CageDisplay.setObjectName(u"BP_CageDisplay")
        self.BP_CageDisplay_Layout = QHBoxLayout(self.BP_CageDisplay)
        self.BP_CageDisplay_Layout.setSpacing(0)
        self.BP_CageDisplay_Layout.setObjectName(u"BP_CageDisplay_Layout")
        self.BP_CageDisplay_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_CageDisplay_FrameLayout.addWidget(self.BP_CageDisplay)

        self.BP_CageDisplayValue = QPieMenuComboBox(self.BP_CageDisplay_Frame)
        self.BP_CageDisplayValue.setObjectName(u"BP_CageDisplayValue")
        self.BP_CageDisplayValue.setMinimumSize(QSize(120, 24))
        self.BP_CageDisplayValue.setMaximumSize(QSize(120, 24))

        self.BP_CageDisplay_FrameLayout.addWidget(self.BP_CageDisplayValue)


        self.BP_CageDisplay_MainLayout.addWidget(self.BP_CageDisplay_Frame)

        self.BP_ContextShading_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.MinimumExpanding, QSizePolicy.Minimum)

        self.BP_CageDisplay_MainLayout.addItem(self.BP_ContextShading_SpacerLeft)


        self.Middle_FrameLeft_Layout.addLayout(self.BP_CageDisplay_MainLayout)

        self.Middle_FrameLeft_SpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameLeft_Layout.addItem(self.Middle_FrameLeft_SpacerBottom)


        self.Middle_MainLayout.addWidget(self.Middle_FrameLeft)

        self.Middle_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.Middle_MainLayout.addItem(self.Middle_SpacerRight)


        self.CentralLayout.addLayout(self.Middle_MainLayout)

        self.BP_ToggleBevelDisplay_MainLayout = QHBoxLayout()
        self.BP_ToggleBevelDisplay_MainLayout.setSpacing(0)
        self.BP_ToggleBevelDisplay_MainLayout.setObjectName(u"BP_ToggleBevelDisplay_MainLayout")
        self.BP_ToggleBevelDisplay_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_ToggleBevelDisplay_MainLayout.addItem(self.BP_ToggleBevelDisplay_SpacerLeft)

        self.BP_ToggleBevelDisplay = QFrameToggleButton(CentralWidget)
        self.BP_ToggleBevelDisplay.setObjectName(u"BP_ToggleBevelDisplay")
        self.BP_ToggleBevelDisplay.setMinimumSize(QSize(200, 24))
        self.BP_ToggleBevelDisplay.setMaximumSize(QSize(200, 24))
        self.BP_ToggleBevelDisplay_Layout = QHBoxLayout(self.BP_ToggleBevelDisplay)
        self.BP_ToggleBevelDisplay_Layout.setSpacing(0)
        self.BP_ToggleBevelDisplay_Layout.setObjectName(u"BP_ToggleBevelDisplay_Layout")
        self.BP_ToggleBevelDisplay_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_ToggleBevelDisplay_MainLayout.addWidget(self.BP_ToggleBevelDisplay)

        self.BP_ToggleBevelDisplay_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_ToggleBevelDisplay_MainLayout.addItem(self.BP_ToggleBevelDisplay_SpacerRight)


        self.CentralLayout.addLayout(self.BP_ToggleBevelDisplay_MainLayout)

        self.BP_TogglexRay_MainLayout = QHBoxLayout()
        self.BP_TogglexRay_MainLayout.setSpacing(0)
        self.BP_TogglexRay_MainLayout.setObjectName(u"BP_TogglexRay_MainLayout")
        self.BP_TogglexRay_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_TogglexRay_MainLayout.addItem(self.BP_TogglexRay_SpacerLeft)

        self.BP_TogglexRay = QFrameToggleButton(CentralWidget)
        self.BP_TogglexRay.setObjectName(u"BP_TogglexRay")
        self.BP_TogglexRay.setMinimumSize(QSize(200, 24))
        self.BP_TogglexRay.setMaximumSize(QSize(200, 24))
        self.BP_TogglexRay_Layout = QHBoxLayout(self.BP_TogglexRay)
        self.BP_TogglexRay_Layout.setSpacing(0)
        self.BP_TogglexRay_Layout.setObjectName(u"BP_TogglexRay_Layout")
        self.BP_TogglexRay_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_TogglexRay_MainLayout.addWidget(self.BP_TogglexRay)

        self.BP_TogglexRay_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_TogglexRay_MainLayout.addItem(self.BP_TogglexRay_SpacerRight)


        self.CentralLayout.addLayout(self.BP_TogglexRay_MainLayout)

        self.BP_ToggleShading_MainLayout = QHBoxLayout()
        self.BP_ToggleShading_MainLayout.setSpacing(0)
        self.BP_ToggleShading_MainLayout.setObjectName(u"BP_ToggleShading_MainLayout")
        self.BP_ToggleShading_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_ToggleShading_MainLayout.addItem(self.BP_ToggleShading_SpacerLeft)

        self.BP_ToggleShading = QFrameToggleButton(CentralWidget)
        self.BP_ToggleShading.setObjectName(u"BP_ToggleShading")
        self.BP_ToggleShading.setMinimumSize(QSize(200, 24))
        self.BP_ToggleShading.setMaximumSize(QSize(200, 24))
        self.BP_ToggleShading_Layout = QHBoxLayout(self.BP_ToggleShading)
        self.BP_ToggleShading_Layout.setSpacing(0)
        self.BP_ToggleShading_Layout.setObjectName(u"BP_ToggleShading_Layout")
        self.BP_ToggleShading_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_ToggleShading_MainLayout.addWidget(self.BP_ToggleShading)

        self.BP_ToggleShading_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_ToggleShading_MainLayout.addItem(self.BP_ToggleShading_SpacerRight)


        self.CentralLayout.addLayout(self.BP_ToggleShading_MainLayout)

        self.BP_WireframeOpacity_MainLayout = QHBoxLayout()
        self.BP_WireframeOpacity_MainLayout.setSpacing(0)
        self.BP_WireframeOpacity_MainLayout.setObjectName(u"BP_WireframeOpacity_MainLayout")
        self.BP_WireframeOpacity_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_WireframeOpacity_MainLayout.addItem(self.BP_WireframeOpacity_SpacerLeft)

        self.BP_WireframeOpacity_Frame = QFrame(CentralWidget)
        self.BP_WireframeOpacity_Frame.setObjectName(u"BP_WireframeOpacity_Frame")
        self.BP_WireframeOpacity_Frame.setMinimumSize(QSize(200, 24))
        self.BP_WireframeOpacity_Frame.setMaximumSize(QSize(200, 24))
        self.BP_WireframeOpacity_FrameLayout = QHBoxLayout(self.BP_WireframeOpacity_Frame)
        self.BP_WireframeOpacity_FrameLayout.setSpacing(0)
        self.BP_WireframeOpacity_FrameLayout.setObjectName(u"BP_WireframeOpacity_FrameLayout")
        self.BP_WireframeOpacity_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.BP_WireframeOpacity = QFrameLabel(self.BP_WireframeOpacity_Frame)
        self.BP_WireframeOpacity.setObjectName(u"BP_WireframeOpacity")
        self.BP_WireframeOpacity.setMinimumSize(QSize(120, 24))
        self.BP_WireframeOpacity.setMaximumSize(QSize(120, 24))
        self.BP_WireframeOpacity_Layout = QHBoxLayout(self.BP_WireframeOpacity)
        self.BP_WireframeOpacity_Layout.setSpacing(0)
        self.BP_WireframeOpacity_Layout.setObjectName(u"BP_WireframeOpacity_Layout")
        self.BP_WireframeOpacity_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_WireframeOpacity_FrameLayout.addWidget(self.BP_WireframeOpacity)

        self.BP_WireframeOpacityValue = QFrameSpinBox(self.BP_WireframeOpacity_Frame)
        self.BP_WireframeOpacityValue.setObjectName(u"BP_WireframeOpacityValue")
        self.BP_WireframeOpacityValue_Layout = QHBoxLayout(self.BP_WireframeOpacityValue)
        self.BP_WireframeOpacityValue_Layout.setSpacing(0)
        self.BP_WireframeOpacityValue_Layout.setObjectName(u"BP_WireframeOpacityValue_Layout")
        self.BP_WireframeOpacityValue_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_WireframeOpacity_FrameLayout.addWidget(self.BP_WireframeOpacityValue)


        self.BP_WireframeOpacity_MainLayout.addWidget(self.BP_WireframeOpacity_Frame)

        self.BP_WireframeOpacity_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_WireframeOpacity_MainLayout.addItem(self.BP_WireframeOpacity_SpacerRight)


        self.CentralLayout.addLayout(self.BP_WireframeOpacity_MainLayout)

        self.BP_BevelOffset_MainLayout = QHBoxLayout()
        self.BP_BevelOffset_MainLayout.setSpacing(0)
        self.BP_BevelOffset_MainLayout.setObjectName(u"BP_BevelOffset_MainLayout")
        self.BP_BevelOffset_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_BevelOffset_MainLayout.addItem(self.BP_BevelOffset_SpacerLeft)

        self.BP_BevelOffset_Frame = QFrame(CentralWidget)
        self.BP_BevelOffset_Frame.setObjectName(u"BP_BevelOffset_Frame")
        self.BP_BevelOffset_Frame.setMinimumSize(QSize(200, 24))
        self.BP_BevelOffset_Frame.setMaximumSize(QSize(200, 24))
        self.BP_BevelOffset_FrameLayout = QHBoxLayout(self.BP_BevelOffset_Frame)
        self.BP_BevelOffset_FrameLayout.setSpacing(0)
        self.BP_BevelOffset_FrameLayout.setObjectName(u"BP_BevelOffset_FrameLayout")
        self.BP_BevelOffset_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.BP_BevelOffset = QFrameLabel(self.BP_BevelOffset_Frame)
        self.BP_BevelOffset.setObjectName(u"BP_BevelOffset")
        self.BP_BevelOffset.setMinimumSize(QSize(120, 24))
        self.BP_BevelOffset.setMaximumSize(QSize(120, 24))
        self.BP_BevelOffset_Layout = QHBoxLayout(self.BP_BevelOffset)
        self.BP_BevelOffset_Layout.setSpacing(0)
        self.BP_BevelOffset_Layout.setObjectName(u"BP_BevelOffset_Layout")
        self.BP_BevelOffset_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_BevelOffset_FrameLayout.addWidget(self.BP_BevelOffset)

        self.BP_BevelOffsetValue = QFrameSpinBox(self.BP_BevelOffset_Frame)
        self.BP_BevelOffsetValue.setObjectName(u"BP_BevelOffsetValue")
        self.BP_BevelOffsetValue_Layout = QHBoxLayout(self.BP_BevelOffsetValue)
        self.BP_BevelOffsetValue_Layout.setSpacing(0)
        self.BP_BevelOffsetValue_Layout.setObjectName(u"BP_BevelOffsetValue_Layout")
        self.BP_BevelOffsetValue_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_BevelOffset_FrameLayout.addWidget(self.BP_BevelOffsetValue)


        self.BP_BevelOffset_MainLayout.addWidget(self.BP_BevelOffset_Frame)

        self.BP_BevelOffset_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_BevelOffset_MainLayout.addItem(self.BP_BevelOffset_SpacerRight)


        self.CentralLayout.addLayout(self.BP_BevelOffset_MainLayout)

        self.BP_WeightedNormals_MainLayout = QHBoxLayout()
        self.BP_WeightedNormals_MainLayout.setSpacing(0)
        self.BP_WeightedNormals_MainLayout.setObjectName(u"BP_WeightedNormals_MainLayout")
        self.BP_WeightedNormals_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_WeightedNormals_MainLayout.addItem(self.BP_WeightedNormals_SpacerLeft)

        self.BP_WeightedNormals = QFrameToggleButton(CentralWidget)
        self.BP_WeightedNormals.setObjectName(u"BP_WeightedNormals")
        self.BP_WeightedNormals.setMinimumSize(QSize(200, 24))
        self.BP_WeightedNormals.setMaximumSize(QSize(200, 24))
        self.BP_WeightedNormals_Layout = QHBoxLayout(self.BP_WeightedNormals)
        self.BP_WeightedNormals_Layout.setSpacing(0)
        self.BP_WeightedNormals_Layout.setObjectName(u"BP_WeightedNormals_Layout")
        self.BP_WeightedNormals_Layout.setContentsMargins(0, 0, 0, 0)

        self.BP_WeightedNormals_MainLayout.addWidget(self.BP_WeightedNormals)

        self.BP_WeightedNormals_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.BP_WeightedNormals_MainLayout.addItem(self.BP_WeightedNormals_SpacerRight)


        self.CentralLayout.addLayout(self.BP_WeightedNormals_MainLayout)

        self.CentralWidget_SpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.CentralLayout.addItem(self.CentralWidget_SpacerBottom)


        self.retranslateUi(CentralWidget)

        QMetaObject.connectSlotsByName(CentralWidget)
    # setupUi

    def retranslateUi(self, CentralWidget):
        CentralWidget.setWindowTitle(QCoreApplication.translate("CentralWidget", u"Form", None))
    # retranslateUi

