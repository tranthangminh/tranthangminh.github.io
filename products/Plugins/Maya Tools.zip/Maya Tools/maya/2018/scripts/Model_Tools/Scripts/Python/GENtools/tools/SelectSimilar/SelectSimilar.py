#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as OpenMaya
import maya.api.OpenMaya as om
from collections import defaultdict
from collections import OrderedDict
from functools import partial
from re import split as reSplit
from webbrowser import open_new_tab

# for python 3 compatibility
import six
from six.moves import range

from ...core.gui.options import OptionsWindow, helpCmd

def isclose(a, b, rt=0.000000001, at=0):
    return abs(a-b) <= max(rt * max(abs(a), abs(b)), at)

def CenterWindow(windowName):
    if cmds.window(windowName, ex=True) is True:
        gMainWindow = mel.eval("$gMainWindow = $gMainWindow")
        gMainWindowWidth = (cmds.window(gMainWindow, q=True, w=True)/2)
        gMainWindowHeight = (cmds.window(gMainWindow, q=True, h=True)/2)
        leftPosition = gMainWindowWidth-(cmds.window(windowName, q=True, w=True)/2)
        topPosition = gMainWindowHeight-(cmds.window(windowName, q=True, h=True)/2)
        cmds.window(windowName, e=True, le=leftPosition, te=topPosition)
        return [topPosition, leftPosition]

def ProgressBarWindow(**kwargs):
	title = "Progress Window"
	width = 300
	height = 25
	minValue = 0
	maxValue = 100
	centered = True
	for key, value in six.iteritems(kwargs):
		if key == "name" or key == "n":
			name = value
		elif key == "title" or key == "t":
			title = value
		elif key == "width" or key == "w":
			width = value
		elif key == "height" or key == "h":
			height = value
		elif key == "minValue" or key == "min":
			minValue = value
		elif key == "maxValue" or key == "max":
			maxValue = value
		elif key == "centered" or key == "c":
			centered = value
	
	if "name" in locals():
		if(cmds.window(name, ex=True) is True):
			cmds.deleteUI(name, wnd=True)
		progressWin = cmds.window(name, t=title, s=False, mxb=False, tlb=True)
	else:
		progressWin = cmds.window(t=title, s=False, mxb=False, tlb=True)
	cmds.formLayout("mainForm")
	progressBarName = cmds.progressBar(min=minValue, max=maxValue)
	cmds.setParent("..")
	
	cmds.formLayout("mainForm", e=True, af=[(progressBarName, "top", 0), (progressBarName, "left", 0), (progressBarName, "right", 0), (progressBarName, "bottom", 0)])
	
	cmds.showWindow(progressWin)
	cmds.window(progressWin, e=True, wh=(width, height), rtf=True)
	if centered is True:
		CenterWindow(progressWin)
	
	return progressWin, progressBarName

def GetIsolatedObjects():
	isolatedObjects = None
	activeModelPanel = cmds.getPanel(wf=True)
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is False:
		activeModelPanel = "modelPanel4"
	
	if cmds.modelEditor(activeModelPanel, q=True, ex=True) is True:
		if cmds.isolateSelect(activeModelPanel, q=True, s=True) is True:
			isolatedObjects = cmds.ls(cmds.sets(cmds.isolateSelect(activeModelPanel, q=True, vo=True), q=True), l=True)
	
	return isolatedObjects

def SS_GetComponents(*args, **kwargs):
	# Create default args
	selection = None
	filterDict = {"vertex": {"filter": False, "filterType": OpenMaya.MFn.kMeshVertComponent}, 
			      "edge": {"filter": False, "filterType": OpenMaya.MFn.kMeshEdgeComponent}, 
			      "face": {"filter": False, "filterType": OpenMaya.MFn.kMeshPolygonComponent}, 
			      "uv": {"filter": False, "filterType": OpenMaya.MFn.kMeshMapComponent}, 
			      "vertexFace": {"filter": False, "filterType": OpenMaya.MFn.kMeshFaceVertComponent}}
	componentsList = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "vertex" or key == "v":
			filterDict["vertex"]["filter"] = value
		elif key == "edge" or key == "e":
			filterDict["edge"]["filter"] = value
		elif key == "face" or key == "f":
			filterDict["face"]["filter"] = value
		elif key == "uv":
			filterDict["uv"]["filter"] = value
		elif key == "vertexFace" or key == "vf":
			filterDict["vertexFace"]["filter"] = value
	
	if selection is None:
		selection = cmds.ls(sl=True, l=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for each in selection:
			selList.add(each)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		compList = OpenMaya.MSelectionList()
		
		for dict in six.itervalues(filterDict):
			if dict["filter"] is True:
				sel_iter = OpenMaya.MItSelectionList(selList, dict["filterType"])
				while not sel_iter.isDone():
					sel_iter.getDagPath(dagPath, component)
					compList.add(dagPath, component)			
					sel_iter.next()
		
		# Create new list and merge elements (unflatten list)
		mergedList = OpenMaya.MSelectionList()
		if compList.isEmpty() is False:
			mergedList.merge(compList, OpenMaya.MSelectionList.kMergeNormal)
		# Get selection strings
		objComponents = []
		mergedList.getSelectionStrings(objComponents)
		# Return full path strings
		objComponents = cmds.ls(objComponents, l=True)
		
		# Add to list
		componentsList.extend(objComponents)
		
	return componentsList
	
def SS_GetCurrentSel(*args):
	objects = None
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	# Get selected objects
	currentSel = cmds.ls(sl=True, l=True)
	if objects is None:
		objects = cmds.ls(hl=True, l=True)
		objects.extend(currentSel)
	# Get selected objects
	objectShapes = cmds.ls(objects, l=True, dag=True, ni=True, o=True, typ="mesh")
	objects = cmds.listRelatives(objectShapes, f=True, p=True, ni=True, typ="transform")
	# Remove intermediate objects
	objects = cmds.ls(objects, l=True, ni=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	return currentSel, objects
	
def SS_GetComponentType(*args, **kwargs):
	# Create default args
	selection = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
	
	selList = OpenMaya.MSelectionList()
	
	if selection is not None:
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
	else:
		OpenMaya.MGlobal_getActiveSelectionList(selList)
	
	filterDict = []
	filterDict.append(("v", OpenMaya.MFn.kMeshVertComponent))
	filterDict.append(("eg", OpenMaya.MFn.kMeshEdgeComponent))
	filterDict.append(("fc", OpenMaya.MFn.kMeshPolygonComponent))
	filterDict.append(("puv", OpenMaya.MFn.kMeshMapComponent))
	filterDict.append(("pvf", OpenMaya.MFn.kMeshVtxFaceComponent))
	#filterDict.append(("cv", OpenMaya.MFn.kCurveCVComponent))
	filterDict = OrderedDict(filterDict)
	
	for key, filter in six.iteritems(filterDict):
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		try:
			if sel_iter.hasComponents() is True:
				return key
		except:
			pass
	
	return None

def SS_SelectionDictionary(*args, **kwargs):
	# Create default args
	selection = None
	objectSelDict = defaultdict(list)
	objectList = []
	faceSelList = []
	filter = OpenMaya.MFn.kMeshPolygonComponent
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			filter = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "filter" or key == "f":
			filter = value
		elif key == "progressBar" or key == "pb":
			progressBar = value
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for each in selection:
			try:
				selList.add(each)
			except:
				pass
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		compList = OpenMaya.MSelectionList()
		
		if "progressBar" in locals() and progressBar is True:
			progressWinName, progressBarName = ProgressBarWindow(n="SS_ProgressWin", t="Building Selection Set Dictionary...", w=300, max=(selList.length()))
		
		sel_iter = OpenMaya.MItSelectionList(selList, filter)
		while not sel_iter.isDone():
			sel_iter.getDagPath(dagPath, component)
			dagPath.pop() # Remove shape
			node = dagPath.fullPathName()
			
			# Add current components to selectionList
			compList.clear()
			compList.add(dagPath, component)
			
			# Create new list and merge elements (unflatten list)
			##mergedList = OpenMaya.MSelectionList()
			##if compList.isEmpty() is False:
				##mergedList.merge(compList, OpenMaya.MSelectionList.kMergeNormal)
			# Get selection strings
			objComponents = []
			compList.getSelectionStrings(objComponents)
			# Return full path strings
			objComponents = cmds.ls(objComponents, l=True)
			
			# Add to dictionary
			objectSelDict[node].extend(objComponents)
			objectList.append(node)
			faceSelList.extend(objComponents)
			
			if "progressBarName" in locals():
				cmds.progressBar(progressBarName, e=True, s=1)
			
			sel_iter.next()
		
		if "progressWinName" in locals():
				cmds.deleteUI(progressWinName, wnd=True)
		
	return objectSelDict, objectList, faceSelList

def SS_ColorSetExists(*args, **kwargs):
	object = None
	colorSetName = None
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			object = arg
		elif i == 1:
			colorSetName = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "object" or key == "obj":
			selection = value
		elif key == "colorSetName" or key == "csn":
			colorSetName = value
	
	if object is None:
		object = SS_GetCurrentSel()[1][0]
	
	if len(object) > 0 and colorSetName is not None:
		colorSets = cmds.polyColorSet(object, q=True, acs=True)
		if colorSets is not None:
			if colorSetName in colorSets:
				return True
	
	return False

def SS_SetVertexColorFaces(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	progressStep = 0
	selection = None
	colorSetName = None
	colorSetDict = defaultdict(list)
	colorSetList = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			colorSetName = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "colorSetName" or key == "csn":
			colorSetName = value
		elif key == "progressStep" or key == "ps":
			progressStep = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(tf=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for face in selection:
			selList.add(face)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		
		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMeshPolygonComponent)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshPolygonComponent):
				dagPath.pop() # Remove shape
				# Get object name
				objectName = dagPath.fullPathName()
				
				# Check if any colorSet matches colorSetName
				colorSetExists = SS_ColorSetExists(objectName, csn=colorSetName)
				# If no matches were found, use current color set
				if colorSetName is None or colorSetExists is False:
					colorSetName = cmds.polyColorSet(objectName, q=True, ccs=True)
					# If no colorSet found, create new colorSet
					if colorSetName is None:
						colorSetName = cmds.polyColorSet(objectName, cr=True)
					colorSetName = colorSetName[0]
				
				# Iterate over faces
				if colorSetName is not None:
					# Create a new color set with colorSetName
					cmds.polyColorSet(objectName, cs=colorSetName, ccs=True)
					# Add colorSetName to dictionary
					colorSetDict[objectName] = colorSetName
					# Add colorSetName to list
					colorSetList.append(colorSetName)
					
					# Create variables
					meshNode = OpenMaya.MFnMesh(dagPath)
					colorsList = OpenMaya.MColorArray()
					faceIdsList = OpenMaya.MIntArray()
					vertexIdsList = OpenMaya.MIntArray()
					
					'''
					# Iterate over faces from selList
					face_iter = OpenMaya.MItMeshPolygon(dagPath, component)
					i = 0
					while not face_iter.isDone():
						# Get current face index
						faceId = face_iter.index()
						# Loop over each face vertex
						vertexIds = OpenMaya.MIntArray()
						face_iter.getVertices(vertexIds)
						for id in vertexIds:
							# Append colorsList, faceIdsList and vertexIdsList
							colorsList.append(OpenMaya.MColor(0, 0, 0))
							faceIdsList.append(faceId)
							vertexIdsList.append(id)
						if progressStep > 0 and (float(i)/progressStep).is_integer() is True:
							cmds.progressBar(gMainProgressBar, e=True, s=progressStep, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
						i += 1
						face_iter.next()
					
					# Set vertex colors on faces
					meshNode.setFaceVertexColors(colorsList, faceIdsList, vertexIdsList)
					'''
					
					# Iterate over faces from selList
					face_iter = OpenMaya.MItMeshPolygon(dagPath, component)
					i = 0
					while not face_iter.isDone():
						# Get current face index
						faceId = face_iter.index()
						# Append colorsList
						colorsList.append(OpenMaya.MColor(0, 0, 0))
						# Append faceIdsList
						faceIdsList.append(faceId)
						# Progress bar
						if progressStep > 0 and (float(i)/progressStep).is_integer() is True:
							cmds.progressBar(gMainProgressBar, e=True, s=progressStep, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
						i += 1
						face_iter.next()
					meshNode.setFaceColors(colorsList, faceIdsList)
			
			if progressStep > 0:		
				cmds.progressBar(gMainProgressBar, e=True, s=1, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
			iterIndex += 1
			sel_iter.next()
	return colorSetList, colorSetDict

def SS_GetVertexColorFaces(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	progressStep = 0
	selection = None
	colorSetName = None
	vertexColorFacesDict = defaultdict(list)
	vertexColorFacesSel = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			colorSetName = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "colorSetName" or key == "csn":
			colorSetName = value
		elif key == "progressStep" or key == "ps":
			progressStep = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(tf=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for face in selection:
			selList.add(face)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()

		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList, OpenMaya.MFn.kMeshPolygonComponent)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshPolygonComponent):
				dagPath.pop() # Remove shape
				# Get object name
				objectName = dagPath.fullPathName()
				
				# Check if any colorSet matches colorSetName
				colorSetExists = SS_ColorSetExists(objectName, csn=colorSetName)
				# If no matches were found, use current color set
				if colorSetName is None or colorSetExists is False:
					colorSetName = cmds.polyColorSet(objectName, q=True, ccs=True)
					if colorSetName is not None:
						colorSetName = colorSetName[0]
				
				if colorSetName is not None:
					# Create vertexColorFacesList
					vertexColorFacesList = OpenMaya.MSelectionList()
					
					# Iterate over faces from selList
					face_iter = OpenMaya.MItMeshPolygon(dagPath, component)
					i = 0
					while not face_iter.isDone():
						# Get current face index
						faceId = face_iter.index()
						# Get face color indices
						colorIds = OpenMaya.MIntArray()
						face_iter.getColorIndices(colorIds, colorSetName)
						
						# If all vertices are colored, add to list
						if any(color < 0 for color in colorIds) is False:
							vertexColorFacesList.add(dagPath, face_iter.currentItem())
						
						if progressStep > 0 and (float(i)/progressStep).is_integer() is True:
							cmds.progressBar(gMainProgressBar, e=True, s=progressStep, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
						
						i += 1
						face_iter.next()
					
					if vertexColorFacesList.isEmpty() is False:
						# Create new list and merge elements (unflatten list)
						mergedList = OpenMaya.MSelectionList()
						mergedList.merge(vertexColorFacesList, OpenMaya.MSelectionList.kMergeNormal)
						# Add faces to dictionary
						mergedList.getSelectionStrings(vertexColorFacesDict[objectName])
						# Add to list
						vertexColorFacesSel.extend(vertexColorFacesDict[objectName])
			
			if progressStep > 0:
				cmds.progressBar(gMainProgressBar, e=True, s=1, st=cmds.progressBar(gMainProgressBar, q=True, st=True))
			iterIndex += 1
			sel_iter.next()
	return vertexColorFacesSel, vertexColorFacesDict

def SS_GetHiddenDisplayLayersMembers():
	selList = om.MSelectionList()
	sel_iter = om.MItDependencyNodes(om.MFn.kDisplayLayer)
	while not sel_iter.isDone():
		dnFn = om.MFnDependencyNode(sel_iter.thisNode())
		
		if dnFn.name() != "defaultLayer" and dnFn.findPlug("visibility", False).asBool() is False:
			layerConnections = dnFn.getConnections()
			
			for lc in layerConnections:
				connectedNodes = lc.connectedTo(False, True)
				for cn in connectedNodes:
					selList.add(cn.node())
		
		sel_iter.next()
	
	objects = selList.getSelectionStrings()
	return objects

def SS_CompareSelfObjects(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	progressBar = False
	objects = None
	tolerance = 0.1
	objectSearchMethod = 3
	sourceList = []
	targetList = []
	sourceDict = defaultdict(list)
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load SelectSimilar optionVars
	if cmds.optionVar(ex="NTSS_ObjectSearchMethod") is True:
		value = cmds.optionVar(q="NTSS_ObjectSearchMethod")+2
		objectSearchMethod = value
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "tolerance" or key == "t":
			tolerance = value
		elif key == "searchMethod" or key == "sm":
			objectSearchMethod = value
		elif key == "progressBar" or key == "pb":
			progressBar = value
	
	if objects is None:
		objects = SS_GetCurrentSel(objects)[1]
	
	if objects is not None and len(objects) > 0:
		# Loop over objects
		for i, sourceObj in enumerate(objects):
			targetObjects = list(objects)
			# Remove objects which already found a match
			targetObjects = list(set(targetObjects).difference(targetList))
			# Loop over a copy of objects
			for targetObj in targetObjects:
				if cmds.progressBar(gMainProgressBar, q=True, ic=True):
					return None, None
				objMatch = False
				if targetObj == sourceObj:
					objMatch = True
				elif cmds.polyEvaluate(sourceObj, v=True) == cmds.polyEvaluate(targetObj, v=True) and cmds.polyEvaluate(sourceObj, v=True) > 0:
					objMatch = False
					polyCompareNum = (cmds.polyCompare(sourceObj, targetObj, v=True, e=True, fd=True) - cmds.polyCompare(sourceObj, targetObj, c=True))
					# If face descriptions match, add object to list
					if polyCompareNum < 7:
						objMatch = True
					# Check if object surface area is similar
					if objectSearchMethod <= 4:
						worldAreaDigits = (len(str(int(min(cmds.polyEvaluate(sourceObj, wa=True), cmds.polyEvaluate(targetObj, wa=True))))))
						##worldAreaTolerance = ((worldAreaDigits*worldAreaDigits)*tolerance)/2
						worldAreaTolerance = ((worldAreaDigits*worldAreaDigits)*tolerance)
						if isclose(cmds.polyEvaluate(sourceObj, wa=True), cmds.polyEvaluate(targetObj, wa=True), at=worldAreaTolerance, rt=((float(10) ** worldAreaDigits)/10000000)*tolerance) is False:
							objMatch = False
						elif objectSearchMethod == 4:
							objMatch = True
					if polyCompareNum == 0 and objMatch is True:
						objMatch = True
					elif objectSearchMethod == 5 or (objectSearchMethod == 4 and objMatch is True):
						# If undo is turned off, turn it on temporarily
						undoState = cmds.undoInfo(query=True, state=True)
						if not undoState:
							cmds.undoInfo(state=True)

						displayColors = cmds.polyOptions(targetObj, q=True, cs=True)[0]
						# Transfer vertex position
						transferAttr = cmds.transferAttributes(sourceObj, targetObj, pos=1, nml=0, uvs=0, col=0, spa=objectSearchMethod, sm=3)
						cmds.polyOptions(targetObj, cs=displayColors)
						polyCompareNum = (cmds.polyCompare(sourceObj, targetObj, v=True, e=True, fd=True) - cmds.polyCompare(sourceObj, targetObj, c=True))
						# If face descriptions match after transfer, add object to list and continue to the next
						if polyCompareNum < 7:
							objMatch = True
						else:
							objMatch = False
						cmds.undo()

						# Restore undo state
						if not undoState:
							cmds.undoInfo(state=False)
						
				if objMatch is True:
					targetList.append(targetObj)
					sourceDict[sourceObj].append(targetObj)
					if sourceObj not in sourceList:
						sourceList.append(sourceObj)
					if progressBar is True:
						cmds.progressBar(gMainProgressBar, e=True, s=(len(objects)-i), st="Selection in progress...")
				if progressBar is True:
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
	return sourceList, sourceDict

def SS_SelectSimilarMeshes(*args, **kwargs):
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	objects = None
	tolerance = 1	
	objectSearchMethod = 3
	ignoreInstances = False
	ignoreHidden = True
	isolateConstraint = True
	similarObjects = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load SelectSimilar optionVars
	if cmds.optionVar(ex="NTSS_SimilarityTolerance") is True:
		value = cmds.optionVar(q="NTSS_SimilarityTolerance")
		tolerance = (value*10)*(value*10)
	if cmds.optionVar(ex="NTSS_ObjectSearchMethod") is True:
		value = cmds.optionVar(q="NTSS_ObjectSearchMethod")+2
		objectSearchMethod = value
	if cmds.optionVar(ex="NTSS_IgnoreInstances") is True:
		value = bool(cmds.optionVar(q="NTSS_IgnoreInstances")[0])
		ignoreInstances = value
	if cmds.optionVar(ex="NTSS_IgnoreHiddenObjects") is True:
		value = bool(cmds.optionVar(q="NTSS_IgnoreHiddenObjects")[0])
		ignoreHidden = value
	if cmds.optionVar(ex="NTSS_IsolateConstraint") is True:
		value = bool(cmds.optionVar(q="NTSS_IsolateConstraint")[0])
		isolateConstraint = value
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "tolerance" or key == "t":
			tolerance = value
		elif key == "searchMethod" or key == "sm":
			objectSearchMethod = value
		elif key == "ignoreHidden" or key == "ih":
			ignoreHidden = value
		elif key == "isolateConstraint" or key == "ic":
			isolateConstraint = value
	
	# Get selected objects
	objects = SS_GetCurrentSel(objects)[1]
	
	if len(objects) > 0:
		similarObjects = list(objects)
		# Get isolated objects list
		isolatedObjects = None
		if isolateConstraint is True:
			isolatedObjects = GetIsolatedObjects()
		# Get all meshes in the scene
		if ignoreHidden is True:
			if isolatedObjects is not None:
				sceneObjects = cmds.ls(isolatedObjects, l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
			else:
				sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh", v=True)
			displayLayersMembers = cmds.ls(SS_GetHiddenDisplayLayersMembers(), l=True, dag=True, ni=True, o=True, typ="mesh")
			sceneObjects = list(set(sceneObjects).difference(displayLayersMembers))
		else:
			if isolatedObjects is not None:
				sceneObjects = cmds.ls(isolatedObjects, l=True, dag=True, ni=True, o=True, typ="mesh")
			else:
				sceneObjects = cmds.ls(l=True, dag=True, ni=True, o=True, typ="mesh")
		sceneObjects = cmds.listRelatives(sceneObjects, f=True, p=True, ni=True, typ="transform")
		# Remove intermediate objects
		sceneObjects = cmds.ls(sceneObjects, l=True, ni=True)
		if sceneObjects is not None:
			# Remove duplicates objects
			sceneObjects = list(OrderedDict.fromkeys(sceneObjects))
			# Remove objects from sceneObjects
			sceneObjects = list(set(sceneObjects).difference(objects))
		if len(sceneObjects) > 0:
			cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selection in progress...", min=0, max=(len(objects)*len(objects)))
			
			# Pause viewport
			if (len(sceneObjects)*len(objects)) > 20000:
				cmds.ogs(p=True)
				cmds.refresh(cv=True)
				viewportPause = True
			
			try:
				# List unique objects
				sourceList = SS_CompareSelfObjects(objects, t=tolerance, sm=objectSearchMethod, pb=True)[0]
				if sourceList is None:
					return None
				
				sourceListSize = len(sourceList)
				progressBarSteps = (len(str(len(sceneObjects)))*len(str(len(sceneObjects))))
				cmds.progressBar(gMainProgressBar, e=True, ep=True)
				cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selection in progress...", min=0, max=(len(sceneObjects)*sourceListSize))
				
				# For every objects in the scene
				for s, targetObj in enumerate(sceneObjects):
					# Loop over unique selected objects
					for i, sourceObj in enumerate(sourceList):
						if cmds.progressBar(gMainProgressBar, q=True, ic=True):
							return None
						objMatch = False
						if targetObj == sourceObj:
							objMatch = True
						elif cmds.polyEvaluate(sourceObj, v=True) == cmds.polyEvaluate(targetObj, v=True) and cmds.polyEvaluate(sourceObj, v=True) > 0:
							objMatch = False
							polyCompareNum = (cmds.polyCompare(sourceObj, targetObj, v=True, e=True, fd=True) - cmds.polyCompare(sourceObj, targetObj, c=True))
							# If face descriptions match, add object to list and continue to the next
							if polyCompareNum < 7:
								objMatch = True
							# Check if object surface area is similar
							if objectSearchMethod <= 4:
								worldAreaDigits = (len(str(int(min(cmds.polyEvaluate(sourceObj, wa=True), cmds.polyEvaluate(targetObj, wa=True))))))
								worldAreaTolerance = ((worldAreaDigits*worldAreaDigits)*tolerance)
								if isclose(cmds.polyEvaluate(sourceObj, wa=True), cmds.polyEvaluate(targetObj, wa=True), at=worldAreaTolerance, rt=((float(10) ** worldAreaDigits)/10000000)*tolerance) is False:
									objMatch = False
								elif objectSearchMethod == 4:
									objMatch = True
							if polyCompareNum == 0 and objMatch is True:
								objMatch = True
							elif objectSearchMethod == 5 or (objectSearchMethod == 4 and objMatch is True):
								# If undo is turned off, turn it on temporarily
								undoState = cmds.undoInfo(query=True, state=True)
								if not undoState:
									cmds.undoInfo(state=True)

								displayColors = cmds.polyOptions(targetObj, q=True, cs=True)[0]
								# Transfer vertex position
								transferAttr = cmds.transferAttributes(sourceObj, targetObj, pos=1, nml=0, uvs=0, col=0, spa=objectSearchMethod, sm=3)
								cmds.polyOptions(targetObj, cs=displayColors)
								polyCompareNum = (cmds.polyCompare(sourceObj, targetObj, v=True, e=True, fd=True) - cmds.polyCompare(sourceObj, targetObj, c=True))
								# If face descriptions match after transfer, add object to list and continue to the next
								if polyCompareNum < 7:
									objMatch = True
								else:
									objMatch = False
								cmds.undo()

								# Restore undo state
								if not undoState:
									cmds.undoInfo(state=False)
							
						if objMatch is True:
							similarObjects.append(targetObj)
							cmds.progressBar(gMainProgressBar, e=True, s=sourceListSize-i, st="Selection in progress...")
							break
						if (float(s)/progressBarSteps).is_integer() is True:
							cmds.progressBar(gMainProgressBar, e=True, s=progressBarSteps, st="Selection in progress...")
				# Select instances
				if not ignoreInstances:
					objectShapes = cmds.listRelatives(similarObjects, fullPath=True, shapes=True)
					similarObjects = cmds.listRelatives(objectShapes, fullPath=True, allParents=True)
				
				cmds.progressBar(gMainProgressBar, e=True, ep=True)
			
			except Exception as e:
				raise Exception(e)
			
			finally:
				# Unpause viewport
				if "viewportPause" in locals() and viewportPause is True:
					cmds.ogs(p=True)
					progressWinName, progressBarName = ProgressBarWindow(n="SS_ProgressWin", t="Refreshing viewport...", w=200, max=1)
					cmds.progressBar(progressBarName, e=True, s=2)
					cmds.evalDeferred("import maya.cmds as cmds;cmds.deleteUI('"+progressWinName+"', wnd=True)")

			# Select objects
			cmds.select(similarObjects, r=True)
	return similarObjects

def SS_SelectSimilarFn(tolerance=0.1):
	currentTolerance = cmds.nexOpt("selSimTolerance", q=True)
	cmds.nexOpt("selSimTolerance", tolerance, e=True)
	cmds.dR_selectSimilar()
	cmds.nexOpt("selSimTolerance", currentTolerance, e=True)

def SS_SelectSimilarComponents(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	selection = None
	objects = None
	tolerance = 0.1	
	objectSearchMethod = 3
	resetTransforms = False
	operation = 1
	matchType = 1
	sampleSpace = 4
	similarFaces = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
		elif i == 1:
			objects = arg
	
	# Load SelectSimilar optionVars
	if cmds.optionVar(ex="NTSS_SimilarityTolerance") is True:
		value = cmds.optionVar(q="NTSS_SimilarityTolerance")
		tolerance = value*10*value
	if cmds.optionVar(ex="NTSS_ObjectSearchMethod") is True:
		value = cmds.optionVar(q="NTSS_ObjectSearchMethod")+2
		objectSearchMethod = value
	if cmds.optionVar(ex="NTSS_ResetTransforms") is True:
		value = bool(cmds.optionVar(q="NTSS_ResetTransforms")[0])
		resetTransforms = value
	if cmds.optionVar(ex="NTSS_Operation") is True:
		value = cmds.optionVar(q="NTSS_Operation")
		operation = value
	if cmds.optionVar(ex="NTSS_MatchType") is True:
		value = cmds.optionVar(q="NTSS_MatchType")
		matchType = value
	if cmds.optionVar(ex="NTSS_SampleSpace") is True:
		value = cmds.optionVar(q="NTSS_SampleSpace")+2
		sampleSpace = value
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "objects" or key == "obj":
			objects = value
		elif key == "tolerance" or key == "t":
			tolerance = value
		elif key == "searchMethod" or key == "sm":
			objectSearchMethod = value
		elif key == "resetTransforms" or key == "rt":
			resetTransforms = value
		elif key == "operation" or key == "o":
			operation = value
		elif key == "matchType" or key == "mt":
			matchType = value
		elif key == "sampleSpace" or key == "spa":
			sampleSpace = value
	
	if selection is None or objects is None:
		selection, objects = SS_GetCurrentSel(objects)
	
	if len(selection) <= 0 or len(objects) <= 0:
		return None
	
	if len(objects) <= 1:
		# Select similar
		SS_SelectSimilarFn(tolerance)
		similarFaces = cmds.ls(sl=True, l=True)
	else:
		# Match by indices
		if matchType == 1:
			# Get selected components
			componentsSel = SS_GetComponents(selection, v=True, e=True, f=True, uv=True, vf=True)
			# List unique objects
			sourceDict = SS_CompareSelfObjects(objects, t=tolerance, sm=objectSearchMethod, pb=False)[1]
			if sourceDict is None:
				return None
			
			# Progress bar
			cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selection in progress...", min=0, max=(len(sourceDict)*2))
			
			componentsSelDict = SS_SelectionDictionary(componentsSel, OpenMaya.MFn.kMeshComponent)[0]
			similarFacesDict = defaultdict(list)
			
			for src, targetList in six.iteritems(sourceDict):
				for target in targetList:
					if target in componentsSelDict:
						similarFacesDict[src].extend(["."+face.split(".", 1)[1] for face in componentsSelDict[target]])
				cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
			
			for src, targetList in six.iteritems(sourceDict):
				for target in targetList:
					for faces in similarFacesDict[src]:
						similarFaces.append("{0}{1}".format(target, faces))
				cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
			
			cmds.select(similarFaces, r=True)
			
			if operation == 2:
				# Select similar
				SS_SelectSimilarFn(tolerance)
				similarFaces = cmds.ls(sl=True, l=True)
			
			cmds.progressBar(gMainProgressBar, e=True, ep=True)
	
		# Match by topology
		else:
			# Get selected faces
			facesSel = SS_GetComponents(selection, f=True)
			
			if len(facesSel) > 0:
				
				matrixDict = defaultdict(list)
				for object in objects:
					# Collapse tweaks
					if cmds.polyCollapseTweaks(object, q=True, hvt=True) is True:
						cmds.polyCollapseTweaks(object)
					# Reset Transforms
					if resetTransforms is True:
						transformMatrix = cmds.xform(object, q=True, ws=True, m=True)
						matrixDict[object] = transformMatrix
						resetMatrix = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, transformMatrix[12], transformMatrix[13], transformMatrix[14], 1]
						cmds.xform(object, ws=True, m=resetMatrix)
				
				# Component / Topology
				if sampleSpace > 3:								
					# List unique objects
					sourceDict = SS_CompareSelfObjects(objects, t=tolerance, sm=objectSearchMethod, pb=False)[1]
					if sourceDict is None:
						return None
					sourceDictLength = sum([len(x) for x in sourceDict.values()])-len(sourceDict)
					
					# Progress bar
					cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selection in progress...", min=0, max=((len(sourceDict)*2)+sourceDictLength))
					
					facesSelDict = SS_SelectionDictionary(facesSel)[0]
					similarFacesDict = defaultdict(list)
					
					for src, targetList in six.iteritems(sourceDict):
						for target in targetList:
							if target in facesSelDict:
								similarFacesDict[src].extend([src+"."+face.split(".", 1)[1] for face in facesSelDict[target]])
						cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					colorSetName = "NTSS_ColorSet"
					undoOperations = False

					# If undo is turned off, turn it on temporarily
					undoState = cmds.undoInfo(query=True, state=True)
					if not undoState:
						cmds.undoInfo(state=True)
					
					# Open undo chunk
					cmds.undoInfo(ock=True)
					
					for src, targetList in six.iteritems(sourceDict):
						if src in similarFacesDict:
							if len(targetList) <= 1:
								##if operation == 2:
									##cmds.select(similarFacesDict[src], r=True)
									# Select similar
									##SS_SelectSimilarFn(tolerance)
									# Add faces to list
									##similarFaces.extend(cmds.ls(sl=True, l=True))
								similarFaces.extend(similarFacesDict[src])
							elif len(set([int(reSplit("\.f\[([0-9:]*)\]", edge)[1]) for edge in cmds.ls(similarFacesDict[src], fl=True)])) == cmds.polyEvaluate(src, f=True):
								similarFaces.extend(cmds.polyListComponentConversion(targetList, tf=True))
							else:
								undoOperations = True
								# If colorSet already exists, delete it
								if SS_ColorSetExists(src, csn=colorSetName) is True:
									cmds.polyColorSet(src, d=True, cs=colorSetName)
								# Create color set on source mesh
								sourceColorSet = cmds.polyColorSet(src, cr=True, cs=colorSetName)[0]
								sourceColorSet = SS_SetVertexColorFaces(similarFacesDict[src], csn=sourceColorSet)[0][0]
								
								for target in targetList:
									if target != src:
										# If colorSet already exists, delete it
										if SS_ColorSetExists(target, csn=colorSetName) is True:
											cmds.polyColorSet(target, d=True, cs=colorSetName)
										##if cmds.listConnections(targetShape+".inMesh") is None:
										# If mesh has no history, create color set manually
										if cmds.listHistory(target, il=1, pdo=True) is None:
											targetShape = cmds.listRelatives(target, f=True, ni=True, s=True)[0]
											targetColorSet = cmds.createNode("createColorSet", ss=True)
											cmds.setAttr(targetColorSet+".colorSetName", colorSetName, typ="string")
											##cmds.setAttr(targetColorSet+".clamped", 0)
											cmds.connectAttr((targetShape+".outMesh"), (targetColorSet+".inputGeometry"), f=True)
											# disconnectAttr to avoid cycle
											cmds.disconnectAttr((targetShape+".outMesh"), (targetColorSet+".inputGeometry"))
											cmds.connectAttr((targetColorSet+".outputGeometry"), (targetShape+".inMesh"), f=True)
											targetColorSet = cmds.getAttr(targetColorSet+".colorSetName")
										# Create color set on target mesh
										else:
											targetColorSet = cmds.polyColorSet(target, cr=True, cs=colorSetName)[0]
										# Transfer vertex colors from duplicated object to object
										transferColorSet = cmds.transferAttributes(src, target, pos=0, nml=0, uvs=0, col=1, scs=sourceColorSet, tcs=targetColorSet, spa=sampleSpace, sm=3, clb=1)
										cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
						cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					# Close undo chunk
					cmds.undoInfo(cck=True)
					
					# Get object's faces with vertex color
					similarFaces.extend(SS_GetVertexColorFaces(cmds.polyListComponentConversion(objects, tf=True), csn=colorSetName)[0])
					
					# If undo queue is not empty
					if undoOperations is True and cmds.undoInfo(query=True, undoQueueEmpty=True) is False:
						# Undo last chunk
						cmds.undo()
					
					# Restore undo state
					if not undoState:
						cmds.undoInfo(state=False)

					# Disable undo
					if undoState:
						cmds.undoInfo(stateWithoutFlush=False)
					# Delete color sets created previously
					for object in objects:
						if SS_ColorSetExists(object, csn=colorSetName) is True:
							cmds.polyColorSet(object, d=True, cs=colorSetName)
					# Enable undo
					if undoState:
						cmds.undoInfo(stateWithoutFlush=True)
					
					# Restore selection
					cmds.select(objects, r=True)
					if cmds.selectMode(q=True, co=True) is False:
						cmds.selectType(fc=True)
					cmds.selectMode(co=True)
					cmds.select(similarFaces, r=True)
					
					if operation == 2:
						# Select similar
						SS_SelectSimilarFn(tolerance)
						similarFaces = cmds.ls(sl=True, l=True)
				
				# World
				else:
					# Progress bar
					cmds.progressBar(gMainProgressBar, e=True, bp=True, ii=True, st="Selection in progress...", min=0, max=(len(objects)*1)+7)
					##progressBarSteps = (len(str(cmds.polyEvaluate(objects, f=True)*2))*len(str(cmds.polyEvaluate(objects, f=True)*2)))
					
					# Fix undo
					cmds.select(objects, r=True)
					cmds.select(selection, r=True)
					
					# Create selection set
					selSet = cmds.sets(facesSel)
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					# Duplicate objects and combine them
					duplicatedObjects = cmds.duplicate(objects)
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					duplicatedObject = cmds.polyUnite(duplicatedObjects, ch=False)
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					componentsList = []
					if cmds.sets(selSet, q=True) is not None:
						componentsList = [c for c in cmds.sets(selSet, q=True) if duplicatedObject[0] == c.split(".")[0]]
					
					# Select similar
					cmds.select(componentsList, r=True)
					SS_SelectSimilarFn(tolerance)
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					colorSetName = "NTSS_ColorSet"
					# If colorSet already exists, delete it
					if SS_ColorSetExists(duplicatedObject[0], csn=colorSetName) is True:
						cmds.polyColorSet(duplicatedObject[0], d=True, cs=colorSetName)
					# Create color set on source mesh
					sourceColorSet = cmds.polyColorSet(duplicatedObject[0], cr=True, cs=colorSetName)[0]
					colorFaces = SS_GetComponents(cmds.ls(sl=True, l=True), f=True)
					##svcf_Steps = cmds.polyEvaluate(objects, f=True)/len(colorFaces)
					sourceColorSet = SS_SetVertexColorFaces(colorFaces, csn=sourceColorSet)[0][0]
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					# If undo is turned off, turn it on temporarily
					undoState = cmds.undoInfo(query=True, state=True)
					if not undoState:
						cmds.undoInfo(state=True)

					# Open undo chunk
					cmds.undoInfo(ock=True)
					
					for object in objects:
						# If colorSet already exists, delete it
						if SS_ColorSetExists(object, csn=colorSetName) is True:
							cmds.polyColorSet(object, d=True, cs=colorSetName)
						##if cmds.listConnections(targetShape+".inMesh") is None:
						# If mesh has no history, create color set manually
						if cmds.listHistory(object, il=1, pdo=True) is None:
							targetShape = cmds.listRelatives(object, f=True, ni=True, s=True)[0]
							targetColorSet = cmds.createNode("createColorSet", ss=True)
							cmds.setAttr(targetColorSet+".colorSetName", colorSetName, typ="string")
							##cmds.setAttr(targetColorSet+".clamped", 0)
							cmds.connectAttr((targetShape+".outMesh"), (targetColorSet+".inputGeometry"), f=True)
							# disconnectAttr to avoid cycle
							cmds.disconnectAttr((targetShape+".outMesh"), (targetColorSet+".inputGeometry"))
							cmds.connectAttr((targetColorSet+".outputGeometry"), (targetShape+".inMesh"), f=True)
							targetColorSet = cmds.getAttr(targetColorSet+".colorSetName")
						# Create color set on object
						else:
							targetColorSet = cmds.polyColorSet(object, cr=True, cs=colorSetName)[0]
						# Transfer vertex colors from duplicated object to object
						cmds.transferAttributes(duplicatedObject[0], object, pos=0, nml=0, uvs=0, col=1, scs=sourceColorSet, tcs=targetColorSet, spa=0, sm=3, clb=1)
						cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					# Close undo chunk
					cmds.undoInfo(cck=True)
					
					# Get object's faces with vertex color
					similarFaces = SS_GetVertexColorFaces(cmds.polyListComponentConversion(objects, tf=True), csn=colorSetName)[0]
					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					# Undo last chunk
					cmds.undo()

					# Restore undo state
					if not undoState:
						cmds.undoInfo(state=False)

					cmds.progressBar(gMainProgressBar, e=True, s=1, st="Selection in progress...")
					
					# Delete duplicated objects
					cmds.delete(selSet)
					cmds.delete(duplicatedObject)
					for object in duplicatedObjects:
						if cmds.objExists(object):
							cmds.delete(object)
					
					# Disable undo
					if undoState:
						cmds.undoInfo(stateWithoutFlush=False)
					# Delete color sets created previously
					for object in objects:
						if SS_ColorSetExists(object, csn=colorSetName) is True:
							cmds.polyColorSet(object, d=True, cs=colorSetName)
					# Enable undo
					if undoState:
						cmds.undoInfo(stateWithoutFlush=True)
					
					# Restore selection
					cmds.select(objects, r=True)
					if cmds.selectMode(q=True, co=True) is False:
						cmds.selectType(fc=True)
					cmds.selectMode(co=True)
					cmds.select(similarFaces, r=True)
				
				# Restore transforms
				if resetTransforms is True:
					for object in objects:
						cmds.xform(object, ws=True, m=matrixDict[object])
				
				cmds.progressBar(gMainProgressBar, e=True, ep=True)
				
	return similarFaces

def SS_SelectSimilar(*args, **kwargs):
	# Create default args
	gMainProgressBar = mel.eval("$gMainProgressBar = $gMainProgressBar")
	objects = None
	tolerance = 0.1	
	objectSearchMethod = 3
	resetTransforms = False
	operation = 1
	matchType = 1
	sampleSpace = 4
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
	
	# Load SelectSimilar optionVars
	if cmds.optionVar(ex="NTSS_SimilarityTolerance") is True:
		value = cmds.optionVar(q="NTSS_SimilarityTolerance")
		tolerance = value*10*value
	if cmds.optionVar(ex="NTSS_ObjectSearchMethod") is True:
		value = cmds.optionVar(q="NTSS_ObjectSearchMethod")+2
		objectSearchMethod = value
	if cmds.optionVar(ex="NTSS_ResetTransforms") is True:
		value = bool(cmds.optionVar(q="NTSS_ResetTransforms")[0])
		resetTransforms = value
	if cmds.optionVar(ex="NTSS_Operation") is True:
		value = cmds.optionVar(q="NTSS_Operation")
		operation = value
	if cmds.optionVar(ex="NTSS_MatchType") is True:
		value = cmds.optionVar(q="NTSS_MatchType")
		matchType = value
	if cmds.optionVar(ex="NTSS_SampleSpace") is True:
		value = cmds.optionVar(q="NTSS_SampleSpace")+2
		sampleSpace = value
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "tolerance" or key == "t":
			tolerance = value
		elif key == "searchMethod" or key == "sm":
			objectSearchMethod = value
		elif key == "resetTransforms" or key == "rt":
			resetTransforms = value
		elif key == "operation" or key == "o":
			operation = value
		elif key == "matchType" or key == "mt":
			matchType = value
		elif key == "sampleSpace" or key == "spa":
			sampleSpace = value
	
	if cmds.pluginInfo("modelingToolkit", q=True, l=True) is True:
		currentSel, objects = SS_GetCurrentSel(objects)
		selectType = SS_GetComponentType()
		# If objects are selected
		if selectType is None and len(objects) > 0:
			similarSel = SS_SelectSimilarMeshes(objects, t=tolerance, sm=objectSearchMethod)
			if similarSel is not None:
				print ("Similar objects selected.")
			else:
				if cmds.ogs(q=True, p=True) is True:
					# Unpause viewport
					cmds.ogs(p=True)
				try:
					cmds.progressBar(gMainProgressBar, e=True, ep=True)
				except:
					pass
		# If components are selected
		else:
			similarSel = SS_SelectSimilarComponents(currentSel, objects, t=tolerance, sm=objectSearchMethod, rt=resetTransforms, o=operation, mt=matchType, spa=sampleSpace)
			if similarSel is not None:
				print ("Similar components selected.")
			else:
				if cmds.ogs(q=True, p=True) is True:
					# Unpause viewport
					cmds.ogs(p=True)
				try:
					cmds.progressBar(gMainProgressBar, e=True, ep=True)
				except:
					pass

class SS_SelectSimilarWin(OptionsWindow):
	def __init__(self):
		self.windowName = "SS_SelectSimilarWin"
		self.pfx = "NTSS_"
		kwargs = {"windowSize": [440, 330], 
		          "windowTitle": "Select Similar Options", 
		          "runLabel": "Select Similar", 
		          "minWindowSize": 300, 
		          "rowOffset": 143, 
				  "preview": False}
		
		super(SS_SelectSimilarWin, self).__init__(self.windowName, **kwargs)
	
	def runCmd(self, *args):
		SS_SelectSimilar()
	
	def controlsCallback(self, *args):
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		settings = self.querySettings()
		# Match By
		if (settings[self.pfx+"MatchType"] == 1):
			cmds.rowLayout(self.pfx+"SampleSpaceRow", e=True, en=False)
			cmds.rowLayout(self.pfx+"ResetTransformsRow", e=True, en=False)
		else:
			cmds.rowLayout(self.pfx+"SampleSpaceRow", e=True, en=True)
			cmds.rowLayout(self.pfx+"ResetTransformsRow", e=True, en=True)
		# Sample Space
		if (settings[self.pfx+"SampleSpace"] == 1):
			cmds.rowLayout(self.pfx+"MatchTypeRow", e=True, en=False)
			cmds.rowLayout(self.pfx+"OperationRow", e=True, en=False)
		else:
			cmds.rowLayout(self.pfx+"MatchTypeRow", e=True, en=True)
			cmds.rowLayout(self.pfx+"OperationRow", e=True, en=True)
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, ex=True) is True):
			cmds.deleteUI(self.windowName, wnd=True)
		cmds.window(self.windowName, t=self.windowTitle, mb=True, s=True, mxb=True)
		
		# Edit menu
		cmds.menu(l="Edit")
		cmds.menuItem(l="Save Settings", c=(partial(self.saveSettings, 1)), ecr=False)
		cmds.menuItem(l="Reset Settings", c=(partial(self.resetSettings)), ecr=False)
		cmds.menuItem(d=True)
		cmds.menuItem(l="Reset Window Size", c=(partial(self.resetWindowSize)), ecr=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(l="Help", helpMenu=True)
		cmds.menuItem(label="Help on {0}".format(self.windowTitle), image="help.png", command=(partial(helpCmd, helpUrl="/docs/selectsimilar-overview/")), enableCommandRepeat=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tv=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", cr=True, rc=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"SettingsFrame", l="Select Similar Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"SettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"SettingsColumn1", adj=True, cat=("left", 0))
		# Similarity Tolerance
		cmds.rowLayout(self.pfx+"SimilarityToleranceRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"), adj=2)
		cmds.text(l="Similarity Tolerance:")
		cmds.floatSliderGrp(self.pfx+"SimilarityTolerance", dtg=self.pfx+"SimilarityTolerance", l="", f=True, pre=4, v=0.1, min=0, max=10, fmx=1000000000, cw3=(1, 70, 1), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Search Method
		cmds.rowLayout(self.pfx+"ObjectSearchMethodRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Search Method:")
		cmds.radioButtonGrp(self.pfx+"ObjectSearchMethod", dtg=self.pfx+"ObjectSearchMethod", l="", nrb=3, la3=("Local", "Component", "Topology"), sl=1, cw4=(0, 70, 100, 100), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Ignore Instances
		cmds.rowLayout(self.pfx+"IgnoreInstancesRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"IgnoreInstances", dtg=self.pfx+"IgnoreInstances", l="", l1="Ignore Instances", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Ignore Hidden Objects
		cmds.rowLayout(self.pfx+"IgnoreHiddenObjectsRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"IgnoreHiddenObjects", dtg=self.pfx+"IgnoreHiddenObjects", l="", l1="Ignore Hidden Objects / Layers", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Isolate Constraint
		cmds.rowLayout(self.pfx+"IsolateConstraintRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"IsolateConstraint", dtg=self.pfx+"IsolateConstraint", l="", l1="Isolate Mode: Isolated Objects Only", v1=True, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# START: Poly Bevel Settings Frame
		cmds.frameLayout(self.pfx+"ComponentsSettingsFrame", l="Components Settings", li=5, cll=False, bgs=True, mh=4, mw=0)
		cmds.formLayout(self.pfx+"ComponentsSettingsForm")
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"ComponentsSettingsColumn1", adj=True, cat=("left", 0))
		# Operation
		cmds.rowLayout(self.pfx+"OperationRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Operation:")
		cmds.radioButtonGrp(self.pfx+"Operation", dtg=self.pfx+"Operation", l="", nrb=2, la2=("Match", "Select Similar"), sl=1, cw3=(0, 70, 100), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Match By
		cmds.rowLayout(self.pfx+"MatchTypeRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Match By:")
		cmds.radioButtonGrp(self.pfx+"MatchType", dtg=self.pfx+"MatchType", l="", nrb=2, la2=("Indices", "Topology"), sl=1, cw3=(0, 70, 100), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Sample Space
		cmds.rowLayout(self.pfx+"SampleSpaceRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="Sample Space:")
		cmds.radioButtonGrp(self.pfx+"SampleSpace", dtg=self.pfx+"SampleSpace", l="", nrb=3, la3=("World", "Component", "Topology"), sl=2, cw4=(0, 70, 100, 100), onc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Reset Transforms
		cmds.rowLayout(self.pfx+"ResetTransformsRow", nc=2, cw=(1, self.rowOffset), cat=(1, "right", 0), ct2=("left", "left"))
		cmds.text(l="")
		cmds.checkBoxGrp(self.pfx+"ResetTransforms", dtg=self.pfx+"ResetTransforms", l="", l1="Ignore Transformations", v1=False, cw2=(2, 140), cc=(partial(self.controlsCallback)))
		cmds.setParent("..")
		# Separation
		cmds.rowLayout(h=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", nd=150)
		cmds.iconTextButton(self.pfx+"executeButton", l=self.runLabel, c=(partial(self.buttonsCmd, True, True)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"applyButton", l="Apply", c=(partial(self.buttonsCmd, True, False)), flat=False, h=26, st="textOnly", rpt=True)
		cmds.iconTextButton(self.pfx+"closeButton", l="Close", c=(partial(self.buttonsCmd, False, True)), flat=False, h=26, st="textOnly", rpt=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, e=True,
						af=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						ac=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, e=True,
						an=(self.pfx+"ButtonForm", "top"),
						af=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", e=True,
						af=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, e=True,
						af=[(self.pfx+"SettingsFrame", "top", 0), (self.pfx+"SettingsFrame", "left", 0), (self.pfx+"SettingsFrame", "right", 0)],
						an=(self.pfx+"SettingsFrame", "bottom"))
		cmds.formLayout(self.scrollForm, e=True,
						ac=(self.pfx+"ComponentsSettingsFrame", "top", 0, self.pfx+"SettingsFrame"),
						af=[(self.pfx+"ComponentsSettingsFrame", "left", 0), (self.pfx+"ComponentsSettingsFrame", "right", 0)],
						an=(self.pfx+"ComponentsSettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"SettingsForm", e=True,
						af=[(self.pfx+"SettingsColumn1", "top", 0), (self.pfx+"SettingsColumn1", "left", 0), (self.pfx+"SettingsColumn1", "right", 0)],
						an=(self.pfx+"SettingsColumn1", "bottom"))
		cmds.formLayout(self.pfx+"ComponentsSettingsForm", e=True,
						af=[(self.pfx+"ComponentsSettingsColumn1", "top", 0), (self.pfx+"ComponentsSettingsColumn1", "left", 0), (self.pfx+"ComponentsSettingsColumn1", "right", 0)],
						an=(self.pfx+"ComponentsSettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"executeButton", "top", 0),
						ap=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						an=(self.pfx+"executeButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"applyButton", "top", 0),
						ap=[(self.pfx+"applyButton", "left", 2, 50), (self.pfx+"applyButton", "right", 2, 100)],
						an=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", e=True,
						af=(self.pfx+"closeButton", "top", 0),
						ap=[(self.pfx+"closeButton", "left", 2, 100), (self.pfx+"closeButton", "right", 0, 150)],
						an=(self.pfx+"closeButton", "bottom"))
