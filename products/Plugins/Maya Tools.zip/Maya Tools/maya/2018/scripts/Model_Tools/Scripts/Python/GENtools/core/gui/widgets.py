#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import os
try:
	from PySide2 import QtCore, QtGui, QtWidgets, QtUiTools
except ImportError:
	from PySide import QtCore, QtGui, QtUiTools
	from PySide import QtGui as QtWidgets
from webbrowser import open_new_tab

# for python 3 compatibility
import six

class QWindowCustom(QtWidgets.QMainWindow):
	def __init__(self, parent, ui_file=None, ui_widget=None, customWidgets=[]):
		super(QWindowCustom, self).__init__(parent)
		
		# Load ui
		self._ui_widget = None
		self._ui_file = None
		self._customWidgets = []
		self.setUIFile(ui_file)
		self.setUIWidget(ui_widget)
		self.setCustomWidgets(customWidgets)
		
		# Window type
		window_flags = QtCore.Qt.Tool | QtCore.Qt.FramelessWindowHint
		if hasattr(QtCore.Qt, "NoDropShadowWindowHint"):
			window_flags |= QtCore.Qt.NoDropShadowWindowHint
		self.setWindowFlags(window_flags)
		# Widget attributes
		self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
		self.setAttribute(QtCore.Qt.WA_DeleteOnClose)		
		# Set focus policy
		self.setFocusPolicy(QtCore.Qt.StrongFocus)
		
		# Create UI
		self.createUI()
		
		# Set stylesheet
		self.setStyleSheet(self.getStyleSheet())
	
	def getStyleSheet(self):
		return ""
	
	def setCustomWidgets(self, customWidgets):
		if customWidgets and isinstance(customWidgets, (list, tuple)):
			self._customWidgets = customWidgets
	
	def addWidgetShadow(self, target, shadowRadius=8, shadowOpacity=70):
		shadowEffect = QtWidgets.QGraphicsDropShadowEffect(self)
		shadowEffect.setBlurRadius(shadowRadius)
		shadowEffect.setXOffset(0)
		shadowEffect.setYOffset(0)
		shadowEffect.setColor(QtGui.QColor(0, 0, 0, int(round(255/100*shadowOpacity))))
		target.setGraphicsEffect(shadowEffect)
	
	def setUIFile(self, ui_file):
		if ui_file and isinstance(ui_file, six.string_types) and os.path.isfile(ui_file) and ui_file.endswith(".ui"):
			self._ui_file = ui_file
	
	def setUIWidget(self, ui_widget):
		if not self._ui_file and ui_widget and isinstance(ui_widget, object) and callable(ui_widget):
			self._ui_widget = ui_widget()
	
	def createUI(self):
		# Load window from .ui file
		if self._ui_file:
			# Create .ui loader
			loader = QtUiTools.QUiLoader()
			for customWidget in self._customWidgets:
				loader.registerCustomWidget(customWidget)
			
			# Load .ui file
			ui_file = QtCore.QFile(self._ui_file)
			if not ui_file.exists():
				return
			
			ui_file.open(QtCore.QFile.ReadOnly)
			self._ui_widget = loader.load(ui_file)
			ui_file.close()
			
			# Attach window to QMainWindow
			self.setCentralWidget(self._ui_widget)
		
		# Load window from .py
		elif self._ui_widget:
			self._ui_widget.setupUi(self)
		
		else:
			return
		
		# Set controls property
		self.setControlsProperty()
		
		# Window size
		self.resize(self.sizeHint())
	
	def setControlsProperty(self):
		pass
	
	def setFocus(self, mayaWin=False):
		super(QWindowCustom, self).setFocus()
		
		if mayaWin and self.objectName() and cmds.window(self.objectName(), exists=True):
			cmds.setFocus(self.objectName())
	
	def initUI(self):
		# Show window
		if self._ui_widget:
			# Show window
			self.show()
			# Set focus
			self.setFocus()

class QFrameUrl(QtWidgets.QFrame):
	clicked = QtCore.Signal()
	
	def __init__(self, parent=None, icon="", iconHover="", url=""):
		super(QFrameUrl, self).__init__(parent)
		
		self._iconFile = None
		self._iconHoverFile = None
		self._url = ""
		self._underMouse = True
		
		layout = QtWidgets.QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.setSpacing(10)
		self._icon = QtWidgets.QLabel(self)
		self._label = QtWidgets.QLabel(self)
		spacerItem = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
		layout.addWidget(self._icon)
		layout.addWidget(self._label)
		layout.addItem(spacerItem)
		
		if icon:
			self.setIcon(icon)
		if iconHover:
			self.setIconHover(iconHover)
		if url:
			self.setUrl(url)
		
		self.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
		self.clicked.connect(self.openUrl)
	
	def setText(self, text):
		if text and isinstance(text, six.string_types):
			self._label.setText(text)
	
	def setIcon(self, icon):
		if icon and isinstance(icon, six.string_types):
			if QtCore.QFile(icon).exists() or os.path.isfile(icon):
				self._iconFile = icon
				self._icon.setPixmap(QtGui.QPixmap(self._iconFile))
	
	def setIconHover(self, icon):
		if icon and isinstance(icon, six.string_types):
			if QtCore.QFile(icon).exists() or os.path.isfile(icon):
				self._iconHoverFile = icon
	
	def setUrl(self, url):
		if url and isinstance(url, six.string_types):
			self._url = url
	
	def openUrl(self):
		if self._url:
			open_new_tab(self._url)
	
	def mouseReleaseEvent(self, event):
		if event.button() == QtCore.Qt.LeftButton:
			# Check if cursor still inside widget
			cursorPos = self.mapFromGlobal(QtGui.QCursor.pos())
			widgetSize = self.size()
			if not any([cursorPos.x() > widgetSize.width(), cursorPos.x() < 0, cursorPos.y() > widgetSize.height(), cursorPos.y() < 0]):
				if self.underMouse():
					self.clicked.emit()
		
		self._underMouse = True
		QtWidgets.QApplication.restoreOverrideCursor()
		
		super(QFrameUrl, self).mouseReleaseEvent(event)
	
	def enterEvent(self, event):
		if self.isEnabled():
			self.setProperty("hover", True)
			self._label.setStyle(self.style())
			
			if self._iconFile and self._iconHoverFile:
				self._icon.setPixmap(QtGui.QPixmap(self._iconHoverFile))
		
		super(QFrameUrl, self).enterEvent(event)
	
	def leaveEvent(self, event):
		if self.isEnabled():
			self.setProperty("hover", False)
			self._label.setStyle(self.style())
			
			if self._iconFile and self._iconHoverFile:
				self._icon.setPixmap(QtGui.QPixmap(self._iconFile))
		
		super(QFrameUrl, self).leaveEvent(event)
	
	def mouseMoveEvent(self, event):
		if event.buttons() == QtCore.Qt.LeftButton:
			# Check if cursor still inside widget
			cursorPos = self.mapFromGlobal(QtGui.QCursor.pos())
			widgetSize = self.size()
			if any([cursorPos.x() > widgetSize.width(), cursorPos.x() < 0, cursorPos.y() > widgetSize.height(), cursorPos.y() < 0]):
				if self._underMouse:
					self._underMouse = False
					
					self.setProperty("hover", False)
					self._label.setStyle(self.style())
					
					if self._iconFile and self._iconHoverFile:
						self._icon.setPixmap(QtGui.QPixmap(self._iconFile))
					
					QtWidgets.QApplication.restoreOverrideCursor()
					QtWidgets.QApplication.setOverrideCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
			elif not self._underMouse:
				self._underMouse = True
				
				self.setProperty("hover", True)
				self._label.setStyle(self.style())
				
				if self._iconFile and self._iconHoverFile:
					self._icon.setPixmap(QtGui.QPixmap(self._iconHoverFile))
				
				QtWidgets.QApplication.restoreOverrideCursor()
				QtWidgets.QApplication.setOverrideCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
		
		super(QFrameUrl, self).mouseMoveEvent(event)

class QLabelButton(QtWidgets.QLabel):
	clicked = QtCore.Signal()
	_is_pressed = False
	
	def mouseReleaseEvent(self, event):
		if event.button() == QtCore.Qt.LeftButton:
			# Check if cursor still inside widget
			cursorPos = self.mapFromGlobal(QtGui.QCursor.pos())
			widgetSize = self.size()
			if not any([cursorPos.x() > widgetSize.width(), cursorPos.x() < 0, cursorPos.y() > widgetSize.height(), cursorPos.y() < 0]):
				if self.underMouse():
					self.clicked.emit()
			
			self._is_pressed = False
			self.setProperty("clicked", False)
			self.setStyle(self.style())
		
		super(QLabelButton, self).mouseReleaseEvent(event)
	
	def mousePressEvent(self, event):
		if event.button() == QtCore.Qt.LeftButton:
			self._is_pressed = True
			self.setProperty("clicked", True)
			self.setStyle(self.style())

		super(QLabelButton, self).mousePressEvent(event)

	def enterEvent(self, event):
		if self.isEnabled():
			self.setProperty("hover", True)
			self.setStyle(self.style())
		
		super(QLabelButton, self).enterEvent(event)
	
	def leaveEvent(self, event):
		if self.isEnabled():
			self.setProperty("hover", False)
			self.setStyle(self.style())
		
		super(QLabelButton, self).leaveEvent(event)
	
	def mouseMoveEvent(self, event):
		if event.buttons() == QtCore.Qt.LeftButton:
			# Check if cursor still inside widget
			cursorPos = self.mapFromGlobal(QtGui.QCursor.pos())
			widgetSize = self.size()
			if any([cursorPos.x() > widgetSize.width(), cursorPos.x() < 0, cursorPos.y() > widgetSize.height(), cursorPos.y() < 0]):
				self.setProperty("hover", False)
				self.setProperty("clicked", False)
				self.setStyle(self.style())
			else:
				self.setProperty("hover", True)
				if self._is_pressed:
					self.setProperty("clicked", True)
				self.setStyle(self.style())
		
		super(QLabelButton, self).mouseMoveEvent(event)

class QFrameTitleBar(QtWidgets.QFrame):
	def __init__(self, parent=None, title="", icon=""):
		super(QFrameTitleBar, self).__init__(parent)
		
		self._oldPos = None
		self.setMouseTracking(True)
		
		self.createFrame()
		self.setProperty("defaultCss", True)
		self.setStyleSheet(self.getStyleSheet())
		
		self.setIcon(icon)
		self.setText(title)
	
	def createFrame(self):
		layout = QtWidgets.QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 1)
		layout.setSpacing(0)
		
		self._titleIcon = QtWidgets.QLabel(self)
		self._titleLabel = QtWidgets.QLabel(self)
		spacerItem = QtWidgets.QSpacerItem(0, 0, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
		self._closeButton = QLabelButton(self)
		
		layout.addWidget(self._titleIcon)
		layout.addWidget(self._titleLabel)
		layout.addItem(spacerItem)
		layout.addWidget(self._closeButton)
		
		# Frame
		self.setMinimumSize(QtCore.QSize(0, 31))
		self.setMaximumSize(QtCore.QSize(16777215, 31))
		self.setProperty("class", "titleBar")
		
		# Icon
		self._titleIcon.setMinimumSize(QtCore.QSize(39, 31))
		self._titleIcon.setMaximumSize(QtCore.QSize(39, 31))
		self._titleIcon.setPixmap(QtGui.QPixmap(":/images/GENtools_logo_16.png"))
		self._titleIcon.setAlignment(QtCore.Qt.AlignCenter)
		
		# Title
		self._titleLabel.setMinimumSize(QtCore.QSize(0, 31))
		self._titleLabel.setMaximumSize(QtCore.QSize(16777215, 31))
		
		# Close Button
		self._closeButton.setMinimumSize(QtCore.QSize(45, 29))
		self._closeButton.setMaximumSize(QtCore.QSize(45, 29))
		self._closeButton.setAlignment(QtCore.Qt.AlignCenter)
		self._closeButton.setPixmap(QtGui.QPixmap(":/images/icon_close_12.png"))
		self._closeButton.clicked.connect(self.window().close)
		self._closeButton.setProperty("class", "closeButton")
	
	def closeEvent(self, event):
		self.window().close()
	
	def getStyleSheet(self):
		return ("""
			QFrame.titleBar[defaultCss=True]{
				background-color: rgba(15, 15, 15, 100%);
				border-bottom: 1px solid rgba(55, 55, 55, 100%);
			}
			
			QLabelButton.closeButton{
				background-color: rgba(15, 15, 15, 0%);
			}
			
			QLabelButton.closeButton[hover=true]{
				background-color: rgba(232, 17, 35, 100%);
			}

			QLabelButton.closeButton[clicked=true]{
				/*background-color: rgba(241, 112, 122, 100%);*/
				background-color: rgba(217, 64, 77, 70%);
			}
		""")
	
	def setIcon(self, icon):
		if icon and isinstance(icon, six.string_types):
			if QtCore.QFile(icon).exists() or os.path.isfile(icon):
				self._titleIcon.setPixmap(QtGui.QPixmap(icon))

	def setText(self, text):
		if text and isinstance(text, six.string_types):
			self._titleLabel.setText(text)
	
	def mousePressEvent(self, event):
		if event.button() == QtCore.Qt.LeftButton:
			if not self._closeButton.underMouse():
				self._oldPos = event.globalPos()
		
		super(QFrameTitleBar, self).mousePressEvent(event)
	
	def mouseReleaseEvent(self, event):
		self._oldPos = None
		
		super(QFrameTitleBar, self).mouseReleaseEvent(event)
	
	def mouseMoveEvent(self, event):
		if self._oldPos:
			delta = QtCore.QPoint(event.globalPos() - self._oldPos)
			self.window().move(self.window().x() + delta.x(), self.window().y() + delta.y())
			self._oldPos = event.globalPos()
		
		super(QFrameTitleBar, self).mouseMoveEvent(event)