#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):	
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Multi Transform")
		self.scriptLoader.setStartupFile("MultiTransform.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Edit Mesh")
		self.scriptLoader.setMenuItemDict({"image": "polyMoveVertex.png", "sourceType": "mel", "command": "MultiTransform"})
		return self.scriptLoader