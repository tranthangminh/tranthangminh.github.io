# -*- coding: utf-8 -*-

def clearLayout(layout):
	if layout:
		while layout.count():
			item = layout.takeAt(0)
			if not item:
				continue
			
			widget = item.widget()
			if widget:
				widget.deleteLater()
			else:
				clearLayout(item.layout())