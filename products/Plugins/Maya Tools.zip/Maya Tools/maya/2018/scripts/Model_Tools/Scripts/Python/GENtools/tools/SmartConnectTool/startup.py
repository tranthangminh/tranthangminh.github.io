#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Smart Connect Tool")
		self.scriptLoader.setStartupFile("SmartConnectTool.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Mesh Tools")
		self.scriptLoader.setMenuItemDict({"image": "polyConnectComponents.png", "subMenu": True, "tearOff": True})
		self.scriptLoader.setMenuItemFunc(self.createMenuItem)
		return self.scriptLoader
	
	def createMenuItem(self):
		cmds.menuItem(label="Smart Connect Tool", image="polyConnectComponents.png", sourceType="mel", command="SmartConnectTool", dragDoubleClickCommand="SmartConnectToolOptions")
		cmds.menuItem(image="polyConnectComponents.png", optionBox=True, sourceType="mel", command="SmartConnectToolOptions")
		cmds.menuItem(divider=True, dividerLabel="Edit Mesh")
		cmds.menuItem(label="Cut Through Faces", image="polyConnectComponents.png", sourceType="mel", command="CutThroughFaces")
		cmds.menuItem(label="Insert With Edge Flow", image="polyEditEdgeFlow.png", sourceType="mel", command="InsertWithEdgeFlow")