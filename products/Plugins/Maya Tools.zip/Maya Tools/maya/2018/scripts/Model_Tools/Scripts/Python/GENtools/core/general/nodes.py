#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.api.OpenMaya as om

class MayaNode(object):
	def __init__(self, node_name):
		selection = om.MSelectionList()
		self._mobject = om.MObject()
		self._node = om.MFnDependencyNode()
		self._uuid = None
		self._mdagpath = om.MDagPath()
		try:
			selection.add(node_name)
			self._mobject = selection.getDependNode(0)
			self._node = om.MFnDependencyNode(self._mobject)
			self._uuid = self._node.uuid()
			self._mdagpath = selection.getDagPath(0)
		except:
			pass

	def __repr__(self):
		return '<{0}("{1}") object at {2}>'.format(self.__class__.__name__, self.name(), hex(id(self)))

	def verify_identity(self, objName):
		try:
			selection = om.MSelectionList()
			selection.add(objName)
			if om.MFnDependencyNode(selection.getDependNode(0)).uuid() == self._uuid:
				return True
		except RuntimeError:
			pass
		return False

	def name(self, long=False):
		nodeName = None
		
		if not self._mobject.isNull():
			if self._mdagpath.isValid():
				if long:
					nodeName = self._mdagpath.fullPathName()
				else:
					nodeName = self._mdagpath.partialPathName()
			else:
				nodeName = self._node.name()
		
		if nodeName and not self.verify_identity(nodeName):
			nodeName = None
		
		return nodeName
