#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numbers
try:
	import winreg
except:
	import _winreg as winreg

# for python 3 compatibility
from six.moves import range

class RegEdit():
	def __init__(self, **kwargs):
		# Default variables
		self.rootKey = winreg.HKEY_CURRENT_USER
		self.regPath = None
		self.keyName = None
		self.keyValue = None
		self.deleteKey = False
	
	def reg(self, **kwargs):		
		# Load keyworded arguments
		for key, value in kwargs.items():
			if key == "rootKey" or key == "rk":
				if value == "HKEY_CURRENT_USER" or value == 2147483649:
					self.rootKey = winreg.HKEY_CURRENT_USER
				elif value == "HKEY_LOCAL_MACHINE" or value == 2147483650:
					self.rootKey = winreg.HKEY_LOCAL_MACHINE
				else:
					self.rootKey = None
			elif key == "regPath" or key == "rp":
				self.regPath = value
			elif key == "keyName" or key == "kn":
				self.keyName = str(value)
			elif key == "keyValue" or key == "kv":
				self.keyValue = str(value)
			elif key == "deleteKey" or key == "dk":
				self.deleteKey = bool(value)
		
		if isinstance(self.rootKey, numbers.Integral) is True and self.regPath is not None:
			if None not in (self.regPath, self.keyName, self.keyValue):
				return self.set_reg(self.rootKey, self.regPath, self.keyName, self.keyValue)
			elif None not in (self.regPath, self.keyName):
				return self.get_reg(self.rootKey, self.regPath, self.keyName)
			elif self.regPath:
				if self.deleteKey:
					return self.delete_key(self.rootKey, self.regPath)
				return self.get_reg_values(self.rootKey, self.regPath)
		return None
	
	# Delete the key and all sub_keys.	
	def delete_key(self, rootKey, regPath): 
		try:
			#arch_keys = [winreg.KEY_WOW64_32KEY, winreg.KEY_WOW64_64KEY]
			arch_key = 0
			open_key = winreg.OpenKey(rootKey, regPath, 0, winreg.KEY_ALL_ACCESS | arch_key)
			info_key = winreg.QueryInfoKey(open_key)
			for i in range(info_key[0]):
				child_key = winreg.EnumKey(open_key, 0)
				self.delete_key(open_key, child_key)
			try:
				winreg.DeleteKey(open_key, "")
			except WindowsError as e:
				pass
			finally:
				winreg.CloseKey(open_key)
		except WindowsError as e:
			return False

	def set_reg(self, rootKey, regPath, keyName, keyValue):
		try:
			winreg.CreateKey(rootKey, regPath)
			registry_key = winreg.OpenKey(rootKey, regPath, 0, winreg.KEY_WRITE)
			winreg.SetValueEx(registry_key, keyName, 0, winreg.REG_SZ, keyValue)
			winreg.CloseKey(registry_key)
			return True
		except WindowsError as e:
			return False
	
	def get_reg(self, rootKey, regPath, keyName):
		try:
			registry_key = winreg.OpenKey(rootKey, regPath, 0, winreg.KEY_READ)
			value, regtype = winreg.QueryValueEx(registry_key, keyName)
			winreg.CloseKey(registry_key)
			return value
		except WindowsError as e:
			return None
	
	def get_reg_values(self, rootKey, regPath):
		try:
			keys = []
			values = []
			key = winreg.OpenKey(rootKey, regPath, 0, winreg.KEY_READ)
			
			for i in range(0, winreg.QueryInfoKey(key)[1]):
				keys.append(winreg.EnumValue(key, i))

			for i in range(0, winreg.QueryInfoKey(key)[0]):
				values.append(winreg.EnumKey(key, i))
			
			return (keys, values)
		except WindowsError as e:
			return ([], [])
