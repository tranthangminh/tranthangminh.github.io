#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.OpenMaya as OpenMaya

# for python 3 compatibility
import six

def GetBorderEdges(*args, **kwargs):
	# Create default args
	selection = None
	flatten = False
	borderEdges = []
	borderEdgesList = OpenMaya.MSelectionList()
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			selection = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = value
		elif key == "flatten" or key == "fl":
			flatten = value
	
	if selection is None:
		selection = cmds.polyListComponentConversion(te=True)
	
	if selection is not None:
		selList = OpenMaya.MSelectionList()
		for edge in selection:
			selList.add(edge)
		
		dagPath = OpenMaya.MDagPath()
		component = OpenMaya.MObject()
		
		# Iterate over selList
		sel_iter = OpenMaya.MItSelectionList(selList)
		iterIndex = 0
		while not sel_iter.isDone():
			selList.getDagPath(iterIndex, dagPath, component)
			if component.hasFn(OpenMaya.MFn.kMeshEdgeComponent):
				dagPath.pop() # Remove shape
				node = dagPath.fullPathName()
				try:
					edge_itr = OpenMaya.MItMeshEdge(dagPath, component)
				except:
					cmds.delete(cmds.ls(cmds.listConnections("{0}.inMesh".format(node), c=False, d=False, s=True)[0], typ="transformGeometry"))
					edge_itr = OpenMaya.MItMeshEdge(dagPath, component)
				while not edge_itr.isDone():
					edgeId = edge_itr.index()
					onBoundary = edge_itr.onBoundary()
					
					if onBoundary is True:
						borderEdgesList.add(dagPath, edge_itr.currentItem())
					
					edge_itr.next()
			
			iterIndex += 1
			sel_iter.next()
		
		# Create new list and merge elements (unflatten list)
		mergedList = OpenMaya.MSelectionList()
		if borderEdgesList.isEmpty() is False:
			mergedList.merge(borderEdgesList, OpenMaya.MSelectionList.kMergeNormal)
		
		mergedList.getSelectionStrings(borderEdges)
		# Return full path strings
		if flatten is False:
			borderEdges = cmds.ls(borderEdges, l=True)
		else:
			borderEdges = cmds.ls(borderEdges, l=True, fl=True)
	return borderEdges

def SelectBorderEdges(selection=None):
	edge_borders = GetBorderEdges(selection)
	if len(edge_borders) > 0:
		cmds.selectMode(component=True)
		cmds.selectType(edge=True)
		cmds.select(edge_borders, replace=True)