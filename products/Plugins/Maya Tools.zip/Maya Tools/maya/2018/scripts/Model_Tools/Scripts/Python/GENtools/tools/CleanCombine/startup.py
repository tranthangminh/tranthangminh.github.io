#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader
import maya.cmds as cmds

class LoadScript(object):	
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Clean Combine")
		self.scriptLoader.setStartupFile("CleanCombine.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Mesh")
		self.scriptLoader.setMenuItemDict({"image": "polyUnite.png", "sourceType": "mel", "command": "gCleanCombine"})
		return self.scriptLoader