#!/usr/bin/python
# -*- coding: utf-8 -*-
import maya.cmds as cmds
import maya.api.OpenMaya as om

# for python 3 compatibility
import six

def getFreeAttributeIndex(node, attribute, startIndex=0, maxIndex=1000000):
	# Check if attributes contains childrens
	child_attributes = cmds.attributeQuery(attribute, node=node, listChildren=True) or [""]
	# Format attributes string for query
	if child_attributes:
		child_attributes = [".{0}".format(attr) for attr in child_attributes]
	
	# Find next free index
	while startIndex < maxIndex:
		attr_free = True
		
		# All children attributes must be free otherwise increment index
		for child_attr in child_attributes:
			if len(cmds.connectionInfo("{0}.{1}[{2}]{3}".format(node, attribute, startIndex, child_attr), sourceFromDestination=True) or []) != 0:
				attr_free = False
				startIndex += 1
				break
		
		if attr_free is True:
			return startIndex
	
	# No connections means the first index is available
	return 0

def stringToPlug(node, attribute):
	plug = None

	selList = om.MSelectionList()
	try:
		selList.add(node)
	except:
		pass

	if not selList.isEmpty():
		mObj = selList.getDependNode(0)
		dependencyNode = om.MFnDependencyNode(mObj)
		if dependencyNode.hasAttribute(attribute):
			plug = dependencyNode.findPlug(attribute, False)
	
	return plug

def getAttachedToPlug(plug, *args, **kwargs):
	attachedObjects = []
	typeNames = []
	noIntermediate = False

	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "type" or key == "t":
			if not isinstance(value, (list, tuple)):
				typeNames = [value]
			else:
				typeNames = value
		elif key == "noIntermediate" or key == "ni":
			noIntermediate = value

	if isinstance(plug, om.MPlug) and plug.isConnected:
		outputDependencyGraph = om.MItDependencyGraph(plug, *args)
		#outputDependencyGraph.pruningOnFilter = True
		#outputDependencyGraph.traversingOverWorldSpaceDependents = True
		while not outputDependencyGraph.isDone():
			if outputDependencyGraph.currentNode() != outputDependencyGraph.rootNode():
				currentItem = outputDependencyGraph.currentNode()

				if not outputDependencyGraph.currentFilter or currentItem.apiType() == outputDependencyGraph.currentFilter:
					currentDependencyNode = om.MFnDependencyNode(currentItem)
					
					if not typeNames or currentDependencyNode.typeName in typeNames:
						try:
							dagNode = om.MFnDagNode(currentItem)
							if not noIntermediate or all([noIntermediate, not dagNode.isIntermediateObject]):
								#dagPath = dagNode.getPath()
								attachedObjects.append(dagNode.fullPathName())
						except:
							attachedObjects.append(currentDependencyNode.name())
				
			outputDependencyGraph.next()

	return attachedObjects

def getAttachedToAttribute(node, attribute, *args, **kwargs):
	attachedObjects = []

	plug = stringToPlug(node, attribute)
	if plug:
		attachedObjects = getAttachedToPlug(plug, *args, **kwargs)
	
	return attachedObjects

def getObjectFromPlug(plug, shape=False):
	if isinstance(plug, om.MPlug):
		plugNode = plug.node()
		if not plugNode.isNull():
			try:
				dagNode = om.MFnDagNode(plugNode)
				dagPath = dagNode.getPath()
				if dagPath.isValid() and dagPath.fullPathName():
					if not shape:
						dagPath.pop()
				return dagPath.fullPathName()
			except:
				dependencyNode = om.MFnDependencyNode(plugNode)
				return dependencyNode.name()
	return None

def getPlugAttribute(plug):
	if isinstance(plug, om.MPlug):
		plugAttribute = plug.attribute()
		if plugAttribute.hasFn(om.MFn.kAttribute):
			return plug.attribute()
	elif isinstance(plug, om.MObject):
		if plug.hasFn(om.MFn.kAttribute):
			return plug
	return None

def plugMatch(plug, plugs, quick=True):
	if not isinstance(plugs, (list, tuple)):
		plugs = [plugs]
	
	if quick:
		return any([plug == x for x in plugs])
	
	plugAttribute = getPlugAttribute(plug)
	for p in plugs:
		pAttribute = getPlugAttribute(p)
		if plugAttribute == pAttribute:
			return True
	
	return False
