#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Select Similar")
		self.scriptLoader.setStartupFile("SelectSimilar.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Select")
		self.scriptLoader.setMenuItemDict({"image": "selectSimilar.png", "sourceType": "mel", "command": "gSelectSimilar"})
		self.scriptLoader.setMenuItemOptionDict({"sourceType": "mel", "command": "gSelectSimilarOptions"})
		return self.scriptLoader