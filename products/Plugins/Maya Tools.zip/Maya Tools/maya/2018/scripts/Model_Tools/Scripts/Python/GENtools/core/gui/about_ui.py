# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'about_ui.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

try:
    from PySide2.QtCore import *
    from PySide2.QtGui import *
    from PySide2.QtWidgets import *
except ImportError:
    from PySide.QtCore import *
    from PySide.QtGui import *

from .widgets import QFrameUrl
from .widgets import QFrameTitleBar

from . import about_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(314, 238)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralWidgetLayout = QHBoxLayout(self.centralwidget)
        self.centralWidgetLayout.setSpacing(0)
        self.centralWidgetLayout.setObjectName(u"centralWidgetLayout")
        self.centralWidgetLayout.setContentsMargins(8, 8, 8, 8)
        self.windowFrame = QFrame(self.centralwidget)
        self.windowFrame.setObjectName(u"windowFrame")
        self.windowFrameLayout = QVBoxLayout(self.windowFrame)
        self.windowFrameLayout.setSpacing(0)
        self.windowFrameLayout.setObjectName(u"windowFrameLayout")
        self.windowFrameLayout.setContentsMargins(0, 0, 0, 0)
        self.titleBar = QFrameTitleBar(self.windowFrame)
        self.titleBar.setObjectName(u"titleBar")

        self.windowFrameLayout.addWidget(self.titleBar)

        self.windowLayout = QHBoxLayout()
        self.windowLayout.setSpacing(15)
        self.windowLayout.setObjectName(u"windowLayout")
        self.windowLayout.setContentsMargins(20, 20, 20, 20)
        self.contentSpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.windowLayout.addItem(self.contentSpacerLeft)

        self.GENtools_Logo = QLabel(self.windowFrame)
        self.GENtools_Logo.setObjectName(u"GENtools_Logo")
        self.GENtools_Logo.setMinimumSize(QSize(145, 147))
        self.GENtools_Logo.setMaximumSize(QSize(145, 147))
        self.GENtools_Logo.setPixmap(QPixmap(u":/images/GENtools_logo_512.png"))
        self.GENtools_Logo.setScaledContents(True)
        self.GENtools_Logo.setAlignment(Qt.AlignCenter)

        self.windowLayout.addWidget(self.GENtools_Logo)

        self.creatorsLayout = QVBoxLayout()
        self.creatorsLayout.setSpacing(15)
        self.creatorsLayout.setObjectName(u"creatorsLayout")
        self.creatorsLayout.setContentsMargins(15, 15, 15, 15)
        self.creatorsSpacerTop = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.creatorsLayout.addItem(self.creatorsSpacerTop)

        self.creatorsLabel = QLabel(self.windowFrame)
        self.creatorsLabel.setObjectName(u"creatorsLabel")

        self.creatorsLayout.addWidget(self.creatorsLabel)

        self.gabrielLabel = QFrameUrl(self.windowFrame)
        self.gabrielLabel.setObjectName(u"gabrielLabel")

        self.creatorsLayout.addWidget(self.gabrielLabel)

        self.etienneLabel = QFrameUrl(self.windowFrame)
        self.etienneLabel.setObjectName(u"etienneLabel")

        self.creatorsLayout.addWidget(self.etienneLabel)

        self.creatorsSpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.creatorsLayout.addItem(self.creatorsSpacerBottom)


        self.windowLayout.addLayout(self.creatorsLayout)

        self.contentSpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.windowLayout.addItem(self.contentSpacerRight)


        self.windowFrameLayout.addLayout(self.windowLayout)

        self.separatorLayout = QHBoxLayout()
        self.separatorLayout.setSpacing(0)
        self.separatorLayout.setObjectName(u"separatorLayout")
        self.separatorFrame = QFrame(self.windowFrame)
        self.separatorFrame.setObjectName(u"separatorFrame")
        self.separatorFrame.setMinimumSize(QSize(0, 1))
        self.separatorFrame.setMaximumSize(QSize(16777215, 1))
        self.separatorFrame.setFrameShape(QFrame.NoFrame)
        self.separatorFrame.setFrameShadow(QFrame.Plain)

        self.separatorLayout.addWidget(self.separatorFrame)


        self.windowFrameLayout.addLayout(self.separatorLayout)

        self.licenseAgreementLayout = QHBoxLayout()
        self.licenseAgreementLayout.setSpacing(0)
        self.licenseAgreementLayout.setObjectName(u"licenseAgreementLayout")
        self.licenseAgreementLayout.setContentsMargins(-1, 10, -1, 10)
        self.licenseAgreementLabel = QFrameUrl(self.windowFrame)
        self.licenseAgreementLabel.setObjectName(u"licenseAgreementLabel")
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.licenseAgreementLabel.sizePolicy().hasHeightForWidth())
        self.licenseAgreementLabel.setSizePolicy(sizePolicy)

        self.licenseAgreementLayout.addWidget(self.licenseAgreementLabel)


        self.windowFrameLayout.addLayout(self.licenseAgreementLayout)


        self.centralWidgetLayout.addWidget(self.windowFrame)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"About", None))
        self.GENtools_Logo.setText("")
        self.creatorsLabel.setText(QCoreApplication.translate("MainWindow", u"Authors", None))
    # retranslateUi

