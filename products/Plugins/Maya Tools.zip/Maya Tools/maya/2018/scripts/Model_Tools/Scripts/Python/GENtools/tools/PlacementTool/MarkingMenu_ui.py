# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'MarkingMenu_ui.ui'
##
## Created by: Qt User Interface Compiler version 5.15.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

try:
    from PySide2.QtCore import *
    from PySide2.QtGui import *
    from PySide2.QtWidgets import *
except:
    from PySide.QtCore import *
    from PySide.QtGui import *

from .MarkingMenu import RadialRing
from .MarkingMenu import QFrameButton
from .MarkingMenu import QFrameSpinBox
from .MarkingMenu import QFrameLabel
from .MarkingMenu import QPieMenuComboBox


class Ui_CentralWidget(object):
    def setupUi(self, CentralWidget):
        if not CentralWidget.objectName():
            CentralWidget.setObjectName(u"CentralWidget")
        CentralWidget.resize(462, 258)
        self.CentralLayout = QVBoxLayout(CentralWidget)
        self.CentralLayout.setSpacing(5)
        self.CentralLayout.setObjectName(u"CentralLayout")
        self.CentralLayout.setContentsMargins(5, 5, 5, 5)
        self.CentralWidget_SpacerTop = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.CentralLayout.addItem(self.CentralWidget_SpacerTop)

        self.PT_ShowOutline_MainLayout = QHBoxLayout()
        self.PT_ShowOutline_MainLayout.setSpacing(0)
        self.PT_ShowOutline_MainLayout.setObjectName(u"PT_ShowOutline_MainLayout")
        self.PT_ShowOutline_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_ShowOutline_MainLayout.addItem(self.PT_ShowOutline_SpacerLeft)

        self.PT_ShowOutline = QFrameButton(CentralWidget)
        self.PT_ShowOutline.setObjectName(u"PT_ShowOutline")
        self.PT_ShowOutline.setMinimumSize(QSize(135, 24))
        self.PT_ShowOutline.setMaximumSize(QSize(135, 24))
        self.PT_ShowOutline_Layout = QHBoxLayout(self.PT_ShowOutline)
        self.PT_ShowOutline_Layout.setSpacing(0)
        self.PT_ShowOutline_Layout.setObjectName(u"PT_ShowOutline_Layout")
        self.PT_ShowOutline_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_ShowOutline_MainLayout.addWidget(self.PT_ShowOutline)

        self.PT_ShowOutline_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_ShowOutline_MainLayout.addItem(self.PT_ShowOutline_SpacerRight)


        self.CentralLayout.addLayout(self.PT_ShowOutline_MainLayout)

        self.PT_ShowWireframe_MainLayout = QHBoxLayout()
        self.PT_ShowWireframe_MainLayout.setSpacing(0)
        self.PT_ShowWireframe_MainLayout.setObjectName(u"PT_ShowWireframe_MainLayout")
        self.PT_ShowWireframe_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_ShowWireframe_MainLayout.addItem(self.PT_ShowWireframe_SpacerLeft)

        self.PT_ShowWireframe = QFrameButton(CentralWidget)
        self.PT_ShowWireframe.setObjectName(u"PT_ShowWireframe")
        self.PT_ShowWireframe.setMinimumSize(QSize(135, 24))
        self.PT_ShowWireframe.setMaximumSize(QSize(135, 24))
        self.PT_ShowWireframe_Layout = QHBoxLayout(self.PT_ShowWireframe)
        self.PT_ShowWireframe_Layout.setSpacing(0)
        self.PT_ShowWireframe_Layout.setObjectName(u"PT_ShowWireframe_Layout")
        self.PT_ShowWireframe_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_ShowWireframe_MainLayout.addWidget(self.PT_ShowWireframe)

        self.PT_ShowWireframe_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_ShowWireframe_MainLayout.addItem(self.PT_ShowWireframe_SpacerRight)


        self.CentralLayout.addLayout(self.PT_ShowWireframe_MainLayout)

        self.PT_ShowHUD_MainLayout = QHBoxLayout()
        self.PT_ShowHUD_MainLayout.setSpacing(0)
        self.PT_ShowHUD_MainLayout.setObjectName(u"PT_ShowHUD_MainLayout")
        self.PT_ShowHUD_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_ShowHUD_MainLayout.addItem(self.PT_ShowHUD_SpacerLeft)

        self.PT_ShowHUD = QFrameButton(CentralWidget)
        self.PT_ShowHUD.setObjectName(u"PT_ShowHUD")
        self.PT_ShowHUD.setMinimumSize(QSize(135, 24))
        self.PT_ShowHUD.setMaximumSize(QSize(135, 24))
        self.PT_ShowHUD_Layout = QHBoxLayout(self.PT_ShowHUD)
        self.PT_ShowHUD_Layout.setSpacing(0)
        self.PT_ShowHUD_Layout.setObjectName(u"PT_ShowHUD_Layout")
        self.PT_ShowHUD_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_ShowHUD_MainLayout.addWidget(self.PT_ShowHUD)

        self.PT_ShowHUD_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_ShowHUD_MainLayout.addItem(self.PT_ShowHUD_SpacerRight)


        self.CentralLayout.addLayout(self.PT_ShowHUD_MainLayout)

        self.Middle_MainLayout = QHBoxLayout()
        self.Middle_MainLayout.setSpacing(0)
        self.Middle_MainLayout.setObjectName(u"Middle_MainLayout")
        self.Middle_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.Middle_MainLayout.addItem(self.Middle_SpacerLeft)

        self.Middle_FrameRight = QFrame(CentralWidget)
        self.Middle_FrameRight.setObjectName(u"Middle_FrameRight")
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Middle_FrameRight.sizePolicy().hasHeightForWidth())
        self.Middle_FrameRight.setSizePolicy(sizePolicy)
        self.Middle_FrameRight_Layout = QVBoxLayout(self.Middle_FrameRight)
        self.Middle_FrameRight_Layout.setSpacing(0)
        self.Middle_FrameRight_Layout.setObjectName(u"Middle_FrameRight_Layout")
        self.Middle_FrameRight_Layout.setContentsMargins(0, 0, 10, 0)
        self.Middle_FrameRight_SpacerTop = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameRight_Layout.addItem(self.Middle_FrameRight_SpacerTop)

        self.PT_RetainSpacing_MainLayout = QHBoxLayout()
        self.PT_RetainSpacing_MainLayout.setSpacing(0)
        self.PT_RetainSpacing_MainLayout.setObjectName(u"PT_RetainSpacing_MainLayout")
        self.PT_RetainSpacing_MainLayout.setContentsMargins(5, 5, 5, 5)
        self.PT_RetainSpacing_SpacerLeft = QSpacerItem(45, 0, QSizePolicy.MinimumExpanding, QSizePolicy.Minimum)

        self.PT_RetainSpacing_MainLayout.addItem(self.PT_RetainSpacing_SpacerLeft)

        self.PT_RetainSpacing = QFrameButton(self.Middle_FrameRight)
        self.PT_RetainSpacing.setObjectName(u"PT_RetainSpacing")
        self.PT_RetainSpacing.setMinimumSize(QSize(135, 24))
        self.PT_RetainSpacing.setMaximumSize(QSize(135, 24))
        self.PT_RetainSpacing_Layout = QHBoxLayout(self.PT_RetainSpacing)
        self.PT_RetainSpacing_Layout.setSpacing(0)
        self.PT_RetainSpacing_Layout.setObjectName(u"PT_RetainSpacing_Layout")
        self.PT_RetainSpacing_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_RetainSpacing_MainLayout.addWidget(self.PT_RetainSpacing)


        self.Middle_FrameRight_Layout.addLayout(self.PT_RetainSpacing_MainLayout)

        self.Middle_FrameRight_SpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameRight_Layout.addItem(self.Middle_FrameRight_SpacerBottom)


        self.Middle_MainLayout.addWidget(self.Middle_FrameRight)

        self.RadialRing = RadialRing(CentralWidget)
        self.RadialRing.setObjectName(u"RadialRing")
        self.RadialRing.setMinimumSize(QSize(50, 50))
        self.RadialRing.setMaximumSize(QSize(50, 50))

        self.Middle_MainLayout.addWidget(self.RadialRing)

        self.Middle_FrameLeft = QFrame(CentralWidget)
        self.Middle_FrameLeft.setObjectName(u"Middle_FrameLeft")
        sizePolicy.setHeightForWidth(self.Middle_FrameLeft.sizePolicy().hasHeightForWidth())
        self.Middle_FrameLeft.setSizePolicy(sizePolicy)
        self.Middle_FrameLeft_Layout = QVBoxLayout(self.Middle_FrameLeft)
        self.Middle_FrameLeft_Layout.setSpacing(0)
        self.Middle_FrameLeft_Layout.setObjectName(u"Middle_FrameLeft_Layout")
        self.Middle_FrameLeft_Layout.setContentsMargins(10, 0, 0, 0)
        self.Middle_FrameLeft_SpacerTop = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameLeft_Layout.addItem(self.Middle_FrameLeft_SpacerTop)

        self.PT_NormalVector_MainLayout = QHBoxLayout()
        self.PT_NormalVector_MainLayout.setSpacing(0)
        self.PT_NormalVector_MainLayout.setObjectName(u"PT_NormalVector_MainLayout")
        self.PT_NormalVector_MainLayout.setContentsMargins(5, 5, 5, 5)
        self.PT_NormalVector_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_NormalVector_MainLayout.addItem(self.PT_NormalVector_SpacerLeft)

        self.PT_NormalVector_Frame = QFrame(self.Middle_FrameLeft)
        self.PT_NormalVector_Frame.setObjectName(u"PT_NormalVector_Frame")
        self.PT_NormalVector_Frame.setMinimumSize(QSize(180, 24))
        self.PT_NormalVector_Frame.setMaximumSize(QSize(180, 24))
        self.PT_NormalVector_FrameLayout = QHBoxLayout(self.PT_NormalVector_Frame)
        self.PT_NormalVector_FrameLayout.setSpacing(0)
        self.PT_NormalVector_FrameLayout.setObjectName(u"PT_NormalVector_FrameLayout")
        self.PT_NormalVector_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.PT_NormalVector = QFrameLabel(self.PT_NormalVector_Frame)
        self.PT_NormalVector.setObjectName(u"PT_NormalVector")
        self.PT_NormalVector_Layout = QHBoxLayout(self.PT_NormalVector)
        self.PT_NormalVector_Layout.setSpacing(0)
        self.PT_NormalVector_Layout.setObjectName(u"PT_NormalVector_Layout")
        self.PT_NormalVector_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_NormalVector_FrameLayout.addWidget(self.PT_NormalVector)

        self.PT_NormalVectorValue = QPieMenuComboBox(self.PT_NormalVector_Frame)
        self.PT_NormalVectorValue.setObjectName(u"PT_NormalVectorValue")
        self.PT_NormalVectorValue.setMinimumSize(QSize(80, 24))
        self.PT_NormalVectorValue.setMaximumSize(QSize(80, 24))

        self.PT_NormalVector_FrameLayout.addWidget(self.PT_NormalVectorValue)


        self.PT_NormalVector_MainLayout.addWidget(self.PT_NormalVector_Frame)

        self.PT_NormalVector_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_NormalVector_MainLayout.addItem(self.PT_NormalVector_SpacerRight)


        self.Middle_FrameLeft_Layout.addLayout(self.PT_NormalVector_MainLayout)

        self.Middle_FrameLeft_SpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Ignored)

        self.Middle_FrameLeft_Layout.addItem(self.Middle_FrameLeft_SpacerBottom)


        self.Middle_MainLayout.addWidget(self.Middle_FrameLeft)

        self.Middle_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.Middle_MainLayout.addItem(self.Middle_SpacerRight)


        self.CentralLayout.addLayout(self.Middle_MainLayout)

        self.PT_StepAlignement_MainLayout = QHBoxLayout()
        self.PT_StepAlignement_MainLayout.setSpacing(0)
        self.PT_StepAlignement_MainLayout.setObjectName(u"PT_StepAlignement_MainLayout")
        self.PT_StepAlignement_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_StepAlignement_MainLayout.addItem(self.PT_StepAlignement_SpacerLeft)

        self.PT_StepAlignement_Frame = QFrame(CentralWidget)
        self.PT_StepAlignement_Frame.setObjectName(u"PT_StepAlignement_Frame")
        self.PT_StepAlignement_Frame.setMinimumSize(QSize(230, 24))
        self.PT_StepAlignement_Frame.setMaximumSize(QSize(230, 24))
        self.PT_StepAlignement_FrameLayout = QHBoxLayout(self.PT_StepAlignement_Frame)
        self.PT_StepAlignement_FrameLayout.setSpacing(0)
        self.PT_StepAlignement_FrameLayout.setObjectName(u"PT_StepAlignement_FrameLayout")
        self.PT_StepAlignement_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.PT_StepAlignement = QFrameButton(self.PT_StepAlignement_Frame)
        self.PT_StepAlignement.setObjectName(u"PT_StepAlignement")
        self.PT_StepAlignement.setMinimumSize(QSize(135, 24))
        self.PT_StepAlignement.setMaximumSize(QSize(135, 24))
        self.PT_StepAlignement_Layout = QHBoxLayout(self.PT_StepAlignement)
        self.PT_StepAlignement_Layout.setSpacing(0)
        self.PT_StepAlignement_Layout.setObjectName(u"PT_StepAlignement_Layout")
        self.PT_StepAlignement_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_StepAlignement_FrameLayout.addWidget(self.PT_StepAlignement)

        self.PT_StepAlignementValue = QFrameSpinBox(self.PT_StepAlignement_Frame)
        self.PT_StepAlignementValue.setObjectName(u"PT_StepAlignementValue")
        self.PT_StepAlignementValue_Layout = QHBoxLayout(self.PT_StepAlignementValue)
        self.PT_StepAlignementValue_Layout.setSpacing(0)
        self.PT_StepAlignementValue_Layout.setObjectName(u"PT_StepAlignementValue_Layout")
        self.PT_StepAlignementValue_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_StepAlignement_FrameLayout.addWidget(self.PT_StepAlignementValue)


        self.PT_StepAlignement_MainLayout.addWidget(self.PT_StepAlignement_Frame)

        self.PT_StepAlignement_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_StepAlignement_MainLayout.addItem(self.PT_StepAlignement_SpacerRight)


        self.CentralLayout.addLayout(self.PT_StepAlignement_MainLayout)

        self.PT_SurfaceOffset_MainLayout = QHBoxLayout()
        self.PT_SurfaceOffset_MainLayout.setSpacing(0)
        self.PT_SurfaceOffset_MainLayout.setObjectName(u"PT_SurfaceOffset_MainLayout")
        self.PT_SurfaceOffset_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_SurfaceOffset_MainLayout.addItem(self.PT_SurfaceOffset_SpacerLeft)

        self.PT_SurfaceOffset_Frame = QFrame(CentralWidget)
        self.PT_SurfaceOffset_Frame.setObjectName(u"PT_SurfaceOffset_Frame")
        self.PT_SurfaceOffset_Frame.setMinimumSize(QSize(230, 24))
        self.PT_SurfaceOffset_Frame.setMaximumSize(QSize(230, 24))
        self.PT_SurfaceOffset_FrameLayout = QHBoxLayout(self.PT_SurfaceOffset_Frame)
        self.PT_SurfaceOffset_FrameLayout.setSpacing(0)
        self.PT_SurfaceOffset_FrameLayout.setObjectName(u"PT_SurfaceOffset_FrameLayout")
        self.PT_SurfaceOffset_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.PT_SurfaceOffset = QFrameButton(self.PT_SurfaceOffset_Frame)
        self.PT_SurfaceOffset.setObjectName(u"PT_SurfaceOffset")
        self.PT_SurfaceOffset.setMinimumSize(QSize(135, 24))
        self.PT_SurfaceOffset.setMaximumSize(QSize(135, 24))
        self.PT_SurfaceOffset_Layout = QHBoxLayout(self.PT_SurfaceOffset)
        self.PT_SurfaceOffset_Layout.setSpacing(0)
        self.PT_SurfaceOffset_Layout.setObjectName(u"PT_SurfaceOffset_Layout")
        self.PT_SurfaceOffset_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_SurfaceOffset_FrameLayout.addWidget(self.PT_SurfaceOffset)

        self.PT_SurfaceOffsetValue = QFrameSpinBox(self.PT_SurfaceOffset_Frame)
        self.PT_SurfaceOffsetValue.setObjectName(u"PT_SurfaceOffsetValue")
        self.PT_SurfaceOffsetValue_Layout = QHBoxLayout(self.PT_SurfaceOffsetValue)
        self.PT_SurfaceOffsetValue_Layout.setSpacing(0)
        self.PT_SurfaceOffsetValue_Layout.setObjectName(u"PT_SurfaceOffsetValue_Layout")
        self.PT_SurfaceOffsetValue_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_SurfaceOffset_FrameLayout.addWidget(self.PT_SurfaceOffsetValue)


        self.PT_SurfaceOffset_MainLayout.addWidget(self.PT_SurfaceOffset_Frame)

        self.PT_SurfaceOffset_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_SurfaceOffset_MainLayout.addItem(self.PT_SurfaceOffset_SpacerRight)


        self.CentralLayout.addLayout(self.PT_SurfaceOffset_MainLayout)

        self.PT_StepRotation_MainLayout = QHBoxLayout()
        self.PT_StepRotation_MainLayout.setSpacing(0)
        self.PT_StepRotation_MainLayout.setObjectName(u"PT_StepRotation_MainLayout")
        self.PT_StepRotation_SpacerLeft = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_StepRotation_MainLayout.addItem(self.PT_StepRotation_SpacerLeft)

        self.PT_StepRotation_Frame = QFrame(CentralWidget)
        self.PT_StepRotation_Frame.setObjectName(u"PT_StepRotation_Frame")
        self.PT_StepRotation_Frame.setMinimumSize(QSize(230, 24))
        self.PT_StepRotation_Frame.setMaximumSize(QSize(230, 24))
        self.PT_StepRotation_FrameLayout = QHBoxLayout(self.PT_StepRotation_Frame)
        self.PT_StepRotation_FrameLayout.setSpacing(0)
        self.PT_StepRotation_FrameLayout.setObjectName(u"PT_StepRotation_FrameLayout")
        self.PT_StepRotation_FrameLayout.setContentsMargins(0, 0, 0, 0)
        self.PT_StepRotation = QFrameButton(self.PT_StepRotation_Frame)
        self.PT_StepRotation.setObjectName(u"PT_StepRotation")
        self.PT_StepRotation.setMinimumSize(QSize(135, 24))
        self.PT_StepRotation.setMaximumSize(QSize(135, 24))
        self.PT_StepRotation_Layout = QHBoxLayout(self.PT_StepRotation)
        self.PT_StepRotation_Layout.setSpacing(0)
        self.PT_StepRotation_Layout.setObjectName(u"PT_StepRotation_Layout")
        self.PT_StepRotation_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_StepRotation_FrameLayout.addWidget(self.PT_StepRotation)

        self.PT_StepRotationValue = QFrameSpinBox(self.PT_StepRotation_Frame)
        self.PT_StepRotationValue.setObjectName(u"PT_StepRotationValue")
        self.PT_StepRotationValue_Layout = QHBoxLayout(self.PT_StepRotationValue)
        self.PT_StepRotationValue_Layout.setSpacing(0)
        self.PT_StepRotationValue_Layout.setObjectName(u"PT_StepRotationValue_Layout")
        self.PT_StepRotationValue_Layout.setContentsMargins(0, 0, 0, 0)

        self.PT_StepRotation_FrameLayout.addWidget(self.PT_StepRotationValue)


        self.PT_StepRotation_MainLayout.addWidget(self.PT_StepRotation_Frame)

        self.PT_StepRotation_SpacerRight = QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.PT_StepRotation_MainLayout.addItem(self.PT_StepRotation_SpacerRight)


        self.CentralLayout.addLayout(self.PT_StepRotation_MainLayout)

        self.CentralWidget_SpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.CentralLayout.addItem(self.CentralWidget_SpacerBottom)


        self.retranslateUi(CentralWidget)

        QMetaObject.connectSlotsByName(CentralWidget)
    # setupUi

    def retranslateUi(self, CentralWidget):
        CentralWidget.setWindowTitle(QCoreApplication.translate("CentralWidget", u"Form", None))
    # retranslateUi

