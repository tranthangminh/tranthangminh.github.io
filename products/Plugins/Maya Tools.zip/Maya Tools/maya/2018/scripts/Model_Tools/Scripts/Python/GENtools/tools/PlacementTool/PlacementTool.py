#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
import math
import time
from threading import Thread
from functools import partial
from collections import defaultdict, OrderedDict, Counter
import maya.cmds as cmds
import maya.api.OpenMaya as om
import maya.mel as mel
from maya.api.OpenMayaUI import M3dView
from maya.OpenMayaUI import MQtUtil
from maya.utils import executeInMainThreadWithResult
import pymel.core as pm
try:
	from PySide2 import QtCore, QtGui, QtWidgets
	from shiboken2 import wrapInstance, isValid
except ImportError:
	from PySide import QtCore, QtGui
	from PySide import QtGui as QtWidgets
	from shiboken import wrapInstance, isValid

# for python 3 compatibility
import six
from six.moves import range
from six.moves import filter
from six.moves import zip
try:
	from past.builtins import long
except:
	pass

from .MarkingMenu import QPieMenu, currentUnitString, getSpinBoxName
from .MarkingMenu_ui import Ui_CentralWidget
from ...core.utils.overrides import rpartial
from ...core.gui.options import OptionsWindow, helpCmd
from ...core.general.decorators import make_undoable
from ...core.utils.infos import getMayaVersion
from ...core.utils.listeners import MayaAppState
from ...core.general.panels import getOutlinerList
try:
	from ..NonDestructiveBevel.ndbevel import getObjectsWithBevelPreview
except:
	getObjectsWithBevelPreview = None

MAYA_VERSION = getMayaVersion()
ROOT_FILE = __file__
ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
ROOT_DIR = ROOT_DIR_RAW
if not isinstance(ROOT_FILE, six.text_type):
	try:
		ROOT_FILE = ROOT_FILE.decode(sys.getfilesystemencoding())
		ROOT_DIR_RAW = os.path.dirname(os.path.realpath(ROOT_FILE))
		ROOT_DIR = ROOT_DIR_RAW.encode(sys.getfilesystemencoding())
	except:
		pass

def dotProduct(v1, v2=[0, 0, 1], useOpenMaya=True):
	if useOpenMaya is True:
		return (om.MVector(*v1) * om.MVector(*v2))+0
	else:
		return sum([i*j for (i, j) in zip(v1, v2)])+0

def crossProduct(v1, v2, useOpenMaya=True):
	if useOpenMaya is True:
		v1 = om.MVector(*v1) ^ om.MVector(*v2)
		return [v1.x+0, v1.y+0, v1.z+0]
	else:
		return [(v1[1]*v2[2] - v1[2]*v2[1])+0,
				(v1[2]*v2[0] - v1[0]*v2[2])+0,
				(v1[0]*v2[1] - v1[1]*v2[0])+0]

def normalizeVector(v1=[1, 0, 0]):
	if isinstance(v1, (list, tuple)) is True and len(v1) >= 3:
		v1 = om.MVector(v1[0], v1[1], v1[2])
		v1.normalize()
		v1 = [v1.x+0, v1.y+0, v1.z+0]
	return v1

def isClose(a, b, rt=0.000000001, at=0):
    return abs(a-b) <= max(rt * max(abs(a), abs(b)), at)

def isAngleParallel(angle1, angle2, degrees=True):
	if degrees:
		angle1 = math.radians(angle1)
		angle2 = math.radians(angle2)
	
	baseVector = om.MVector(1, 0, 0)
	v1 = baseVector.rotateBy(om.MEulerRotation(0, 0, angle1, om.MVector.kZaxis))
	v2 = baseVector.rotateBy(om.MEulerRotation(0, 0, angle2, om.MVector.kZaxis))

	return v1.isParallel(v2)

def mapMatrixToWorld(matrix):
	### SHOULD CONVERT THIS TO OPENMAYA ###
	if isinstance(matrix, (list, tuple)) and len(matrix) == 16:
		# Set matrix scale to 1
		tmpNode = cmds.createNode("transform", skipSelect=True)
		cmds.xform(tmpNode, worldSpace=True, matrix=matrix)
		cmds.xform(tmpNode, worldSpace=True, scale=[1, 1, 1])
		matrix = cmds.xform(tmpNode, query=True, worldSpace=True, matrix=True)
		cmds.delete(tmpNode)
		
		tangent = [matrix[0], matrix[1], matrix[2], matrix[3]]
		binormal = [matrix[4], matrix[5], matrix[6], matrix[7]]
		normal = [matrix[8], matrix[9], matrix[10], matrix[11]]
		position = [matrix[12], matrix[13], matrix[14], matrix[15]]
		matrix = [tangent, binormal, normal]
		
		newMatrix = []
		for num in range(3):
			maximum = [0, 0, 0, 0]
			for vector in matrix:
				if abs(vector[num]) > abs(maximum[num]):
					if vector[num] < 0:
						maximum = [x*-1+0 for x in vector]
					else:
						maximum = vector
			newMatrix.append(maximum)
		
		return [x for sublist in newMatrix for x in sublist] + position

def setPivotPosition(objects, posX="mid", posY="mid", posZ="min"):
	# Objects
	if isinstance(objects, six.string_types) is True:
		objects = [objects]
	objects = cmds.ls(objects, long=True)
	
	# Position
	defaultPosition = ["min", "mid", "max"]	
	if isinstance(posX, six.string_types) is False or posX not in defaultPosition:
		posX = "mid"
	if isinstance(posY, six.string_types) is False or posY not in defaultPosition:
		posY = "mid"
	if isinstance(posZ, six.string_types) is False or posZ not in defaultPosition:
		posZ = "mid"
	
	# Set pivot
	for obj in objects:
		objectShape = cmds.ls(obj, long=True, dagObjects=True, noIntermediate=True, type="mesh")
		
		if len(objectShape) <= 0:
			continue
		
		boundingBoxMin = cmds.getAttr(objectShape[0]+".boundingBoxMin")[0]
		boundingBoxMax = cmds.getAttr(objectShape[0]+".boundingBoxMax")[0]
		boundingBoxX = {"min": boundingBoxMin[0], "mid": (boundingBoxMin[0]+boundingBoxMax[0])*0.5, "max": boundingBoxMax[0]}
		boundingBoxY = {"min": boundingBoxMin[1], "mid": (boundingBoxMin[1]+boundingBoxMax[1])*0.5, "max": boundingBoxMax[1]}
		boundingBoxZ = {"min": boundingBoxMin[2], "mid": (boundingBoxMin[2]+boundingBoxMax[2])*0.5, "max": boundingBoxMax[2]}
		
		pointMatrixMult = cmds.createNode("pointMatrixMult", skipSelect=True)
		cmds.connectAttr(obj+".worldMatrix", pointMatrixMult+".inMatrix")
		cmds.setAttr(pointMatrixMult+".inPoint", boundingBoxX[posX], boundingBoxY[posY], boundingBoxZ[posZ])
		pivotPosition = cmds.getAttr(pointMatrixMult+".output")[0]
		cmds.delete(pointMatrixMult)
		cmds.xform(obj, worldSpace=True, pivots=pivotPosition)

def normalizeNumList(numList):
	newNumList = []
	for num in numList:
		if num < 0:
			newNumList.append(-1)
		else:
			newNumList.append(1)
	return newNumList

def getOffsetedObjectPosition(obj, position, offset=0):
	mMatrix = getMMatrix(obj, worldSpace=True)
	tmMatrix = om.MTransformationMatrix(mMatrix)
	tmMatrix.setTranslation(om.MVector(position), om.MSpace.kWorld)
	objScale = normalizeNumList(tmMatrix.scale(om.MSpace.kWorld))
	tmMatrix.setScale(objScale, om.MSpace.kWorld)
	if cmds.upAxis(query=True, axis=True) == "z":
		tmMatrix.translateBy(om.MVector(0, 0, offset), om.MSpace.kObject)
	else:
		tmMatrix.translateBy(om.MVector(0, offset, 0), om.MSpace.kObject)
	return tmMatrix.translation(om.MSpace.kWorld)

def getLocalOffset(parent, child, useOpenMaya=True):
	if useOpenMaya:
		parentWorldMatrix = getMMatrix(parent, worldSpace=True, rotatePivot=True)
		childWorldMatrix = getMMatrix(child, worldSpace=True, rotatePivot=True)
	else:
		parentWorldMatrix = om.MMatrix(cmds.xform(getPyNodeName(parent), query=True, worldSpace=True, matrix=True))
		childWorldMatrix = om.MMatrix(cmds.xform(getPyNodeName(child), query=True, worldSpace=True, matrix=True))
	return childWorldMatrix * parentWorldMatrix.inverse()

def offsetParentMatrix(parent_obj, child_obj, child_matrix, position=False, rotation=False, scale=False):
	offsetMatrixDict = {"position": [], "rotation": [], "scale": []}
	
	if all([parent_obj, child_obj]):
		if any([position, rotation, scale]):
			objMatrix = child_matrix * getMMatrix(parent_obj, rotatePivot=True)
			
			tMatrix = om.MTransformationMatrix(objMatrix)
			offsetMatrixDict["position"] = tMatrix.translation(om.MSpace.kWorld)
		
			if rotation or scale:
				# need to multiply matrix by inverse parent matrix to get object-space rotation
				objMatrix = objMatrix * getMDagPath(child_obj).exclusiveMatrix().inverse()
				tMatrix = om.MTransformationMatrix(objMatrix)
			
				if rotation:
					rot_r = tMatrix.rotation(False)
					offsetMatrixDict["rotation"] = [math.degrees(rot_r[x]) for x in range(3)]
				
				if scale:
					offsetMatrixDict["scale"] = tMatrix.scale(om.MSpace.kObject)
	
	return offsetMatrixDict

def orientToTransform(obj, position=[], rotation=[]):
	if len(position) < 3 or len(rotation) < 3:
		return

	# Create a transform matrix with position adn rotation data
	transform_matrix = om.MTransformationMatrix()
	rotate_by = [math.radians(x) for x in rotation[:3]]
	transform_matrix.setRotation(om.MEulerRotation(rotate_by[0], rotate_by[1], rotate_by[2], om.MEulerRotation.kXYZ))
	transform_matrix.setTranslation(om.MVector(position[:3]), om.MSpace.kWorld)

	# Find matrix offset between object and transform
	parentWorldMatrix = transform_matrix.asMatrix()
	childWorldMatrix = getMMatrix(obj, worldSpace=True)
	offsetMatrix = childWorldMatrix * parentWorldMatrix.inverse()

	cmds.xform(obj, matrix=offsetMatrix, worldSpace=True)

def orientFromTransform(obj, position=[], rotation=[]):
	if len(position) < 3 or len(rotation) < 3:
		return
	
	# Create a transform matrix with position adn rotation data
	transform_matrix = om.MTransformationMatrix()
	rotate_by = [math.radians(x) for x in rotation[:3]]
	transform_matrix.setRotation(om.MEulerRotation(rotate_by[0], rotate_by[1], rotate_by[2], om.MEulerRotation.kXYZ))
	transform_matrix.setTranslation(om.MVector(position[:3]), om.MSpace.kWorld)

	# Find matrix offset between transform and object
	parentWorldMatrix = getMMatrix(obj, worldSpace=True)
	childWorldMatrix = transform_matrix.asMatrix()
	offsetMatrix = (childWorldMatrix.inverse() * parentWorldMatrix.inverse()).inverse()

	cmds.xform(obj, matrix=offsetMatrix, worldSpace=True)

def getVisibleObjects():
	visibleObjectShapes = cmds.ls(dagObjects=True, visible=True, noIntermediate=True)
	visibleObjects = cmds.listRelatives(visibleObjectShapes, fullPath=True, parent=True, noIntermediate=True, type="transform")
	# Remove intermediate objects
	visibleObjects = cmds.ls(visibleObjects, long=True, noIntermediate=True)
	# Remove duplicates objects
	visibleObjects = list(OrderedDict.fromkeys(visibleObjects))
	
	return visibleObjects

def getCursorPosition():
	pressPosition = QtCore.QPoint(0, 0)
	
	# Get viewport cursor position
	position = QtGui.QCursor.pos()
	widget = QtWidgets.QApplication.widgetAt(position)
	if widget:
		pressPosition = widget.mapFromGlobal(position)
	
	return pressPosition

def getActiveViewportCursorPosition():
	pressPosition = QtCore.QPoint(0, 0)
	
	position = QtGui.QCursor.pos()
	#widget = QtWidgets.QApplication.widgetAt(position)
	widget = wrapInstance(long(M3dView.active3dView().widget()), QtWidgets.QWidget)
	if widget:
		pressPosition = widget.mapFromGlobal(position)
		pressPosition = [pressPosition.x(), widget.height() - pressPosition.y() - 1]
	
	return pressPosition

def hideInOutliner(nodeName, hide=True):
	# Apply to all DAG nodes
	nodeName = cmds.ls(nodeName, dagObjects=True, objectsOnly=True)
	# Hide/Unhide the items
	for i in range(len(nodeName)):
		cmds.setAttr((nodeName[i]+".hiddenInOutliner"), hide)
	# Refresh any outliner editors
	eds = cmds.lsUI(editors=True)
	for i in range(len(eds)):
		if cmds.outlinerEditor(eds[i], exists=True) is True:
			cmds.outlinerEditor(eds[i], edit=True, refresh=True)

def simulateMousePressEvent(pressPosition=QtCore.QPoint(0, 0)):
	# Simulate QMouseEvent on active3dView
	simulateMousePressEvent = QtGui.QMouseEvent(QtCore.QEvent.MouseButtonPress, pressPosition, QtCore.Qt.LeftButton, QtCore.Qt.LeftButton, QtCore.Qt.NoModifier)
	
	#mainWindow = wrapInstance(long(MQtUtil.mainWindow()), QtWidgets.QWidget)
	currentView = wrapInstance(long(M3dView.active3dView().widget()), QtWidgets.QWidget)
	QtCore.QCoreApplication.postEvent(currentView, simulateMousePressEvent)

def getAngleFromNormal(normal, targetMatrix, useNormal=True, world=True):
	if isinstance(targetMatrix, (list, tuple)) is False or len(targetMatrix) != 16:
		return []
	else:
		normal = normalizeVector(normal)
		if world is True:
			targetMatrix = mapMatrixToWorld(targetMatrix)
		targetTangent = normalizeVector([targetMatrix[0], targetMatrix[1], targetMatrix[2]])
		if cmds.upAxis(query=True, axis=True) == "z" or world:
			targetBinormal = normalizeVector([targetMatrix[4], targetMatrix[5], targetMatrix[6]])
			targetNormal = normalizeVector([targetMatrix[8], targetMatrix[9], targetMatrix[10]])
		else:
			targetNormal = normalizeVector([targetMatrix[4], targetMatrix[5], targetMatrix[6]])
			targetBinormal = normalizeVector([targetMatrix[8], targetMatrix[9], targetMatrix[10]])
	
	if useNormal is True:
		vector1 = targetNormal
		vector2 = targetTangent
	else:
		vector1 = targetTangent
		vector2 = targetNormal
		
	if dotProduct(normal, vector1) > 0.999 or dotProduct(normal, vector1) < -0.999:
		binormal = normalizeVector(crossProduct(normal, vector2))
		# If opposite direction, invert vector
		if dotProduct(targetBinormal, binormal) < -0.999:
			binormal = [x*-1 for x in binormal]
		tangent = crossProduct(binormal, normal)
		if useNormal is True:
			normal = targetNormal
	else:
		binormal = normalizeVector(crossProduct(normal, vector1))
		tangent = crossProduct(binormal, normal)
	
	position = [0, 0, 0]
	
	if cmds.upAxis(query=True, axis=True) == "z" or world:
		tMatrix = tangent + [0] + binormal + [0] + normal + [0] + position + [1]
	else:
		tMatrix = tangent + [0] + normal + [0] + binormal + [0] + position + [1]
	mMatrix = om.MMatrix(tMatrix)
	tmMatrix = om.MTransformationMatrix(mMatrix)
	rotate = tmMatrix.rotation(False).reorder(om.MEulerRotation.kXYZ)
	rotate = [x + 0 for x in list(rotate)[:3]]
	
	return [math.degrees(rotate[0]), math.degrees(rotate[1]), math.degrees(rotate[2])]

def getOrientationFromVectors(normal, tangent):
	binormal = normalizeVector(crossProduct(normal, tangent))
	
	position = [0, 0, 0]
	
	if cmds.upAxis(query=True, axis=True) == "z":
		tMatrix = tangent + [0] + binormal + [0] + normal + [0] + position + [1]
	else:
		tMatrix = tangent + [0] + normal + [0] + binormal + [0] + position + [1]
	mMatrix = om.MMatrix(tMatrix)
	tmMatrix = om.MTransformationMatrix(mMatrix)
	rotate = tmMatrix.rotation(False).reorder(om.MEulerRotation.kXYZ)
	rotate = [x + 0 for x in list(rotate)[:3]]
	
	return [math.degrees(rotate[0]), math.degrees(rotate[1]), math.degrees(rotate[2])]

def getOrientationFromFace(face, normal=None, highPrecision=True):
	if isinstance(face, six.string_types) and cmds.objExists(face):
		faces = [face]
	elif isinstance(face, (list, tuple)):
		faces = cmds.ls(face, long=True, flatten=True)
	else:
		return None
	
	faces_orientation = {}
	if len(faces) > 0:
		selList = om.MSelectionList()
		for f in faces:
			selList.add(f)
		
		# Loop over objects
		for i in range(selList.length()):
			dagPath, component = selList.getComponent(i)
			
			# Get transform dagPath
			#if not dagPath.hasFn(om.MFn.kTransform):
				#dagPath.pop()
			objectName = dagPath.fullPathName()
			
			face_ids = om.MFnSingleIndexedComponent(component).getElements()

			if not dagPath.hasFn(om.MFn.kMesh):
				continue

			face_iter = om.MItMeshPolygon(dagPath)
			
			# Loop over faces
			for face_id in face_ids:
				face_iter.setIndex(face_id)
				
				# Get current face normal
				faceNormal = face_iter.getNormal(space=om.MSpace.kWorld)
				if normal is None:
					normal = faceNormal
				
				# Get all connected faces that have similar normal
				cfaces = list(face_iter.getConnectedFaces())
				faces_dict = {face_id: True}
				
				cface_iter = om.MItMeshPolygon(dagPath)
				while len(cfaces) > 0:
					if cfaces[0] not in faces_dict:
						cface_iter.setIndex(cfaces[0])
						cface_normal = cface_iter.getNormal(space=om.MSpace.kWorld)
						if faceNormal.isEquivalent(cface_normal, 0.01):
							faces_dict[cfaces[0]] = True
							for f in cface_iter.getConnectedFaces():
								if f not in faces_dict:
									cfaces.append(f)
						else:
							faces_dict[cfaces[0]] = False
					
					del cfaces[0]
					
				# Get edge vectors from connected faces
				cfaces = [f for f, value in six.iteritems(faces_dict) if value is True]
				edges_dict = {}
				
				cedge_iter = om.MItMeshEdge(dagPath)
				for f in cfaces:
					cface_iter.setIndex(f)
					cedges = list(cface_iter.getEdges())
					
					for edge in cedges:
						if edge not in edges_dict:
							cedge_iter.setIndex(edge)
							edge_v = vectorBetweenPoints(list(cedge_iter.point(0, om.MSpace.kWorld)), list(cedge_iter.point(1, om.MSpace.kWorld)))
							edges_dict[edge] = tuple([round(v, 3)+0 for v in edge_v])
				
				# Get the most common vector
				tangent, vector_count = Counter(list(edges_dict.values())).most_common(1)[0]
				# if no common vector is found, check for parallel vectors
				if vector_count < 2:
					all_vectors = list(edges_dict.values())
					parallel_vectors = {k: 1 for k in all_vectors}
					while len(all_vectors) > 0:
						omV = om.MVector(all_vectors[0])
						for ov in all_vectors:
							if ov == all_vectors[0]:
								continue
							if omV.isParallel(om.MVector(ov)):
								parallel_vectors[all_vectors[0]] += 1
								del parallel_vectors[ov]
						del all_vectors[0]
					v = max(parallel_vectors, key=parallel_vectors.get)
					if parallel_vectors[v] > 1:
						tangent, vector_count = v, parallel_vectors[v]
				# if no parallel vector is found, use first two points
				if vector_count < 2:
					# get face-relative vertices positions
					vertices_position = face_iter.getPoints(space=om.MSpace.kWorld)
					vertices_dict = {}
					# convert face-relative indices to object-relative indices
					for i in range(face_iter.polygonVertexCount()):
						vertices_dict[int(face_iter.vertexIndex(i))] = vertices_position[i]
					vertices_dict = OrderedDict(sorted(vertices_dict.items()))
					vertices_position = []
					for pos in six.itervalues(vertices_dict):
						vertices_position.append(pos)
						if len(vertices_position) == 2:
							break
					tangent = vectorBetweenPoints(list(vertices_position[0]), list(vertices_position[1]))
				else:
					# Get back the original vector since we needed to round the values for comparing the vectors
					if highPrecision:
						edge_id = list(edges_dict.keys())[list(edges_dict.values()).index(tangent)]
						cedge_iter.setIndex(edge_id)
						tangent = vectorBetweenPoints(list(cedge_iter.point(0, om.MSpace.kWorld)), list(cedge_iter.point(1, om.MSpace.kWorld)))				
				
				# Get orientation from the face normal and edge vector
				face_string = "{0}.f[{1}]".format(objectName, face_id)
				
				face_orientation = getOrientationFromVectors(list(normal), tangent)
				faces_orientation[face_string] = face_orientation
	
	if isinstance(face, six.string_types):
		return next(iter(faces_orientation.values()), None)
	else:
		return [faces_orientation[f] for f in faces if f in faces_orientation] or None

def viewToWorld(x, y):
	# Create ray position and direction
	rayPos = om.MPoint()
	rayDirection = om.MVector()
	
	# Converting to world
	M3dView.active3dView().viewToWorld(int(x), int(y), rayPos, rayDirection)
	
	return rayPos, rayDirection

def objectUnderCursorFn(pressPosition=None, panel=None):
	if panel is None:
		panel = cmds.getPanel(underPointer=True) or ""
	
	if isModelPanel(panel):
		if isinstance(pressPosition, (list, tuple)):
			if len(pressPosition) >= 2:
				pressPosition = QtCore.QPoint(pressPosition[0], pressPosition[1])
			else:
				pressPosition = None
		
		elif isinstance(pressPosition, QtCore.QPoint) is False:
			position = QtGui.QCursor.pos()
			widget = wrapInstance(long(M3dView.getM3dViewFromModelPanel(panel).widget()), QtWidgets.QWidget)
			
			if widget:
				pressPosition = widget.mapFromGlobal(position)
		
		if pressPosition is not None:
			#return next(iter(cmds.listRelatives(cmds.hitTest(panel, pressPosition.x(), pressPosition.y()), fullPath=True, parent=True, noIntermediate=True, type="transform") or []), None)
			return (cmds.listRelatives(cmds.hitTest(panel, pressPosition.x(), pressPosition.y()), fullPath=True, parent=True, noIntermediate=True, type="transform") or [None])[0]
	
	return None

def faceUnderCursorFn(pressPosition, targetObject=None, getSurfaceNormal=False):
	if isinstance(targetObject, (list, tuple)) is True and len(targetObject) > 0:
		targetObject = targetObject[0]
	if isinstance(targetObject, six.string_types) is True:
		if cmds.objectType(targetObject) != "transform":
			targetObject = cmds.listRelatives(targetObject, fullPath=True, parent=True, noIntermediate=True, type="transform")
			# Remove intermediate objects
			targetObject = cmds.ls(targetObject, long=True, noIntermediate=True)[0]
	
	# Default variables
	facePosition = []
	faceUnderCursor = None
	faceNormal = []
	objectList = om.MSelectionList()
	
	# Screen position of mouse
	x, y = int(pressPosition[0]), int(pressPosition[1])
	
	# Get ray source and direction
	raySource, rayDirection = viewToWorld(x, y)
	
	# Create variables
	raySourceFloat = om.MFloatPoint(raySource.x, raySource.y, raySource.z)
	rayDirectionFloat = om.MFloatVector(rayDirection.x, rayDirection.y, rayDirection.z)
	
	if targetObject is None:
		targetObject = objectUnderCursorFn()
	
	if targetObject:
		targetShape = next(iter(cmds.listRelatives(targetObject, fullPath=True, shapes=True, noIntermediate=True, type="mesh") or []), None)

		# If bevelPreview, get outMesh shape
		if not targetShape and cmds.objectType(tagFromType="gtBevelPreview"):
			bevelPreviewShape = next(iter(cmds.listRelatives(targetObject, fullPath=True, shapes=True, noIntermediate=True, type="gtBevelPreview") or []), None)
			if bevelPreviewShape:
				targetShape = next(iter(cmds.listConnections("{0}.outMesh".format(bevelPreviewShape), source=False, destination=True, connections=False, shapes=True) or []), None)

		if targetShape:
			objectList.add(targetShape)
	
	# Cast ray from mouse position and return faceId
	if objectList.length() >= 1:
		dagPath = objectList.getDagPath(0)
		#targetObject = dagPath.fullPathName()
		if dagPath.hasFn(om.MFn.kMesh):
			fnMesh = om.MFnMesh(dagPath)
			maxDistance = 100000
			panel = cmds.getPanel(withFocus=True)
			if panel in cmds.getPanel(type="modelPanel") and cmds.modelEditor(panel, query=True, exists=True) is True:
				cameraName = cmds.modelPanel(panel, query=True, camera=True)
				maxDistance = int(cmds.camera(cameraName, query=True, farClipPlane=True))
			
			hitPoint, hitRayParam, faceId, hitTriangle, hitBary1, hitBary2 = om.MFloatPoint(0, 0, 0, 1), 0.0, -1, -1, 0.0, 0.0
			closestIntersection = fnMesh.closestIntersection(raySourceFloat, rayDirectionFloat, om.MSpace.kWorld, maxDistance, False, idsSorted=False, tolerance=.000001)
			# fix unpacking in maya 2022
			if closestIntersection:
				hitPoint, hitRayParam, faceId, hitTriangle, hitBary1, hitBary2 = closestIntersection
				facePosition = [(hitPoint.x), (hitPoint.y), (hitPoint.z)]
			
			if faceId != -1:
				faceUnderCursor = "{0}.f[{1}]".format(dagPath.fullPathName(), faceId)
				
				if getSurfaceNormal:
					# Get surface normal at position
					faceNormal = list(fnMesh.getClosestPointAndNormal(om.MPoint(facePosition), space=om.MSpace.kWorld)[1])
				else:
					# Get target face normal
					polygonNormalVector = fnMesh.getPolygonNormal(faceId, om.MSpace.kWorld)
					faceNormal = [polygonNormalVector.x, polygonNormalVector.y, polygonNormalVector.z]
	
	return targetObject, facePosition, faceUnderCursor, faceNormal

def getClosestVertex(faces=[], position=[0, 0, 0]):
	"""
	Returns the closest vertex given face(s) and a position [x, y, z] in world space.
	
	:param faces: The target face.
	:param position: The position in world space.
	:return: A vertex string.
	"""
	closestVertex = None
	closestVertexPosition = []
	closestDistance = None
	faces = cmds.filterExpand(faces, expand=False, fullPath=True, selectionMask=34)
	vertices = cmds.ls(cmds.polyListComponentConversion(faces, fromFace=True, toVertex=True), flatten=True)

	for vert in vertices:
		vertPosition = cmds.xform(vert, query=True, translation=True, worldSpace=True)
		vertDistance = distanceBetweenPoints(position, vertPosition)
		if closestDistance is None or vertDistance < closestDistance:
			closestDistance = float(vertDistance)
			closestVertex = str(vert)
			closestVertexPosition = list(vertPosition)

	return closestVertex, closestVertexPosition

def objectPlaneIntersect(pressPosition=[0, 0], targetObject=None, worldPosition=[]):
	wsPos = None
	
	if not targetObject:
		targetObject = cmds.ls(selection=True, long=True)
		if len(targetObject) == 0:
			return wsPos
	
	# Screen position of mouse
	x, y = int(pressPosition[0]), int(pressPosition[1])
	
	# Raysource rs, Raydirection rd
	rs, rd = viewToWorld(x, y)
	
	# Position should be selected dag object's world position to create object plane
	if not (isinstance(worldPosition, (tuple, list)) and len(worldPosition) > 2):
		worldPosition = om.MPoint(cmds.xform(targetObject, query=True, worldSpace=True, rotatePivot=True))
	
	# Object plane normal vector
	objectMatrix = cmds.xform(targetObject, query=True, worldSpace=True, matrix=True)
	if cmds.upAxis(query=True, axis=True) == "z":
		nPlane = om.MVector(objectMatrix[8], objectMatrix[9], objectMatrix[10]).normalize()
	else:
		nPlane = om.MVector(objectMatrix[4], objectMatrix[5], objectMatrix[6]).normalize()
	
	dl = rd * nPlane
	
	# Ray is on the plane or parallel to the plane, shouldn't be possible    
	if dl == 0:
		dl = (worldPosition - rs) * nPlane
		if dl == 0: # On the plane
			pass
		else: # Parallel
			pass
	else:
		d = (worldPosition - rs) * nPlane / dl
		point = rs + d * rd
		wsPos = (point[0], point[1], point[2])
	
	return wsPos

def planePointIntersect(pressPosition=[0, 0], planePoint=[], normal=[]):
	wsPos = None

	if all([pressPosition, planePoint, normal]):
		if not isinstance(planePoint, om.MPoint):
			planePoint = om.MPoint(planePoint)
		
		if not isinstance(normal, om.MVector):
			normal = om.MVector(normal)
	
		# Screen position of mouse
		x, y = int(pressPosition[0]), int(pressPosition[1])
		
		# Raysource rs, Raydirection rd
		rs, rd = viewToWorld(x, y)
		
		dl = rd * normal
		
		# Ray is on the plane or parallel to the plane, shouldn't be possible    
		if dl == 0:
			dl = (planePoint - rs) * normal
			if dl == 0: # On the plane
				pass
			else: # Parallel
				pass
		else:
			d = (planePoint - rs) * normal / dl
			point = rs + d * rd
			wsPos = (point[0], point[1], point[2])
	
	return wsPos

def rayCastPlaneIntersection(planeNormal, planePoint, rayDirection, rayPoint, epsilon=1e-6):
	ndotu = dotProduct(planeNormal, rayDirection)
	if abs(ndotu) < epsilon:
		return None

	w = om.MVector(rayPoint) - om.MVector(planePoint)
	si = (dotProduct(planeNormal, w) * -1) / ndotu

	psi = list(w + si * om.MVector(rayDirection) +  om.MVector(planePoint))
	
	return psi

def angleBetween2DVectors(p1, p2):
	angleBetweenVectors = 0

	if len(p1) > 1 and len(p2) > 1:
		ang1 = math.atan2(*list(reversed(p1))[:2])
		ang2 = math.atan2(*list(reversed(p2))[:2])
		angleBetweenVectors = math.degrees((ang1 - ang2) % (2 * math.pi))
	
	return angleBetweenVectors

def angleBetween3DVectors(v1, v2, normalVector):
	#angleBetweenVectors = math.degrees(math.acos(dotProduct(v1, v2) / (vectorMagnitude(v1) * vectorMagnitude(v2))))
	angleBetweenVectors = math.degrees(math.atan2(vectorMagnitude(crossProduct(v1, v2)), dotProduct(v1, v2)))

	if dotProduct(normalVector, crossProduct(v1, v2)) < 0:
		angleBetweenVectors = 360 - angleBetweenVectors
	
	return angleBetweenVectors

def vectorToAxisDirection(obj, initialPos, newPos, worldSpace=True):
	# Find in which direction the object was translated
	if worldSpace is True:
		objectMatrix = cmds.xform(obj, query=True, worldSpace=True, matrix=True)
	else:
		objectMatrix = cmds.xform(obj, query=True, objectSpace=True, matrix=True)

	objectTangent = normalizeVector([objectMatrix[0], objectMatrix[1], objectMatrix[2]])
	objectBinormal = normalizeVector([objectMatrix[4], objectMatrix[5], objectMatrix[6]])
	objectNormal = normalizeVector([objectMatrix[8], objectMatrix[9], objectMatrix[10]])
	vectorList = {"x": objectTangent, "y": objectBinormal, "z": objectNormal}
	
	posVector = vectorBetweenPoints(initialPos, newPos)
	translateVector = objectTangent
	translateAxis = "x"
	vectorDotProduct = 0
	for key, value in six.iteritems(vectorList):
		vp = dotProduct(value, posVector)
		if abs(vp) > vectorDotProduct:
			if vp < 0:
				translateAxis = "-{0}".format(key)
				translateVector = [x * -1 for x in vectorList[key]]
			else:
				translateAxis = key
				translateVector = vectorList[key]
			vectorDotProduct = abs(vp)
	
	return translateAxis, om.MVector(translateVector), objectMatrix

def getShortName(objectSel):
	dagPath = []
	shortName = objectSel
	dagPath = shortName.split("|")
	#shortName = filter(None, shortName)
	if(len(dagPath)>0):
		shortName = dagPath[len(dagPath)-1]
	return shortName

def getRuntimeCommandInfo(cmd):
	for index in range(1, cmds.assignCommand(query=True, numElements=True)+1):
		if cmds.assignCommand(index, query=True, command=True) == cmd:
			commandName = cmds.assignCommand(index, query=True, name=True)
			runTimeCommandName = cmds.assignCommand(index, query=True, command=True)
			annotation = cmds.assignCommand(index, query=True, annotation=True)
			hotkeyCmd = cmds.assignCommand(index, query=True, keyString=True)
			
			hotkeyDict = {"key": "NONE", "ctrl": False, "shift": False, "alt": False, "command": False}
			hotkeyDict["key"] = hotkeyCmd[0]
			hotkeyDict["ctrl"] = cmds.hotkey(hotkeyCmd[0], query=True, ctrlModifier=True)
			hotkeyDict["shift"] = cmds.hotkey(hotkeyCmd[0], query=True, shiftModifier=True)
			hotkeyDict["alt"] = cmds.hotkey(hotkeyCmd[0], query=True, altModifier=True)
			hotkeyDict["command"] = cmds.hotkey(hotkeyCmd[0], query=True, commandModifier=True)
			
			runTimeCommandDict = {"name": runTimeCommandName, "default": False, "command": "", "language": "mel", "show": True, "annotation": ""}
			runTimeCommandDict["default"] = cmds.runTimeCommand(runTimeCommandName, query=True, default=True)
			runTimeCommandDict["command"] = cmds.runTimeCommand(runTimeCommandName, query=True, command=True)
			runTimeCommandDict["language"] = cmds.runTimeCommand(runTimeCommandName, query=True, commandLanguage=True)
			runTimeCommandDict["show"] = cmds.runTimeCommand(runTimeCommandName, query=True, showInHotkeyEditor=True)
			runTimeCommandDict["annotation"] = cmds.runTimeCommand(runTimeCommandName, query=True, annotation=True)
			
			return {"name": commandName, "annotation": annotation, "command": runTimeCommandName, "hotkey": hotkeyDict, "runTimeCommand": runTimeCommandDict}
	return {}

def	findFreeBlocks(section=0, block=cmds.headsUpDisplay(nextFreeBlock=0), num=1):
	blockValue = int(block)
	blockStart = int(block)-1
	restart = False
	while True:
		restart = False
		for i in range(num):
			if restart is True:
				break
			blockStart = int(blockStart)+1
			while True:
				try:
					if cmds.headsUpDisplay("TempHUD", query=True, exists=True) is True:
						cmds.headsUpDisplay("TempHUD", remove=True)
					cmds.headsUpDisplay("TempHUD", section=section, block=blockStart, blockSize="small", padding=15, label="Temp", labelFontSize="small")
					if i == 1:
						blockValue = int(blockStart)
					break
				except:
					if i > 1:
						restart = True
						break
					blockStart += 1
					continue
		if restart is False:
			break
	if cmds.headsUpDisplay("TempHUD", query=True, exists=True) is True:
		cmds.headsUpDisplay("TempHUD", remove=True)
	return blockValue

def isModelPanel(panel):
	return (panel in cmds.getPanel(type="modelPanel") and cmds.modelEditor(panel, query=True, exists=True))

def getFreeAttributeIndex(node, attribute, startIndex=0, maxIndex=1000000):
	# Check if attributes contains childrens
	child_attributes = cmds.attributeQuery(attribute, node=node, listChildren=True) or [""]
	# Format attributes string for query
	if child_attributes:
		child_attributes = [".{0}".format(attr) for attr in child_attributes]
	
	# Find next free index
	while startIndex < maxIndex:
		attr_free = True
		
		# All children attributes must be free otherwise increment index
		for child_attr in child_attributes:
			if len(cmds.connectionInfo("{0}.{1}[{2}]{3}".format(node, attribute, startIndex, child_attr), sourceFromDestination=True) or []) != 0:
				attr_free = False
				startIndex += 1
				break
		
		if attr_free is True:
			return startIndex
	
	# No connections means the first index is available
	return 0

def vectorBetweenPoints(point1, point2):
	return normalizeVector([point2[i] - point1[i] for i in range(len(point1))])

def vectorMagnitude(vector1, useOpenMaya=True):
	if len(vector1) >= 3:
		if useOpenMaya:
			return om.MVector(vector1).length()
		else:
			return math.sqrt(sum(i**2 for i in vector1[:3]))

def distanceBetweenPoints(point1, point2):
	# distance between 3D points
	if len(point1) >= 3 and len(point2) >= 3:
		return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2 + (point2[2] - point1[2])**2)
	# distance between 2D points
	else:
		return math.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

def getMiddlePoint(point1, point2):
	return om.MVector(om.MVector(point1) + om.MVector(point2)) / 2

def refreshHud(huds=None):
	if huds is not None:
		if isinstance(huds, six.string_types):
			huds = [huds]
		if len(huds) > 0:
			for hud in huds:
				if cmds.headsUpDisplay(hud, query=True, exists=True) is True:
					cmds.headsUpDisplay(hud, refresh=True)

def pixmapWithOffset(image, padding=0, offset=QtCore.QPoint(0, 0)):
	input = QtGui.QPixmap(image)
	output = QtGui.QPixmap(input.size().width()+padding, input.size().height()+padding)
	output.fill(QtCore.Qt.transparent)
	painter = QtGui.QPainter(output)
	painter.drawPixmap(padding/2 + offset.x(), padding/2 + offset.y(), input)
	painter.end()
	return output

def pyNodeToCmds(nodes=[], long=True):
	if isinstance(nodes, (list, tuple)):
		#[str(node) for node in nodes] # fastest way
		#return cmds.ls([node.longName() if isinstance(node, pm.PyNode) else node for node in nodes], long=long)
		return cmds.ls([node.longName() for node in nodes if isinstance(node, pm.PyNode) and node.exists()], long=long)
	elif isinstance(nodes, pm.PyNode):
		return next(iter(cmds.ls(nodes.longName(), long=long)), "")
	return nodes

def getPyNodeName(node, long=True):
	if isinstance(node, pm.PyNode):
		if node.exists() is False:
			return None
		if long is True:
			node = node.longName()
		else:
			node = node.shortName()
	return node

def pyNodeExists(node, strict=True):
	if isinstance(node, pm.PyNode):
		return node.exists()
	elif isinstance(node, six.string_types) and strict is False:
		return cmds.objExists(node or "")
	return False

def getMDagPath(obj):
	mDagPath = None
	obj = getPyNodeName(obj)
	
	if cmds.objExists(obj):
		objectList = om.MSelectionList()
		objectList.add(obj)
		mDagPath = objectList.getDagPath(0)

	return mDagPath

def getMObject(obj):
	mObject = None
	obj = getPyNodeName(obj)
	
	if cmds.objExists(obj):
		objectList = om.MSelectionList()
		objectList.add(obj)
		mObject = objectList.getDependNode(0)

	return mObject

def getMMatrix(obj, worldSpace=True, rotatePivot=False):
	dagPath = getMDagPath(obj)
	
	if not dagPath:
		return om.MMatrix()
	
	objectMatrix = dagPath.inclusiveMatrix()
	
	if rotatePivot:
		pivotPos = cmds.xform(getPyNodeName(obj), query=True, worldSpace=True, rotatePivot=True)
		if pivotPos != (list(objectMatrix)[12:15]):
			for i in range(3):
				objectMatrix.setElement(3, i, pivotPos[i])
	
	if worldSpace is False:
		objectMatrix = objectMatrix * dagPath.exclusiveMatrix().inverse()
	
	return objectMatrix

def getScreenSpaceBoundingBox(obj, ignoreHidden=False, clampToViewport=True):
	if isinstance(obj, (list, tuple)):
		obj = obj[0]
	if not isinstance(obj, six.string_types) or not cmds.objExists(obj):
		return None
	
	# Get the boundingBox of the object
	boundingBox = cmds.exactWorldBoundingBox(obj)
	boundingBoxMin = [boundingBox[0], boundingBox[1], boundingBox[2]]
	boundingBoxMax = [boundingBox[3], boundingBox[4], boundingBox[5]]
	boundingBoxX = {"min": boundingBoxMin[0], "mid": (boundingBoxMin[0]+boundingBoxMax[0])*0.5, "max": boundingBoxMax[0]}
	boundingBoxY = {"min": boundingBoxMin[1], "mid": (boundingBoxMin[1]+boundingBoxMax[1])*0.5, "max": boundingBoxMax[1]}
	boundingBoxZ = {"min": boundingBoxMin[2], "mid": (boundingBoxMin[2]+boundingBoxMax[2])*0.5, "max": boundingBoxMax[2]}

	# Get all the positions of the bounding box
	allVerticesPositions = []
	allVerticesPositions.append((boundingBoxX["max"], boundingBoxY["max"], boundingBoxZ["max"]))
	allVerticesPositions.append((boundingBoxX["min"], boundingBoxY["max"], boundingBoxZ["max"]))
	allVerticesPositions.append((boundingBoxX["max"], boundingBoxY["max"], boundingBoxZ["min"]))
	allVerticesPositions.append((boundingBoxX["min"], boundingBoxY["max"], boundingBoxZ["min"]))
	allVerticesPositions.append((boundingBoxX["max"], boundingBoxY["min"], boundingBoxZ["min"]))
	allVerticesPositions.append((boundingBoxX["min"], boundingBoxY["min"], boundingBoxZ["min"]))
	allVerticesPositions.append((boundingBoxX["max"], boundingBoxY["min"], boundingBoxZ["max"]))
	allVerticesPositions.append((boundingBoxX["min"], boundingBoxY["min"], boundingBoxZ["max"]))

	vertPositionsX = []
	vertPositionsY = []
	currentView = M3dView.active3dView()
	viewportSize = [int(x) for x in currentView.viewport()[2:4]]

	for vert in allVerticesPositions:
		pos = om.MPoint(vert)
		
		# Returns the screen x position, y position, and whether of not the vertex is within the clipping plane
		xPos, yPos, visible = currentView.worldToView(pos)
		
		# If the vert isn't being clipped by the camera, we append those positions
		if visible or ignoreHidden is False:
			vertPositionsX.append(xPos)
			vertPositionsY.append(yPos)

	# Get the positions we'll need to build our 2d bounding box (which verts are highest, lowest, farthest right and farthest left)
	top = max(vertPositionsY)
	bottom = min(vertPositionsY)
	right = max(vertPositionsX)
	left = min(vertPositionsX)
	
	if clampToViewport:
		top = min(top, viewportSize[1])
		bottom = max(bottom, 0)
		right = min(right, viewportSize[0])
		left = max(left, 0)
	
	return {"top": top, "bottom": bottom, "right": right, "left": left}

def screenSpaceBoundingBoxToWorld(screenSpaceBoundingBox):
	if not isinstance(screenSpaceBoundingBox, dict):
		return None
	
	currentView = M3dView.active3dView()
	
	dir = om.MVector()
	topRight = om.MPoint()
	topLeft = om.MPoint()
	bottomLeft = om.MPoint()
	bottomRight = om.MPoint()
	
	currentView.viewToWorld(screenSpaceBoundingBox["right"], screenSpaceBoundingBox["top"], topRight, dir)
	currentView.viewToWorld(screenSpaceBoundingBox["left"], screenSpaceBoundingBox["top"], topLeft, dir)
	currentView.viewToWorld(screenSpaceBoundingBox["left"], screenSpaceBoundingBox["bottom"], bottomLeft, dir)
	currentView.viewToWorld(screenSpaceBoundingBox["right"], screenSpaceBoundingBox["bottom"], bottomRight, dir)
	
	return {"topRight": list(topRight)[:3], "topLeft": list(topLeft)[:3], "bottomLeft": list(bottomLeft)[:3], "bottomRight": list(bottomRight)[:3]}

def makeLiveQuiet(obj=None, none=False):
	if none or (obj and cmds.objExists(obj)):
		inViewMessageState = cmds.optionVar(q="inViewMessageEnable")
		if inViewMessageState:
			cmds.optionVar(intValue=("inViewMessageEnable", False))
		
		cmds.makeLive(obj, none=none)
		
		if inViewMessageState:
			#cmds.optionVar(intValue=("inViewMessageEnable", True))
			cmds.scriptJob(event=("idle", partial(cmds.optionVar, intValue=("inViewMessageEnable", True))), runOnce=True)

def getListLastItem(x):
	return x[-1] if x else None

def isolateSelectAutoAdd(editor):
	if MAYA_VERSION <= 2017:
		mel.eval("global string $isolateSelectAutoAddEditors[];")
		mel.eval("global int $isolateSelectAutoAddEnabled[];")
		
		e_size = mel.eval("size($isolateSelectAutoAddEditors);")
		for i in range(e_size):
			if editor == mel.eval("$PT_tmpVar = $isolateSelectAutoAddEditors[{0}];".format(i)):
				return bool(int(mel.eval("$PT_tmpVar = $isolateSelectAutoAddEnabled[{0}];".format(i))))
		
		# Not found, default is enabled so add this editor 
		mel.eval('$isolateSelectAutoAddEditors[{0}] = "{1}";'.format(e_size, editor))
		mel.eval('$isolateSelectAutoAddEnabled[{0}] = 1;'.format(e_size))
		return True
	else:
		mel.eval("global string $gIsolateSelectAutoAddEditors[];")
		mel.eval("global int $gIsolateSelectAutoAddEnabled[];")
		
		e_size = mel.eval("size($gIsolateSelectAutoAddEditors);")
		for i in range(e_size):
			if editor == mel.eval("$PT_tmpVar = $gIsolateSelectAutoAddEditors[{0}];".format(i)):
				return bool(int(mel.eval("$PT_tmpVar = $gIsolateSelectAutoAddEnabled[{0}];".format(i))))
		
		# Not found, default is enabled so add this editor 
		mel.eval('$gIsolateSelectAutoAddEditors[{0}] = "{1}";'.format(e_size, editor))
		mel.eval('$gIsolateSelectAutoAddEnabled[{0}] = 1;'.format(e_size))
		return True

#@make_undoable
def safeDgdirty(nodes, **kwargs):
	try:
		if isinstance(nodes, six.string_types):
			nodes = [nodes]
		nodes = list(filter(cmds.objExists, nodes))
		cmds.dgdirty(nodes, **kwargs)
	except Exception as e:
		pass

@make_undoable
def setAttrUndoable(*args, **kwargs):
	try:
		cmds.setAttr(*args, **kwargs)
	except Exception as e:
		pass

def PT_GetResource(file_name):
	resource_file = os.path.join(ROOT_DIR, file_name.replace("/", os.sep))
	
	if not os.path.isfile(resource_file):
		resource_file = ":/{0}".format(file_name.replace(os.sep, "/"))
	
	return resource_file

def getDisplayColor(colorName, colorValue, **kwargs):
	try:
		colorIndex = cmds.displayColor(colorName, query=True, **kwargs)
	except:
		cmds.displayColor(colorName, colorValue, create=True, **kwargs)
		colorIndex = colorValue
	
	return colorIndex

class PlacementTool(object):
	def __init__(self, contextName="placementToolContext"):
		super(PlacementTool, self).__init__()
		
		self.undoScriptJob = None
		_forceReload = False
		self._pressPositionOptimization = True
		
		# Use existing draggerContext if one already exists
		if _forceReload is False:
			# Check if context already exists
			if cmds.draggerContext(contextName, exists=True) is True:
				if cmds.currentCtx() == contextName:
					try:
						cmds.setToolTo(mel.eval("$gCurrentSacredTool = $gCurrentSacredTool"))
					except:
						cmds.setToolTo("selectSuperContext")
				else:
					cmds.setToolTo(contextName)
				return
		
		# Create context
		self.contextName = contextName
		self.createDraggerContext()
	
	def createDraggerContext(self):
		if cmds.draggerContext(self.contextName, exists=True) is True:
			cmds.deleteUI(self.contextName)
		cmds.draggerContext(self.contextName, 
							initialize = rpartial(self.toolEnterFn, partialLabel="PlacementTool"), 
							pressCommand = rpartial(self.toolPressFn, partialLabel="PlacementTool"), 
							releaseCommand = rpartial(self.toolReleaseFn, partialLabel="PlacementTool"), 
							dragCommand = rpartial(self.toolDragFn, partialLabel="PlacementTool"), 
							finalize = rpartial(self.toolExitFn, partialLabel="PlacementTool"), 
							cursor = "default", 
							projection = "s", 
							undoMode = "step")
		cmds.setToolTo(self.contextName)
	
	def createDefaultVar(self):
		self.draggerButton = 1
		self.draggerModifier = "none"
		self.dragging = False
		self.lastFaceUnderCursor = None
		self.objectUnderCursor = None
		self.rotation = None
		self.rotationDict = {}
		self.objectMatrixDict = {}
		self.pressPosition = [0, 0]
		self.lastPressPosition = None
		self.dragPosition = [0, 0]
		self.rotationStep = None
		self.invertRotation = False
		self.invertScale = False
		self.objtMatrix = None
		self.straightLineAngle = None
		self.objBoundingBox = None
		self.placementLine = None
		self.placementLabel = None
		self.currentSel = None
		self.currentSelCmds = []
		self.lastSelectedObjects = None
		self.lastMovedObjects = set()
		self.lastSurfaceOffset = 0
		self.currentLiveObjects = []
		self.templateLayers = []
		self.templateList = []
		self.invalidTarget = False
		self.dragTolerance = 8
		self.selectionChangeScriptJob = None
		self.nameChangedScriptJob = None
		self.outlineShape = None
		self.outlineTransform = None
		self.hideOutline = False

		# Get viewport settings/preferances
		self.shadeTemplate = cmds.displayPref(query=True, shadeTemplates=True)
		self.wireframeOnShadedActive = cmds.displayPref(query=True, wireframeOnShadedActive=True)
		self.displayAffected = cmds.displayPref(query=True, displayAffected=True)
		self.cameraBasedSelection = cmds.selectPref(query=True, useDepth=True)
		self.clickBoxSize = cmds.selectPref(query=True, clickBoxSize=True)
		self.strokeSelection = cmds.selectType(query=True, stroke=True)
		self.activeTemplateColor = getDisplayColor("activeTemplate", 21, active=True)
		self.activePolymeshColor = getDisplayColor("polymesh", 21, active=True)
		self.referenceLayerColor = getDisplayColor("referenceLayer", 1, dormant=True)
		self.leadColorIndex = getDisplayColor("lead", 21, active=True)
		self.strokeColorIndex = getDisplayColor("stroke", 16, active=True)
		liveColorIndex = getDisplayColor("live", 23, dormant=True)
		self.liveColorRGB = cmds.colorIndex(liveColorIndex, query=True)
		self.leadColorRGB = cmds.colorIndex(self.leadColorIndex, query=True)
		self.activeAffectedIndex = getDisplayColor("activeAffected", 9, active=True)
		
		# Get polygons display edges settings
		self.displayEdges = "allEdges"
		displayEdgesFlags = ["allEdges", "softEdge", "hardEdgeColor", "hardEdge"]
		for flag in displayEdgesFlags:
			if eval("cmds.polyOptions(query=True, newPolymesh=True, {0}=True)".format(flag))[0]:
				self.displayEdges = flag
				break
		
		# Get texture border and solid overlay settings
		if MAYA_VERSION >= 2018:
			self.texWinName = next(iter(cmds.getPanel(scriptType="polyTexturePlacementPanel") or []), None)
			if self.texWinName:
				self.textureBorder3dView = cmds.textureWindow(self.texWinName, query=True, textureBorder3dView=True)
				self.solidMap3dView = cmds.textureWindow(self.texWinName, query=True, solidMap3dView=True)
	
	def toolEnterFn(self):
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		# Create default variables
		self.createDefaultVar()
		
		# Increase recursion limit to avoid RuntimeError
		self._recursionLimit = sys.getrecursionlimit()
		sys.setrecursionlimit(10**4)
		
		self.filterSelectionType()
		self.currentSel = self.getCurrentSel()
		self.lastSelectedObjects = list(self.currentSel)
		
		if self.shadeTemplate is False:
			# Disable shading on layers with "template" display
			self.templateLayers = []
			for layer in pm.ls(long=True, type="displayLayer"):
				if layer.getAttr("displayType") == 1 and layer.getAttr("shading") == 1:
					self.templateLayers.append(layer)
					layer.setAttr("shading", 0)
			
			# Enable shaded template
			cmds.displayPref(shadeTemplates=True)
		
		# Set stroke Display Color
		cmds.displayColor("stroke", self.leadColorIndex, active=True)
		cmds.displayColor("activeAffected", self.leadColorIndex, active=True)
		
		# Update Outline
		self.updateOutline(self.currentSel)
		
		# Set Hard Edges display color to lead & polymesh colors
		#cmds.displayRGBColor("hardedgeHilite", *self.leadColorRGB)
		#cmds.displayRGBColor("hardedge", *self.polymeshColorRGB)
		
		# Delete ScriptJob
		if self.undoScriptJob is not None:
			cmds.scriptJob(kill=self.undoScriptJob, force=True)
		
		# Create ScriptJob
		self.selectionChangeScriptJob = cmds.scriptJob(event=("SelectionChanged", partial(self.selectionChange)), protected=True, compressUndo=True)
		self.nameChangedScriptJob = cmds.scriptJob(event=("NameChanged", partial(self.nameChanged)), protected=True)
		#self.selectionChangeScriptJob = cmds.scriptJob(event=("SelectionChanged", partial(cmds.evalDeferred, self.selectionChange)), protected=True, compressUndo=True)
		
		# Create EventFilter
		self.PT_MainWindowFilter = PT_EventFilter()
		# Connect controlsCallbackSignal to function
		self.PT_MainWindowFilter.pieMenu.controlsCallbackSignal.connect(self.controlsCallback)
		#  Connect keyCallbackSignal to function 
		self.PT_MainWindowFilter.keyCallbackSignal.connect(self.keyCallback)
		#  Connect modelEditorCallback to function 
		self.PT_MainWindowFilter.modelEditorCallback.connect(self.modelEditorCallback)
		
		# Create Hud
		self.createHud()
		
		# Fix performance on first press
		self.prePlacementSetup(False)
		self.postPlacementSetup()
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def toolExitFn(self):
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		# Reset recursion limit
		sys.setrecursionlimit(self._recursionLimit)
		
		# Delete Hud
		self.deleteHud()
		
		if self.shadeTemplate is False:
			# Disable shaded template
			cmds.displayPref(shadeTemplates=False)
			
			# Enable shading on layers with "template" display
			for layer in self.templateLayers:
				if pyNodeExists(layer):
					layer.setAttr("shading", 1)
			self.templateLayers = []
		
		# Reset wireframe on active objects to default
		#if self.wireframeOnShadedActive != "none":
			#cmds.displayPref(wireframeOnShadedActive=self.wireframeOnShadedActive)
		
		# Set Hard Edges display color back to default
		#cmds.displayRGBColor("hardedgeHilite", *self.hardedgeHiliteColorRGB)
		#cmds.displayRGBColor("hardedge", *self.hardedgeColorRGB)
		
		# Reset selection masks
		if self.strokeSelection:
			cmds.selectType(stroke=True)
		
		# Set live object back
		if len(self.currentLiveObjects) > 0:
			currentLiveObjects = pyNodeToCmds(self.currentLiveObjects)
			makeLiveQuiet(currentLiveObjects[-1])
			cmds.color(currentLiveObjects)
		
		# Set active display color back to default
		cmds.displayColor("activeTemplate", self.activeTemplateColor, active=True)
		#cmds.displayColor("polymesh", self.activePolymeshColor, active=True)
		cmds.displayPref(displayAffected=self.displayAffected)
		
		# Set Texture Border and Solid Overlay in viewport to default
		if MAYA_VERSION >= 2018:
			if self.texWinName:
				cmds.textureWindow(self.texWinName, edit=True, textureBorder3dView=self.textureBorder3dView)
				cmds.textureWindow(self.texWinName, edit=True, solidMap3dView=self.solidMap3dView)
		
		# Delete Outline
		if pyNodeExists(self.outlineTransform):
			pm.delete(self.outlineTransform)
		# Set stroke display color back to default
		cmds.displayColor("stroke", self.strokeColorIndex, active=True)
		cmds.displayColor("activeAffected", self.activeAffectedIndex, active=True)
		
		# Delete ScriptJob
		if self.selectionChangeScriptJob is not None:
			cmds.scriptJob(kill=self.selectionChangeScriptJob, force=True)
		if self.nameChangedScriptJob is not None:
			cmds.scriptJob(kill=self.nameChangedScriptJob, force=True)
		
		# Undo ScriptJob
		self.undoScriptJob = cmds.scriptJob(event=("Undo", partial(self.undo)), protected=True)
		
		# Remove EventFilter
		self.PT_MainWindowFilter.removePlacementEventFilter()
		
		# Remove cursor override
		self.changeCursorOverride(None)
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def undo(self):
		if not self or not cmds:
			return
		
		if cmds.currentCtx() == self.contextName:
			return
		
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		# Disable visibility, deleting makes Maya crash sometimes
		#self.cleanupOutline(deleteAll=True)
		if pyNodeExists(self.outlineShape):
			self.outlineShape.setAttr("displayInViewport", False)
			for attr, value in (("visibility", False), ("lodVisibility", False), ("overrideEnabled", True), ("overrideVisibility", False)):
				self.outlineShape.setAttr(attr, value)
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def prePlacementSetup(self, templateObjects=True):
		#refreshViewport = False
		
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		if templateObjects:
			self.currentSel = self.getCurrentSel()
		#self.templateList = []
		
		currentLiveObjects = pm.ls(long=True, live=True)
		if len(currentLiveObjects) > 0 and set(currentLiveObjects) != set(self.currentLiveObjects):
			cmds.color(pyNodeToCmds(self.currentLiveObjects))
			cmds.color(getPyNodeName(currentLiveObjects[-1]), rgbColor=self.liveColorRGB)
			self.currentLiveObjects.extend(currentLiveObjects)
		
		# Update Outline
		#if len(self.currentSel) > 0:
			#self.updateOutline(self.currentSel)
		# Set Outline visibility
		self.displayOutline()
		
		# Enable highlight affected to make outline color match active selection color
		if not cmds.displayPref(query=True, displayAffected=True):
			cmds.displayPref(displayAffected=True)
		
		# Disable outline selection
		if cmds.selectType(query=True, stroke=True):
			self.strokeSelection = True
			cmds.selectType(stroke=False)
		
		# Set active objects display settings
		self.modelEditorCallback(edgeDisplay=True)
		
		# Set selected object as template, so it is ignored by hit-tests
		for obj in self.currentSel:
			objectName = getPyNodeName(obj)
			if cmds.objExists(objectName or "") and cmds.attributeQuery("template", node=objectName, exists=True) is True:
				if cmds.getAttr("{0}.template".format(objectName)) is False:
					cmds.setAttr("{0}.template".format(objectName), True)
					#refreshViewport = True
				
				self.templateList.append(obj)
		
		# Disable live object, so it does not interfere with the tool
		if len(cmds.ls(long=True, live=True)) > 0:
			makeLiveQuiet(none=True)
			#refreshViewport = True
		
		# Disable camera-based selection, so template objects will be ignored by hit-tests
		if cmds.selectPref(query=True, useDepth=True) is True:
			cmds.selectPref(useDepth=False)
			cmds.selectPref(clickBoxSize=1)
			#refreshViewport = True
		
		#if refreshViewport is True:
			#cmds.refresh()
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def postPlacementSetup(self):
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		# Un-template selected objects
		for obj in self.templateList:
			objectName = getPyNodeName(obj)
			if cmds.objExists(objectName or "") and cmds.attributeQuery("template", node=objectName, exists=True) is True:
				cmds.setAttr(objectName+".template", False)
		self.templateList = []
		
		# Set Outline visibility
		self.displayOutline(visibility="hide")
		
		# Set active objects display settings
		self.modelEditorCallback(reset=True)
		
		# Set selection preferences back
		cmds.selectPref(useDepth=self.cameraBasedSelection)
		cmds.selectPref(clickBoxSize=self.clickBoxSize)
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def controlsCallback(self, obj):
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		if isinstance(obj, QtWidgets.QWidget):
			# Surface offset callback
			if obj.objectName() == "PT_SurfaceOffset" or getSpinBoxName(obj) == "PT_SurfaceOffsetValue":
				# Apply surface offset if the selected objects were moved with placementFn
				if self.lastMovedObjects and self.lastMovedObjects == set(self.currentSel):
					
					currentOffset = 0
					if bool(cmds.optionVar(query="PT_SurfaceOffset")):
						currentOffset = cmds.optionVar(query="PT_SurfaceOffsetValue")
					
					offsetValue = currentOffset - self.lastSurfaceOffset
					self.lastSurfaceOffset = currentOffset
					
					# Add surface offset to position
					if offsetValue != 0:
						offsetPosition = getOffsetedObjectPosition(self.currentSel[-1], pm.xform(self.currentSel[-1], query=True, worldSpace=True, rotatePivot=True), offsetValue)
						
						# Set object position
						if bool(cmds.optionVar(query="PT_RetainSpacing")):
							objectsToMove = self.currentSel[-1]
							# Get parentMatrix before position is changed
							parentMatrix = getMMatrix(self.currentSel[-1], rotatePivot=True)
						else:
							objectsToMove = self.currentSel
						pm.move(offsetPosition[0], offsetPosition[1], offsetPosition[2], objectsToMove, worldSpace=True, rotatePivotRelative=True)
						
						# Offset matrix from last selected object
						if bool(cmds.optionVar(query="PT_RetainSpacing")):
							for obj in self.currentSel[:-1]:
								offsetMatrix = getMMatrix(obj, rotatePivot=True) * parentMatrix.inverse()
								offsetMatrixDict = offsetParentMatrix(self.currentSel[-1], obj, offsetMatrix, position=True)
								
								pos = offsetMatrixDict["position"]
								pm.move(pos[0], pos[1], pos[2], obj, worldSpace=True, rotatePivotRelative=True)
						
						# Refresh viewport
						cmds.refresh()
			
			# Show Outline / Show Wireframe callback
			elif obj.objectName() in ["PT_ShowOutline", "PT_ShowWireframe"]:
				# Update Outline
				self.updateOutline(self.currentSel)
			
			# Show HUD callback
			elif obj.objectName() == "PT_ShowHUD":
				# Update Hud
				self.createHud()
			
			# Step Alignement callback
			elif obj.objectName() == "PT_StepAlignement" or getSpinBoxName(obj) == "PT_StepAlignementValue":
				if bool(cmds.optionVar(query="PT_ShowHUD")):
					refreshHud("PlacementToolHUD_Status")
			
			# Step Rotation callback
			elif obj.objectName() == "PT_StepRotation" or getSpinBoxName(obj) == "PT_StepRotationValue":
				if bool(cmds.optionVar(query="PT_ShowHUD")):
					refreshHud("PlacementToolHUD_Status")
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def keyCallback(self, key):
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		# Refresh status
		refreshHud("PlacementToolHUD_Status")
		
		# Reset rotation step
		if key == QtCore.Qt.Key_J:
			self.rotationStep = None
		# Clear selection
		elif key == QtCore.Qt.Key_D:
			cmds.select(clear=True)
			self.currentSel = []
		
		if self.PT_MainWindowFilter.placementModifier is not None:			
			self.changeCursorOverride(self.PT_MainWindowFilter.placementModifier)
			
			# Affect dragging behaviour
			if self.PT_MainWindowFilter.placementModifier != "shift":
				#self.removePlacementLine(refresh=True) # removing will crash if user undo, hide it instead
				if self.placementLine and cmds.objExists(self.placementLine):
					for attr, value in ((".visibility", False), (".lodVisibility", False), (".overrideEnabled", True), (".overrideVisibility", False)):
						cmds.setAttr(self.placementLine+attr, value)
					
					refreshHud("PlacementToolHUD_TargetObject")
					self.objtMatrix = None
					self.straightLineAngle = None
					cmds.refresh()
		
		else:
			# Remove cursor override
			self.changeCursorOverride(None)
			
			# Delete old placementLine
			#self.removePlacementLine(refresh=True) # removing will crash if user undo, hide it instead
			if self.placementLine and cmds.objExists(self.placementLine):
				for attr, value in ((".visibility", False), (".lodVisibility", False), (".overrideEnabled", True), (".overrideVisibility", False)):
					cmds.setAttr(self.placementLine+attr, value)
				
				refreshHud("PlacementToolHUD_TargetObject")
				self.objtMatrix = None
				self.straightLineAngle = None
				cmds.refresh()
	
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def modelEditorCallback(self, reset=False, edgeDisplay=False):
		currentSel = pyNodeToCmds(self.currentSel)
		
		if reset is True:
			if len(currentSel) == 0:
				currentSel = pyNodeToCmds(self.lastSelectedObjects)
			
			# Set objects Display Edges back to default
			eval("cmds.polyOptions({0}, {1}=True)".format(currentSel, self.displayEdges))
			
			return
		
		# Set active display color to active lead
		#for displayColorName in ["activeTemplate", "polymesh"]:
		for displayColorName in ["activeTemplate"]:
			if cmds.displayColor(displayColorName, query=True, active=True) != self.leadColorIndex:
				cmds.displayColor(displayColorName, self.leadColorIndex, active=True)
		
		# Disable Texture Border and Solid Overlay in viewport
		if MAYA_VERSION >= 2018:
			if self.texWinName:
				if cmds.textureWindow(self.texWinName, query=True, textureBorder3dView=True):
					cmds.textureWindow(self.texWinName, edit=True, textureBorder3dView=False)
				if cmds.textureWindow(self.texWinName, query=True, solidMap3dView=True):
					cmds.textureWindow(self.texWinName, edit=True, solidMap3dView=False)
		
		# Set active wireframe display settings
		if self.wireframeOnShadedActive != "none":
			if M3dView.active3dView().displayStyle() == M3dView.kWireFrame:
				# Reset wireframe on active objects to default
				#cmds.displayPref(wireframeOnShadedActive=self.wireframeOnShadedActive)
				# Set objects Display Edges to default
				if edgeDisplay:
					eval("cmds.polyOptions({0}, {1}=True)".format(currentSel, self.displayEdges))
				# Hide outline
				self.hideOutline = True
				#self.displayOutline()
			else:
				# Show outline
				self.hideOutline = False
				#self.displayOutline()
				if M3dView.active3dView().wireframeOnShaded() is True:
					# Reset wireframe on active objects to default
					#cmds.displayPref(wireframeOnShadedActive=self.wireframeOnShadedActive)
					# Set objects Display Edges to default
					#eval("cmds.polyOptions({0}, {1}=True)".format(self.currentSel, self.displayEdges))
					if edgeDisplay:
						cmds.polyOptions(currentSel, allEdges=True)
					
					# Need to draw outline as mesh to make it visible
					if pyNodeExists(self.outlineShape):
						self.outlineShape.setAttr("drawAsMesh", True)
						self.outlineShape.setAttr("overrideShading", True)
					
				else:
					# Disable wireframe on active objects
					#cmds.displayPref(wireframeOnShadedActive="none")
					# Set objects Display Edges to Standard
					if edgeDisplay:
						cmds.polyOptions(currentSel, allEdges=True)
					
					# Set outline display back to default
					if pyNodeExists(self.outlineShape):
						self.outlineShape.setAttr("drawAsMesh", False)
						self.outlineShape.setAttr("overrideShading", False)
	
	def removePlacementLine(self, refresh=False, cleanUp=False):
		placementLineShapes = cmds.ls("PlacementLineShape*", long=True, objectsOnly=True, type="bezierCurve")
		placementLineTransforms = cmds.listRelatives(placementLineShapes, fullPath=True, parent=True, noIntermediate=True, type="transform") or []
		placementLineTransforms = list(OrderedDict.fromkeys(placementLineTransforms)) # Remove duplicates
		
		placementLine = getPyNodeName(self.placementLine)
		if cmds.objExists(placementLine or "") and placementLine not in placementLineTransforms:
			placementLineTransforms.append(placementLine)
		
		if len(placementLineTransforms) > 0:
			cmds.delete(placementLineTransforms)
			if refresh:
				cmds.refresh()
		
		self.placementLine = None
		self.placementLabel = None
	
	def createOutline(self):		
		transformParent = None
		#if len(self.currentSel) > 0 and pyNodeExists(self.currentSel[-1]):
			#transformParent = self.currentSel[-1]
		
		# Create Outline node
		self.outlineTransform = pm.createNode("transform", name="PlacementToolOutline1", skipSelect=True, parent=transformParent)
		self.outlineShape = pm.createNode("pfxToon", name="PlacementToolOutlineShape1", skipSelect=True, parent=self.outlineTransform)
		
		# Set Outline Shape attributes
		self.outlineShape.setAttr("displayInViewport", True)
		self.outlineShape.setAttr("profileLines", 0)
		self.outlineShape.setAttr("borderLines", 1)
		self.outlineShape.setAttr("creaseLines", False)
		self.outlineShape.setAttr("intersectionLines", False)
		self.outlineShape.setAttr("lineWidth", 0)
		self.outlineShape.setAttr("occlusionWidthScale", False)
		self.outlineShape.setAttr("profileLineWidth", 0)
		self.outlineShape.setAttr("smoothProfile", False)
		self.outlineShape.setAttr("creaseLineWidth", 0)
		self.outlineShape.setAttr("creaseBreakAngle", 0)
		self.outlineShape.setAttr("creaseAngleMin", 0)
		self.outlineShape.setAttr("creaseAngleMax", 0)
		self.outlineShape.setAttr("hardCreasesOnly", False)
		self.outlineShape.setAttr("borderLineWidth", 0)
		self.outlineShape.setAttr("intersectionLineWidth", 0)
		self.outlineShape.setAttr("drawAsMesh", False)
		self.outlineShape.setAttr("displayPercent", 100)
		self.outlineShape.setAttr("profileColor", self.leadColorRGB)
		self.outlineShape.setAttr("creaseColor", self.leadColorRGB)
		self.outlineShape.setAttr("borderColor", self.leadColorRGB)
		self.outlineShape.setAttr("intersectionColor", self.leadColorRGB)
		self.outlineShape.setAttr("screenspaceWidth", True)
		self.outlineShape.setAttr("minPixelWidth", 1.2)
		self.outlineShape.setAttr("maxPixelWidth", 1.2)
		self.outlineShape.setAttr("isHistoricallyInteresting", 0)
		self.outlineShape.setAttr("overrideEnabled", True)
		self.outlineShape.setAttr("overrideShading", False)
		self.outlineShape.setAttr("overrideColor", self.leadColorIndex)
		#self.outlineShape.lock()
		
		# Set Outline Transform attributes
		hideInOutliner(self.outlineTransform.longName(), True)
		self.outlineTransform.setAttr("translateX", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("translateY", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("translateZ", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("rotateX", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("rotateY", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("rotateZ", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("scaleX", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("scaleY", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("scaleZ", lock=True, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("visibility", False, keyable=False, channelBox=False)
		self.outlineTransform.setAttr("lodVisibility", False)
		self.outlineTransform.setAttr("overrideEnabled", True)
		self.outlineTransform.setAttr("overrideVisibility", False)
		self.outlineTransform.setAttr("inheritsTransform", False, lock=True)
		self.outlineTransform.setAttr("template", True, lock=True)
	
	def cleanupOutline(self, deleteAll=False):
		# Delete empty Outline transforms
		outlineTransforms = cmds.ls("PlacementToolOutline*", long=True, objectsOnly=True, type="transform")
		for transform in list(outlineTransforms):
			if cmds.listRelatives(transform, fullPath=True, children=True):
				outlineTransforms.remove(transform)
		
		# Delete old Outline nodes
		outlineShapes = cmds.ls("PlacementToolOutline*", long=True, objectsOnly=True, type="pfxToon")
		outlineTransforms.extend(cmds.listRelatives(outlineShapes, fullPath=True, parent=True, noIntermediate=True, type="transform") or [])
		outlineTransforms = list(OrderedDict.fromkeys(outlineTransforms)) # Remove duplicates
		if deleteAll is False:
			outlineTransform = getPyNodeName(self.outlineTransform)
			if outlineTransform in outlineTransforms:
				outlineTransforms.remove(outlineTransform)
		
		if len(outlineTransforms) > 0:
			cmds.delete(outlineTransforms)
		
		return outlineTransforms
	
	def displayOutline(self, visibility=None):
		if visibility is None:
			outlineShape = getPyNodeName(self.outlineShape)
			if outlineShape is None:
				return
			outlineConnections = cmds.listConnections("{0}.inputSurface".format(outlineShape), shapes=True)
		elif visibility == "show":
			outlineConnections = [None]
		else:
			outlineConnections = None
		
		if outlineConnections is None or self.hideOutline:
			# Hide outline
			if pyNodeExists(self.outlineTransform):
				for attr, value in (("visibility", False), ("lodVisibility", False), ("overrideEnabled", True), ("overrideVisibility", False)):
					if self.outlineTransform.getAttr(attr) is not value:
						self.outlineTransform.setAttr(attr, value)
		elif len(outlineConnections) > 0:
			# Show outline
			if pyNodeExists(self.outlineTransform):
				for attr, value in (("visibility", True), ("lodVisibility", True), ("overrideEnabled", False), ("overrideVisibility", True)):
					if self.outlineTransform.getAttr(attr) is not value:
						self.outlineTransform.setAttr(attr, value)
	
	def updateOutline(self, objects=[]):
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		# Cleanup outlines
		self.cleanupOutline()
		
		# If Show Outline and Show Wireframe are turned off, delete existing outlines
		if any([bool(cmds.optionVar(query="PT_ShowOutline")), bool(cmds.optionVar(query="PT_ShowWireframe"))]) is False:
			# Delete Outline
			if pyNodeExists(self.outlineTransform):
				pm.delete(self.outlineTransform)
			
			# Turns undo/redo back on
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)
			
			return
		
		# Create Outline if it does not exists
		if pyNodeExists(self.outlineShape) is False:
			self.createOutline()
		
		# Get all connected transform on outlineShape
		outlineShape = getPyNodeName(self.outlineShape)
		inputSurfaceConnections = cmds.listConnections("{0}.inputSurface".format(outlineShape), source=True, destination=True, shapes=True, type="transform") or []
		inputSurfaceConnections.extend(cmds.listConnections("{0}.inputSurface".format(outlineShape), source=True, destination=True, shapes=True, type="mesh") or [])
		inputSurfaceConnections = list(OrderedDict.fromkeys(inputSurfaceConnections)) # Remove duplicates objects
		inputSurfaceConnections = cmds.ls(inputSurfaceConnections, long=True) # Get longname
		
		# Filter only transform
		objects = cmds.ls(pyNodeToCmds(objects), long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="transform")
		objectShapes = cmds.listRelatives(objects, fullPath=True, noIntermediate=True, shapes=True) or []

		# Filter bevelPreviews
		bevelPreviews = {}
		objectsWithBP = {}
		inputObjectsWithBP = {}
		forceAdd, forceRemove = [], []
		if callable(getObjectsWithBevelPreview):
			if objects:
				objectsWithBP = getObjectsWithBevelPreview(objects)
			
			bevelPreviewsOutMesh = [item for sublist in (cmds.ls(cmds.listConnections("{0}.inMesh".format(x), source=True, destination=False, connections=False, shapes=True) or [], long=True) for x in inputSurfaceConnections) for item in sublist]
			if bevelPreviewsOutMesh:
				inputObjectsWithBP = getObjectsWithBevelPreview(bevelPreviewsOutMesh)

			bevelPreviewShapes = [x["name"] for x in objectsWithBP.values() if "name" in x]
			bevelPreviews = {x: next(iter(cmds.ls(cmds.listConnections("{0}.outMesh".format(x), 
																		source=False, 
																		destination=True, 
																		connections=False, 
																		shapes=True) or [], long=True)), None) 
								for x in cmds.listRelatives(bevelPreviewShapes, fullPath=True, parent=True) or [] if x in objects}

			if bevelPreviews:
				objects = [x for x in objects if x not in bevelPreviews.keys() + inputObjectsWithBP.keys()]

				# When switching to Cage Display to Component Mode with a selected object
				forceAdd = [x for x in objectsWithBP.keys() if x in inputSurfaceConnections]
				forceRemove = list(forceAdd) + (cmds.listRelatives(forceAdd, fullPath=True, noIntermediate=True, shapes=True) or [])
				forceRemove = [x for x in forceRemove if x in inputSurfaceConnections]
		
		# Get selected objects to add, and objects no longer selected to remove
		objectsToAdd = [x for x in objects if x not in set(inputSurfaceConnections)] + forceAdd
		objectsToRemove = [x for x in inputSurfaceConnections if x not in set(objects + objectShapes + list(bevelPreviews.values()))] + forceRemove
		
		# Remove Outline on objects
		for obj in objectsToRemove:
			self.disconnectFromOutline(obj)
		
		# Add Outline on objects
		for obj in objectsToAdd:
			objShape = None

			# for bevelPreview, get intermediate object
			if obj in objectsWithBP:
				if "name" in objectsWithBP[obj]:
					bevelPreview = next(iter(cmds.listRelatives(objectsWithBP[obj]["name"], fullPath=True, parent=True) or []), None)
					if bevelPreview in bevelPreviews.keys():
						objShape = bevelPreviews[bevelPreview]
						obj = objShape

			if not objShape:
				objShape = next(iter(cmds.listRelatives(obj, fullPath=True, noIntermediate=True, shapes=True) or []), None)
			
			if objShape and cmds.attributeQuery("outMesh", node=objShape, exists=True) is True:
				attrIndex = getFreeAttributeIndex(outlineShape, "inputSurface")
				cmds.connectAttr("{0}.outMesh".format(objShape), "{0}.inputSurface[{1}].surface".format(outlineShape, attrIndex), force=True)
				# Connect the transform worldMatrix instead of shape so it also works with instances
				cmds.connectAttr("{0}.worldMatrix[0]".format(obj), "{0}.inputSurface[{1}].inputWorldMatrix".format(outlineShape, attrIndex), force=True)
		
		# Set outline and wireframe attributes
		#self.outlineShape.setAttr("displayInViewport", 1)
		self.outlineShape.setAttr("profileLines", bool(cmds.optionVar(query="PT_ShowOutline")))
		self.outlineShape.setAttr("creaseLines", bool(cmds.optionVar(query="PT_ShowWireframe")))
		
		# Check if wireframe on shaded active
		self.modelEditorCallback()
		
		# Disabling displayInViewport increase performance and still works with wireframe (cached?)
		#if not bool(cmds.optionVar(query="PT_ShowOutline")):
			#cmds.evalDeferred(partial(self.outlineShape.setAttr, "displayInViewport", 0))
		
		# If nothing is connected in outline inputs
		#self.displayOutline()
		
		# Disable outline selection
		if cmds.selectType(query=True, stroke=True):
			self.strokeSelection = True
			cmds.selectType(stroke=False)
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
	
	def disconnectFromOutline(self, node):
		outlineShape = getPyNodeName(self.outlineShape)
		connectionsList = cmds.listConnections(outlineShape+".inputSurface", connections=True, source=True, destination=True, plugs=True) or []
		
		a = iter(connectionsList)
		for c_dest, c_source in zip(a, a):
			connectedObj = c_source.split(".")[0]
			connectedObj = next(iter(cmds.ls(connectedObj, long=True)), None) # Get longname
			connectedOutline = c_dest.rsplit(".")[0]
			connectedOutline = next(iter(cmds.ls(connectedOutline, long=True)), None) # Get longname

			if all([connectedObj == node, connectedOutline == outlineShape]):
				# Disconnect .inputWorldMatrix
				try:
					cmds.disconnectAttr(c_source, c_dest)
				except Exception as e:
					pass
				# Disconnect .surface
				connectedMatrix = cmds.listConnections(c_dest.rsplit(".", 1)[0]+".surface", connections=True, source=True, destination=True, plugs=True) or []
				if len(connectedMatrix) > 1:
					try:
						cmds.disconnectAttr(connectedMatrix[1], connectedMatrix[0])
					except Exception as e:
						pass
				#break
	
	def getCurrentSel(self, shapes=False, pymel=True):
		currentSel = []
		if shapes is False:
			if pymel:
				currentSel = pm.ls(selection=True, long=True, objectsOnly=True, type="transform")
				#if self.outlineTransform in currentSel:
					#currentSel.remove(self.outlineTransform)
			else:
				currentSel = cmds.ls(selection=True, long=True, objectsOnly=True, type="transform")
				#outlineTransform = getPyNodeName(self.outlineTransform)
				#if outlineTransform in currentSel:
					#currentSel.remove(outlineTransform)
		else:
			if pymel:
				currentSel = pm.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
				#if self.outlineShape in currentSel:
					#currentSel.remove(self.outlineShape)
			else:
				currentSel = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
				#outlineShape = getPyNodeName(self.outlineShape)
				#if outlineShape in currentSel:
					#currentSel.remove(outlineShape)
		return currentSel
	
	def filterSelectionType(self, types=["transform"], ignore=[], returnSelection=False):
		# Turns undo/redo off without flushing the queue
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		
		selection = cmds.ls(selection=True, long=True)
		
		# Remove ignored objects from list
		ignore_list = list(ignore)
		# Add outlineShape to ignored objects
		#ignore_list.append(getPyNodeName(self.outlineShape))
		selection = [x for x in selection if x not in ignore_list]
		selection = list(filter(cmds.objExists, selection))
		outlineTransform = getPyNodeName(self.outlineTransform)

		filterTypes = ["mesh"]
		if cmds.objectType(tagFromType="gtBevelPreview"):
			filterTypes.append("gtBevelPreview")
		
		for obj in selection:
			# If an object of another type is found, filter selection
			if (cmds.objectType(obj) not in types) or obj == outlineTransform:
				# If shape of polymesh is selected, select his transform
				# Get selected polymesh
				
				objectShapes = cmds.ls(selection, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type=filterTypes)
				# Get selected polymesh transform
				objects = cmds.listRelatives(objectShapes, fullPath=True, parent=True, noIntermediate=True, type="transform")
				# Remove intermediate objects
				objects = cmds.ls(objects, long=True, noIntermediate=True)
				# Remove duplicates objects
				objects = list(OrderedDict.fromkeys(objects))
				
				selection = objects
				if returnSelection is False:
					# Replace selection
					cmds.select(selection, replace=True)
				
				break
		
		# Turns undo/redo back on
		if undoState:
			cmds.undoInfo(stateWithoutFlush=True)
		
		if returnSelection is True:
			return selection
	
	def selectionChange(self):
		self.filterSelectionType()
		currentSel = self.getCurrentSel()
		if len(currentSel) > 0:			
			# If selection didn't change, skip
			if set(currentSel) == set(self.lastSelectedObjects):
				return
		
		# Update Outline
		try:
			self.updateOutline(currentSel)
		except Exception as e:
			pass
		
		# Set last selected object
		self.lastSelectedObjects = list(currentSel)
		
		# Update HUD
		refreshHud("PlacementToolHUD_Selection")
	
	def nameChanged(self):
		# Update HUD
		refreshHud("PlacementToolHUD_Selection")
	
	def changeCursorOverride(self, value=None):
		if self.dragging is True:
			return
		
		QtWidgets.QApplication.restoreOverrideCursor()
		cursor = None
		
		if value == "move":
			#cursor = QtGui.QCursor(QtGui.QPixmap(":/create.png"))
			cursor = QtGui.QCursor(QtGui.QPixmap(PT_GetResource("icons/PlacementTool_Cursor_Move.png")))
		elif value == "rotate":
			cursor = QtGui.QCursor(QtGui.QPixmap(":/tumbleCursor.png"))
		elif value == "scale":
			cursor = QtGui.QCursor(QtGui.QPixmap(":/dollyCursor.png"))
		elif value == "shift":
			cursor = QtGui.QCursor(pixmapWithOffset(":/leftArrowPlus.png", padding=10, offset=QtCore.QPoint(5, 7)))
		elif value == "control":
			cursor = QtGui.QCursor(pixmapWithOffset(":/leftArrowMinus.png", padding=10, offset=QtCore.QPoint(5, 7)))
		
		if cursor is not None:
			QtWidgets.QApplication.setOverrideCursor(cursor)
	
	def toolPressFn(self):
		# Open Undo chunk
		cmds.undoInfo(openChunk=True)
		
		self.pressPosition = cmds.draggerContext(self.contextName, query=True, anchorPoint=True)
		self.draggerButton = cmds.draggerContext(self.contextName, query=True, button=True)
		self.draggerModifier = cmds.draggerContext(self.contextName, query=True, modifier=True)
		
		self.dragPosition = list(self.pressPosition)
		self.lastPressPosition = list(self.pressPosition)
		self.invertScale = False
		self.invertRotation = False
		self.rotationStep = None
		self.objtMatrix = None
		self.straightLineAngle = None
		self.objBoundingBox = None
		self.currentSelCmds = []
		self.objectMatrixDict = {}
		
		# Delete old placementLine
		self.removePlacementLine()
		
		self.lastFaceUnderCursor = None
		#self.lastObjectUnderCursor = []
		self.objectUnderCursor = None
		self.rotation = None
		self.rotationDict = {}
		
		# If no objects are selected, return
		if len(self.getCurrentSel(pymel=False)) == 0:
			return
		
		if self.draggerButton == 2:
			self.prePlacementSetup()
			
			# Set cursor override
			self.changeCursorOverride(self.PT_MainWindowFilter.placementContext)
			self.dragging = True
			
			if len(self.currentSel) > 0:
				# currentSel should not change after press...
				self.currentSelCmds = pyNodeToCmds(self.currentSel)

				# remove bevelPreview from selection
				if callable(getObjectsWithBevelPreview):
					bevelPreviewShapes = [x["name"] for x in getObjectsWithBevelPreview(self.currentSelCmds).values() if "name" in x]
					bevelPreviews = cmds.listRelatives(bevelPreviewShapes, fullPath=True, parent=True) or []
					if bevelPreviews:
						self.currentSelCmds = [x for x in self.currentSelCmds if x not in bevelPreviews]

				if not self.currentSelCmds:
					return
				
				if bool(cmds.optionVar(query="PT_RetainSpacing")):
					# Build matrixDict for parent constraint
					parentMatrix = getMMatrix(self.currentSelCmds[-1], rotatePivot=True)
					self.objectMatrixDict[self.currentSelCmds[-1]] = parentMatrix
					for obj in self.currentSelCmds[:-1]:
						# Need to "self" apply the matrix on each object to avoid flipping
						objMatrix = cmds.xform(obj, query=True, worldSpace=True, matrix=True)
						rotatePivot = cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True)
						cmds.xform(obj, matrix=objMatrix, worldSpace=True)
						cmds.xform(obj, worldSpace=True, rotatePivot=rotatePivot)
						# Add to matrixDict
						self.objectMatrixDict[obj] = getMMatrix(obj, rotatePivot=True) * parentMatrix.inverse()
				
				# Snap on press
				if self.PT_MainWindowFilter.placementContext == "move":
					self.placementFn(self.pressPosition)
				
				# Build rotationDict for rotation step
				if self.PT_MainWindowFilter.placementContext in ["move", "rotate"]:
					for obj in self.currentSelCmds:
						self.rotationDict[obj] = cmds.xform(obj, query=True, objectSpace=True, rotation=True)
	
	def toolReleaseFn(self):
		if self.draggerButton == 1:
			# If no drag operation (below tolerance)
			if distanceBetweenPoints(self.pressPosition[:2], self.dragPosition[:2]) < self.dragTolerance:				
				objectUnderCursor = objectUnderCursorFn()
				#self.lastSelectedObjects = list(self.currentSel)
				currentSel = None
				if self.PT_MainWindowFilter.placementModifier is None:
					# If no object under cursor, clear selection
					if objectUnderCursor is None:
						cmds.select(clear=True)
						currentSel = []
					# Otherwise, replace selection
					else:
						cmds.select(objectUnderCursor, replace=True)
				elif self.PT_MainWindowFilter.placementModifier == "shift":
					if objectUnderCursor in pyNodeToCmds(self.currentSel):
						cmds.select(objectUnderCursor, deselect=True)
					else:
						cmds.select(objectUnderCursor, add=True)
				elif self.PT_MainWindowFilter.placementModifier == "control":
					cmds.select(objectUnderCursor, deselect=True)
				
				if currentSel is None:
					self.currentSel = self.getCurrentSel()
				else:
					self.currentSel = []
	
		elif self.draggerButton == 2:
			self.postPlacementSetup()
			
			# Remove cursor override
			self.dragging = False
			self.changeCursorOverride(None)
			
			self.removePlacementLine()
			
			# Refresh HUD
			self.objectUnderCursor = None
			self.invalidTarget = False
		
		# Refresh HUD
		refreshHud("PlacementToolHUD_Status")
		refreshHud("PlacementToolHUD_TargetObject")
		
		# Close Undo chunk
		cmds.undoInfo(closeChunk=True)
	
	def toolDragFn(self):
		self.dragPosition = cmds.draggerContext(self.contextName, query=True, dragPoint=True)
		self.draggerButton = cmds.draggerContext(self.contextName, query=True, button=True)
		self.draggerModifier = cmds.draggerContext(self.contextName, query=True, modifier=True)
		
		if self.draggerButton == 2:
			# If object(s) are selected, snap on drag
			if len(self.currentSel) > 0:
				# Move
				if self.PT_MainWindowFilter.placementContext == "move":
					self.placementFn(self.dragPosition)
				# Rotate
				elif self.PT_MainWindowFilter.placementContext == "rotate":
					self.rotateFn(self.dragPosition)
				# Scale
				elif self.PT_MainWindowFilter.placementContext == "scale":
					self.scaleFn(self.dragPosition)
	
	def scaleFn(self, pressPosition):
		# Ignore placement if pressPosition and current cursor position are different
		if self._pressPositionOptimization and [int(pressPosition[i]) for i in range(2)] != getActiveViewportCursorPosition():
			return
		
		if self.invertScale:
			scale = -self.lastPressPosition[0] - -pressPosition[0]
		else:
			scale = self.lastPressPosition[0] - pressPosition[0]
		self.lastPressPosition = pressPosition
		
		# The more the object is scaled, the less we want to multiply his scaling
		if self.currentSelCmds:
			averageScale = sum(cmds.xform(self.currentSelCmds[-1], query=True, relative=True, objectSpace=True, scale=True)) / 3
		
		# Shift / Control modifier
		scale_multiplier = 0.1
		if self.PT_MainWindowFilter.placementModifier == "control":
			scale_multiplier /= 2
		elif self.PT_MainWindowFilter.placementModifier == "shift":
			scale_multiplier *= 2
		
		currentView = M3dView.active3dView()
		viewportSize = [float(x) for x in currentView.viewport()[2:4]]
		viewportArea = viewportSize[0] * viewportSize[1]

		bb = getScreenSpaceBoundingBox(getListLastItem(self.currentSelCmds))
		boundingBoxArea = (bb["top"] - bb["bottom"]) * (bb["right"] - bb["left"])
		screenPercentage = max(((boundingBoxArea / viewportArea) * 100), 0.001)
		
		# If mouse is going right, scale up
		if scale >= 0:
			#scale = (1 - abs((1 / abs(averageScale * scale_multiplier)) * scale))
			scale = (1 - (abs((1 / (math.sqrt(screenPercentage) * 10)) * scale) * scale_multiplier))
		# If mouse is going left, scale down
		else:
			#scale = (1 + abs((1 / abs(averageScale * scale_multiplier)) * scale))
			scale = (1 + (abs((1 / (math.sqrt(screenPercentage) * 10)) * scale) * scale_multiplier))
		
		# When scale is negative, invert scale
		if scale < 0:
			self.invertScale = not self.invertScale
		
		# Scale selection
		if bool(cmds.optionVar(query="PT_RetainSpacing")):
			objectsToScale = getListLastItem(self.currentSelCmds)
		else:
			objectsToScale = self.currentSelCmds
		
		if objectsToScale:
			cmds.scale(scale, scale, scale, objectsToScale, objectSpace=True, relative=True)
		
			# Offset matrix from last selected object
			if bool(cmds.optionVar(query="PT_RetainSpacing")):
				for obj in self.currentSelCmds[:-1]:
					offsetMatrixDict = offsetParentMatrix(objectsToScale, obj, self.objectMatrixDict[obj], position=True, scale=True)
					
					pos = offsetMatrixDict["position"]
					scale = offsetMatrixDict["scale"]

					# Apply the scale
					cmds.move(pos[0], pos[1], pos[2], obj, worldSpace=True, rotatePivotRelative=True)
					cmds.scale(scale[0], scale[1], scale[2], obj, objectSpace=True)
			
			# Refresh viewport
			cmds.refresh()
		
	def rotateFn(self, pressPosition):
		# Ignore placement if pressPosition and current cursor position are different
		if self._pressPositionOptimization and [int(pressPosition[i]) for i in range(2)] != getActiveViewportCursorPosition():
			return
		
		# Step rotation
		if bool(cmds.optionVar(query="PT_StepRotation")) and cmds.optionVar(query="PT_StepRotationValue") > 0:
			if self.rotationStep is None:
				# Reset object rotation back before step rotation
				for obj, rotation in six.iteritems(self.rotationDict):
					cmds.xform(obj, objectSpace=True, rotation=rotation)
				
				self.rotationStep = 0
				self.lastPressPosition = pressPosition
			
			rotation = 0
			stepRotationValue = cmds.optionVar(query="PT_StepRotationValue")
			
			rotationDistance = abs(-self.lastPressPosition[0] - -pressPosition[0]) * 0.5
			self.rotationStep = math.floor(rotationDistance / stepRotationValue) * stepRotationValue
			
			if self.rotationStep > 0:
				rotation = stepRotationValue
				# If mouse is going left, invert rotation
				if self.lastPressPosition[0] > pressPosition[0]:
					rotation *= -1
				
				self.lastPressPosition = pressPosition
		
		# Normal rotation
		else:
			rotation = (-self.lastPressPosition[0] - -pressPosition[0]) * 0.5
			
			self.lastPressPosition = pressPosition
		
		# Shift / Control modifier
		if self.PT_MainWindowFilter.placementModifier == "control":
			rotation /= 2
		elif self.PT_MainWindowFilter.placementModifier == "shift":
			rotation *= 2
		
		# Rotate selection
		if bool(cmds.optionVar(query="PT_RetainSpacing")):
			objectsToRotate = getListLastItem(self.currentSelCmds)
		else:
			objectsToRotate = self.currentSelCmds
		
		if objectsToRotate:
			if cmds.upAxis(query=True, axis=True) == "z":
				cmds.rotate(0, 0, rotation, objectsToRotate, objectSpace=True, relative=True, forceOrderXYZ=True)
			else:
				cmds.rotate(0, rotation, 0, objectsToRotate, objectSpace=True, relative=True, forceOrderXYZ=True)
		
			# Offset matrix from last selected object
			if bool(cmds.optionVar(query="PT_RetainSpacing")):
				for obj in self.currentSelCmds[:-1]:
					offsetMatrixDict = offsetParentMatrix(objectsToRotate, obj, self.objectMatrixDict[obj], position=True, rotation=True)
					
					pos = offsetMatrixDict["position"]
					rot = offsetMatrixDict["rotation"]
					
					cmds.move(pos[0], pos[1], pos[2], obj, worldSpace=True, rotatePivotRelative=True)
					cmds.rotate(rot[0], rot[1], rot[2], obj, objectSpace=True)
			
			# Refresh viewport
			cmds.refresh()
	
	def placementFn(self, pressPosition):		
		# Ignore placement if pressPosition and current cursor position are different
		if self._pressPositionOptimization and [int(pressPosition[i]) for i in range(2)] != getActiveViewportCursorPosition():
			return
		
		if not self.currentSelCmds:
			return
		
		# Lock translation to object plane axis
		if self.PT_MainWindowFilter.placementModifier == "shift":
			if self.objtMatrix is None:
				self.objtMatrix = om.MTransformationMatrix(getMMatrix(self.currentSelCmds[-1]))
				self.objtMatrix.setTranslation(om.MVector(cmds.xform(self.currentSelCmds[-1], query=True, worldSpace=True, rotatePivot=True)), om.MSpace.kWorld)
				self.objtMatrix.setRotatePivot(om.MPoint(cmds.xform(self.currentSelCmds[-1], query=True, worldSpace=True, rotatePivot=True)), om.MSpace.kWorld, True)
				self.objtMatrix.setRotatePivotTranslation(om.MVector(cmds.xform(self.currentSelCmds[-1], query=True, objectSpace=True, rotatePivot=True)) * -1, om.MSpace.kObject)
				
				objectList = om.MSelectionList()
				objectList.add(self.currentSelCmds[-1])
				dagPath = objectList.getDagPath(0)
				dagNode = None

				if dagPath.hasFn(om.MFn.kMesh):
					if dagPath.hasFn(om.MFn.kTransform):
						dagPath.extendToShape()
					dagNode = om.MFnDagNode(dagPath)
				
				if dagNode:
					self.objBoundingBox = dagNode.boundingBox
				else:
					self.objBoundingBox = om.MBoundingBox()
					for i in range(dagPath.childCount()):
						mObj = dagPath.child(i)
						dagNode = om.MFnDagNode(mObj)
						self.objBoundingBox.expand(dagNode.boundingBox)

				#inclusiveMatrix = dagPath.inclusiveMatrix()
				#self.objBoundingBox.transformUsing(inclusiveMatrix)
			
			# Reset object rotation back before translation lock
			if self.objtMatrix.rotation(False) != om.MTransformationMatrix(getMMatrix(self.currentSelCmds[-1])).rotation(False):
				for obj, rotation in six.iteritems(self.rotationDict):
					cmds.xform(obj, objectSpace=True, rotation=rotation)
			
			if self.objBoundingBox is None:
				return

			# Get object bounding box from initial position
			objBoundingBox = om.MBoundingBox(self.objBoundingBox)
			objBoundingBox.transformUsing(self.objtMatrix.asMatrix())
			initialPositionBbx = objBoundingBox.center

			# Ray cast screen press position to the object plane
			cursorWsPos = objectPlaneIntersect(pressPosition=pressPosition, targetObject=self.currentSelCmds[-1])
			if cursorWsPos is None:
				return
			
			# Find in which direction the object was translated
			initialPositionWs = om.MVector(self.objtMatrix.rotatePivot(om.MSpace.kWorld))
			#translateAxis, translateVector, objMatrix = vectorToAxisDirection(self.currentSelCmds[-1], initialPositionWs, cursorWsPos)
			#direction = om.MVector(vectorBetweenPoints(self.objtMatrix, cursorWsPos))
			#rotation = direction.angle(translateVector)

			# Freeze scale to return correct world space orientation
			#objMatrix = cmds.xform(self.currentSelCmds[-1], query=True, objectSpace=True, matrix=True)
			#tMatrix = om.MTransformationMatrix(om.MMatrix(objMatrix))
			tMatrix = om.MTransformationMatrix(self.objtMatrix)
			tMatrix.setScale((1, 1, 1), om.MSpace.kWorld)
			objMatrix = tMatrix.asMatrix()

			# Get angle between press position and object's tangent and position between press position and object's origin
			objectTangent = normalizeVector([objMatrix[0], objMatrix[1], objMatrix[2]])
			objectNormal = normalizeVector([objMatrix[8], objMatrix[9], objMatrix[10]])
			positionVector = vectorBetweenPoints(initialPositionWs, cursorWsPos)
			positionDistance = distanceBetweenPoints(initialPositionWs, cursorWsPos)
			angleBetweenVectors = angleBetween3DVectors(objectTangent, positionVector, objectNormal)

			# Round to nearest step rotation
			stepRotationValue = cmds.optionVar(query="PT_StepRotationValue")
			straightLineAngle = round(angleBetweenVectors / stepRotationValue) * stepRotationValue

			if not all([cmds.optionVar(exists="placementVertexSnap"), cmds.optionVar(query="placementVertexSnap"), self.straightLineAngle is not None]):
				self.straightLineAngle = float(straightLineAngle)

			# First rotate locally with the angle found and translate locally by the distance found
			tMatrix.rotateBy(om.MEulerRotation(0, 0, math.radians(self.straightLineAngle), om.MEulerRotation.kXYZ), om.MSpace.kObject)
			tMatrix.translateBy(om.MVector(positionDistance, 0, 0), om.MSpace.kObject)
			newPositionWs = tMatrix.translation(om.MSpace.kWorld)

			# Snap to closest vertex
			if all([cmds.optionVar(exists="placementVertexSnap"), cmds.optionVar(query="placementVertexSnap")]):
				
				positionVector = vectorBetweenPoints(initialPositionWs, newPositionWs)
				directionVector = crossProduct(objectNormal, positionVector)
				newPositionWs = rayCastPlaneIntersection(directionVector, initialPositionWs, directionVector, cursorWsPos)

				objectUnderCursor, faceUnderCursor = None, None
				useSurfaceNormal = bool(max(0, cmds.optionVar(q="PT_NormalVectorValue")))
				objectUnderCursor, facePosition, faceUnderCursor, targetNormal = faceUnderCursorFn(pressPosition, getSurfaceNormal=useSurfaceNormal)
				
				if objectUnderCursor is not None and faceUnderCursor is not None:
					closestVertex, closestVertexPosition = getClosestVertex(faceUnderCursor, facePosition)
					cursorPos = planePointIntersect(pressPosition=pressPosition, planePoint=facePosition, normal=targetNormal)
					maxDistance = 5
					if all([cursorPos, closestVertexPosition]):
						if distanceBetweenPoints(cursorPos, closestVertexPosition) < maxDistance:
							planeIntersectionPoint = rayCastPlaneIntersection(objectNormal, initialPositionWs, objectNormal, closestVertexPosition)

							snapPosition = rayCastPlaneIntersection(directionVector, initialPositionWs, directionVector, planeIntersectionPoint)
							if snapPosition:
								newPositionWs = snapPosition


			# Get object bounding box from new position
			objBoundingBox = om.MBoundingBox(self.objBoundingBox)
			tMatrix = om.MTransformationMatrix(self.objtMatrix)
			tMatrix.setTranslation(om.MVector(newPositionWs), om.MSpace.kWorld)
			objBoundingBox.transformUsing(tMatrix.asMatrix())
			newPositionBbx = objBoundingBox.center


			'''position = om.MVector(newPositionWs)
			tMatrix = om.MTransformationMatrix(self.objtMatrix)
			tMatrix.setTranslation(position, om.MSpace.kWorld)
			newPositionOs = tMatrix.translation(om.MSpace.kObject)
			
			initialPositionOs = self.objtMatrix.translation(om.MSpace.kObject)
			osTranslation = [initialPositionOs[0], initialPositionOs[1], initialPositionOs[2]]

			if translateAxis in ["x", "-x"]:
				osTranslation[0] = newPositionOs[0]
				#rTranslation = [newPositionOs[0] - initialPositionOs[0], 0, 0]
			elif translateAxis in ["y", "-y"] and cmds.upAxis(query=True, axis=True) == "z":
				osTranslation[1] = newPositionOs[1]
				#rTranslation = [0, newPositionOs[1] - initialPositionOs[1], 0]
			elif translateAxis in ["z", "-z"] and cmds.upAxis(query=True, axis=True) == "y":
				osTranslation[2] = newPositionOs[2]
				#rTranslation = [0, 0, newPositionOs[2] - initialPositionOs[2]]
			
			tMatrix.setTranslation(om.MVector(osTranslation), om.MSpace.kObject)
			#tMatrix.translateBy(tMatrix.rotatePivotTranslation(om.MSpace.kObject), om.MSpace.kObject)
			newPositionWs = tMatrix.translation(om.MSpace.kWorld)
			
			# Get object bounding box from new position
			objBoundingBox = om.MBoundingBox(self.objBoundingBox)
			objBoundingBox.transformUsing(tMatrix.asMatrix())
			newPositionBbx = objBoundingBox.center'''
			
			# Create Line and distance Label for feedback in viewport
			if self.placementLine is None or cmds.objExists(self.placementLine) is False:
				#self.placementLine = cmds.curve(worldSpace=True, bezier=True, degree=3, point=[initialPositionWs, initialPositionWs, initialPositionWs, initialPositionWs])
				# Need to create the curve manually so it doesn't change our active selection list
				self.placementLine = cmds.createNode("transform", name="PlacementLine1", skipSelect=True)
				placementLineShape = cmds.createNode("bezierCurve", name="PlacementLineShape1", skipSelect=True, parent=self.placementLine)
				# Set Line Color
				cmds.color(self.placementLine, rgbColor=(1, 1, 0))
				# Set Line Attributes
				cmds.setAttr(self.placementLine+".cc", 
						3, 1, 0, False, 3, 		# degree spans form isRational dimension
						(0, 0, 0, 1, 1, 1), 6, 	# (knotValue) knotCount
						4, 						# cvCount
						initialPositionBbx, 	# (cv X Y Z)
						initialPositionBbx,  	# (cv X Y Z)
						newPositionBbx,  		# (cv X Y Z)
						newPositionBbx,  		# (cv X Y Z)
						type="nurbsCurve")
				hideInOutliner(self.placementLine)
				
				# Create distance Label
				self.placementLabel = cmds.createNode("joint", skipSelect=True, parent=self.placementLine)
				cmds.setAttr(self.placementLabel+".radius", 0)
				cmds.setAttr(self.placementLabel+".type", 18)
				cmds.setAttr(self.placementLabel+".otherType", "{0}{1}".format(round(distanceBetweenPoints(initialPositionWs, newPositionWs), 3), currentUnitString()), type="string")
				cmds.setAttr(self.placementLabel+".drawLabel", True)
				hideInOutliner(self.placementLabel)
				# Set Label Color
				cmds.color(self.placementLabel, rgbColor=(100.0/255, 220.0/255, 255.0/255))
				# Set Label position
				labelPos = getMiddlePoint(initialPositionBbx, newPositionBbx)
				cmds.move(labelPos[0], labelPos[1], labelPos[2], self.placementLabel, worldSpace=True)
			else:
				for attr, value in ((".visibility", True), (".lodVisibility", True), (".overrideEnabled", False), (".overrideVisibility", True)):
					if cmds.getAttr(self.placementLine+attr) is not value:
						cmds.setAttr(self.placementLine+attr, value)
				# Set Line position
				cmds.move(initialPositionBbx[0], initialPositionBbx[1], initialPositionBbx[2], self.placementLine+".ep[0]", worldSpace=True)
				cmds.move(newPositionBbx[0], newPositionBbx[1], newPositionBbx[2], self.placementLine+".ep[1]", worldSpace=True)
				# Set Label distance
				if cmds.objExists(self.placementLabel):
					cmds.setAttr(self.placementLabel+".otherType", "{0}{1}".format(round(distanceBetweenPoints(initialPositionWs, newPositionWs), 3), currentUnitString()), type="string")
				# Set Label position
				labelPos = getMiddlePoint(initialPositionBbx, newPositionBbx)
				cmds.move(labelPos[0], labelPos[1], labelPos[2], self.placementLabel, worldSpace=True)
			
			# Move object to world space position	
			if bool(cmds.optionVar(query="PT_RetainSpacing")):
				objectsToMove = self.currentSelCmds[-1]
			else:
				objectsToMove = self.currentSelCmds
			cmds.move(newPositionWs[0], newPositionWs[1], newPositionWs[2], objectsToMove, worldSpace=True, rotatePivotRelative=True)
			
			# Offset matrix from last selected object
			if bool(cmds.optionVar(query="PT_RetainSpacing")):
				for obj in self.currentSelCmds[:-1]:
					offsetMatrixDict = offsetParentMatrix(self.currentSelCmds[-1], obj, self.objectMatrixDict[obj], position=True)
					
					pos = offsetMatrixDict["position"]
					cmds.move(pos[0], pos[1], pos[2], obj, worldSpace=True, rotatePivotRelative=True)
			
			# Refresh viewport
			self.objectUnderCursor = None
			refreshHud("PlacementToolHUD_TargetObject")
			cmds.refresh()
			return
		
		if cmds.optionVar(exists="placementVertexSnap"):
			placementVertexSnap = cmds.optionVar(query="placementVertexSnap")
			if placementVertexSnap:

				objectUnderCursor, faceUnderCursor = None, None
				useSurfaceNormal = bool(max(0, cmds.optionVar(q="PT_NormalVectorValue")))
				objectUnderCursor, facePosition, faceUnderCursor, targetNormal = faceUnderCursorFn(pressPosition, getSurfaceNormal=useSurfaceNormal)
				
				if objectUnderCursor is not None and faceUnderCursor is not None:
					closestVertex, closestVertexPosition = getClosestVertex(faceUnderCursor, facePosition)
					if closestVertexPosition:
						# Move object to world space position	
						if bool(cmds.optionVar(query="PT_RetainSpacing")):
							objectsToMove = self.currentSelCmds[-1]
						else:
							objectsToMove = self.currentSelCmds
						cmds.move(closestVertexPosition[0], closestVertexPosition[1], closestVertexPosition[2], objectsToMove, worldSpace=True, rotatePivotRelative=True)
						
						# Refresh viewport
						cmds.refresh()

				return

		self.objtMatrix = None
		self.straightLineAngle = None
		faceUnderCursor = None
		objectUnderCursor = None
		targetNormal = []
		useSurfaceNormal = bool(max(0, cmds.optionVar(q="PT_NormalVectorValue")))
		objectUnderCursor, facePosition, faceUnderCursor, targetNormal = faceUnderCursorFn(pressPosition, getSurfaceNormal=useSurfaceNormal)
		positionChanged, rotationChanged = False, False
		
		if objectUnderCursor is not None and faceUnderCursor is not None:			
			# Refresh HUD
			refreshTargetHud = False
			if self.invalidTarget is True:
				self.invalidTarget = False
				refreshTargetHud = True
			if self.objectUnderCursor != objectUnderCursor:
				self.objectUnderCursor = objectUnderCursor
				refreshTargetHud = True
			if refreshTargetHud is True:
				refreshHud("PlacementToolHUD_TargetObject")
			
			#targetMatrix = cmds.xform(objectUnderCursor, query=True, worldSpace=True, matrix=True)
			
			# Stop placement if drag position has changed
			#if pressPosition != self.dragPosition:
				#return
			
			# Modify object position
			if self.PT_MainWindowFilter.placementModifier != "shift+control":
				positionChanged = True
				offsetValue = 0
				if bool(cmds.optionVar(query="PT_SurfaceOffset")):
					offsetValue = cmds.optionVar(query="PT_SurfaceOffsetValue")
				# Add surface offset to position
				if offsetValue != 0:
					facePosition = getOffsetedObjectPosition(self.currentSelCmds[-1], facePosition, offsetValue)
				
				# Set object position
				if bool(cmds.optionVar(query="PT_RetainSpacing")):
					objectsToMove = self.currentSelCmds[-1]
				else:
					objectsToMove = self.currentSelCmds
				cmds.move(facePosition[0], facePosition[1], facePosition[2], objectsToMove, worldSpace=True, rotatePivotRelative=True)
				self.lastMovedObjects = set(self.currentSel)
				self.lastSurfaceOffset = offsetValue
			
			# If faceUnderCursor has changed, we have to calculate the new orientation
			if self.lastFaceUnderCursor != faceUnderCursor or useSurfaceNormal is True:
				self.lastFaceUnderCursor = faceUnderCursor
				orientation = []
			
			# Modify object orientation
			if len(targetNormal) > 2 and self.PT_MainWindowFilter.placementModifier != "control" and "orientation" in locals():
				rotationChanged = True
				# Default alignement
				#objectMatrix = cmds.xform(self.currentSelCmds[-1], query=True, worldSpace=True, matrix=True)
				objectMatrix = list(getMMatrix(self.currentSelCmds[-1]))
				#objectNormal = [objectMatrix[8], objectMatrix[9], objectMatrix[10]]
				# Verify that the up vector is not already the same as the target normal
				#if [round(x, 3)+0 for x in targetNormal] != [round(x, 3)+0 for x in objectNormal] or self.dragPosition == self.pressPosition:
				local_orientation = getAngleFromNormal(targetNormal, objectMatrix, False, False)
				
				if local_orientation and len(local_orientation) > 0:
					# Get object-space rotation if object is parented
					parent = cmds.listRelatives(self.currentSelCmds[-1], fullPath=True, parent=True, noIntermediate=True)
					if parent is not None:
						# Create empty MTransformationMatrix
						transform_matrix = om.MTransformationMatrix()
						
						# Rotate matrix to new orientation
						rotate_by = [math.radians(x) for x in local_orientation]
						transform_matrix.setRotation(om.MEulerRotation(rotate_by[0], rotate_by[1], rotate_by[2], om.MEulerRotation.kXYZ))
						
						# Get the matrix outside of the parent_matrix space
						parent_matrix = om.MMatrix(cmds.xform(parent[0], query=True, worldSpace=True, matrix=True))
						offset_matrix = (transform_matrix.asMatrix() * parent_matrix.inverse())
						
						# Get the rotations values of the relative matrix
						transform_matrix = om.MTransformationMatrix(offset_matrix)
						local_orientation_r = transform_matrix.rotation(False)
						local_orientation = [math.degrees(local_orientation_r[x]) for x in range(3)]
						
						# If number close to zero, round number
						for i in range(3):
							if isClose(local_orientation[i], 0, rt=0.000000001, at=0.0000000001):
								local_orientation[i] = round(local_orientation[i], 10) + 0
					
					orientation = local_orientation
					
					# Stop placement if drag position has changed
					#if pressPosition != self.dragPosition:
						#return
					
					# Calculate the rotation offset to apply after Step alignement
					if bool(cmds.optionVar(query="PT_StepAlignement")):
						#if useSurfaceNormal:
							#step_orientation = getOrientationFromFace(faceUnderCursor, normal=targetNormal)
						step_orientation = getOrientationFromFace(faceUnderCursor) or []
						
						# Get object-space rotation if object is parented
						if parent is not None:
							# Create empty MTransformationMatrix
							transform_matrix = om.MTransformationMatrix()
							
							# Rotate matrix to new orientation
							rotate_by = [math.radians(x) for x in step_orientation]
							transform_matrix.setRotation(om.MEulerRotation(rotate_by[0], rotate_by[1], rotate_by[2], om.MEulerRotation.kXYZ))
							
							# Get the matrix outside of the parent_matrix space
							offset_matrix = (transform_matrix.asMatrix() * parent_matrix.inverse())
							
							# Get the rotations values of the relative matrix
							transform_matrix = om.MTransformationMatrix(offset_matrix)
							step_orientation_r = transform_matrix.rotation(False).reorder(om.MEulerRotation.kXYZ)
							step_orientation = [math.degrees(step_orientation_r[x]) for x in range(3)]
							
							# If number close to zero, round number
							for i in range(3):
								if isClose(step_orientation[i], 0, rt=0.000000001, at=0.0000000001):
									step_orientation[i] = round(step_orientation[i], 10) + 0
						
						orientation = step_orientation
						
						# Convert degrees rotations to radians
						if "step_orientation_r" not in locals():
							step_orientation_r = [math.radians(x) for x in step_orientation]
						if "local_orientation_r" not in locals():
							local_orientation_r = [math.radians(x) for x in local_orientation]
						
						if all([len(x) >= 3 for x in [step_orientation_r, local_orientation_r]]):
							# Create MTransformationMatrix
							parent_tmatrix = om.MTransformationMatrix()
							parent_tmatrix.setRotation(om.MEulerRotation(step_orientation_r[0], step_orientation_r[1], step_orientation_r[2], om.MEulerRotation.kXYZ))
							
							child_tmatrix = om.MTransformationMatrix()
							child_tmatrix.setRotation(om.MEulerRotation(local_orientation_r[0], local_orientation_r[1], local_orientation_r[2], om.MEulerRotation.kXYZ))
							
							# Create the object matrix relative to the parent
							offset_matrix = child_tmatrix.asMatrix() * parent_tmatrix.asMatrixInverse()
							offset_tmatrix = om.MTransformationMatrix(offset_matrix)
							
							# Get the rotations values of the relative matrix
							rotations = offset_tmatrix.rotation(False)					
							rotations = [math.degrees(rotations[x]) for x in range(3)]
							
							# Step align rotation values
							stepAlignementValue = cmds.optionVar(query="PT_StepAlignementValue")
							if cmds.upAxis(query=True, axis=True) == "z":
								self.rotation = round(rotations[2] / stepAlignementValue) * stepAlignementValue
							else:
								self.rotation = round(rotations[1] / stepAlignementValue) * stepAlignementValue
								
								# Fix flipping in Y up axis, needs to find a proper solution eventually
								r = [(round(x / stepAlignementValue) * stepAlignementValue) == 180 for x in rotations[:3:2]]
								if any(r):
									y = (round(self.rotation / 90) * 90) or -90
									self.rotation = ((self.rotation * -1) + y) + y
					
					# Stop placement if drag position has changed
					#if pressPosition != self.dragPosition:
						#return
					
					# Round orientation
					orientation = [round(x, 4) + 0 for x in orientation]

					# Set object orientation
					if len(orientation) >= 3:
						cmds.rotate(orientation[0], orientation[1], orientation[2], self.currentSelCmds[-1], objectSpace=True)
					
					# Set object rotation offset
					if bool(cmds.optionVar(query="PT_StepAlignement")):
						if self.rotation and self.rotation != 0:
							if cmds.upAxis(query=True, axis=True) == "z":
								cmds.rotate(0, 0, self.rotation, self.currentSelCmds[-1], objectSpace=True, relative=True, forceOrderXYZ=True)
							else:
								cmds.rotate(0, self.rotation, 0, self.currentSelCmds[-1], objectSpace=True, relative=True, forceOrderXYZ=True)
					
					if not bool(cmds.optionVar(query="PT_RetainSpacing")):
						# Match rotation on all selected objects
						if len(self.currentSelCmds) > 1:
							cmds.matchTransform(self.currentSelCmds[:-1], self.currentSelCmds[-1], rotation=True)
							'''
							if bool(cmds.optionVar(query="PT_StepAlignement")):
								# Fix match rotation with negative scale
								matchScaleZ = cmds.xform(self.currentSelCmds[-1], query=True, worldSpace=True, scale=True)[2]
								for obj in self.currentSelCmds[:-1]:
									wsScaleZ = cmds.xform(obj, query=True, worldSpace=True, scale=True)[2]
									if math.copysign(1, matchScaleZ) != math.copysign(1, wsScaleZ):
										cmds.rotate(180, 0, 0, obj, objectSpace=True, relative=True, forceOrderXYZ=True)
							'''
					
					# Fix negative scale rotation
					if bool(cmds.optionVar(query="PT_RetainSpacing")):
						objectsToRotate = [self.currentSelCmds[-1]]
					else:
						objectsToRotate = self.currentSelCmds
					for obj in objectsToRotate:
						currentSelScale = cmds.xform(obj, query=True, objectSpace=True, scale=True, relative=True)
						if cmds.xform(obj, query=True, worldSpace=True, scale=True, absolute=True)[2] < 0:
							cmds.rotate(180, 0, 0, obj, objectSpace=True, relative=True, forceOrderXYZ=True)
						if currentSelScale[0] < 0:
							if cmds.upAxis(query=True, axis=True) == "z":
								cmds.rotate(0, 180, 0, obj, objectSpace=True, relative=True, forceOrderXYZ=True)
							else:
								cmds.rotate(0, 0, 180, obj, objectSpace=True, relative=True, forceOrderXYZ=True)
						if currentSelScale[1] < 0:
							cmds.rotate(180, 0, 0, obj, objectSpace=True, relative=True, forceOrderXYZ=True)
			
			# Offset matrix from last selected object
			if bool(cmds.optionVar(query="PT_RetainSpacing")):
				for obj in self.currentSelCmds[:-1]:
					offsetMatrixDict = offsetParentMatrix(self.currentSelCmds[-1], obj, self.objectMatrixDict[obj], position=positionChanged, rotation=rotationChanged)
					
					if positionChanged:
						pos = offsetMatrixDict["position"]
						cmds.move(pos[0], pos[1], pos[2], obj, worldSpace=True, rotatePivotRelative=True)
					
					if rotationChanged:						
						rot = offsetMatrixDict["rotation"]
						cmds.rotate(rot[0], rot[1], rot[2], obj, objectSpace=True)
			
			# Refresh viewport
			cmds.refresh()
		else:
			self.invalidTarget = True
			refreshHud("PlacementToolHUD_TargetObject")
			cmds.refresh()
	
	def deleteHud(self):
		if cmds.headsUpDisplay("PlacementToolHUD", query=True, exists=True) is True:
			cmds.headsUpDisplay("PlacementToolHUD", remove=True)
		if cmds.headsUpDisplay("PlacementToolHUD_Status", query=True, exists=True) is True:
			cmds.headsUpDisplay("PlacementToolHUD_Status", remove=True)
		if cmds.headsUpDisplay("PlacementToolHUD_Selection", query=True, exists=True) is True:
			cmds.headsUpDisplay("PlacementToolHUD_Selection", remove=True)
		if cmds.headsUpDisplay("PlacementToolHUD_TargetObject", query=True, exists=True) is True:
			cmds.headsUpDisplay("PlacementToolHUD_TargetObject", remove=True)
	
	def createHud(self):
		self.deleteHud()
		if bool(cmds.optionVar(query="PT_ShowHUD")):
			section = 0
			#block = cmds.headsUpDisplay(nextFreeBlock=section)+1
			block = findFreeBlocks(section, cmds.headsUpDisplay(nextFreeBlock=section), 4)
			# Title
			cmds.headsUpDisplay("PlacementToolHUD", 
				section = section, 
				block = block, 
				blockSize = "small", 
				padding = 15, 
				label = "Placement Tool", 
				labelFontSize = "small")
			# Status
			cmds.headsUpDisplay("PlacementToolHUD_Status", 
				section = section, 
				block = block + 1, 
				blockAlignment = "left", 
				labelWidth = 60, 
				blockSize = "small", 
				padding = 15, 
				label = "Status:", 
				labelFontSize = "small", 
				attachToRefresh = True, 
				command = partial(self.hudGetPlacementStatus))
			# Selection
			cmds.headsUpDisplay("PlacementToolHUD_Selection", 
				section = section, 
				block = block + 2, 
				blockAlignment = "left", 
				labelWidth = 60, 
				blockSize = "small", 
				padding = 15, 
				label = "Selection:", 
				labelFontSize = "small", 
				event = "quitApplication",  
				command = partial(self.hudGetSelectedObject))
			# Target
			cmds.headsUpDisplay("PlacementToolHUD_TargetObject", 
				section = section, 
				block = block + 3, 
				blockAlignment = "left", 
				labelWidth = 60, 
				blockSize = "small", 
				padding = 15, 
				label = "Target:", 
				labelFontSize = "small", 
				event = "quitApplication", 
				command = partial(self.hudGetTargetObject))
	
	def hudGetPlacementStatus(self):
		status = "Select an object"
		if self.currentSel is not None and len(self.currentSel) > 0:
			status = "Ready"
			# Move
			if self.PT_MainWindowFilter.placementContext == "move":
				if self.PT_MainWindowFilter.placementModifier == "shift":
					status = "Move [straight line] (Shift)"
				elif self.PT_MainWindowFilter.placementModifier == "control":
					status = "Move [position only] (Ctrl)"
				elif self.PT_MainWindowFilter.placementModifier == "shift+control":
					status = "Orient to normal (Shift+Ctrl)"
				elif cmds.optionVar(exists="placementVertexSnap") and bool(cmds.optionVar(query="placementVertexSnap")):
					status = "Move [vertex snap] (V)"
				elif bool(cmds.optionVar(query="PT_StepAlignement")):
					status = "Move [step aligned: {0}]".format(cmds.optionVar(query="PT_StepAlignementValue"))
				else:
					status = "Move"
			# Rotate
			elif self.PT_MainWindowFilter.placementContext == "rotate":
				if bool(cmds.optionVar(query="PT_StepRotation")):
					status = "Rotate [step: {0}]".format(cmds.optionVar(query="PT_StepRotationValue"))
				else:
					status = "Rotate"
				
				if self.PT_MainWindowFilter.placementModifier == "shift":
					if bool(cmds.optionVar(query="PT_StepRotation")):
						status = "Rotate [step: {0}] ".format(cmds.optionVar(query="PT_StepRotationValue")*2)
					status += " (Shift)"
				elif self.PT_MainWindowFilter.placementModifier == "control":
					if bool(cmds.optionVar(query="PT_StepRotation")):
						status = "Rotate [step: {0}] ".format(cmds.optionVar(query="PT_StepRotationValue")/2)
					status += " (Ctrl)"
			# Scale
			elif self.PT_MainWindowFilter.placementContext == "scale":
				status = "Scale"
				
				if self.PT_MainWindowFilter.placementModifier == "shift":
					status += " (Shift)"
				elif self.PT_MainWindowFilter.placementModifier == "control":
					status += " (Ctrl)"
		
		return status
	
	def hudGetSelectedObject(self):
		selection = self.filterSelectionType(returnSelection=True)
		#selection = self.getCurrentSel()
		if selection is not None and len(selection) > 0:
			return getShortName(getPyNodeName(selection[-1]))
		return "(none)"
	
	def hudGetTargetObject(self):
		if self.invalidTarget is True:
			return "(Invalid target)"
		if self.objectUnderCursor is not None and len(self.objectUnderCursor) > 0:
			return getShortName(self.objectUnderCursor)
		return "(none)"	

class PT_EventFilter(QtCore.QObject):
	keyCallbackSignal = QtCore.Signal(object)
	modelEditorCallback = QtCore.Signal()
	
	def __init__(self):
		super(PT_EventFilter, self).__init__()
		
		# Create non-existing optionVar
		if cmds.optionVar(exists="placementContext") is False:
			cmds.optionVar(stringValue=("placementContext", "move"))
		cmds.optionVar(intValue=("placementVertexSnap", 0))
		self.placementContext = cmds.optionVar(query="placementContext")
		self.setPlacementModifier(None)
		
		#ROOT_DIR = os.path.abspath(os.curdir)
		#ROOT_DIR = os.path.dirname(os.path.realpath(__file__))
		ui_file_name = os.path.join(ROOT_DIR_RAW, r"MarkingMenu_ui.ui")

		# Create PieMenu
		if os.path.isfile(ui_file_name):
			self.pieMenu = QPieMenu(ui_file=ui_file_name)
		else:
			self.pieMenu = QPieMenu(ui_widget=Ui_CentralWidget())
		
		# Install EventFilter
		self.viewportFilterDict = defaultdict(dict)
		self.mainWindow = wrapInstance(long(MQtUtil.mainWindow()), QtWidgets.QWidget)
		#self.appInstance = QtWidgets.QApplication.instance()
		self.mayaAppState = None
		self.installPlacementEventFilter(init=True)
		
		# Create ScriptJob
		self.PT_ModelEditorScriptJob = cmds.scriptJob(event=("modelEditorChanged", partial(self.installPlacementEventFilter)), protected=True)
	
	#def __del__(self):
		#self.deleteLater()
	
	def setPlacementContext(self, key):
		value = "move"
		
		if key == QtCore.Qt.Key_W:
			value = "move"
		elif key == QtCore.Qt.Key_E:
			value = "rotate"
		elif key == QtCore.Qt.Key_R:
			value = "scale"
		
		self.placementContext = value
		cmds.optionVar(stringValue=("placementContext", value))
		self.keyCallbackSignal.emit(key)
	
	def setPlacementVertexSnap(self, value):
		cmds.optionVar(intValue=("placementVertexSnap", int(value)))
		refreshHud("PlacementToolHUD_TargetObject")

	def togglePlacementStep(self, key):
		if self.placementContext == "move":
			self.pieMenu._window.PT_StepAlignement.toggleActivated()
		elif self.placementContext == "rotate":
			self.pieMenu._window.PT_StepRotation.toggleActivated()
		self.keyCallbackSignal.emit(key)
	
	def setPlacementModifier(self, modifiers):
		value = None
		
		if not modifiers:
			value = None
		elif modifiers == QtCore.Qt.ShiftModifier:
			value = "shift"
		elif modifiers == QtCore.Qt.ControlModifier:
			value = "control"
		elif modifiers == (QtCore.Qt.ShiftModifier | QtCore.Qt.ControlModifier):
			value = "shift+control"
		
		self.placementModifier = value
		self.keyCallbackSignal.emit(modifiers)
		
	def installPlacementEventFilter(self, init=False):
		if init is False:
			self.modelEditorCallback.emit()
		
		# Viewport EventFilter
		viewNum = M3dView.numberOf3dViews()
		for i in range(viewNum):
			view = M3dView.get3dView(i)
			if str(view.widget()) not in self.viewportFilterDict:
				widget_instance = wrapInstance(long(view.widget()), QtWidgets.QWidget)
				widget_instance.setObjectName(str(view.widget()))
				widget_instance.installEventFilter(self)			
				self.viewportFilterDict[str(view.widget())]["widget"] = widget_instance
				#self.viewportFilterDict[str(view.widget())]["cursor"] = widget_instance.cursor()
		
		# MainWindow EventFilter
		self.mainWindow.installEventFilter(self)
		
		# Application EventFilter
		#self.appInstance.installEventFilter(self)
		self.mayaAppState = MayaAppState()
		self.mayaAppState.addSignal(self.appStateChange)
		self.mayaAppState.start()
		
		# PieMenu EventFilter
		self.pieMenu.installEventFilter(self)
	
	def removePlacementEventFilter(self, skipPieMenu=False):		
		# Viewport EventFilter
		for viewportDict in self.viewportFilterDict.values():
			viewportDict["widget"].removeEventFilter(self)
		self.viewportFilterDict = defaultdict(dict)
		
		# MainWindow EventFilter
		self.mainWindow.removeEventFilter(self)
		
		# Application EventFilter
		#self.appInstance.removeEventFilter(self)
		if isinstance(self.mayaAppState, MayaAppState):
			self.mayaAppState.stop()
		
		if not skipPieMenu:
			# PieMenu EventFilter
			self.pieMenu.removeEventFilter(self)
			
			# Hide PieMenu
			self.pieMenu.setVisibility(False)
	
		# Kill ScriptJob
		if cmds.scriptJob(exists=self.PT_ModelEditorScriptJob) is True:
			cmds.scriptJob(kill=self.PT_ModelEditorScriptJob, force=True)
	
	def appStateChange(self, state):
		if state != QtCore.Qt.ApplicationState.ApplicationActive:
			# Hide PieMenu
			self.pieMenu.setVisibility(False)
			# Remove modifiers
			cmds.evalDeferred(partial(self.setPlacementModifier, None))

	def eventFilter(self, source, event):
		# Viewport EventFilter
		if isinstance(source, QtWidgets.QWidget) and source.objectName() in self.viewportFilterDict:
			if event.type() in [QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseButtonRelease]:
				# Right Click
				if (event.button() == QtCore.Qt.RightButton):
					if event.modifiers() & QtCore.Qt.ALT:
						return False
					return True
		
		# MainWindow & PieMenu EventFilter
		elif isinstance(source, QtWidgets.QWidget) and (source.objectName() == "MayaWindow" or source is self.pieMenu):
			if not isValid(self.pieMenu):
				self.removePlacementEventFilter(skipPieMenu=True)
				return False

			if event.type() == QtCore.QEvent.HoverMove:
				if self.pieMenu.isVisible():
					self.pieMenu._window.RadialRing.update()
			
			elif event.type() == QtCore.QEvent.KeyPress:
				if event.isAutoRepeat():
					return False
				
				# Modifiers
				self.setPlacementModifier(event.modifiers())
				
				# ESC
				if event.key() == QtCore.Qt.Key_Escape:
					if source is self.pieMenu or self.pieMenu.isVisible():
						self.pieMenu.setVisibility(False)
						return False
					cmds.setToolTo("selectSuperContext")
					return True
				# D
				elif event.key() == QtCore.Qt.Key_D:
					if event.modifiers():
						return False
					self.keyCallbackSignal.emit(event.key())
					return True
				# W
				elif event.key() in [QtCore.Qt.Key_W, QtCore.Qt.Key_E, QtCore.Qt.Key_R]:
					if event.modifiers():
						return False
					self.setPlacementContext(event.key())
					return True
				# J
				elif event.key() == QtCore.Qt.Key_J:
					if event.modifiers():
						return False
					self.togglePlacementStep(event.key())
					return True
				# O
				elif event.key() == QtCore.Qt.Key_O:
					if event.modifiers():
						return False
					self.pieMenu._window.PT_SurfaceOffset.toggleActivated()
					self.keyCallbackSignal.emit(event.key())
					return True
				# S
				elif event.key() == QtCore.Qt.Key_S:
					if event.modifiers():
						return False
					self.pieMenu._window.PT_RetainSpacing.toggleActivated()
					self.keyCallbackSignal.emit(event.key())
					return True
				# V
				elif event.key() == QtCore.Qt.Key_V:
					#if event.modifiers():
						#return False
					#self.keyCallbackSignal.emit(event.key())
					self.setPlacementVertexSnap(True)
					return True
				# T
				elif event.key() == QtCore.Qt.Key_T:
					if event.modifiers():
						return False
					# Check that viewport or pieMenu is under cursor
					panel = cmds.getPanel(underPointer=True)
					widgetWindow = QtWidgets.QApplication.widgetAt(QtGui.QCursor.pos())
					if widgetWindow:
						widgetWindow = widgetWindow.window()
					if self.pieMenu not in [source, widgetWindow]:
						if panel not in cmds.getPanel(type="modelPanel") or cmds.modelEditor(panel, query=True, exists=True) is False:
							return True
					self.pieMenu.toggleVisibility()
					return True
			
			elif event.type() == QtCore.QEvent.KeyRelease:
				if event.isAutoRepeat():
					return False

				# Modifiers
				self.setPlacementModifier(event.modifiers())

				if event.key() == QtCore.Qt.Key_V:
					#if event.modifiers():
						#return False
					#self.keyCallbackSignal.emit(event.key())
					self.setPlacementVertexSnap(False)
					return True
		
		# Application EventFilter
		#elif isinstance(source, QtWidgets.QApplication) and source is self.appInstance:
			#if event.type() == QtCore.QEvent.ApplicationStateChange:
				# Hide PieMenu
				#self.pieMenu.setVisibility(False)
		
		return False

class MayaNode(object):
	def __init__(self, node_name):
		selection = om.MSelectionList()
		self._mobject = om.MObject()
		self._node = om.MFnDependencyNode()
		self._uuid = None
		self._mdagpath = om.MDagPath()
		try:
			selection.add(node_name)
			self._mobject = selection.getDependNode(0)
			self._node = om.MFnDependencyNode(self._mobject)
			self._uuid = self._node.uuid()
			self._mdagpath = selection.getDagPath(0)
		except:
			pass
	
	def __repr__(self):
		return '<{0}("{1}") object at {2}>'.format(self.__class__.__name__, self.name(), hex(id(self)))
	
	def objExists(self, objName):
		try:
			selection = om.MSelectionList()
			selection.add(objName)
			if om.MFnDependencyNode(selection.getDependNode(0)).uuid() == self._uuid:
				return True
		except RuntimeError:
			pass
		return False
	
	def name(self, long=False):
		nodeName = None
		
		if not self._mobject.isNull():
			if self._mdagpath.isValid():
				if long:
					nodeName = self._mdagpath.fullPathName()
				else:
					nodeName = self._mdagpath.partialPathName()
			else:
				nodeName = self._node.name()
		
		if nodeName and not self.objExists(nodeName):
			nodeName = None
		
		return nodeName

class CreatePrimitiveLive(object):
	ctxExists = False
	toolExitScriptJob = None
	
	@staticmethod
	def exists(value=False):
		CreatePrimitiveLive.ctxExists = value
	
	def __init__(self, toolContext="CreatePolyCubeCtx"):
		super(CreatePrimitiveLive, self).__init__()

		# Create non-existing optionVar
		CreatePrimitive_Options(showWindow=False).saveSettings(0)
		
		if not bool(cmds.optionVar(query="PT_CP_EnableCreatePrimitiveLive")[0]):
			cmds.setToolTo(toolContext)
			return
		
		self.toolContext = toolContext
		self.createdNode = ""
		self.contextName = "createPrimitiveLiveContext"
		self.ctxReady = False
		
		# Change tool temporarily
		if cmds.contextInfo("selectSuperContext", exists=True) is True:
			cmds.setToolTo("selectSuperContext")
		
		# Init in another thread
		createPrimitiveThread = Thread(target=self.createPrimitiveThread)
		createPrimitiveThread.daemon = True
		createPrimitiveThread.start()
	
	def createPrimitiveThread(self):
		startTime = time.time()
		while True:
			if time.time() - startTime > 3:
				return
			if self.__class__.toolExitScriptJob is None:
				self.__class__.exists(True)
				break
			else:
				if self.__class__.ctxExists is False:
					self.__class__.exists(True)
					break
			time.sleep(0.02)
		executeInMainThreadWithResult(self.createDraggerContext)
		executeInMainThreadWithResult(self.initCtx)
	
	def setNonSacredToolThread(self):
		time.sleep(0.5)
		while True:
			if mel.eval('$gNonSacredTool = $gNonSacredTool;') != self.contextName:
				mel.eval('$gNonSacredTool = "{0}";'.format(self.contextName))
				break
			else:
				break
			#time.sleep(0.02)
	
	def findCreatedNode(self, createType, existingNodes):
		startTime = time.time()
		time.sleep(0.5)
		while True:
			nodes = executeInMainThreadWithResult(cmds.ls, long=True, type=createType)
			if nodes:
				node = next(iter([x for x in nodes if x not in set(existingNodes)]), None)
				if node:
					self.createdNode = node
					break
			if time.time() - startTime > 3:
				self.createdNode = ""
				break
			time.sleep(0.02)
	
	def resetSceneOrientation(self, node):
		if self.objectUnderCursor is not None and self.improvedOrientation:
			# Turns undo/redo off without flushing the queue
			undoState = cmds.undoInfo(query=True, state=True)
			if undoState:
				cmds.undoInfo(stateWithoutFlush=False)
			
			currentSel = cmds.ls(selection=True, long=True)
			# reset assemblies orientation
			sceneAssemblies = cmds.ls(long=True, assemblies=True)
			for obj in sceneAssemblies:
				orientFromTransform(obj, self.createPosition, self.createRotation)
			
			# reset polyBase nodes state
			for n, v_dict in six.iteritems(self.polyBaseNodesDict):
				if cmds.objExists(n):
					for attr, v in six.iteritems(v_dict):
						cmds.setAttr(n+attr, v)
						#cmds.evalDeferred(partial(setAttrUndoable, n+attr, v), lowestPriority=False)
			if self.polyBaseNodesDict:
				safeDgdirty(self.polyBaseNodesDict.keys(), clean=True)
				#cmds.evalDeferred(partial(safeDgdirty, self.polyBaseNodesDict.keys(), clean=True), lowestPriority=False)
				#cmds.evalDeferred(partial(safeDgdirty, self.polyBaseNodesDict.keys()), lowestPriority=False)

			# reset dynamicBevel nodes state
			for n, v_dict in six.iteritems(self.dynamicBevelsNodesDict):
				if cmds.objExists(n):
					for attr, v in six.iteritems(v_dict):
						cmds.setAttr(n+attr, v)
						#cmds.evalDeferred(partial(cmds.setAttr, n+attr, v), lowestPriority=False)
						#cmds.evalDeferred(partial(setAttrUndoable, n+attr, v), lowestPriority=False)
			if self.dynamicBevelsNodesDict:
				safeDgdirty(self.dynamicBevelsNodesDict.keys(), clean=True)
				#cmds.evalDeferred(partial(safeDgdirty, self.dynamicBevelsNodesDict.keys(), clean=True), lowestPriority=False)
				#cmds.evalDeferred(partial(safeDgdirty, self.dynamicBevelsNodesDict.keys()), lowestPriority=False)

			self.setCurrentState(False)

			# un-parent/re-parent camera
			if isinstance(self.currentCamera, MayaNode) and self.currentCamera.name() and cmds.listRelatives(self.currentCamera.name(), fullPath=True, parent=True):
				if self.currentCameraParent and cmds.objExists(self.currentCameraParent):
					cmds.parent(self.currentCamera.name(), self.currentCameraParent)
				else:
					cmds.parent(self.currentCamera.name(), world=True)
			# delete grip transform
			if self.defaultGrid.name():
				cmds.delete(self.defaultGrid.name())
			# fix camera outliner position
			if isinstance(self.currentCamera, MayaNode) and self.currentCamera.name():
				outlinerList = getOutlinerList(self.currentCamera.name())
				if self.currentCamera.name(long=True) in outlinerList:
					reorderPosition = self.currentCameraOutlinerPos - outlinerList.index(self.currentCamera.name(long=True))
					cmds.reorder(self.currentCamera.name(), relative=reorderPosition)
			cmds.select(currentSel)

			# Turns undo/redo back on
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)

			# Fix object position for redo operation
			if cmds.objExists(node or ""):
				translation = cmds.xform(node, query=True, translation=True)
				rotation = cmds.xform(node, query=True, rotation=True)
				cmds.xform(node, translation=translation, rotation=rotation)
	
	def initCtx(self):
		# Create default variables
		self.draggerButton = 1
		self.draggerModifier = "none"
		self.cameraBasedSelection = cmds.selectPref(query=True, useDepth=True)
		self.abortCmd = getRuntimeCommandInfo("AbortCurrentTool")
		self.objectUnderCursor = None
		self.createPosition = []
		self.createRotation = []
		self.pressPosition = QtCore.QPoint(0, 0)
		self.currentSceneObjects = []
		self.currentLiveObjects = []
		self.currentLiveShapes = []
		self.isolatedObjects = None
		self.visibleObjects = None
		self._overrideDict = {}
		self.currentCamera = None
		self.currentCameraOutlinerPos = 0
		self.currentCameraParent = None
		self.defaultGrid = None
		self.polyBaseNodesDict = {}
		self.dynamicBevelsNodesDict = {}
		self.createdNodeTransform = None
		self.wireframeOnShadedPanels = {}
		self.activeModelPanel = self.getActiveModelPanel()
		self.isolateAutoAdd = isolateSelectAutoAdd(self.activeModelPanel)
		self.wireframeOnShadedPref = cmds.displayPref(query=True, wireframeOnShadedActive=True)
		self.wireframeOnShadedViewport = False
		self.resetWireframeOnShaded = False
		self.modelEditorScriptJob = None
		self.previousCtx = mel.eval("$gCurrentSacredTool = $gCurrentSacredTool")
		self.currentSel = cmds.ls(selection=True, long=True)
		self.tweakMode = False
		if cmds.optionVar(exists="trsManipsTweakMode") is True:
			self.tweakMode = bool(cmds.optionVar(query="trsManipsTweakMode"))
		# Get display color preferences
		self.polyMeshColorId = getDisplayColor("polymesh", 21, dormant=True)
		self.makeLiveColorId = getDisplayColor("live", 23, dormant=True)
		self.overrideColor, self.objectUnderCursor_OC = False, False
		self.overrideColorId, self.objectUnderCursor_OCid = 0, 0
		# Tool settings
		self.displayWireframe = True
		self.addToIsolateSet = True
		if cmds.optionVar(exists="PT_CP_EnableWireframeOnShaded") is True:
			self.displayWireframe = bool(cmds.optionVar(query="PT_CP_EnableWireframeOnShaded")[0])
		if cmds.optionVar(exists="PT_CP_AddToIsolateSet") is True:
			self.addToIsolateSet = bool(cmds.optionVar(query="PT_CP_AddToIsolateSet")[0])
		# Randomly crashes on Maya 2016
		if cmds.optionVar(exists="PT_CP_ImprovedOrientation") is True:
			self.improvedOrientation = bool(cmds.optionVar(query="PT_CP_ImprovedOrientation")[0])
		if MAYA_VERSION < 2018:
			self.improvedOrientation = False
		# Ready
		self.ctxReady = True
	
	def createDraggerContext(self):
		# Create dragger context
		if cmds.draggerContext(self.contextName, exists=True) is True:
			cmds.deleteUI(self.contextName)
		cmds.draggerContext(self.contextName, pressCommand=partial(self.createPrimitiveLive), cursor="crossHair", projection="s")
		cmds.setToolTo(self.contextName)
	
	def deleteDraggerContext(self):
		if cmds.draggerContext(self.contextName, exists=True) is True:
			cmds.deleteUI(self.contextName)
	
	def saveWireframeOnShadedPref(self):
		for panel in six.iterkeys(self.wireframeOnShadedPanels):
			if cmds.modelEditor(panel, query=True, exists=True) is True:
				self.wireframeOnShadedPanels[panel] = cmds.modelEditor(panel, query=True, wireframeOnShaded=True)
				
				if self.wireframeOnShadedPanels[panel] is True:
					if self.resetWireframeOnShaded is False:
						cmds.displayPref(wireframeOnShadedActive=self.wireframeOnShadedPref)
						self.resetWireframeOnShaded = True
	
	def resetWireframeOnShadedPref(self):
		for panel, value in six.iteritems(self.wireframeOnShadedPanels):		
			if cmds.modelEditor(panel, query=True, exists=True) is True:
				cmds.modelEditor(panel, edit=True, wireframeOnShaded=value)
	
	def getActiveModelPanel(self):
		activeModelPanel = cmds.getPanel(withFocus=True)
		modelPanels = cmds.getPanel(type="modelPanel")
		if activeModelPanel not in modelPanels or not cmds.modelPanel(activeModelPanel, query=True, exists=True):
			activeModelPanel = "modelPanel4"
		
		return activeModelPanel
	
	def isolatedObjectsHide(self):
		self.isolatedObjects = None
		self.currentSceneObjects = cmds.ls(long=True, type="transform")
		
		self.activeModelPanel = self.getActiveModelPanel()

		if not self.displayWireframe:
			for panel in cmds.getPanel(type="modelPanel"):		
				if cmds.modelEditor(panel, query=True, exists=True) is True:
					self.wireframeOnShadedPanels[panel] = cmds.modelEditor(panel, query=True, wireframeOnShaded=True)
		
		if cmds.modelEditor(self.activeModelPanel, query=True, exists=True) is True:
			if not self.displayWireframe:
				# If wireframe on shaded is not active, disable wireframeOnShaded preference setting temporarily
				self.wireframeOnShadedViewport = cmds.modelEditor(self.activeModelPanel, query=True, wireframeOnShaded=True)
				if self.wireframeOnShadedViewport is False:
					self.wireframeOnShadedPref = cmds.displayPref(query=True, wireframeOnShadedActive=True)
					cmds.displayPref(wireframeOnShadedActive="none")
					for panel, value in six.iteritems(self.wireframeOnShadedPanels):
						if value is False:
							if cmds.modelEditor(panel, query=True, wireframeOnShaded=True) is False:
								cmds.modelEditor(panel, edit=True, wireframeOnShaded=True)
								cmds.evalDeferred("import maya.cmds as cmds;cmds.modelEditor('{0}', edit=True, wireframeOnShaded=False)".format(panel))
								#cmds.evalDeferred("{0}".format(self.resetWireframeOnShadedPref()))
			'''else:
				self.wireframeOnShadedViewport = cmds.modelEditor(self.activeModelPanel, query=True, wireframeOnShaded=True)
				if not self.wireframeOnShadedViewport:
					cmds.modelEditor(self.activeModelPanel, edit=True, wireframeOnShaded=True)
					cmds.refresh(currentView=True)
					print ("enable WireframeOnShaded")'''
			
			if self.addToIsolateSet:
				if cmds.isolateSelect(self.activeModelPanel, query=True, state=True) is True:
					if cmds.isolateSelect(self.activeModelPanel, query=True, viewObjects=True) != "":
						self.isolatedObjects = cmds.ls(cmds.sets(cmds.isolateSelect(self.activeModelPanel, query=True, viewObjects=True), query=True), long=True)
					else:
						self.isolatedObjects = []
					if self.isolatedObjects is not None:
						# Hide objects not part of isolate set
						self.visibleObjects = getVisibleObjects()
						if self.visibleObjects is not None:
							# Get all parents of children's and childrens of parent's
							allObjectParents = []
							for object in self.isolatedObjects:
								objectParents = object.split("|")[1:-1]
								objectParents = ["|"+"|".join(objectParents[:i]) for i in range(1, 1 + len(objectParents))]
								allObjectParents.extend(objectParents)
							removeObjects = cmds.listRelatives(self.isolatedObjects, fullPath=True, allDescendents=True, noIntermediate=True)
							if removeObjects is None:
								removeObjects = []
							removeObjects.extend(allObjectParents)
							removeObjects.extend(self.isolatedObjects)
							# Remove them from list so they are kept visible
							self.visibleObjects = list(set(self.visibleObjects).difference(set(removeObjects)))
							self._overrideDict = {}
							for objectName in self.visibleObjects:
								# Use shape for drawing override because layers have priority on objects
								objectShape = cmds.listRelatives(objectName, fullPath=True, noIntermediate=True, shapes=True)
								if objectShape is not None:
									objectName = objectShape[0]
								if cmds.attributeQuery("overrideEnabled", node=objectName, exists=True) is True:
									try:
										self._overrideDict[objectName] = {".overrideEnabled": cmds.getAttr(objectName+".overrideEnabled"), ".overrideVisibility": cmds.getAttr(objectName+".overrideVisibility")}
										cmds.setAttr(objectName+".overrideEnabled", True)
										cmds.setAttr(objectName+".overrideVisibility", False)
									except Exception as e:
										pass
						
						# Disable isolate mode
						cmds.isolateSelect(self.activeModelPanel, state=False)
		
		# Create wireframeOnShaded scriptJob
		if not self.displayWireframe:
			self.modelEditorScriptJob = cmds.scriptJob(event=("modelEditorChanged", partial(self.saveWireframeOnShadedPref)), parent="MayaWindow")
	
	def isolatedObjectsShow(self):
		if self.addToIsolateSet:
			if self.isolatedObjects is not None:
				# Add objects to isolate set
				self.isolatedObjects.extend(list(set(cmds.ls(long=True, type="transform")).difference(self.currentSceneObjects)))
				
				# Set visibility back
				visibleObjects = list(filter(cmds.objExists, self.visibleObjects or []))
				if visibleObjects:
					for objectName in visibleObjects:
						# Use shape for drawing override because layers have priority on objects
						objectShape = cmds.listRelatives(objectName, fullPath=True, noIntermediate=True, shapes=True)
						if objectShape:
							objectName = objectShape[0]
						if objectName in self._overrideDict:
							for key, value in six.iteritems(self._overrideDict[objectName]):
								try:
									cmds.setAttr(objectName+key, value)
								except Exception as e:
									pass
				# Activate isolate selection
				cmds.isolateSelect(self.activeModelPanel, state=True)
				isolatedObjects = list(filter(cmds.objExists, self.isolatedObjects or []))
				if isolatedObjects:
					# Add first object to make sure the isolate set exists
					cmds.isolateSelect(self.activeModelPanel, addDagObject=isolatedObjects[0])
					# Add all the other objects in the set if any
					cmds.sets(isolatedObjects[1:], forceElement=cmds.isolateSelect(self.activeModelPanel, query=True, viewObjects=True), noWarnings=True)
				cmds.isolateSelect(self.activeModelPanel, update=True)
	
	def setObjectPivotDeferred(self):
		startTime = time.time()
		node = None
		
		executeInMainThreadWithResult(mel.eval, "global int $CreatePrimitiveLiveAborted;")
		CreatePrimitiveLiveAborted = executeInMainThreadWithResult(mel.eval, "$CreatePrimitiveLiveAborted = $CreatePrimitiveLiveAborted;")
		node = ""
		if not CreatePrimitiveLiveAborted:
			# Wait while the object is created
			while True:
				# Abort after 2 seconds
				if (time.time() - startTime) > 2:
					break
				
				# Check if object has been created
				node = executeInMainThreadWithResult(self.getCreateTypeTransform)
				if executeInMainThreadWithResult(cmds.objExists, node or ""):
					self.createdNodeTransform = node
					break
				
				time.sleep(0.03)
		
		executeInMainThreadWithResult(self.resetSceneOrientation, node)
		executeInMainThreadWithResult(self.setObjectPivot, node)
		executeInMainThreadWithResult(self.setTweakMode, False)
		executeInMainThreadWithResult(self.addToIsolateSetFn)

		if not CreatePrimitiveLiveAborted:
			# Close undo chunk
			executeInMainThreadWithResult(cmds.undoInfo, closeChunk=True)
			#print ("close")
	
	def setObjectPivot(self, node):
		if not cmds.objExists(node or ""):
			return
		
		createPosition = self.createPosition

		# If object has been created on the grid
		if not createPosition :
			# Check if the pivot is already on the grid
			rotatePivot = cmds.xform(node, query=True, worldSpace=True, rotatePivot=True)
			bbox = cmds.exactWorldBoundingBox(node)
			# If the pivot is not on the grid, we translate it to the grid
			# [x-min, y-min, z-min, x-max, y-max, z-max]
			if cmds.upAxis(query=True, axis=True) == "z":
				if not isClose(rotatePivot[2], 0, rt=0.000000001, at=0.0000000001):
					# average X, average Y, and minimum Z
					createPosition = [(bbox[0] + bbox[3]) / 2, (bbox[1] + bbox[4]) / 2, bbox[2]]
			else:
				if not isClose(rotatePivot[1], 0, rt=0.000000001, at=0.0000000001):
					# average X, minimum Y, and average Z
					createPosition = [(bbox[0] + bbox[3]) / 2, bbox[1], (bbox[2] + bbox[5]) / 2]		
		
		if createPosition and len(createPosition) >= 3:
			# Turns undo/redo off without flushing the queue
			undoState = cmds.undoInfo(query=True, state=True)
			if undoState:
				cmds.undoInfo(stateWithoutFlush=False)

			# Set pivot position
			currentSelMatrix = cmds.xform(node, query=True, worldSpace=True, matrix=True)
			currentSelPivot = cmds.xform(node, query=True, worldSpace=True, pivots=True)
			tmpParent = cmds.createNode("transform", skipSelect=True)
			tmpChildren = cmds.createNode("transform", parent=tmpParent, skipSelect=True)
			cmds.xform(tmpParent, worldSpace=True, matrix=currentSelMatrix, translation=[currentSelPivot[0], currentSelPivot[1], currentSelPivot[2]])
			cmds.move(createPosition[0], createPosition[1], createPosition[2], tmpChildren, worldSpace=True, rotatePivotRelative=True)
			if cmds.upAxis(query=True, axis=True) == "z":
				cmds.xform(node, objectSpace=True, pivots=[0, 0, cmds.xform(tmpChildren, query=True, objectSpace=True, translation=True)[2]])
			else:
				cmds.xform(node, objectSpace=True, pivots=[0, cmds.xform(tmpChildren, query=True, objectSpace=True, translation=True)[1], 0])
			cmds.delete([tmpParent, tmpChildren])
			
			# Turns undo/redo back on
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)
	
	def setTweakMode(self, state=False):
		# Disable tweak mode
		if self.tweakMode is False:
			if cmds.manipMoveContext("Move", exists=True) is True:
				cmds.manipMoveContext("Move", edit=True, tweakMode=state)
			if cmds.manipRotateContext("Rotate", exists=True) is True:
				cmds.manipRotateContext("Rotate", edit=True, tweakMode=state)
			if cmds.manipScaleContext("Scale", exists=True) is True:
				cmds.manipScaleContext("Scale", edit=True, tweakMode=state)
	
	def addToIsolateSetFn(self):
		# Enable isolateSelectAutoAdd
		if not self.addToIsolateSet and self.isolateAutoAdd:
			mel.eval('evalDeferred "setIsolateSelectAutoAdd \\"{0}\\" true";'.format(self.activeModelPanel))
	
	def toolExitFn(self):
		try:
			# Set object pivot position
			# Randomly crashes on Maya 2016-2017
			if MAYA_VERSION >= 2018:
				setObjectPivotThread = Thread(target=self.setObjectPivotDeferred)
				setObjectPivotThread.daemon = True
				setObjectPivotThread.start()

			# Delete sketchPlanes
			sketchPlanes = cmds.listRelatives(cmds.ls(self.objectUnderCursor, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="sketchPlane"), fullPath=True, parent=True, noIntermediate=True)
			if sketchPlanes is not None:
				cmds.delete(sketchPlanes)
			
			# Reset live color preference
			if self.draggerModifier == "shift":
				cmds.displayColor("live", self.makeLiveColorId, dormant=True)
			# Reset makeLive
			if len(self.currentLiveObjects) > 0:
				makeLiveQuiet(self.currentLiveObjects[0])
				# Override wireframe color on current live object
				cmds.setAttr(self.currentLiveShapes[0]+".overrideEnabled", self.overrideColor)
				cmds.setAttr(self.currentLiveShapes[0]+".overrideColor", self.overrideColorId)
			else:
				makeLiveQuiet(none=True)
			
			if not self.displayWireframe:
				if self.modelEditorScriptJob is not None:
					cmds.scriptJob(kill=self.modelEditorScriptJob, force=True)
				
				if self.wireframeOnShadedViewport is False:
					cmds.displayPref(wireframeOnShadedActive=self.wireframeOnShadedPref)
				
				self.resetWireframeOnShadedPref()
			'''else:
				if not self.wireframeOnShadedViewport and cmds.modelEditor(self.activeModelPanel, query=True, exists=True):
					cmds.evalDeferred(partial(cmds.modelEditor, self.activeModelPanel, edit=True, wireframeOnShaded=False))
					print ("disable WireframeOnShaded")'''
			
			self.isolatedObjectsShow()
			
			# Delete dragger context
			#self.deleteDraggerContext()
		except:
			pass
		finally:
			# Restore abort command		
			if self.abortCmd:
				cmds.nameCommand(self.abortCmd["name"], command=self.abortCmd["command"], default=self.abortCmd["runTimeCommand"]["default"], sourceType=self.abortCmd["runTimeCommand"]["language"], annotation=self.abortCmd["annotation"])
			else:
				cmds.nameCommand("NameComAbort_Context", command="AbortCurrentTool", default=True, sourceType="mel", annotation="Abort Current Tool")
			if cmds.runTimeCommand("PT_AbortCurrentTool", query=True, exists=True) is True:
				cmds.runTimeCommand("PT_AbortCurrentTool", edit=True, delete=True)
			
			# Exit tool
			mel.eval('$gNonSacredTool = "{0}";'.format(self.contextName))
			self.__class__.exists(False)
			self.__class__.toolExitScriptJob = None

	def objectUnderCursorFn(self):
		objectName = []
		hitPoint = []
		faceUnderCursor = None
		orientation = []
		#panel = cmds.getPanel(underPointer=True)
		panel = cmds.getPanel(withFocus=True)
		
		if panel in cmds.getPanel(type="modelPanel") and cmds.modelEditor(panel, query=True, exists=True) is True:
			self.pressPosition = getCursorPosition()
			if self.cameraBasedSelection is False:
				cmds.selectPref(useDepth=True)
				cmds.refresh(currentView=True)
			
			objectName = cmds.hitTest(panel, self.pressPosition.x(), self.pressPosition.y())
			
			if len(objectName) > 0:
				targetObject, hitPoint, faceUnderCursor, faceNormal = faceUnderCursorFn(cmds.draggerContext(self.contextName, query=True, anchorPoint=True), targetObject=objectName[0])[0:4]
				
				if faceUnderCursor is None:
					objectName = [None]
				elif targetObject is not None and len(faceNormal) > 2:
					targetMatrix = cmds.xform(targetObject, query=True, worldSpace=True, matrix=True)
					orientation = getAngleFromNormal(faceNormal, targetMatrix)
		
		if self.cameraBasedSelection is False:
			cmds.selectPref(useDepth=False)
		
		return (objectName or [None])[0], hitPoint, orientation
	
	def getCreateTypeTransform(self):
		if cmds.objExists(self.createdNode or ""):
			
			connectionList = cmds.listConnections(self.createdNode, source=False, destination=True, shapes=True)
			if connectionList:
				root = next(iter(cmds.ls(connectionList[0], long=True)), "")[1:].split("|", 1)[0]
				if root:
					return ("|"+root)
		
		return ""
	
	def getCreateType(self):
		createType = ""
		if self.toolContext == "CreatePolySphereCtx":
			createType = "polySphere"
		elif self.toolContext == "CreatePolyCubeCtx":
			createType = "polyCube"
		elif self.toolContext == "CreatePolyCylinderCtx":
			createType = "polyCylinder"
		elif self.toolContext == "CreatePolyConeCtx":
			createType = "polyCone"
		elif self.toolContext == "CreatePolyPlaneCtx":
			createType = "polyPlane"
		elif self.toolContext == "CreatePolyTorusCtx":
			createType = "polyTorus"
		elif self.toolContext == "CreatePolyPrismCtx":
			createType = "polyPrism"
		elif self.toolContext == "CreatePolyPyramidCtx":
			createType = "polyPyramid"
		elif self.toolContext == "CreatePolyPipeCtx":
			createType = "polyPipe"
		elif self.toolContext == "CreatePolyHelixCtx":
			createType = "polyHelix"
		elif self.toolContext == "CreatePolySoccerBallCtx":
			createType = "polyPrimitiveMisc"
		elif self.toolContext == "CreatePolyPlatonicSolidCtx":
			createType = "polyPlatonicSolid"
		elif self.toolContext == "CreateNurbsSphereCtx":
			createType = "makeNurbSphere"
		elif self.toolContext == "CreateNurbsCubeCtx":
			createType = "makeNurbCube"
		elif self.toolContext == "CreateNurbsCylinderCtx":
			createType = "makeNurbCylinder"
		elif self.toolContext == "CreateNurbsConeCtx":
			createType = "makeNurbCone"
		elif self.toolContext == "CreateNurbsPlaneCtx":
			createType = "makeNurbPlane"
		elif self.toolContext == "CreateNurbsTorusCtx":
			createType = "makeNurbTorus"
		elif self.toolContext == "CreateNurbsCircleCtx":
			createType = "makeNurbCircle"
		elif self.toolContext == "CreateNurbsSquareCtx":
			createType = "makeNurbsSquare"
		
		return createType
	
	@staticmethod
	def getCurrentState():
		global PT_CreatePrimitiveLive_State
		if "PT_CreatePrimitiveLive_State" in globals() and PT_CreatePrimitiveLive_State:
			return True
		return False
	
	def setCurrentState(self, state=False):
		global PT_CreatePrimitiveLive_State
		if state:
			PT_CreatePrimitiveLive_State = True
		elif "PT_CreatePrimitiveLive_State" in globals():
			del PT_CreatePrimitiveLive_State

	def createPrimitiveLive(self):
		if self.ctxReady is False:
			return
		
		mel.eval("global int $CreatePrimitiveLiveAborted;")
		CreatePrimitiveLiveAborted = mel.eval("$CreatePrimitiveLiveAborted = $CreatePrimitiveLiveAborted;")
		if not CreatePrimitiveLiveAborted:
			# Open undo chunk
			cmds.undoInfo(openChunk=True)
			#print ("open")
		
		# Activate tweak mode
		if MAYA_VERSION >= 2018:
			self.setTweakMode(True)
		
		self.draggerButton = cmds.draggerContext(self.contextName, query=True, button=True)
		self.draggerModifier = cmds.draggerContext(self.contextName, query=True, modifier=True)
		self.objectUnderCursor, self.createPosition, self.createRotation = self.objectUnderCursorFn()
		self.createRotation = [round(x, 4) + 0 for x in self.createRotation]
		self.currentLiveObjects = cmds.ls(long=True, live=True)
		self.currentLiveShapes = cmds.ls(self.currentLiveObjects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type=["mesh", "sketchPlane"])
		if len(self.currentLiveObjects) > 0:
			# Override wireframe color on current live object
			self.overrideColor = cmds.getAttr(self.currentLiveShapes[0]+".overrideEnabled")
			self.overrideColorId = cmds.getAttr(self.currentLiveShapes[0]+".overrideColor")
			cmds.setAttr(self.currentLiveShapes[0]+".overrideEnabled", True)
			cmds.setAttr(self.currentLiveShapes[0]+".overrideColor", self.makeLiveColorId)
		if self.objectUnderCursor is not None:			
			# Make objectUnderCursor live
			if self.draggerModifier != "shift" and len(self.createRotation) == 3:
				self.objectUnderCursor = cmds.plane(size=2, position=self.createPosition, rotation=self.createRotation)
				for attr, value in ((".visibility", False), (".lodVisibility", False), (".overrideEnabled", True), (".overrideVisibility", False)):
					cmds.setAttr(self.objectUnderCursor+attr, value)
				hideInOutliner(self.objectUnderCursor, True)
			else:
				self.objectUnderCursor_OC = cmds.getAttr(self.objectUnderCursor+".overrideEnabled")
				self.objectUnderCursor_OCId = cmds.getAttr(self.objectUnderCursor+".overrideColor")
				if self.objectUnderCursor_OC is True:
					# Set live color preference to object's override
					cmds.displayColor("live", self.objectUnderCursor_OCId, dormant=True)
				else:
					# Set live color preference to match polymesh color
					cmds.displayColor("live", self.polyMeshColorId, dormant=True)
			cmds.makeLive(self.objectUnderCursor)
		
		#cmds.refresh(currentView=True)
		
		self.isolatedObjectsHide()
		
		# Set the right context for each primitive type		
		if cmds.contextInfo(self.toolContext, exists=True) is False:
			if self.toolContext == "CreatePolySphereCtx":
				self.toolContext = cmds.createPolySphereCtx()
			elif self.toolContext == "CreatePolyCubeCtx":
				self.toolContext = cmds.createPolyCubeCtx()
			elif self.toolContext == "CreatePolyCylinderCtx":
				self.toolContext = cmds.createPolyCylinderCtx()
			elif self.toolContext == "CreatePolyConeCtx":
				self.toolContext = cmds.createPolyConeCtx()
			elif self.toolContext == "CreatePolyPlaneCtx":
				self.toolContext = cmds.createPolyPlaneCtx()
			elif self.toolContext == "CreatePolyTorusCtx":
				self.toolContext = cmds.createPolyTorusCtx()
			elif self.toolContext == "CreatePolyPrismCtx":
				self.toolContext = cmds.createPolyPrismCtx()
			elif self.toolContext == "CreatePolyPyramidCtx":
				self.toolContext = cmds.createPolyPyramidCtx()
			elif self.toolContext == "CreatePolyPipeCtx":
				self.toolContext = cmds.createPolyPipeCtx()
			elif self.toolContext == "CreatePolyHelixCtx":
				self.toolContext = cmds.createPolyHelixCtx()
			elif self.toolContext == "CreatePolySoccerBallCtx":
				self.toolContext = cmds.createPolySoccerBallCtx()
			elif self.toolContext == "CreatePolyPlatonicSolidCtx":
				self.toolContext = cmds.createPolyPlatonicSolidCtx()
			elif self.toolContext == "CreateNurbsSphereCtx":
				self.toolContext = cmds.createNurbsSphereCtx()
			elif self.toolContext == "CreateNurbsCubeCtx":
				self.toolContext = cmds.createNurbsCubeCtx()
			elif self.toolContext == "CreateNurbsCylinderCtx":
				self.toolContext = cmds.createNurbsCylinderCtx()
			elif self.toolContext == "CreateNurbsConeCtx":
				self.toolContext = cmds.createNurbsConeCtx()
			elif self.toolContext == "CreateNurbsPlaneCtx":
				self.toolContext = cmds.createNurbsPlaneCtx()
			elif self.toolContext == "CreateNurbsTorusCtx":
				self.toolContext = cmds.createNurbsTorusCtx()
			elif self.toolContext == "CreateNurbsCircleCtx":
				self.toolContext = cmds.createNurbsCircleCtx()
			elif self.toolContext == "CreateNurbsSquareCtx":
				self.toolContext = cmds.createNurbsSquareCtx()
			else:
				cmds.warning("Tool context is invalid, aborting.", noContext=True)
				cmds.setToolTo(self.previousCtx)
				return
		
		cmds.setToolTo(self.toolContext)
		
		# Get new node in another thread
		createType = self.getCreateType()
		existingNodes = cmds.ls(long=True, type=createType)
		findCreatedNode = Thread(target=self.findCreatedNode, args=(createType, existingNodes))
		findCreatedNode.daemon = True
		
		# Set NonScaredTool in another thread
		changeNonSacredTool = Thread(target=self.setNonSacredToolThread)
		changeNonSacredTool.daemon = True
		
		# Disable isolateSelectAutoAdd
		if not self.addToIsolateSet and cmds.isolateSelect(self.activeModelPanel, query=True, state=True):
			self.isolateAutoAdd = isolateSelectAutoAdd(self.activeModelPanel)
			if self.isolateAutoAdd:
				mel.eval('setIsolateSelectAutoAdd "{0}" false'.format(self.activeModelPanel))
		
		self.__class__.toolExitScriptJob = cmds.scriptJob(event=("ToolChanged", partial(self.toolExitFn)), runOnce=True, replacePrevious=True, parent=self.toolContext, compressUndo=True)

		if self.objectUnderCursor is not None and self.improvedOrientation:
			# Turns undo/redo off without flushing the queue
			undoState = cmds.undoInfo(query=True, state=True)
			if undoState:
				cmds.undoInfo(stateWithoutFlush=False)

			# create grid transform
			self.defaultGrid = MayaNode(cmds.createNode("transform", skipSelect=True, name="tmp_cam_group1"))
			# parent camera to grid transform
			self.currentCamera = next(iter(cmds.ls(cmds.modelEditor(self.getActiveModelPanel(), query=True, activeView=True, camera=True), long=True, dagObjects=True, type="camera")))
			self.currentCamera = next(iter(cmds.listRelatives(self.currentCamera, fullPath=True, parent=True) or []), None)
			if self.currentCamera:
				outlinerList = getOutlinerList(self.currentCamera)
				if self.currentCamera in outlinerList:
					self.currentCameraOutlinerPos = outlinerList.index(self.currentCamera)
				self.currentCameraParent = next(iter(cmds.listRelatives(self.currentCamera, fullPath=True, parent=True) or []), None)
				self.currentCamera = next(iter(cmds.parent(self.currentCamera, self.defaultGrid.name()) or []), None)
				self.currentCamera = MayaNode(self.currentCamera)
			
			# Get dynamicBevel polyBase
			self.dynamicBevelsNodesDict = {}
			dynamicBevelsNodes = []
			if cmds.objectType(tagFromType="gtDynamicBevel"):
				dynamicBevels = cmds.ls(type="gtDynamicBevel", long=True)
				if dynamicBevels:
					dynamicBevelsNodes = cmds.ls(cmds.listConnections(dynamicBevels, connections=False, destination=True, source=False), type="polyBase", long=True)
					dynamicBevelsNodes = list(dict.fromkeys(dynamicBevelsNodes))
			
			# Set nodeState to blocking to avoid computations temporarily 
			for n in dynamicBevelsNodes:
				self.dynamicBevelsNodesDict[n] = {".nodeState": cmds.getAttr(n+".nodeState")}
				cmds.setAttr(n+".nodeState", 2)
			
			# set polyBase nodes state to blocking 
			self.polyBaseNodesDict = {}
			blockNodes = cmds.ls(type=["polyBase", "deleteComponent"], long=True)
			#blockNodes = [x for x in blockNodes if x not in dynamicBevelsNodes]
			# Get only the last polyBase attached to an object in a hierarchy
			if blockNodes:
				blockShapes = cmds.ls(cmds.listConnections(blockNodes, connections=False, destination=True, source=False), long=True, dagObjects=True, noIntermediate=True, type="mesh")
				blockNodes = []
				for bShape in blockShapes:
					bNodes = cmds.listConnections(bShape+".inMesh", connections=False, destination=False, source=True) or []
					blockNodes.extend(cmds.ls(bNodes, type=["polyBase", "deleteComponent"], long=True))
				# remove duplicates
				blockNodes = list(dict.fromkeys(blockNodes))
			
			# Set nodeState to blocking to avoid computations temporarily
			for n in blockNodes:
				self.polyBaseNodesDict[n] = {".nodeState": cmds.getAttr(n+".nodeState")}
				cmds.setAttr(n+".nodeState", 2)

			self.setCurrentState(True)

			# orient assemblies to grid
			sceneAssemblies = cmds.ls(long=True, assemblies=True)
			for obj in sceneAssemblies:
				orientToTransform(obj, self.createPosition, self.createRotation)
			
			# Turns undo/redo back on
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)

		simulateMousePressEvent(self.pressPosition)
		
		findCreatedNode.start()
		changeNonSacredTool.start()
		
		if self.abortCmd:
			if cmds.runTimeCommand("PT_AbortCurrentTool", query=True, exists=True) is True:
				cmds.runTimeCommand("PT_AbortCurrentTool", edit=True, delete=True)
			mel.eval("global int $CreatePrimitiveLiveAborted; $CreatePrimitiveLiveAborted = 0;")
			cmds.runTimeCommand("PT_AbortCurrentTool", commandLanguage="mel", command='ctxAbort;setToolTo "selectSuperContext";evalDeferred "CreatePolyPrimitiveLive(\\"{0}\\")" -lowestPriority;global int $CreatePrimitiveLiveAborted;$CreatePrimitiveLiveAborted = 1;'.format(self.toolContext), showInHotkeyEditor=False, default=False, annotation=self.abortCmd["runTimeCommand"]["annotation"])
			cmds.nameCommand(self.abortCmd["name"], command="PT_AbortCurrentTool", default=self.abortCmd["runTimeCommand"]["default"], sourceType=self.abortCmd["runTimeCommand"]["language"], annotation=self.abortCmd["annotation"])

class CreatePrimitive_Options(OptionsWindow):
	_WindowName = "CreatePrimitive_Options"
	
	def __new__(cls, **kwargs):
		showWindow = True
		for key, value in six.iteritems(kwargs):
			if key == "showWindow" or key == "sw":
				showWindow = value
		
		optionsWindowDict = cls._OptionsWindowDict
		windowName = CreatePrimitive_Options._WindowName
		
		if not showWindow and windowName in optionsWindowDict:
			class_instance = optionsWindowDict[windowName]
		else:
			class_instance = super(CreatePrimitive_Options, cls).__new__(cls)
		
		optionsWindowDict[windowName] = class_instance
		
		return class_instance
	
	def __init__(self, **kwargs):		
		if hasattr(self, "_instanceInitDone"):
			return
		
		self.windowName = "CreatePrimitive_Options"
		self.pfx = "PT_"
		kwargs.update({"windowSize": [260, 200], 
		          "windowTitle": "Interactive Creation Options", 
				  "toolbox": True, 
		          "runLabel": "Save and Close", 
				  "applyLabel": "Save", 
		          "minWindowSize": 260, 
		          "rowOffset": 1, 
				  "preview": False})
		
		super(CreatePrimitive_Options, self).__init__(self.windowName, **kwargs)
		
		self._instanceInitDone = True
	
	def runCmd(self, *args):
		return
	
	def controlsCallback(self, *args):
		# Save settings
		self.saveSettings(1)
		# Query optionVar
		settings = self.querySettings()
		# Match By
		if bool(settings[self.pfx+"CP_EnableCreatePrimitiveLive"][0]):
			cmds.rowLayout(self.pfx+"CP_EnableWireframeOnShadedRow", e=True, en=True)
			cmds.rowLayout(self.pfx+"CP_AddToIsolateSetRow", e=True, en=True)
			if cmds.rowLayout(self.pfx+"CP_ImprovedOrientationRow", query=True, exists=True):
				cmds.rowLayout(self.pfx+"CP_ImprovedOrientationRow", e=True, en=True)
		else:
			cmds.rowLayout(self.pfx+"CP_EnableWireframeOnShadedRow", e=True, en=False)
			cmds.rowLayout(self.pfx+"CP_AddToIsolateSetRow", e=True, en=False)
			if cmds.rowLayout(self.pfx+"CP_ImprovedOrientationRow", query=True, exists=True):
				cmds.rowLayout(self.pfx+"CP_ImprovedOrientationRow", e=True, en=False)
	
	def createUI(self):
		# If window already opened, delete it
		if(cmds.window(self.windowName, exists=True) is True):
			cmds.deleteUI(self.windowName, window=True)
		cmds.window(self.windowName, title=self.windowTitle, menuBar=True, sizeable=True, maximizeButton=True)
		
		# Edit menu
		cmds.menu(label="Edit")
		cmds.menuItem(label="Save Settings", command=(partial(self.saveSettings, 1)), enableCommandRepeat=False)
		cmds.menuItem(label="Reset Settings", command=(partial(self.resetSettings)), enableCommandRepeat=False)
		cmds.menuItem(divider=True)
		cmds.menuItem(label="Reset Window Size", command=(partial(self.resetWindowSize)), enableCommandRepeat=False)
		cmds.setParent("..")
		# Help menu
		cmds.menu(label="Help", helpMenu=True)
		cmds.menuItem(label="Help on {0}".format(self.windowTitle), image="help.png", command=(partial(helpCmd, helpUrl="/docs/createprimitivelive-options/")), enableCommandRepeat=False)
		cmds.setParent("..")
		
		# START: Window Form
		self.windowForm = cmds.formLayout(self.pfx+"WindowForm")
		
		# START: Tab Layout
		cmds.tabLayout(self.pfx+"TabLayout", tabsVisible=False)
		cmds.formLayout(self.pfx+"TabForm")
		
		# START: Scroll Layout
		self.scrollLayout = cmds.scrollLayout(self.pfx+"ScrollLayout", childResizable=True, resizeCommand=(partial(self.scrollResized)))
		self.scrollForm = cmds.formLayout(self.pfx+"ScrollForm")
		
		# START: Settings Frame
		cmds.frameLayout(self.pfx+"CreatePrimitiveSettingsFrame", label="Interactive Creation Settings", labelIndent=5, collapsable=False, backgroundShade=True, marginHeight=4, marginWidth=0)
		cmds.formLayout(self.pfx+"CreatePrimitiveSettingsForm")
		
		# START: Settings Column #1
		cmds.columnLayout(self.pfx+"CreatePrimitiveSettingsColumn1", adjustableColumn=True, columnAttach=("left", 0))
		
		# Enable Create Primitive Live
		cmds.rowLayout(self.pfx+"CP_EnableCreatePrimitiveLiveRow", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"))
		cmds.text(label="")
		cmds.checkBoxGrp(self.pfx+"CP_EnableCreatePrimitiveLive", docTag=self.pfx+"CP_EnableCreatePrimitiveLive", label="", label1="Enable Create Primitive Live", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback)))
		cmds.setParent("..")
		
		# Enable Wireframe On Shaded
		cmds.rowLayout(self.pfx+"CP_EnableWireframeOnShadedRow", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"))
		cmds.text(label="")
		cmds.checkBoxGrp(self.pfx+"CP_EnableWireframeOnShaded", docTag=self.pfx+"CP_EnableWireframeOnShaded", label="", label1="Enable Wireframe On Shaded", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback)))
		cmds.setParent("..")
		
		# Add To Isolate Set
		cmds.rowLayout(self.pfx+"CP_AddToIsolateSetRow", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"))
		cmds.text(label="")
		cmds.checkBoxGrp(self.pfx+"CP_AddToIsolateSet", docTag=self.pfx+"CP_AddToIsolateSet", label="", label1="Isolate Mode: Add To Isolate Set", value1=True, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback)))
		cmds.setParent("..")

		# Improved Orientation
		# Randomly crashes on Maya 2016-2017
		if MAYA_VERSION >= 2018:
			cmds.rowLayout(self.pfx+"CP_ImprovedOrientationRow", numberOfColumns=2, columnWidth=(1, self.rowOffset), columnAttach=(1, "right", 0), columnAttach2=("left", "left"))
			cmds.text(label="")
			cmds.checkBoxGrp(self.pfx+"CP_ImprovedOrientation", docTag=self.pfx+"CP_ImprovedOrientation", label="", label1="Improved Orientation", value1=False, columnWidth2=(2, 140), changeCommand=(partial(self.controlsCallback)))
			cmds.setParent("..")
		
		# Separation
		cmds.rowLayout(height=1)
		cmds.setParent("..")
		# END: Settings Column #1
		cmds.setParent("..")
		
		# END: Settings Frame
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Scroll Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# END: Tab Layout
		cmds.setParent("..")
		cmds.setParent("..")
		
		# Buttons
		cmds.formLayout(self.pfx+"ButtonForm", numberOfDivisions=150)
		#cmds.iconTextButton(self.pfx+"executeButton", label=self.runLabel, command=(partial(self.buttonsCmd, True, True)), flat=False, height=26, style="textOnly", commandRepeatable=True)
		cmds.iconTextButton(self.pfx+"applyButton", label=self.applyLabel, command=(partial(self.buttonsCmd, True, False)), flat=False, height=26, style="textOnly", commandRepeatable=True)
		cmds.iconTextButton(self.pfx+"closeButton", label="Close", command=(partial(self.buttonsCmd, False, True)), flat=False, height=26, style="textOnly", commandRepeatable=False)
		cmds.setParent("..")
		
		# END: Window Form
		cmds.setParent("..")
		
		# Window Form Layout
		cmds.formLayout(self.windowForm, edit=True,
						attachForm=[(self.pfx+"TabLayout", "top", 0), (self.pfx+"TabLayout", "left", 0), (self.pfx+"TabLayout", "right", 0)],
						attachControl=(self.pfx+"TabLayout", "bottom", 5, self.pfx+"ButtonForm"))
		cmds.formLayout(self.windowForm, edit=True,
						attachNone=(self.pfx+"ButtonForm", "top"),
						attachForm=[(self.pfx+"ButtonForm", "left", 5), (self.pfx+"ButtonForm", "right", 5), (self.pfx+"ButtonForm", "bottom", 5)])
		
		# Tabs Form Layout
		cmds.formLayout(self.pfx+"TabForm", edit=True,
						attachForm=[(self.scrollLayout, "top", 0), (self.scrollLayout, "left", 0), (self.scrollLayout, "right", 0), (self.scrollLayout, "bottom", 0)])
		
		# Scroll Form Layout
		cmds.formLayout(self.scrollForm, edit=True,
						attachForm=[(self.pfx+"CreatePrimitiveSettingsFrame", "top", 0), (self.pfx+"CreatePrimitiveSettingsFrame", "left", 0), (self.pfx+"CreatePrimitiveSettingsFrame", "right", 0)],
						attachNone=(self.pfx+"CreatePrimitiveSettingsFrame", "bottom"))
		
		# Columns Form Layout
		cmds.formLayout(self.pfx+"CreatePrimitiveSettingsForm", edit=True,
						attachForm=[(self.pfx+"CreatePrimitiveSettingsColumn1", "top", 0), (self.pfx+"CreatePrimitiveSettingsColumn1", "left", 0), (self.pfx+"CreatePrimitiveSettingsColumn1", "right", 0)],
						attachNone=(self.pfx+"CreatePrimitiveSettingsColumn1", "bottom"))
		
		# Buttons Form Layout
		'''cmds.formLayout(self.pfx+"ButtonForm", edit=True,
						attachForm=(self.pfx+"executeButton", "top", 0),
						attachPosition=[(self.pfx+"executeButton", "left", 0, 0), (self.pfx+"executeButton", "right", 2, 50)],
						attachNone=(self.pfx+"executeButton", "bottom"))'''
		cmds.formLayout(self.pfx+"ButtonForm", edit=True,
						attachForm=(self.pfx+"applyButton", "top", 0),
						attachPosition=[(self.pfx+"applyButton", "left", 0, 0), (self.pfx+"applyButton", "right", 2, 75)],
						attachNone=(self.pfx+"applyButton", "bottom"))
		cmds.formLayout(self.pfx+"ButtonForm", edit=True,
						attachForm=(self.pfx+"closeButton", "top", 0),
						attachPosition=[(self.pfx+"closeButton", "left", 2, 75), (self.pfx+"closeButton", "right", 0, 150)],
						attachNone=(self.pfx+"closeButton", "bottom"))
