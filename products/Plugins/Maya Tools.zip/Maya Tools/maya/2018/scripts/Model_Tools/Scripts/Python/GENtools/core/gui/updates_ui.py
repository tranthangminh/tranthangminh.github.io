# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'updates_ui.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

try:
    from PySide2.QtCore import *
    from PySide2.QtGui import *
    from PySide2.QtWidgets import *
except ImportError:
    from PySide.QtCore import *
    from PySide.QtGui import *

from .widgets import QFrameUrl
from .widgets import QFrameTitleBar

from . import updates_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(319, 211)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralWidgetLayout = QHBoxLayout(self.centralwidget)
        self.centralWidgetLayout.setSpacing(0)
        self.centralWidgetLayout.setObjectName(u"centralWidgetLayout")
        self.centralWidgetLayout.setContentsMargins(8, 8, 8, 8)
        self.windowFrame = QFrame(self.centralwidget)
        self.windowFrame.setObjectName(u"windowFrame")
        sizePolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.windowFrame.sizePolicy().hasHeightForWidth())
        self.windowFrame.setSizePolicy(sizePolicy)
        self.windowFrameLayout = QVBoxLayout(self.windowFrame)
        self.windowFrameLayout.setSpacing(0)
        self.windowFrameLayout.setObjectName(u"windowFrameLayout")
        self.windowFrameLayout.setContentsMargins(0, 0, 0, 0)
        self.titleBar = QFrameTitleBar(self.windowFrame)
        self.titleBar.setObjectName(u"titleBar")

        self.windowFrameLayout.addWidget(self.titleBar)

        self.windowLayout = QHBoxLayout()
        self.windowLayout.setSpacing(0)
        self.windowLayout.setObjectName(u"windowLayout")
        self.windowLayout.setContentsMargins(10, 10, 10, 10)
        self.mainLayout = QVBoxLayout()
        self.mainLayout.setSpacing(15)
        self.mainLayout.setObjectName(u"mainLayout")
        self.mainLayout.setContentsMargins(15, 15, 15, 15)
        self.updateTitle = QLabel(self.windowFrame)
        self.updateTitle.setObjectName(u"updateTitle")

        self.mainLayout.addWidget(self.updateTitle)

        self.updateDescription = QLabel(self.windowFrame)
        self.updateDescription.setObjectName(u"updateDescription")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.updateDescription.sizePolicy().hasHeightForWidth())
        self.updateDescription.setSizePolicy(sizePolicy1)
        self.updateDescription.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)
        self.updateDescription.setWordWrap(True)

        self.mainLayout.addWidget(self.updateDescription)

        self.updateLink = QFrameUrl(self.windowFrame)
        self.updateLink.setObjectName(u"updateLink")
        sizePolicy2 = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.updateLink.sizePolicy().hasHeightForWidth())
        self.updateLink.setSizePolicy(sizePolicy2)

        self.mainLayout.addWidget(self.updateLink)

        self.mainSpacerBottom = QSpacerItem(0, 0, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.mainLayout.addItem(self.mainSpacerBottom)


        self.windowLayout.addLayout(self.mainLayout)


        self.windowFrameLayout.addLayout(self.windowLayout)

        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setSpacing(0)
        self.buttonLayout.setObjectName(u"buttonLayout")
        self.buttonLayout.setContentsMargins(10, 0, 10, 10)
        self.buttonBox = QDialogButtonBox(self.windowFrame)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setStandardButtons(QDialogButtonBox.Close|QDialogButtonBox.Ignore)

        self.buttonLayout.addWidget(self.buttonBox)


        self.windowFrameLayout.addLayout(self.buttonLayout)


        self.centralWidgetLayout.addWidget(self.windowFrame)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"About", None))
        self.updateTitle.setText(QCoreApplication.translate("MainWindow", u"New update available", None))
        self.updateDescription.setText(QCoreApplication.translate("MainWindow", u"To download the new update, go to your ArtStation library and select your GENtools product.", None))
    # retranslateUi

