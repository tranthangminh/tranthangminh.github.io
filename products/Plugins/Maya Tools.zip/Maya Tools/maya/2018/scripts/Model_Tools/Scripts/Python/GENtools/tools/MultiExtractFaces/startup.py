#!/usr/bin/python
# -*- coding: utf-8 -*-
from ...GENtools import ScriptLoader

class LoadScript(object):	
	def createScriptLoader(self):
		self.scriptLoader = ScriptLoader()
		self.scriptLoader.setToolName("Multi Extract Faces")
		self.scriptLoader.setStartupFile("MultiExtractFaces.mel")
		self.scriptLoader.setMenuCategory("Tools")
		self.scriptLoader.setSubMenuName("Edit Mesh")
		self.scriptLoader.setMenuItemDict({"image": "polyChipOff.png", "sourceType": "mel", "command": "MultiExtractFaces"})
		self.scriptLoader.setMenuItemOptionDict({"sourceType": "mel", "command": "MultiExtractFacesOptions"})
		return self.scriptLoader