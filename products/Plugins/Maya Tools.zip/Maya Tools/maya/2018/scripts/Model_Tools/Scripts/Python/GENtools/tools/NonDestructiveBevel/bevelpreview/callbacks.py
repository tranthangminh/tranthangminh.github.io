#!/usr/bin/python
# -*- coding: utf-8 -*-
import time
import logging
import maya.cmds as cmds
from threading import Thread
from functools import partial
import maya.api.OpenMaya as om
import maya.api.OpenMayaUI as omui
from collections import OrderedDict
from maya.utils import executeDeferred, executeInMainThreadWithResult

# for python 3 compatibility
import six

#from .xray import xRayOverride
from ....core.general.decorators import make_undoable
from ....core.general.panels import getActiveModelPanel
from .miscs import getObjectsWithBevelPreview, setDisplaySurface, getDynamicBevelFromObject

def getIsolatedObjects(activeModelPanel=None):
	isolatedObjects = None

	if not activeModelPanel:
		activeModelPanel = getActiveModelPanel()
	
	try:
		if activeModelPanel:
			if cmds.isolateSelect(activeModelPanel, query=True, state=True):
				isolatedObjectsSet = cmds.isolateSelect(activeModelPanel, query=True, viewObjects=True)
				if isolatedObjectsSet:
					isolatedObjects = cmds.ls(cmds.sets(isolatedObjectsSet, query=True), long=True)
	except Exception as e:
		logging.exception(e)
	
	return isolatedObjects

@make_undoable
def toggleBevelPreviewDisplay(objects=None):
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		return

	visibilityPlugList = []
	enableVisibilityCounter, disableVisibilityCounter = 0, 0

	if objects:
		selectedShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	else:
		selectedShapes = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
		selectedBevelPreview = cmds.ls(selection=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="gtBevelPreview")
	
	if not selectedShapes and not selectedBevelPreview:
		return
	
	if selectedShapes:
		selList = om.MSelectionList()
		for x in selectedShapes:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			outMeshPlug = dependencyNode.findPlug("outMesh", False)
			dependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtBevelPreview":

					visibilityPlug = currentDependencyNode.findPlug("visibility", False)
					lodVisibilityPlug = currentDependencyNode.findPlug("lodVisibility", False)

					visibilityPlugList.extend([visibilityPlug, lodVisibilityPlug])
					if not visibilityPlug.asBool() or not lodVisibilityPlug.asBool():
						enableVisibilityCounter += 1
					else:
						disableVisibilityCounter += 1
					
					# remove from selectedBevelPreview list to avoid processing twice
					bevelPreviewDagPath = om.MDagPath.getAPathTo(currentItem)
					if bevelPreviewDagPath.fullPathName() in selectedBevelPreview:
						selectedBevelPreview.remove(bevelPreviewDagPath.fullPathName())

					break
				dependencyGraph.next()
	
	if selectedBevelPreview:
		selList = om.MSelectionList()
		for x in selectedBevelPreview:
			selList.add(x)

		for each in range(selList.length()):
			dagPath = selList.getDagPath(each)
			dependencyNode = om.MFnDependencyNode(dagPath.node())

			visibilityPlug = dependencyNode.findPlug("visibility", False)
			lodVisibilityPlug = dependencyNode.findPlug("lodVisibility", False)

			visibilityPlugList.extend([visibilityPlug, lodVisibilityPlug])
			if not visibilityPlug.asBool() or not lodVisibilityPlug.asBool():
				enableVisibilityCounter += 1
			else:
				disableVisibilityCounter += 1
	
	# enable visibility
	if enableVisibilityCounter >= disableVisibilityCounter:
		for p in visibilityPlugList:
			p.setBool(True)
	# disable visibility
	else:
		for p in visibilityPlugList:
			p.setBool(False)

@make_undoable
def bevelPreviewViewportCallbackFn(*args, **kwargs):
	global NDB_IgnoreViewportCallback
	if "NDB_IgnoreViewportCallback" in globals() and NDB_IgnoreViewportCallback:
		NDB_IgnoreViewportCallback = False
		return

	forceDisplay = False
	if "forceDisplay" in kwargs:
		forceDisplay = kwargs["forceDisplay"]

	activeModelPanel = None
	if "modelEditor" in kwargs:
		activeModelPanel= kwargs["modelEditor"]

	if not cmds.objectType(tagFromType="gtBevelPreview"):
		removeViewportCallback()
		return
	
	bevelPreview = cmds.ls(type="gtBevelPreview", long=True)

	selList = om.MSelectionList()
	for x in bevelPreview:
		selList.add(x)

	isolatedObjects = getIsolatedObjects(activeModelPanel)
	isolatedShapes = []
	if isolatedObjects:
		isolatedShapes = cmds.ls(isolatedObjects, long=True, dagObjects=True, noIntermediate=True, type=["mesh", "gtBevelPreview"])

	for each in range(selList.length()):
		bevelPreviewDagPath = selList.getDagPath(each)
		dependencyNode = om.MFnDependencyNode(bevelPreviewDagPath.node())
		inMeshPlug = dependencyNode.findPlug("inMesh", False)
		dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
		while not dependencyGraph.isDone():
			currentItem = dependencyGraph.currentNode()
			currentDependencyNode = om.MFnDependencyNode(currentItem)
			if currentDependencyNode.typeName == "gtDynamicBevel":
				plugDict = {}
				for attr in ["enableXRay", "enableShading"]:	
					if currentDependencyNode.hasAttribute(attr):
						plugDict[attr] = currentDependencyNode.findPlug(attr, False)

				BP_isVisible = True
				if isolatedShapes and bevelPreviewDagPath.fullPathName() not in isolatedShapes:
					BP_isVisible = False

				if "enableXRay" in plugDict and plugDict["enableXRay"].asBool():
					inputMeshPlug = currentDependencyNode.findPlug("inputMesh", False)
					inputPlugArray = inputMeshPlug.connectedTo(True, False)
					if len(inputPlugArray) > 0:
						inputMeshMObject = inputPlugArray[0].node()
						if inputMeshMObject.hasFn(om.MFn.kMesh):
							dagNode = om.MFnDagNode(inputMeshMObject)
							if dagNode.isIntermediateObject:
								dependencyGraph.next()
								continue
							dagPath = om.MDagPath.getAPathTo(inputMeshMObject)
							if not dagPath.isValid() or not dagPath.isVisible():
								dependencyGraph.next()
								continue

							xRayState = next(iter(cmds.displaySurface(dagPath.fullPathName(), query=True, xRay=True) or []))
							#xRayState = xRayOverride.getXRay(dagPath.fullPathName())

							'''if (not bevelPreviewDagPath.isVisible() or not BP_isVisible) and (xRayState or forceDisplay):
								cmds.displaySurface(dagPath.fullPathName(), xRay=False)
								#xRayOverride.setXRay(dagPath.fullPathName(), xRay=False)
								#logging.info("disable xRay {0}".format(dagPath.fullPathName()))
							elif bevelPreviewDagPath.isVisible() and BP_isVisible and (not xRayState or forceDisplay):
								cmds.displaySurface(dagPath.fullPathName(), xRay=True)
								#xRayOverride.setXRay(dagPath.fullPathName(), xRay=True)
								#logging.info("enable xRay {0}".format(dagPath.fullPathName()))'''
							
							if (not bevelPreviewDagPath.isVisible() or not BP_isVisible) and (xRayState or forceDisplay):
								NDB_IgnoreViewportCallback = True
								cmds.displaySurface(dagPath.fullPathName(), xRay=False)
								#xRayOverride.setXRay(dagPath.fullPathName(), xRay=False)
								#logging.info("disable xRay {0}".format(dagPath.fullPathName()))
							elif bevelPreviewDagPath.isVisible() and BP_isVisible and ("enableShading" in plugDict and plugDict["enableShading"].asBool()):
								NDB_IgnoreViewportCallback = True
								cmds.displaySurface(dagPath.fullPathName(), xRay=True)
								#xRayOverride.setXRay(dagPath.fullPathName(), xRay=True)
								#logging.info("enable xRay {0}".format(dagPath.fullPathName()))
				
				if "enableShading" in plugDict and not plugDict["enableShading"].asBool():
					inputMeshPlug = currentDependencyNode.findPlug("inputMesh", False)
					inputPlugArray = inputMeshPlug.connectedTo(True, False)
					if len(inputPlugArray) > 0:
						inputMeshMObject = inputPlugArray[0].node()
						if inputMeshMObject.hasFn(om.MFn.kMesh):
							dagPath = om.MDagPath.getAPathTo(inputMeshMObject)
							dNode = om.MFnDependencyNode(dagPath.node())
							overrideShadingPlug = dNode.findPlug("overrideShading", False)
							if (not bevelPreviewDagPath.isVisible() or not BP_isVisible) and not overrideShadingPlug.asBool():
								NDB_IgnoreViewportCallback = True
								overrideShadingPlug.setBool(True)
								#logging.info("enable shading {0}".format(dagPath.fullPathName()))
							if bevelPreviewDagPath.isVisible() and BP_isVisible and overrideShadingPlug.asBool():
								NDB_IgnoreViewportCallback = True
								overrideShadingPlug.setBool(False)
								#logging.info("disable shading {0}".format(dagPath.fullPathName()))
				break
			dependencyGraph.next()

@make_undoable
def bevelPreviewViewportCallback(*args, **kwargs):
	#logging.info("bevelPreviewViewportCallback")
	global deferredViewportCallback
	if deferredViewportCallback:
		executeDeferred(partial(bevelPreviewViewportCallbackFn, *args, **kwargs))
	else:
		executeInMainThreadWithResult(partial(bevelPreviewViewportCallbackFn, *args, **kwargs))
		deferredViewportCallback = True

class bevelPreviewViewportCallbackThread(Thread):
	def __init__(self):
		Thread.__init__(self)
		self._cancelCallback = False
		self._runCallback = False
		self._modelEditor = None
	
	def runCallback(self, modelEditor, *args):
		self._modelEditor = modelEditor
		self._runCallback = True
	
	def cancelCallback(self):
		self._cancelCallback = True

	def run(self):
		while True:
			try:
				time.sleep(0.25)
			except:
				break

			if self._cancelCallback:
				break
			elif not self._runCallback:
				continue

			bevelPreviewViewportCallback(modelEditor=self._modelEditor)
			
			self._runCallback = False

@make_undoable
def bevelPreviewModelEditorCallback(*args):
	if not cmds.objectType(tagFromType="gtBevelPreview"):
		removeViewportCallback()
		return
	
	#logging.info("bevelPreviewModelEditorCallback")
	
	global deferredViewportCallback
	bevelPreview = cmds.ls(type="gtBevelPreview", long=True)

	# verify that the viewport callback is binded to the correct modelPanel
	activeModelPanel = getActiveModelPanel()
	if activeModelPanel:
		for x in list(bevelPreviewCallback):
			if x["modelEditor"] != activeModelPanel:
				try:
					omui.MUiMessage.removeCallback(x["id"])
				except Exception as e:
					logging.exception(e)
				bevelPreviewCallback.remove(x)
				bevelPreviewCallback.append({"id": omui.MUiMessage.add3dViewPostRenderMsgCallback(activeModelPanel, bpvcThread.runCallback), "modelEditor": activeModelPanel})

	# modelEditor callback for isolate mode
	selList = om.MSelectionList()
	for x in bevelPreview:
		selList.add(x)
	
	for each in range(selList.length()):
		bevelPreviewDagPath = selList.getDagPath(each)
		dependencyNode = om.MFnDependencyNode(bevelPreviewDagPath.node())
		inMeshPlug = dependencyNode.findPlug("inMesh", False)
		dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
		while not dependencyGraph.isDone():
			currentItem = dependencyGraph.currentNode()
			currentDependencyNode = om.MFnDependencyNode(currentItem)
			if currentDependencyNode.typeName == "mesh":
				dagPath = om.MDagPath.getAPathTo(currentItem)

				isolatedObjects = getIsolatedObjects()
				if isolatedObjects:
					isolatedShapes = cmds.ls(isolatedObjects, long=True, dagObjects=True, noIntermediate=True, type=["mesh", "gtBevelPreview"])

					if dagPath.fullPathName() in isolatedShapes and bevelPreviewDagPath.fullPathName() not in isolatedShapes:
						deferredViewportCallback = False
						'''
						outMeshPlug = currentDependencyNode.findPlug("outMesh", False)
						outMeshPlugArray = outMeshPlug.connectedTo(False, True)
						for p in outMeshPlugArray:
							outMeshMObject = p.node()
							dNode = om.MFnDependencyNode(outMeshMObject)
							if dNode.typeName == "gtDynamicBevel":
								overridePlug = dependencyNode.findPlug("overrideEnabled", False)
								visibilityPlug = dependencyNode.findPlug("overrideVisibility", False)
								if not (overridePlug.asBool() and not visibilityPlug.asBool()):
									overridePlug.setBool(True)
									visibilityPlug.setBool(False)
									deferredViewportCallback = False
									#logging.info("hide bevelPreview {0}".format(bevelPreviewDagPath.fullPathName()))3
						'''

				else:
					deferredViewportCallback = False
					'''
					outMeshPlug = currentDependencyNode.findPlug("outMesh", False)
					outMeshPlugArray = outMeshPlug.connectedTo(False, True)
					for p in outMeshPlugArray:
						outMeshMObject = p.node()
						dNode = om.MFnDependencyNode(outMeshMObject)
						if dNode.typeName == "gtDynamicBevel":
							overridePlug = dependencyNode.findPlug("overrideEnabled", False)
							visibilityPlug = dependencyNode.findPlug("overrideVisibility", False)
							if overridePlug.asBool() and not visibilityPlug.asBool():
								overridePlug.setBool(True)
								visibilityPlug.setBool(True)
								deferredViewportCallback = False
								#logging.info("show bevelPreview {0}".format(bevelPreviewDagPath.fullPathName()))
					'''

				break
			dependencyGraph.next()
	else:
		bevelPreviewViewportCallback()

def getSelectedBevelPreviewAndCage():
	if not cmds.objectType(tagFromType="gtDynamicBevel"):
		return {}

	currentSel = cmds.ls(selection=True, long=True, objectsOnly=True)
	selectedBevelPreview = {}

	if currentSel:
		# Get dynamicBevels nodes
		dynamicBevels = cmds.ls(cmds.listHistory(currentSel, future=True, leaf=True), long=True, type="gtDynamicBevel")
		dynamicBevels.extend(cmds.ls(cmds.listHistory(currentSel, leaf=True), long=True, type="gtDynamicBevel"))
		dynamicBevels = list(OrderedDict.fromkeys(dynamicBevels))
		
		if dynamicBevels:
			bevelPreviewDict = {}

			# Get sourceShapes
			sourceShapes = []
			for dynamicBevel in dynamicBevels:
				sourceShapes = cmds.listConnections("{0}.inputMesh".format(dynamicBevel), source=True, destination=False, shapes=True, type="mesh") or []
				sourceShapes = cmds.ls(list(OrderedDict.fromkeys(sourceShapes)), long=True)
			
				for srcShape in sourceShapes:
					srcObj = next(iter(cmds.listRelatives(srcShape, fullPath=True, parent=True) or []), None)

					#if all([srcObj not in bevelPreviewDict, srcObj not in unselectedObjects, srcShape not in unselectedObjects]):
					if srcObj not in bevelPreviewDict:
						bevelPreviewDict[srcObj] = {}
						bevelPreviewDict[srcObj]["shape"] = srcShape

						bevelPreviewShapes = cmds.ls(cmds.listHistory(dynamicBevel, allConnections=True, future=True, leaf=True), long=True, type="gtBevelPreview")
						bevelPreviewShapes = list(OrderedDict.fromkeys(bevelPreviewShapes))
						for bevelPreviewShape in bevelPreviewShapes:
							bevelPreview = next(iter(cmds.listRelatives(bevelPreviewShape, fullPath=True, parent=True) or []), None)
							if bevelPreview:
								bevelPreviewDict[srcObj]["bevelPreview"] = bevelPreview
								bevelPreviewDict[srcObj]["bevelPreviewShape"] = bevelPreviewShape
								break

			for obj, objDict in six.iteritems(bevelPreviewDict):
				if not all([x in objDict for x in ["shape", "bevelPreview", "bevelPreviewShape"]]):
					continue

				if any(x in currentSel for x in [obj, objDict["shape"]]) and any(x in currentSel for x in [objDict["bevelPreview"], objDict["bevelPreviewShape"]]):
					selectedBevelPreview[obj] = []
					if objDict["bevelPreview"] in currentSel:
						selectedBevelPreview[obj].append(objDict["bevelPreview"])
					if objDict["bevelPreviewShape"] in currentSel:
						selectedBevelPreview[obj].append(objDict["bevelPreviewShape"])
	
	return selectedBevelPreview

@make_undoable
def createViewportCallback(setValue=None, toggle=False, startup=False):
	if setValue is not None:
		cmds.optionVar(intValue=("BP_ContextViewportCallback", setValue))
	elif not cmds.optionVar(exists="BP_ContextViewportCallback"):
		cmds.optionVar(intValue=("BP_ContextViewportCallback", True))

	if toggle:
		cmds.optionVar(intValue=("BP_ContextViewportCallback", not cmds.optionVar(query="BP_ContextViewportCallback")))

	if startup:
		global bevelPreviewCallback, modelEditorCallback
		if ("bevelPreviewCallback" in globals() and bevelPreviewCallback) and ("modelEditorCallback" in globals() and modelEditorCallback):
			return

	removeViewportCallback()

	if cmds.optionVar(query="BP_ContextViewportCallback"):
		# create callbacks
		activeModelPanel = getActiveModelPanel()
		if activeModelPanel:
			bpvcThread = bevelPreviewViewportCallbackThread()
			bpvcThread.start()
			bevelPreviewCallback.append({"id": omui.MUiMessage.add3dViewPostRenderMsgCallback(activeModelPanel, bpvcThread.runCallback), "modelEditor": activeModelPanel})
		modelEditorCallback.append(om.MEventMessage.addEventCallback("modelEditorChanged", bevelPreviewModelEditorCallback))
	
		bevelPreviewShapes = cmds.ls(type="gtBevelPreview", long=True)
		for bps in bevelPreviewShapes:
			for attr, value in [("overrideEnabled", True), ("overrideDisplayType", 2)]:
				if cmds.attributeQuery(attr, node=bps, exists=True) and cmds.getAttr("{0}.{1}".format(bps, attr)) != value:
					cmds.setAttr("{0}.{1}".format(bps, attr), value)

def removeViewportCallback():
	global bevelPreviewCallback, modelEditorCallback, deferredViewportCallback, bpvcThread
	if "bevelPreviewCallback" not in globals():
		bevelPreviewCallback = []
	if "modelEditorCallback" not in globals():
		modelEditorCallback = []
	if "deferredViewportCallback" not in globals():
		deferredViewportCallback = True
	if "bpvcThread" not in globals():
		bpvcThread = ""
	
	# if callbacks already exists, remove them
	for x in list(bevelPreviewCallback):
		try:
			omui.MUiMessage.removeCallback(x["id"])
			bevelPreviewCallback.remove(x)
		except Exception as e:
			logging.exception(e)
	
	for id in list(modelEditorCallback):
		try:
			om.MEventMessage.removeCallback(id)
			modelEditorCallback.remove(id)
		except Exception as e:
			logging.exception(e)
	
	if isinstance(bpvcThread, Thread):
		bpvcThread.cancelCallback()
		bpvcThread = ""

def bevelPreviewSelectionChangedCallback(*args):
	if not cmds.optionVar(exists="NDB_SelectionChangedCallback"):
		cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))
	NDB_SelectionChangedCallback = cmds.optionVar(query="NDB_SelectionChangedCallback")
	
	if not NDB_SelectionChangedCallback:
		return
	
	executeDeferred(bevelPreviewSelectionChangedFn)

@make_undoable
def bevelPreviewSelectionChangedFn():
	#logging.info("selectionChanged callback!")
	global NDB_LastSelection
	global NDB_LastHilite
	if "NDB_LastSelection" not in globals():
		NDB_LastSelection = []
	if "NDB_LastHilite" not in globals():
		NDB_LastHilite = []

	currentSel = cmds.ls(selection=True, long=True, objectsOnly=True)
	currentHl = cmds.ls(hilite=True, long=True, objectsOnly=True)
	addToSel = []
	removeFromSel = []

	if currentSel:
		# When an object is hilited from the RMB menu, we don't want to change the selection
		componentMode = cmds.selectMode(query=True, component=True)
		# In component mode, we check if we need to modify the bevelPreview source object's visibility
		if componentMode:
			setBevelPreviewSourceVisibility(currentHl)
		
		elif cmds.objectType(tagFromType="gtDynamicBevel"):
			# Get dynamicBevels nodes
			dynamicBevels = cmds.ls(cmds.listHistory(currentSel, future=True, leaf=True), long=True, type="gtDynamicBevel")
			dynamicBevels.extend(cmds.ls(cmds.listHistory(currentSel, leaf=True), long=True, type="gtDynamicBevel"))
			dynamicBevels = list(OrderedDict.fromkeys(dynamicBevels))
			
			if dynamicBevels:
				bevelPreviewDict = {}
				# Detects deselection from global variable... should find a better way
				unselectedObjects = [x for x in NDB_LastSelection if x not in currentSel]

				# Get sourceShapes
				sourceShapes = []
				for dynamicBevel in dynamicBevels:
					sourceShapes = cmds.listConnections("{0}.inputMesh".format(dynamicBevel), source=True, destination=False, shapes=True, type="mesh") or []
					sourceShapes = cmds.ls(list(OrderedDict.fromkeys(sourceShapes)), long=True)
				
					for srcShape in sourceShapes:
						srcObj = next(iter(cmds.listRelatives(srcShape, fullPath=True, parent=True) or []), None)

						#if all([srcObj not in bevelPreviewDict, srcObj not in unselectedObjects, srcShape not in unselectedObjects]):
						if srcObj not in bevelPreviewDict and srcObj not in currentHl:
							bevelPreviewDict[srcObj] = {}
							bevelPreviewDict[srcObj]["shape"] = srcShape

							bevelPreviewShapes = cmds.ls(cmds.listHistory(dynamicBevel, allConnections=True, future=True, leaf=True), long=True, type="gtBevelPreview")
							bevelPreviewShapes = list(OrderedDict.fromkeys(bevelPreviewShapes))
							for bevelPreviewShape in bevelPreviewShapes:
								bevelPreview = next(iter(cmds.listRelatives(bevelPreviewShape, fullPath=True, parent=True) or []), None)
								if bevelPreview:
									bevelPreviewDict[srcObj]["bevelPreview"] = bevelPreview
									bevelPreviewDict[srcObj]["bevelPreviewShape"] = bevelPreviewShape
									if any([bevelPreview in unselectedObjects, bevelPreviewShape in unselectedObjects]):
										removeFromSel.extend([srcObj, srcShape, bevelPreview, bevelPreviewShape])
									break

				for obj, objDict in six.iteritems(bevelPreviewDict):
					if not all([x in objDict for x in ["shape", "bevelPreview", "bevelPreviewShape"]]):
						continue

					if any(x in currentSel for x in [obj, objDict["shape"]]) and not any(x in currentSel for x in [objDict["bevelPreview"], objDict["bevelPreviewShape"]]):
						if objDict["bevelPreview"] not in removeFromSel:
							addToSel.append(objDict["bevelPreview"])
					if any(x in currentSel for x in [objDict["bevelPreview"], objDict["bevelPreviewShape"]]) and not any(x in currentSel for x in [obj, objDict["shape"]]):
						if obj not in removeFromSel:
							addToSel.append(obj)
				
				cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 0))
				if addToSel:
					cmds.select(addToSel, add=True)
				if removeFromSel:
					cmds.select(removeFromSel, deselect=True)
				cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))

				if any([addToSel, removeFromSel]):
					# Refresh any outliner editors
					outliners = cmds.lsUI(editors=True)
					for o in outliners:
						if cmds.outlinerEditor(o, exists=True):
							cmds.outlinerEditor(o, edit=True, refresh=True)
	
	if currentHl != NDB_LastHilite:
		# Detects deselection from global variable... should find a better way
		unHilitedObjects = [x for x in NDB_LastHilite if x not in currentHl]
		if unHilitedObjects:
			setBevelPreviewSourceVisibility(currentHl)
	
	NDB_LastSelection = currentSel + addToSel
	NDB_LastHilite = currentHl

def setBevelPreviewSourceVisibility(excludeList=[], visibility=False):
	if not cmds.objectType(tagFromType="gtDynamicBevel"):
		return
	
	#logging.info("setBevelPreviewSourceVisibility")
	# Get dynamicBevels nodes
	dynamicBevels = cmds.ls(type="gtDynamicBevel", long=True)
	if dynamicBevels:
		# Get sourceShapes
		sourceShapes = []
		for dynamicBevel in dynamicBevels:
			sourceShapes.extend(cmds.listConnections("{0}.inputMesh".format(dynamicBevel), source=True, destination=False, shapes=True, type="mesh") or [])
		sourceShapes = cmds.ls(list(OrderedDict.fromkeys(sourceShapes)), long=True)
		# Get sourceObjects
		sourceObjects = cmds.listRelatives(sourceShapes, fullPath=True, parent=True) or []
		sourceObjects = [x for x in sourceObjects if x not in excludeList]
		#sourceShapes = cmds.listRelatives(sourceObjects, fullPath=True, noIntermediate=True, shapes=True) or []
		bevelPreviewDict = getObjectsWithBevelPreview(sourceObjects)		

		for obj in sourceObjects:
			srcShape = next(iter(cmds.listRelatives(obj, fullPath=True, noIntermediate=True, shapes=True) or []), None)
			if not srcShape:
				continue
			
			bevelDisplayOff = False
			if obj in bevelPreviewDict and "name" in bevelPreviewDict[obj]:
				bevelDisplayOff = any([not cmds.getAttr("{0}.{1}".format(bevelPreviewDict[obj]["name"], attr)) for attr in ["visibility", "lodVisibility"]])

			if visibility or bevelDisplayOff:
				if cmds.attributeQuery("overrideVisibility", node=srcShape, exists=True) and not cmds.getAttr("{0}.overrideVisibility".format(srcShape)):
					cmds.setAttr("{0}.overrideVisibility".format(srcShape), True)
				
				if visibility and obj in bevelPreviewDict:
					dynamicBevel = getDynamicBevelFromObject(srcShape)
					if dynamicBevel and dynamicBevel.hasAttribute("enableXRay"):
						p = dynamicBevel.findPlug("enableXRay", False)
						xRayState = next(iter(cmds.displaySurface(srcShape, query=True, xRay=True) or []))
						if p.asBool() and not xRayState:
							#cmds.displaySurface(srcShape, xRay=True)
							setDisplaySurface(srcShape, xRay=True)
					
					'''if dynamicBevel and dynamicBevel.hasAttribute("enableShading"):
						p = dynamicBevel.findPlug("enableShading", False)
						if p.asBool() != cmds.getAttr("{0}.overrideShading".format(srcShape)):
							cmds.setAttr("{0}.overrideVisibility".format(srcShape), p.asBool())'''

			else:
				if cmds.attributeQuery("overrideEnabled", node=srcShape, exists=True) and not cmds.getAttr("{0}.overrideEnabled".format(srcShape)):
					cmds.setAttr("{0}.overrideEnabled".format(srcShape), True)
				if cmds.attributeQuery("overrideVisibility", node=srcShape, exists=True) and cmds.getAttr("{0}.overrideVisibility".format(srcShape)):
					cmds.setAttr("{0}.overrideVisibility".format(srcShape), False)

def removeSelectionCallback():
	global bevelPreviewSelectionCallback
	if "bevelPreviewSelectionCallback" not in globals():
		bevelPreviewSelectionCallback = []
	
	# if callbacks already exists, remove them	
	for id in list(bevelPreviewSelectionCallback):
		try:
			om.MEventMessage.removeCallback(id)
			bevelPreviewSelectionCallback.remove(id)
		except Exception as e:
			logging.exception(e)
	
	# Clear global variables
	global NDB_LastSelection
	global NDB_LastHilite
	NDB_LastSelection = []
	NDB_LastHilite = []

def createSelectionCallback(setValue=None, toggle=False, startup=False):
	if setValue is not None:
		cmds.optionVar(intValue=("BP_ContextSelectionCallback", setValue))
	elif not cmds.optionVar(exists="BP_ContextSelectionCallback"):
		cmds.optionVar(intValue=("BP_ContextSelectionCallback", False))

	if toggle:
		cmds.optionVar(intValue=("BP_ContextSelectionCallback", not cmds.optionVar(query="BP_ContextSelectionCallback")))

	if startup:
		global bevelPreviewSelectionCallback
		if ("bevelPreviewSelectionCallback" in globals() and bevelPreviewSelectionCallback):
			return

	removeSelectionCallback()

	if cmds.optionVar(query="BP_ContextSelectionCallback"):
		cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))
		# create callbacks
		bevelPreviewSelectionCallback.append(om.MEventMessage.addEventCallback("SelectionChanged", bevelPreviewSelectionChangedCallback))
		#bevelPreviewSelectionCallback.append(om.MEventMessage.addEventCallback("PreSelectionChangedTriggered", bevelPreviewSelectionChangedCallback))

		setBevelPreviewSourceVisibility(visibility=False)
		bevelPreviewShapes = cmds.ls(type="gtBevelPreview", long=True)
		for bps in bevelPreviewShapes:
			for attr, value in [("overrideDisplayType", 0)]:
				if cmds.attributeQuery(attr, node=bps, exists=True) and cmds.getAttr("{0}.{1}".format(bps, attr)) != value:
					cmds.setAttr("{0}.{1}".format(bps, attr), value)
		
		bevelPreviewSelectionChangedCallback()
	
	else:
		setBevelPreviewSourceVisibility(visibility=True)
		bevelPreviewShapes = cmds.ls(type="gtBevelPreview", long=True)
		for bps in bevelPreviewShapes:
			for attr, value in [("overrideEnabled", True), ("overrideDisplayType", 2)]:
				if cmds.attributeQuery(attr, node=bps, exists=True) and cmds.getAttr("{0}.{1}".format(bps, attr)) != value:
					cmds.setAttr("{0}.{1}".format(bps, attr), value)
		
		# Deselect bevelPreviews
		selectedBevelPreview = getSelectedBevelPreviewAndCage()
		if selectedBevelPreview:
			bevelPreviews = []
			for objList in six.itervalues(selectedBevelPreview):
				bevelPreviews.extend(objList)
			cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 0))
			cmds.select(bevelPreviews, deselect=True)
			cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))