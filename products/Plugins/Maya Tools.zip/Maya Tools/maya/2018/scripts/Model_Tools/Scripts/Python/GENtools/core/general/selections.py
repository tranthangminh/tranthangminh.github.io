#!/usr/bin/python
# -*- coding: utf-8 -*-
import re
import copy
import itertools
import maya.cmds as cmds
import maya.api.OpenMaya as om
from collections import defaultdict, OrderedDict

# for python 3 compatibility
import six
from six.moves import range, zip

from ..utils.utils import DefaultOrderedDict

def to_ranges(iterable, orderedList=False):
	if orderedList:
		iterable = list(iterable)
	else:
		iterable = sorted(set(iterable))
	for key, group in itertools.groupby(enumerate(iterable), lambda t: t[1] - t[0]):
		group = list(group)
		yield group[0][1], group[-1][1]

def createComponentDict(components):
	_defaultdict_dict = (lambda: defaultdict(set))
	elementDict = defaultdict(_defaultdict_dict)

	if isinstance(components, six.string_types):
		components = [components]

	if components and isinstance(components, (list, tuple)):
		for e in components:
			try:
				objectName, element = e.split(".")    
				elementStr = element.split("[")[0]
				
				if elementStr == "vtxFace":
					vtxIds, faceIds = re.findall(r"[\w:\*]+", element)[-2:]
					if "*" in [vtxIds, faceIds]:
						elementDict.update(createComponentDict(cmds.ls(e)))
						continue

					vtxRange, faceRange = [[int(i) for i in x.split(":")] for x in [vtxIds, faceIds]]
					
					if len(vtxRange) > 1:
						vtxRange = range(vtxRange[0], vtxRange[1]+1)
					if len(faceRange) > 1:
						faceRange = range(faceRange[0], faceRange[1]+1)
					
					while True:
						if len(vtxRange) > len(faceRange):
							faceRange.append(faceRange[-1])
						elif len(vtxRange) < len(faceRange):
							vtxRange.append(vtxRange[-1])
						else:
							break
					
					idRange = zip(vtxRange, faceRange)

				else:
					ids = re.findall(r"[\w:\*]+", element)[-1].split(":")
					if next(iter(ids)) == "*":
						element = next(iter(cmds.ls(e))).split(".")[-1]
						ids = re.findall(r"[\w:\*]+", element)[-1].split(":")

					idRange = [int(x) for x in ids]
					if len(idRange) > 1:
						idRange = range(idRange[0], idRange[1]+1)
			
				elementDict[objectName][elementStr].update(idRange)
			
			except:
				pass

	return elementDict

def createComponentOrderedDict(components, removeDuplicates=True):
	elementDict = {}

	if isinstance(components, six.string_types):
		components = [components]

	if components and isinstance(components, (list, tuple)):
		_defaultdict_dict = (lambda: DefaultOrderedDict(list))
		elementDict = DefaultOrderedDict(_defaultdict_dict)
		for e in components:
			try:
				objectName, element = e.split(".")    
				elementStr = element.split("[")[0]
				
				if elementStr == "vtxFace":
					vtxIds, faceIds = re.findall(r"[\w:\*]+", element)[-2:]
					if "*" in [vtxIds, faceIds]:
						elementDict.update(createComponentDict(cmds.ls(e)))
						continue

					vtxRange, faceRange = [[int(i) for i in x.split(":")] for x in [vtxIds, faceIds]]
					
					if len(vtxRange) > 1:
						vtxRange = range(vtxRange[0], vtxRange[1]+1)
					if len(faceRange) > 1:
						faceRange = range(faceRange[0], faceRange[1]+1)
					
					while True:
						if len(vtxRange) > len(faceRange):
							faceRange.append(faceRange[-1])
						elif len(vtxRange) < len(faceRange):
							vtxRange.append(vtxRange[-1])
						else:
							break
					
					idRange = zip(vtxRange, faceRange)

				else:
					ids = re.findall(r"[\w:\*]+", element)[-1].split(":")
					if next(iter(ids)) == "*":
						element = next(iter(cmds.ls(e))).split(".")[-1]
						ids = re.findall(r"[\w:\*]+", element)[-1].split(":")

					idRange = [int(x) for x in ids]
					if len(idRange) > 1:
						idRange = range(idRange[0], idRange[1]+1)

				if removeDuplicates:
					elementDict[objectName][elementStr].extend([x for x in idRange if x not in elementDict[objectName][elementStr]])
				else:
					elementDict[objectName][elementStr].extend([x for x in idRange])
			
			except:
				pass

	return elementDict

def getSelectionString(objName, componentDict, orderedList=False):
	selectionStrings = []

	for e, ids in six.iteritems(componentDict):
		for (x, y) in list(to_ranges(ids, orderedList=orderedList)):
			if x == y:
				selectionStrings.append(u"{0}.{1}[{2}]".format(objName, e, x))
			else:
				selectionStrings.append(u"{0}.{1}[{2}:{3}]".format(objName, e, x, y))

	return selectionStrings

def componentListUnion(list1, list2, orderedList=False):
	selectionStrings = []
	if orderedList:
		listDict1 = createComponentOrderedDict(list1)
		listDict2 = createComponentOrderedDict(list2)
	else:
		listDict1 = createComponentDict(list1)
		listDict2 = createComponentDict(list2)

	listDict3 = copy.deepcopy(listDict1)

	for objName, compDict in six.iteritems(listDict2):
		if objName in listDict1:
			for e, ids in six.iteritems(compDict):
				if e in listDict1[objName]:
					set1 = listDict1[objName][e]
					set2 = listDict2[objName][e]
					if orderedList:
						ids = list(set1)
						ids.extend([x for x in set2 if x not in set1])
					else:
						ids = set2.union(set1)
					listDict3[objName][e] = ids
				else:
					listDict3[objName][e] = ids
		else:
			for e, ids in six.iteritems(compDict):
				listDict3[objName][e] = ids
	
	for objName, compDict in six.iteritems(listDict3):
		for e, ids in six.iteritems(compDict):
			for (x, y) in list(to_ranges(ids, orderedList=orderedList)):
				if x == y:
					selectionStrings.append(u"{0}.{1}[{2}]".format(objName, e, x))
				else:
					selectionStrings.append(u"{0}.{1}[{2}:{3}]".format(objName, e, x, y))

	return selectionStrings

def componentListIntersection(list1, list2, orderedList=False):
	selectionStrings = []
	if orderedList:
		listDict1 = createComponentOrderedDict(list1)
		listDict2 = createComponentOrderedDict(list2)
	else:
		listDict1 = createComponentDict(list1)
		listDict2 = createComponentDict(list2)

	for objName, compDict in six.iteritems(listDict1):
		if objName in listDict2:
			for e, ids in six.iteritems(compDict):
				if e in listDict2[objName]:
					set1 = listDict1[objName][e]
					set2 = listDict2[objName][e]
					if orderedList:
						ids = [x for x in set1 if x in set2]
					else:
						ids = set1.intersection(set2)
					for (x, y) in list(to_ranges(ids, orderedList=orderedList)):
						if x == y:
							selectionStrings.append(u"{0}.{1}[{2}]".format(objName, e, x))
						else:
							selectionStrings.append(u"{0}.{1}[{2}:{3}]".format(objName, e, x, y))
	
	return selectionStrings

def componentListDifference(list1, list2, orderedList=False):
	selectionStrings = []
	if orderedList:
		listDict1 = createComponentOrderedDict(list1)
		listDict2 = createComponentOrderedDict(list2)
	else:
		listDict1 = createComponentDict(list1)
		listDict2 = createComponentDict(list2)

	for objName, compDict in six.iteritems(listDict1):
		if objName in listDict2:
			for e, ids in six.iteritems(compDict):
				if e in listDict2[objName]:
					set1 = listDict1[objName][e]
					set2 = listDict2[objName][e]
					if orderedList:
						ids = [x for x in set1 if x not in set2]
					else:
						ids = set1.difference(set2)
					for (x, y) in list(to_ranges(ids, orderedList=orderedList)):
						if x == y:
							selectionStrings.append(u"{0}.{1}[{2}]".format(objName, e, x))
						else:
							selectionStrings.append(u"{0}.{1}[{2}:{3}]".format(objName, e, x, y))
				else:
					for (x, y) in list(to_ranges(ids, orderedList=orderedList)):
						if x == y:
							selectionStrings.append(u"{0}.{1}[{2}]".format(objName, e, x))
						else:
							selectionStrings.append(u"{0}.{1}[{2}:{3}]".format(objName, e, x, y))
		else:
			for e, ids in six.iteritems(compDict):
				for (x, y) in list(to_ranges(ids, orderedList=orderedList)):
					if x == y:
						selectionStrings.append(u"{0}.{1}[{2}]".format(objName, e, x))
					else:
						selectionStrings.append(u"{0}.{1}[{2}:{3}]".format(objName, e, x, y))
	
	return selectionStrings

def getComponentCount(list1):
	componentCount = 0
	listDict1 = createComponentDict(list1)

	if not listDict1:
		return None

	for compDict in six.itervalues(listDict1):
		for ids in six.itervalues(compDict):
			componentCount += len(ids)
	
	return componentCount

def getComponentIds(list1):
	componentIds = []
	listDict1 = createComponentDict(list1)

	for compDict in six.itervalues(listDict1):
		for ids in six.itervalues(compDict):			
			componentIds.extend(sorted(ids))
	
	return componentIds

def getSortedVertexFaces(list1):
	sortedVertexFaces = []
	_defaultdict_dict = (lambda: defaultdict(set))
	vertexFacesDict = defaultdict(_defaultdict_dict)
	listDict1 = createComponentDict(list1)

	for objName, compDict in six.iteritems(listDict1):
		if "vtxFace" in compDict:
			for vertexId, faceId in compDict["vtxFace"]:			    
				vertexFacesDict[objName][vertexId].update([faceId])

	for objName, vertexFaceDict in six.iteritems(vertexFacesDict):
		for vertexId, faceIds in six.iteritems(vertexFaceDict):
			sortedVertexFaces.append(["{0}.vtxFace[{1}][{2}]".format(objName, vertexId, faceId) for faceId in faceIds])

	return sortedVertexFaces

def flattenList(list1, orderedList=False, removeDuplicates=True):
	selectionStrings = []
	if orderedList:
		listDict1 = createComponentOrderedDict(list1, removeDuplicates=removeDuplicates)
	else:
		listDict1 = createComponentDict(list1)

	for objName, compDict in six.iteritems(listDict1):
		for e, ids in six.iteritems(compDict):
			if not orderedList:
				ids = sorted(ids)
			for id in ids:
				if isinstance(id, (tuple, list)):
					selStr = u"{0}.{1}".format(objName, e)
					for i in id:
						selStr += "[{0}]".format(i)
					selectionStrings.append(selStr)
				else:
					selectionStrings.append(u"{0}.{1}[{2}]".format(objName, e, id))
	
	return selectionStrings

def getCurrentSel(*args, **kwargs):
	# Create default args
	objects = None
	allParents = False
	allDescendents = False
	orderedSelection = False

	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			objects = arg
		elif i == 1:
			allParents = arg
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "objects" or key == "obj":
			objects = value
		elif key == "allParents" or key == "ap":
			allParents = value
		elif key == "allDescendents" or key == "ad":
			allDescendents = value
		elif key == "orderedSelection" or key == "os":
			orderedSelection = value

	# Get selected objects
	if orderedSelection:
		currentSel = cmds.ls(orderedSelection=True, long=True)
	else:
		currentSel = cmds.ls(selection=True, long=True)
	currentHl = cmds.ls(hilite=True, long=True)
	if objects is None:
		objects = list(currentHl)
		objects.extend(currentSel)
	
	# Get selected objects
	if not allDescendents:
		objectShapes = cmds.ls(objects, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
	else:
		objectShapes = cmds.ls(cmds.listRelatives(allDescendents=True, fullPath=True, type="mesh"), long=True, noIntermediate=True)
	if not allParents:
		objects = cmds.listRelatives(objectShapes, fullPath=True, parent=True, noIntermediate=True, type="transform")
	else:
		objects = cmds.listRelatives(objectShapes, fullPath=True, allParents=True, noIntermediate=True, type="transform")
	
	# Remove intermediate objects
	objects = cmds.ls(objects, long=True, noIntermediate=True)
	# Remove duplicates objects
	if objects is not None:
		objects = list(OrderedDict.fromkeys(objects))
	
	return currentSel, currentHl, objects

def componentDictionary(selection, flatten=False):
	if selection is None:
		return {}

	# Create default args
	objectSelDict = defaultdict(list)
	#objectList = []
	#vertSelList = []
	#filter = om.MFn.kMeshVertComponent
	
	selList = om.MSelectionList()
	for each in selection:
		try:
			selList.add(each)
		except:
			pass
	
	compList = om.MSelectionList()
	
	for each in range(selList.length()):
		dagPath, component = selList.getComponent(each)
		dagPath.pop() # Remove shape
		node = dagPath.fullPathName()
		
		# Add current components to selectionList
		compList.clear()
		compList.add((dagPath, component))
		
		# Get selection strings
		objComponents = cmds.ls(compList.getSelectionStrings(), long=True, flatten=flatten)
		
		# Add to dictionary
		objectSelDict[node].extend(objComponents)
		#objectList.append(node)
		#vertSelList.extend(objComponents)

	return objectSelDict

def getComponentType(*args, **kwargs):
	selTypes = []

	# Create default args
	currentSel = []
	selection = False
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			if not isinstance(arg, (list, tuple)):
				currentSel = [arg]
			else:
				currentSel = arg
		elif i == 1:
			selection = bool(arg)
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = bool(value)
	
	if selection:
		currentSel.extend(cmds.ls(selection=True, long=True))

	if currentSel:
		selList = om.MSelectionList()
		for each in currentSel:
			try:
				selList.add(each)
			except:
				pass
		
		if not selList.isEmpty():
			filterDict = []
			filterDict.append(("v", om.MFn.kMeshVertComponent))
			filterDict.append(("eg", om.MFn.kMeshEdgeComponent))
			filterDict.append(("fc", om.MFn.kMeshPolygonComponent))
			filterDict.append(("puv", om.MFn.kMeshMapComponent))
			filterDict.append(("pvf", om.MFn.kMeshVtxFaceComponent))
			#filterDict.append(("cv", om.MFn.kCurveCVComponent))
			filterDict = OrderedDict(filterDict)
			
			for key, filter in six.iteritems(filterDict):
				sel_iter = om.MItSelectionList(selList, filter)
				try:
					if sel_iter.hasComponents() is True:
						#return key
						selTypes.append(key)
				except:
					pass
	
	return selTypes

def filterSelectedComponents(*args, **kwargs):
	compList = om.MSelectionList()

	# Create default args
	currentSel = []
	selection = False
	componentType = []
	
	# Load arguments (override default args)
	for i, arg in enumerate(args):
		if i == 0:
			if not isinstance(arg, (list, tuple)):
				currentSel = [arg]
			else:
				currentSel = arg
		elif i == 1:
			if isinstance(arg, (tuple, list)):
				componentType = arg
			else:
				componentType = [arg]
	
	# Load keyworded arguments (override *args)
	for key, value in six.iteritems(kwargs):
		if key == "selection" or key == "sel":
			selection = bool(value)
		elif key == "componentType" or "ct":
			if isinstance(value, (tuple, list)):
				componentType = value
			else:
				componentType = [value]
		
	if selection:
		currentSel.extend(cmds.ls(selection=True, long=True))

	if currentSel:
		selList = om.MSelectionList()
		for each in currentSel:
			try:
				selList.add(each)
			except:
				pass
		
		if not selList.isEmpty():
			filterDict = []
			for cType in componentType:
				omType = None
				if cType == "v":
					omType = om.MFn.kMeshVertComponent
				elif cType == "eg":
					omType = om.MFn.kMeshEdgeComponent
				elif cType == "fc":
					omType = om.MFn.kMeshPolygonComponent
				elif cType == "puv":
					omType = om.MFn.kMeshMapComponent
				elif cType == "pvf":
					omType = om.MFn.kMeshVtxFaceComponent
				elif cType == "cv":
					omType = om.MFn.kCurveCVComponent

				if omType:
					filterDict.append((cType, omType))
			
			filterDict = OrderedDict(filterDict)
			
			for key, filter in six.iteritems(filterDict):
				sel_iter = om.MItSelectionList(selList, filter)

				while not sel_iter.isDone():
					try:
						if sel_iter.hasComponents() is True:
							compList.add(sel_iter.getComponent(), mergeWithExisting=True)
					except:
						pass
					finally:
						sel_iter.next()
	
	return cmds.ls(compList.getSelectionStrings(), long=True)
