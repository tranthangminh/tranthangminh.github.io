#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import time
import inspect
import logging
import threading
import maya.cmds as cmds
from maya import OpenMaya
from functools import partial
import maya.api.OpenMaya as om
import maya.api.OpenMayaUI as omui
import maya.api.OpenMayaRender as omr
from collections import defaultdict, OrderedDict
from maya.utils import executeDeferred, executeInMainThreadWithResult

# for python 3 compatibility
from six.moves import range

try:
	from GENtools.tools.PlacementTool.PlacementTool import CreatePrimitiveLive
except:
	CreatePrimitiveLive = None

from GENtools.core.general.nodes import MayaNode
from GENtools.core.general.attributes import plugMatch
from GENtools.core.utils.listeners import getMayaInputState
from GENtools.core.general.materials import getMainMaterial
from GENtools.core.general.decorators import make_undoable, make_thread_safe
#from GENtools.tools.NonDestructiveBevel.bevelpreview.xray import xRayOverride
from GENtools.tools.NonDestructiveBevel.bevelpreview.callbacks import createViewportCallback, createSelectionCallback, removeViewportCallback, removeSelectionCallback, bevelPreviewSelectionChangedCallback
from GENtools.tools.NonDestructiveBevel.bevelpreview.miscs import getDynamicBevelFromObject

# Create logger
'''logging.basicConfig(level=logging.DEBUG)

# Set logging handler
from maya.utils import MayaGuiLogHandler
handler = MayaGuiLogHandler()
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter("%(asctime)s %(message)s")
handler.setFormatter(formatter)
logging.root.handlers = []
logging.getLogger("").addHandler(handler)'''

#logging.disable(logging.NOTSET)
#logging.disable(logging.CRITICAL)

ROOT_DIR = os.path.dirname(os.path.realpath(inspect.getfile(lambda: None)))

def maya_useNewAPI():
	pass

def getHardEdgeIds(mesh):
	edgeIter = om.MItMeshEdge(mesh)
	ids = []
	while not edgeIter.isDone():
		if not edgeIter.isSmooth:
			ids.append(edgeIter.index())
		edgeIter.next()
	return ids

def idsToCompObj(ids, componentType):
	sic = om.MFnSingleIndexedComponent()
	sic.create(componentType) # om.MFn.kMeshEdgeComponent
	sic.addElements(ids)

	compData = om.MFnComponentListData()
	compObj = compData.create()
	compData.add(sic.object())

	return (sic.object(), compObj)

def softSelectionToSelection(ignoreSel=None):
	softSelection = om.MGlobal.getRichSelection()
	selList = softSelection.getSelection()

	compList = om.MSelectionList()
	removeList = om.MSelectionList()

	for each in range(selList.length()):
		dagPath, component = selList.getComponent(each)
		dagPath.pop() # Remove shape

		# Add current components to selectionList
		compList.add((dagPath, component))
	
	if ignoreSel is not None:
		selList = om.MSelectionList()
		for each in ignoreSel:
			selList.add(each)
		
		for each in range(selList.length()):
			dagPath, component = selList.getComponent(each)
			dagPath.pop() # Remove shape

			# Add current components to selectionList
			removeList.add((dagPath, component))

	# Remove elements if any
	if not removeList.isEmpty():
		compList.merge(removeList, om.MSelectionList.kRemoveFromList)
	# Get selection strings
	elements = compList.getSelectionStrings()
	# Return full path strings
	elements = cmds.ls(elements, long=True)
	
	return elements

def getNearVertices(ignoreSel=None):
	maxDistance = 0.001
	nearVertices = []
	
	# Store softSelect current values
	softSelectEnabled = cmds.softSelect(query=True, softSelectEnabled=True)
	softSelectDistance = cmds.softSelect(query=True, softSelectDistance=True)
	softSelectColorCurve = cmds.softSelect(query=True, softSelectCurve=True)
	softSelectFalloff = cmds.softSelect(query=True, softSelectFalloff=True)

	try:
		# Disable symmetry to avoid warnings
		symmetryEnabled = cmds.symmetricModelling(query=True, symmetry=True)
		if symmetryEnabled:
			cmds.symmetricModelling(edit=True, symmetry=0)
		
		# Set softSelect to global with a flat falloff
		cmds.softSelect(edit=True, softSelectEnabled=1, softSelectDistance=maxDistance, softSelectCurve="1,0,0,0,1,2", softSelectFalloff=2)

		# Find vertices located inside the maximum distance radius
		nearVertices = softSelectionToSelection(ignoreSel=ignoreSel)

		# Restore softSelect values
		cmds.softSelect(edit=True,
						softSelectEnabled=softSelectEnabled, 
						softSelectDistance=softSelectDistance,
						softSelectColorCurve=softSelectColorCurve,
						softSelectFalloff=softSelectFalloff)
		
	except Exception as e:
		logging.exception(e)
	
	return nearVertices

def createMeshFromPoints(vertices, polygonCounts, polygonConnects):
	try:
		# Create mesh
		mesh = om.MFnMesh()
		mesh_object = mesh.create(vertices, polygonCounts, polygonConnects)
		mesh.updateSurface() # Signal that this polygonal mesh needs to be redrawn

		# Assign default shading
		#cmds.sets(mesh.name(), edit=True, forceElement="initialShadingGroup")

		# Get objectName
		dagNode = om.MFnDagNode(mesh_object)
		dagPath = dagNode.getPath()
		objectName = dagPath.fullPathName()
		
		return objectName
	
	except Exception as e:
		logging.exception(e)
	
	return None

def getPointsFromMesh(obj):
	try:
		if obj:
			selList = om.MSelectionList()
			selList.add(obj)

			dagPath = selList.getDagPath(0)
			if dagPath.isValid():
				fnMesh = om.MFnMesh(dagPath)
				vertices = fnMesh.getPoints(om.MSpace.kObject)
				polygonCounts, polygonConnects = fnMesh.getVertices()

				return {"vertices": vertices, "polygonCounts": polygonCounts, "polygonConnects": polygonConnects}
	except Exception as e:
		logging.exception(e)
	
	return None

def componentDictionary(selection, flatten=False):
	if selection is None:
		return {}

	# Create default args
	objectSelDict = defaultdict(list)
	#objectList = []
	#vertSelList = []
	#filter = om.MFn.kMeshVertComponent
	
	selList = om.MSelectionList()
	for each in selection:
		try:
			selList.add(each)
		except:
			pass
	
	compList = om.MSelectionList()
	
	for each in range(selList.length()):
		dagPath, component = selList.getComponent(each)
		dagPath.pop() # Remove shape
		node = dagPath.fullPathName()
		
		# Add current components to selectionList
		compList.clear()
		compList.add((dagPath, component))
		
		# Get selection strings
		objComponents = cmds.ls(compList.getSelectionStrings(), long=True, flatten=flatten)
		
		# Add to dictionary
		objectSelDict[node].extend(objComponents)
		#objectList.append(node)
		#vertSelList.extend(objComponents)

	return objectSelDict

def findObjectFromData(vertices, polygonCounts, polygonConnects, objMatrix, excludeSel=None):
	closestObject = None
	nearVertices = []

	if all([vertices, polygonCounts, polygonConnects, objMatrix]):
		undoState = cmds.undoInfo(query=True, state=True)
		if undoState:
			cmds.undoInfo(stateWithoutFlush=False)
		try:
			# Store current selection
			currentSel = cmds.ls(selection=True)
			currentHl = cmds.ls(hilite=True)

			# Create object
			newObject = createMeshFromPoints(vertices, polygonCounts, polygonConnects)
			cmds.xform(newObject, matrix=objMatrix, worldSpace=True)

			# Find vertices near object
			vertexSel = cmds.polyListComponentConversion(newObject, toVertex=True)
			ignoreSel = list(vertexSel)
			if excludeSel:
				ignoreSel.extend(cmds.polyListComponentConversion(excludeSel, toVertex=True))
			
			if vertexSel:
				cmds.select(vertexSel)
				nearVertices = getNearVertices(ignoreSel=ignoreSel)

			# Delete object
			cmds.delete(newObject)

			# Restore selection
			cmds.hilite(currentHl)
			cmds.select(currentSel)

		except Exception as e:
			logging.exception(e)
		
		finally:
			if undoState:
				cmds.undoInfo(stateWithoutFlush=True)

	if nearVertices:
		# Find the object with the largest component list
		nearVerticesDict = componentDictionary(nearVertices, flatten=True)
		closestObject = max(nearVerticesDict, key=lambda x:len(set(nearVerticesDict[x])))

	return closestObject

#@deferred_thread_safe
def getDataFromObject(obj):
	objectTransform, objectShape = None, None

	if cmds.objExists(obj or ""):

		if cmds.objectType(obj) == "transform":
			objectTransform = obj
			objectShape = next(iter(cmds.listRelatives(obj, fullPath=True, noIntermediate=True, shapes=True) or []), None)
		elif cmds.objectType(obj) == "mesh":
			objectTransform = next(iter(cmds.listRelatives(obj, fullPath=True, parent=True) or []), None)
			objectShape = obj

		if all([objectTransform, objectShape]):
			dataDict = getPointsFromMesh(objectShape)
			if dataDict:
				objMatrix = cmds.xform(objectTransform, query=True, matrix=True, worldSpace=True)

				return {"vertices": dataDict["vertices"], "polygonCounts": dataDict["polygonCounts"], "polygonConnects": dataDict["polygonConnects"], "matrix": objMatrix}

	return {}

@make_undoable
@make_thread_safe
def setDisplaySurface(*args, **kwargs):
	# Create default args
	targetObject = None

	if args and cmds.objExists(args[0] or ""):
		targetObject = args[0]

	if targetObject:
		try:
			cmds.displaySurface(*args, **kwargs)
		except Exception as e:
			logging.exception(e)

@make_undoable
def changeXRay(objName, plugAttr):
	try:
		plugValue = cmds.getAttr(plugAttr)
		if cmds.objExists(objName):
			#logging.info("Set xRay: {0}".format(plugValue))
			#xRayState = next(iter(cmds.displaySurface(objName, query=True, xRay=True) or []))
			#xRayState = xRayOverride.getXRay(objName)
			#if xRayState != plugValue:
				#xRayOverride.createOverride()
				#cmds.displaySurface(objName, xRay=plugValue)
				#xRayOverride.setXRay(objName, xRay=plugValue)
			cmds.displaySurface(objName, xRay=plugValue)

	except Exception as e:
		logging.exception(e)

@make_undoable
def disableXRay(plug, deferred=False):
	#logging.info("Disable xRay")
	inputMObject = plug.node()
	if inputMObject.hasFn(om.MFn.kMesh):
		dagNode = om.MFnDagNode(inputMObject)
		dagPath = dagNode.getPath()
		if dagPath.isValid() and not dagNode.isIntermediateObject:
			if deferred:
				cmds.evalDeferred(partial(setDisplaySurface, dagPath.fullPathName(), xRay=False))
			else:
				cmds.displaySurface(dagPath.fullPathName(), xRay=False)
				#xRayOverride.setXRay(dagPath.fullPathName(), xRay=False)

def safeConnect(plugSource, plugTarget, **kwargs):
	try:
		if not cmds.isConnected(plugSource, plugTarget):
			cmds.connectAttr(plugSource, plugTarget, **kwargs)
	except Exception as e:
		logging.exception(e)

def safeAddAttr(*args, **kwargs):
	# Create default args
	targetObject = None
	longName = None

	if args and cmds.objExists(args[0] or ""):
		targetObject = args[0]

	if "longName" in kwargs:
		longName = kwargs["longName"]
	elif "ln" in kwargs:
		longName = kwargs["ln"]

	if targetObject and longName:
		if not cmds.attributeQuery(longName, node=targetObject, exists=True):
			cmds.addAttr(*args, **kwargs)

def safeDeleteAttr(plugAttr):
	try:
		if plugAttr:
			plugAttrSplit = plugAttr.split(".", 1)[:2]
			if len(plugAttrSplit) == 2:
				if cmds.objExists(plugAttrSplit[0]):
					cmds.deleteAttr(plugAttr)
	except Exception as e:
		logging.exception(e)

def safeDelete(objectName):
	try:
		if objectName:
			if cmds.objExists(objectName):
				cmds.delete(objectName)
	except Exception as e:
		logging.exception(e)

def getFullPathPlugs(plugs):
	fullPathPlugs = []

	if isinstance(plugs, om.MPlug):
		plugs = [plugs]

	try:
		for x in plugs:
			if isinstance(x, om.MPlug):
				try:
					dagNode = om.MFnDagNode(x.node())
					attribute = x.attribute()
					fullPathPlugs.append(dagNode.fullPathName()+"."+attribute.name())
					continue
				except:
					fullPathPlugs.append(x.name())
			else:
				fullPathPlugs.append(str(x))
	except Exception as e:
		logging.exception(e)

	return fullPathPlugs

def getPlugValue(plug, attr=None):
	"""
	Gets the value of the given plug.

	@param plug: MPlug. The node plug.
	@param attr: MPlug. The node attribute.
	@return: The value of the passed in node plug.
	"""
	if not (attr and isinstance(attr, om.MObject)):
		attr = plug.attribute()
	apiType = attr.apiType()

	# Float Groups - rotate, translate, scale; Compounds
	if apiType in [om.MFn.kAttribute3Double, om.MFn.kAttribute3Float, om.MFn.kCompoundAttribute]:
		result = []
		if plug.isCompound():
			for c in range(plug.numChildren()):
				result.append(getPlugValue(plug.child(c)))
			return result

	# Distance
	elif apiType in [om.MFn.kDoubleLinearAttribute, om.MFn.kFloatLinearAttribute]:
		uiUnit = plug.asMDistance().uiUnit()
		dVal = plug.asMDistance().asUnits(uiUnit)
		return dVal

	# Angle
	elif apiType in [om.MFn.kDoubleAngleAttribute, om.MFn.kFloatAngleAttribute]:
		return plug.asMAngle().asDegrees()

	# Typed
	elif apiType == om.MFn.kTypedAttribute:
		pType = om.MFnTypedAttribute(attr).attrType()
		
		# Matrix
		if pType == om.MFnData.kMatrix:
			#return om.MFnMatrixData(plug.asMObject()).matrix()
			return plug.asMDataHandle().asMatrix()
		
		# String
		elif pType == om.MFnData.kString:
			return plug.asString()
	
	# Matrix
	elif apiType == om.MFn.kMatrixAttribute:
		#return om.MFnMatrixData(plug.asMObject()).matrix()
		return plug.asMDataHandle().asMatrix()

	# Numbers
	elif apiType == om.MFn.kNumericAttribute:
		pType = om.MFnNumericAttribute(attr).numericType()

		if pType == om.MFnNumericData.kBoolean:
			return plug.asBool()
		
		elif pType in [om.MFnNumericData.kShort, om.MFnNumericData.kInt, om.MFnNumericData.kLong, om.MFnNumericData.kByte]:
			return plug.asInt()
		
		elif pType in [om.MFnNumericData.kFloat, om.MFnNumericData.kDouble, om.MFnNumericData.kAddr]:
			return plug.asDouble()
	
	# Enum
	elif apiType == om.MFn.kEnumAttribute:
		return plug.asInt()

	return None

@make_undoable
def changeAttr(plugTarget, plugSource):
	try:
		plugValue = cmds.getAttr(plugSource)
		#logging.info("Change shading: {0}".format(plugValue))
		cmds.setAttr(plugTarget, plugValue)
	except Exception as e:
		logging.exception(e)

@make_undoable
def changeBevelDisplay(mObj, dagPath):
	# if "Enable Bevel Display" is off and Cage Display in "Component Mode", turn object visibility back on 
	if cmds.optionVar(exists="NDB_CageDisplay"):
		cageDisplay = cmds.optionVar(query="NDB_CageDisplay")
		if cageDisplay in [1, 3]:
			dependencyNode = om.MFnDependencyNode(dagPath.node())
			if dependencyNode.typeName == "mesh":
				if dependencyNode.hasAttribute("overrideVisibility"):
					dPlug = dependencyNode.findPlug("overrideVisibility", False)
					
					dNode = om.MFnDependencyNode(mObj)
					if dNode.hasAttribute("enableBevelDisplay"):
						plug = dNode.findPlug("enableBevelDisplay", False)

						currentHl = cmds.ls(hilite=True, long=True, dagObjects=True, noIntermediate=True, objectsOnly=True, type="mesh")
						xRayState = next(iter(cmds.displaySurface(dagPath.fullPathName(), query=True, xRay=True) or []))

						setXray = False
						if cageDisplay == 1:
							setXray = True
						
						# enable bevel display
						if plug.asBool():
							if cageDisplay == 3:
								# If object is not hilited
								if dagPath.fullPathName() not in currentHl:
									# hide source object
									dPlug.setBool(False)
								else:
									setXray = True
							
							# If object is hilited and xRay not detected
							if setXray and not xRayState:
								# enable xRay if the plug is enabled
								if dNode.hasAttribute("enableXRay"):
									xRayPlug = dNode.findPlug("enableXRay", False)
									if xRayPlug.asBool():
										#setDisplaySurface(dagPath.fullPathName(), xRay=True)
										cmds.evalDeferred(partial(setDisplaySurface, dagPath.fullPathName(), xRay=True), lowestPriority=True)
							
							if dNode.hasAttribute("enableShading"):
								sPlug = dNode.findPlug("enableShading", False)
								# set override shading
								if dependencyNode.hasAttribute("overrideShading"):
									p = dependencyNode.findPlug("overrideShading", False)
									p.setBool(sPlug.asBool())

						# disable bevel display
						else:
							if cageDisplay == 3:
								# show source object
								dPlug.setBool(True)
							
							# force disable xRay
							if xRayState:
								#setDisplaySurface(dagPath.fullPathName(), xRay=False)
								cmds.evalDeferred(partial(setDisplaySurface, dagPath.fullPathName(), xRay=False), lowestPriority=True)
								cmds.evalDeferred(partial(setDisplaySurface, dagPath.fullPathName(), xRay=False), lowestPriority=True)
					
							# force enable shading
							if dependencyNode.hasAttribute("overrideShading"):
								p = dependencyNode.findPlug("overrideShading", False)
								p.setBool(True)

@make_undoable
@make_thread_safe
def forceSetAttr(plugAttr, value):
	try:
		if plugAttr:
			plugSplit = plugAttr.split(".")
			if len(plugSplit) >= 2 and cmds.objExists(plugSplit[0]):
				# Check if attribute already set
				if cmds.attributeQuery(plugSplit[1], node=plugSplit[0], exists=True) and cmds.getAttr(plugAttr) != value:
					# Make sure it's not locked
					if cmds.getAttr(plugAttr, lock=True):
						cmds.setAttr(plugAttr, lock=False)
					# Set attribute
					cmds.setAttr(plugAttr, value)
	except Exception as e:
		logging.exception(e)

@make_undoable
def enableShading(plug, deferred=False):
	#logging.info("Enable Shading")
	inputMObject = plug.node()
	if inputMObject.hasFn(om.MFn.kMesh):
		dagNode = om.MFnDagNode(inputMObject)
		dagPath = dagNode.getPath()
		objectName = dagPath.fullPathName()
		if deferred:
			cmds.evalDeferred(partial(forceSetAttr, objectName+".overrideEnabled", False))
			cmds.evalDeferred(partial(forceSetAttr, objectName+".overrideVisibility", True))
			cmds.evalDeferred(partial(forceSetAttr, objectName+".overrideShading", True))
			cmds.evalDeferred(partial(forceSetAttr, objectName+".overrideColor", 0))
		else:
			forceSetAttr(objectName+".overrideEnabled", False)
			forceSetAttr(objectName+".overrideVisibility", True)
			forceSetAttr(objectName+".overrideShading", True)
			forceSetAttr(objectName+".overrideColor", 0)

@make_undoable
def deleteUnconnectedNode(node, attr, **kwargs):
	try:
		connections = cmds.listConnections(node+attr, **kwargs)
		for c in list(connections or []):
			if not cmds.objExists(c):
				connections.remove(c)
		if not connections and cmds.objExists(node):
			cmds.delete(node)
	except Exception as e:
		logging.exception(e)

def forceConnectMaterial(objectName, materialName):
	cmds.undoInfo(openChunk=True, chunkName="NDB_ForceConnectMaterial")
	try:
		cmds.sets(objectName, edit=True, forceElement=materialName)
	except Exception as e:
		logging.exception(e)
	finally:
		cmds.undoInfo(closeChunk=True)

@make_undoable
def propagateMaterial(sourceObjName, targetObjName):
	if all([cmds.objExists(sourceObjName), cmds.objExists(targetObjName)]):
		#logging.info("propagate material!")
		materialsDict = getMainMaterial(sourceObjName)
		if sourceObjName in materialsDict:
			shadingGroup = materialsDict[sourceObjName]
			cmds.sets(targetObjName, edit=True, forceElement=shadingGroup)

def getBevelPreviewSourceObject(bevelPreview=[]):
	if bevelPreview:
		# Get dynamicBevels nodes
		dynamicBevels = cmds.ls(cmds.listHistory(bevelPreview, future=True, leaf=True), long=True, type="gtDynamicBevel")
		dynamicBevels.extend(cmds.ls(cmds.listHistory(bevelPreview, leaf=True), long=True, type="gtDynamicBevel"))
		dynamicBevels = list(OrderedDict.fromkeys(dynamicBevels))
		
		if dynamicBevels:
			# Get sourceShapes
			sourceShapes = []
			for dynamicBevel in dynamicBevels:
				sourceShapes.extend(cmds.listConnections("{0}.inputMesh".format(dynamicBevel), source=True, destination=False, shapes=True, type="mesh") or [])
			sourceShapes = cmds.ls(list(OrderedDict.fromkeys(sourceShapes)), long=True)
			# Get sourceObjects
			sourceObjects = cmds.listRelatives(sourceShapes, fullPath=True, parent=True) or []
			
			return sourceObjects
	return []

class GetHardEdgesNode(om.MPxNode):
	kNodeName = "gtGetHardEdges"
	kNodeId = om.MTypeId(0x11573)

	aForceCompute = None
	aInputMesh = None
	aIds = None

	def __init__(self):
		super(GetHardEdgesNode, self).__init__()

		self._numVertices = 0
		self._numPolygons = 0
		self._numNormals = 0
		self._forceCompute = False
		self._faceVertexCount = []
		self._faceVertexIds = []

	@classmethod
	def creator(cls):
		return cls()

	@classmethod
	def initialize(cls):
		fcAttr = om.MFnNumericAttribute()
		cls.aForceCompute = fcAttr.create("forceCompute", "fc", om.MFnNumericData.kBoolean, False)
		fcAttr.writable = False
		fcAttr.readable = False
		fcAttr.connectable = False
		fcAttr.hidden = True

		tAttr = om.MFnTypedAttribute()
		cls.aInputMesh = tAttr.create("inMesh", "i", om.MFnData.kMesh, om.MObject.kNullObj)
		tAttr.writable = True
		tAttr.readable = False
		tAttr.storable = False
		tAttr.hidden = True

		cAttr = om.MFnTypedAttribute()
		cls.aIds = cAttr.create("componentList", "cl", om.MFnComponentListData.kComponentList)
		cAttr.writable = False
		cAttr.readable = True
		cAttr.storable = False

		om.MPxNode.addAttribute(cls.aForceCompute)
		om.MPxNode.addAttribute(cls.aInputMesh)
		om.MPxNode.addAttribute(cls.aIds)

		om.MPxNode.attributeAffects(cls.aInputMesh, cls.aIds)
		om.MPxNode.attributeAffects(cls.aForceCompute, cls.aIds)

	def postConstructor(self):
		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		dependencyNode.setName("getHardEdges#")

	def attrToPlug(self, attr):
		return om.MPlug(self.thisMObject(), attr)

	def setDependentsDirty(self, plug, affect):
		if plugMatch(plug, [GetHardEdgesNode.aInputMesh, GetHardEdgesNode.aForceCompute]):
			if plug == GetHardEdgesNode.aForceCompute and self._forceCompute:
				self._forceCompute = False
				return
			affect.append(self.attrToPlug(GetHardEdgesNode.aIds))

	def compute(self, plug, data):
		if plug != GetHardEdgesNode.aIds:
			return None

		computeHardEdges = False

		inMeshHandle = data.inputValue(GetHardEdgesNode.aInputMesh)
		inMesh = inMeshHandle.asMesh()
		inMeshFn = om.MFnMesh(inMesh)
		_faceVertexCount, _faceVertexIds = inMeshFn.getVertices()
		_faceVertexCount, _faceVertexIds = list(_faceVertexCount), list(_faceVertexIds)
		forceComputePlug = self.attrToPlug(GetHardEdgesNode.aForceCompute)

		if self._numVertices != inMeshFn.numVertices or self._numPolygons != inMeshFn.numPolygons or self._numNormals != inMeshFn.numNormals or self._faceVertexCount != _faceVertexCount or self._faceVertexIds != _faceVertexIds:
			self._numVertices = inMeshFn.numVertices
			self._numPolygons = inMeshFn.numPolygons
			self._numNormals = inMeshFn.numNormals
			self._faceVertexCount, self._faceVertexIds = _faceVertexCount, _faceVertexIds
			computeHardEdges = True
		else:
			#logging.info("force compute?")
			if forceComputePlug.asBool():
				#logging.info("force compute!")
				forceComputePlug.setBool(False)
				self._forceCompute = True
				computeHardEdges = True

		if computeHardEdges:
			#logging.info("compute hard edges")
			forceComputePlug.setBool(False)
			hardEdgeIds = getHardEdgeIds(inMesh)
			compObj = idsToCompObj(hardEdgeIds, om.MFn.kMeshEdgeComponent)[1]

			outIdsHandle = data.outputValue(GetHardEdgesNode.aIds)
			outIdsHandle.setMObject(compObj)
			outIdsHandle.setClean()

class TransferVertexNormalsNode(om.MPxNode):
	kNodeName = "gtTransferVertexNormals"
	kNodeId = om.MTypeId(0x15948)

	aInputMesh = None
	aSourceMesh = None
	aOutput = None
	aForceCompute = None

	def __init__(self):
		super(TransferVertexNormalsNode, self).__init__()
		self._idle_callback = []
		self._compute_deferred = "action"
		self._polyBevelDict = None

	@classmethod
	def creator(cls):
		return cls()

	@classmethod
	def initialize(cls):
		wTypeAttr = om.MFnTypedAttribute()
		cls.aInputMesh = wTypeAttr.create("inputMesh", "in", om.MFnData.kMesh, om.MObject.kNullObj)
		wTypeAttr.writable = True
		wTypeAttr.readable = False
		wTypeAttr.hidden = True
		om.MPxNode.addAttribute(cls.aInputMesh)

		srcTypeAttr = om.MFnTypedAttribute()
		cls.aSourceMesh = srcTypeAttr.create("sourceMesh", "src", om.MFnData.kMesh, om.MObject.kNullObj)
		srcTypeAttr.writable = True
		srcTypeAttr.readable = False
		srcTypeAttr.hidden = True
		om.MPxNode.addAttribute(cls.aSourceMesh)

		rTypeAttr = om.MFnTypedAttribute()
		cls.aOutput = rTypeAttr.create("output", "out", om.MFnData.kMesh, om.MObject.kNullObj)
		rTypeAttr.writable = False
		rTypeAttr.readable = True
		om.MPxNode.addAttribute(cls.aOutput)

		fcAttr = om.MFnNumericAttribute()
		cls.aForceCompute = fcAttr.create("forceCompute", "fc", om.MFnNumericData.kBoolean, False)
		fcAttr.writable = False
		fcAttr.readable = False
		fcAttr.hidden = True
		om.MPxNode.addAttribute(cls.aForceCompute)

		om.MPxNode.attributeAffects(cls.aInputMesh, cls.aOutput)
		om.MPxNode.attributeAffects(cls.aSourceMesh, cls.aOutput)
		om.MPxNode.attributeAffects(cls.aForceCompute, cls.aOutput)

	def postConstructor(self):
		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		dependencyNode.setName("transferVertexNormals#")

	def createCallback(self):
		#logging.info("create callback")
		self._idle_callback.append(om.MEventMessage.addEventCallback("idleVeryLow", self.deferredCompute))
		#self._idle_callback.append(om.MDGMessage.addNodeRemovedCallback(self.removeCallbacks, "dependNode"))
		self._idle_callback.append(om.MNodeMessage.addNodeDestroyedCallback(self.thisMObject(), self.removeCallbacks))
		#self._idle_callback.append(om.MNodeMessage.addNodePreRemovalCallback(self.thisMObject(), self.removeCallbacks))
		#self._idle_callback.append(om.MNodeMessage.addNodeAboutToDeleteCallback(self.thisMObject(), self.removeCallbacks))

	def removeCallbacks(self, *args):
		#logging.info("remove callbacks")
		for id in list(self._idle_callback):
			try:
				om.MEventMessage.removeCallback(id)
			except:
				pass
			try:
				om.MNodeMessage.removeCallback(id)
			except:
				pass
			try:
				om.MDGMessage.removeCallback(id)
			except:
				pass

			self._idle_callback.remove(id)
		self._compute_deferred = "action"

	def deferredCompute(self, *args):
		if not om.MObjectHandle(self.thisMObject()).isValid():
			self.removeCallbacks()
		
		if self._compute_deferred == "bypass":
			#logging.info("compute now!")
			self._compute_deferred = "action"
			# trigger compute
			forceComputePlugHandle = self.attrToPlug(TransferVertexNormalsNode.aForceCompute)
			forceComputePlugHandle.setBool(not forceComputePlugHandle.asBool())

	def attrToPlug(self, attr):
		return om.MPlug(self.thisMObject(), attr)

	def setDependentsDirty(self, plug, affect):
		if plugMatch(plug, [TransferVertexNormalsNode.aInputMesh, TransferVertexNormalsNode.aSourceMesh, TransferVertexNormalsNode.aForceCompute]):
			affect.append(self.attrToPlug(TransferVertexNormalsNode.aOutput))

	#@make_thread_safe
	def getPolyBevelDict(self, setValue=False):
		#logging.info("getPolyBevelDict")
		_polyBevelDict = defaultdict(dict)
		inputPlug = self.attrToPlug(TransferVertexNormalsNode.aInMesh)
		if inputPlug.isConnected:
			inputPlugArray = inputPlug.connectedTo(True, False)
			for p in inputPlugArray:
				if p.node().apiType() in [om.MFn.kPolyBevel, om.MFn.kPolyBevel2, om.MFn.kPolyBevel3]:
					nodeName = p.name().split(".")[0]
					#attributeList = cmds.listAttr(nodeName, write=True, settable=True, keyable=True)
					#for attr in attributeList:
						#_polyBevelDict[nodeName][attr] = cmds.getAttr(nodeName+"."+attr)
					
					dNode = om.MFnDependencyNode(p.node())
					for attrId in range(dNode.attributeCount()):
						attrMobj = dNode.attribute(attrId)
						attr = om.MFnAttribute(attrMobj)
						plug = dNode.findPlug(attrMobj, False)
						if all([attr.writable, attr.storable, not attr.hidden]):
							_polyBevelDict[nodeName][attr.name] = getPlugValue(plug, attrMobj)

		if setValue:
			self._polyBevelDict = _polyBevelDict
		return _polyBevelDict

	def compute(self, plug, data):
		# Create default polyBevelDict
		if not isinstance(self._polyBevelDict, dict):
			self._polyBevelDict = self.getPolyBevelDict()

		# Create callbacks
		if not self._idle_callback:
			self.createCallback()
		
		if plug != TransferVertexNormalsNode.aOutput:
			#logging.info("stop compute normals")
			return None
		
		if self._compute_deferred != "action":
			# verify if polyBevel attribute changed
			attributeChange = False
			_polyBevelDict = self.getPolyBevelDict()
			if _polyBevelDict != self._polyBevelDict:
				#logging.info("polyBevel attribute change!")
				self._polyBevelDict = dict(_polyBevelDict)
				attributeChange = True

			if not attributeChange:
				self._compute_deferred = "bypass"
				return
		self._compute_deferred = "sleep"
		
		inputMeshHandle = data.inputValue(TransferVertexNormalsNode.aInputMesh)
		outputMeshHandle = data.outputValue(TransferVertexNormalsNode.aOutput)
		inputMesh = inputMeshHandle.asMesh()
		
		# If input object exists
		if not inputMesh.isNull() and inputMesh.hasFn(om.MFn.kMesh):
			#logging.info("compute vertex normals")
			sourceMeshHandle = data.inputValue(TransferVertexNormalsNode.aSourceMesh)
			sourceMesh = sourceMeshHandle.asMesh()

			# If source object exists
			if not sourceMesh.isNull() and sourceMesh.hasFn(om.MFn.kMesh):
				#logging.info("transfer vertex normals")
				
				# Copy the input mesh
				outputMeshHandle.copy(inputMeshHandle)
				outputMesh = outputMeshHandle.asMesh()
				outputMeshFn = om.MFnMesh(outputMesh)

				# Get the source vertex normals
				sourceMeshFn = om.MFnMesh(sourceMesh)
				sourceNormals = sourceMeshFn.getNormals(om.MSpace.kWorld)
				#sourceNormals = sourceMeshFn.getVertexNormals(True, om.MSpace.kWorld)

				# Transfer the vertex normals
				outputMeshFn.setNormals(sourceNormals[:outputMeshFn.numNormals], om.MSpace.kWorld)

				# Set output
				outputMeshHandle.setMObject(outputMesh)
				outputMeshHandle.setClean()

			# Else passthrough input
			else:
				outputMeshHandle.setMObject(inputMesh)
				outputMeshHandle.setClean()

class DynamicBevelNode(om.MPxNode):
	kNodeName = "gtDynamicBevel"
	kNodeId = om.MTypeId(0x182295)

	aOutput = None
	aInputMesh = None
	aIntermediateObject = None
	aInputMatrix = None
	aOutputTranslate = None
	aOutputRotate = None
	aOutputScale = None
	aOutputShear = None
	aOutputMatrix = None
	aEnableXRay = None
	aEnableShading = None
	aForceCompute = None
	aForceComputeScale = None
	aKeepNodeAlive = None
	aTransformLink = None
	aComputeBevelPreview = None
	aScaleMatrix = None
	aReverseNormals = None
	aEnableBevelDisplay = None

	def __init__(self):
		super(DynamicBevelNode, self).__init__()
		self._initNode = True
		self._lastObject = []
		self._lastObjectData = {}
		self._callbacks = []
		self._compute_deferred = "action"
		self._lastScaleMatrix = None
		self._currentScaleMatrix = om.MMatrix()

	@classmethod
	def creator(cls):
		return cls()

	@classmethod
	def initialize(cls):
		rTypeAttr = om.MFnTypedAttribute()
		cls.aOutput = rTypeAttr.create("output", "out", om.MFnData.kMesh, om.MObject.kNullObj)
		rTypeAttr.writable = False
		rTypeAttr.readable = True
		rTypeAttr.hidden = True
		#rTypeAttr.storable = False
		om.MPxNode.addAttribute(cls.aOutput)

		wTypeAttr = om.MFnTypedAttribute()
		cls.aInputMesh = wTypeAttr.create("inputMesh", "in", om.MFnData.kMesh, om.MObject.kNullObj)
		wTypeAttr.writable = True
		wTypeAttr.readable = False
		wTypeAttr.hidden = True
		#wTypeAttr.storable = False
		om.MPxNode.addAttribute(cls.aInputMesh)

		nAttr = om.MFnNumericAttribute()
		cls.aIntermediateObject = nAttr.create("intermediateObject", "io", om.MFnNumericData.kBoolean, False)
		nAttr.writable = True
		nAttr.readable = False
		nAttr.hidden = True
		om.MPxNode.addAttribute(cls.aIntermediateObject)

		knAttr = om.MFnNumericAttribute()
		cls.aKeepNodeAlive = knAttr.create("keepNodeAlive", "kna", om.MFnNumericData.kBoolean, False)
		knAttr.writable = True
		knAttr.readable = False
		#knAttr.keyable = True
		knAttr.connectable = True
		knAttr.hidden = True
		om.MPxNode.addAttribute(cls.aKeepNodeAlive)

		tlAttr = om.MFnMessageAttribute()
		cls.aTransformLink = tlAttr.create("transformLink", "tlnk")
		tlAttr.writable = True
		tlAttr.readable = False
		#tlAttr.keyable = True
		tlAttr.connectable = True
		tlAttr.hidden = True
		om.MPxNode.addAttribute(cls.aTransformLink)

		wMtxAttr = om.MFnMatrixAttribute()
		cls.aInputMatrix = wMtxAttr.create("inputMatrix", "im", om.MFnMatrixAttribute.kDouble)
		wMtxAttr.default = om.MMatrix()
		wMtxAttr.writable = True
		wMtxAttr.readable = False
		wMtxAttr.hidden = True
		om.MPxNode.addAttribute(cls.aInputMatrix)
		
		translateNAttr = om.MFnNumericAttribute()
		cls.aOutputTranslate = translateNAttr.create("outputTranslate", "outTr", om.MFnNumericData.k3Double)
		translateNAttr.writable = False
		translateNAttr.readable = True
		translateNAttr.hidden = True
		translateNAttr.default = (0, 0, 0)
		om.MPxNode.addAttribute(cls.aOutputTranslate)
		
		uAttr = om.MFnUnitAttribute()
		aOutputRotateX = uAttr.create("outputRotateX", "outRtX", om.MFnUnitAttribute.kAngle, 0)
		aOutputRotateY = uAttr.create("outputRotateY", "outRtY", om.MFnUnitAttribute.kAngle, 0)
		aOutputRotateZ = uAttr.create("outputRotateZ", "outRtZ", om.MFnUnitAttribute.kAngle, 0)
		uAttr.writable = False
		uAttr.readable = True
		uAttr.hidden = True

		rotateNAttr = om.MFnNumericAttribute()
		cls.aOutputRotate = rotateNAttr.create("outputRotate", "outRt", aOutputRotateX, aOutputRotateY, aOutputRotateZ)
		rotateNAttr.writable = False
		rotateNAttr.readable = True
		rotateNAttr.hidden = True
		rotateNAttr.default = (0, 0, 0)
		om.MPxNode.addAttribute(cls.aOutputRotate)

		scaleNAttr = om.MFnNumericAttribute()
		cls.aOutputScale = scaleNAttr.create("outputScale", "outSc", om.MFnNumericData.k3Double)
		scaleNAttr.writable = False
		scaleNAttr.readable = True
		scaleNAttr.hidden = True
		scaleNAttr.default = (1, 1, 1)
		om.MPxNode.addAttribute(cls.aOutputScale)

		shearNAttr = om.MFnNumericAttribute()
		cls.aOutputShear = shearNAttr.create("outputShear", "outSh", om.MFnNumericData.k3Double)
		shearNAttr.writable = False
		shearNAttr.readable = True
		shearNAttr.hidden = True
		shearNAttr.default = (0, 0, 0)
		om.MPxNode.addAttribute(cls.aOutputShear)

		rMtxAttr = om.MFnMatrixAttribute()
		cls.aOutputMatrix = rMtxAttr.create("outputMatrix", "outM", om.MFnMatrixAttribute.kDouble)
		rMtxAttr.default = om.MMatrix()
		rMtxAttr.writable = False
		rMtxAttr.readable = True
		rMtxAttr.hidden = True
		om.MPxNode.addAttribute(cls.aOutputMatrix)

		sMtxAttr = om.MFnMatrixAttribute()
		cls.aScaleMatrix = sMtxAttr.create("scaleMatrix", "sMat", om.MFnMatrixAttribute.kDouble)
		sMtxAttr.default = om.MMatrix()
		sMtxAttr.writable = False
		sMtxAttr.readable = True
		sMtxAttr.hidden = True
		om.MPxNode.addAttribute(cls.aScaleMatrix)

		fcAttr = om.MFnNumericAttribute()
		cls.aForceCompute = fcAttr.create("forceCompute", "fc", om.MFnNumericData.kBoolean, False)
		fcAttr.writable = False
		fcAttr.readable = False
		fcAttr.hidden = True
		om.MPxNode.addAttribute(cls.aForceCompute)

		fcsAttr = om.MFnNumericAttribute()
		cls.aForceComputeScale = fcsAttr.create("forceComputeScale", "fcs", om.MFnNumericData.kBoolean, False)
		fcsAttr.writable = False
		fcsAttr.readable = False
		fcsAttr.hidden = True
		om.MPxNode.addAttribute(cls.aForceComputeScale)

		cpbAttr = om.MFnNumericAttribute()
		cls.aComputeBevelPreview = cpbAttr.create("computeBevelPreview", "cbp", om.MFnNumericData.kBoolean, False)
		cpbAttr.writable = False
		cpbAttr.readable = False
		cpbAttr.hidden = True
		om.MPxNode.addAttribute(cls.aComputeBevelPreview)

		ebdNumAttr = om.MFnNumericAttribute()
		cls.aEnableBevelDisplay = ebdNumAttr.create("enableBevelDisplay", "ebd", om.MFnNumericData.kBoolean, True)
		ebdNumAttr.writable = True
		ebdNumAttr.readable = False
		#ebdNumAttr.internal = True
		ebdNumAttr.keyable = True
		#ebdNumAttr.channelBox = True
		om.MPxNode.addAttribute(cls.aEnableBevelDisplay)

		kNumAttr = om.MFnNumericAttribute()
		cls.aEnableXRay = kNumAttr.create("enableXRay", "xray", om.MFnNumericData.kBoolean, True)
		kNumAttr.writable = True
		kNumAttr.readable = False
		#kNumAttr.internal = True
		kNumAttr.keyable = True
		#kNumAttr.channelBox = True
		om.MPxNode.addAttribute(cls.aEnableXRay)

		esNumAttr = om.MFnNumericAttribute()
		cls.aEnableShading = esNumAttr.create("enableShading", "esh", om.MFnNumericData.kBoolean, True)
		esNumAttr.writable = True
		esNumAttr.readable = False
		#esNumAttr.internal = True
		esNumAttr.keyable = True
		#esNumAttr.channelBox = True
		#esNumAttr.storable = True
		om.MPxNode.addAttribute(cls.aEnableShading)

		rnNumAttr = om.MFnNumericAttribute()
		cls.aReverseNormals = rnNumAttr.create("reverseNormals", "rn", om.MFnNumericData.kBoolean, False)
		rnNumAttr.writable = False
		rnNumAttr.readable = True
		rnNumAttr.hidden = True
		om.MPxNode.addAttribute(cls.aReverseNormals)

		om.MPxNode.attributeAffects(cls.aInputMesh, cls.aOutput)
		om.MPxNode.attributeAffects(cls.aForceCompute, cls.aOutput)
		om.MPxNode.attributeAffects(cls.aForceComputeScale, cls.aOutputScale)
		om.MPxNode.attributeAffects(cls.aForceComputeScale, cls.aOutputShear)
		om.MPxNode.attributeAffects(cls.aForceComputeScale, cls.aScaleMatrix)
		om.MPxNode.attributeAffects(cls.aForceComputeScale, cls.aReverseNormals)
		om.MPxNode.attributeAffects(cls.aIntermediateObject, cls.aOutput)
		om.MPxNode.attributeAffects(cls.aInputMatrix, cls.aOutputTranslate)
		om.MPxNode.attributeAffects(cls.aInputMatrix, cls.aOutputRotate)
		om.MPxNode.attributeAffects(cls.aInputMatrix, cls.aOutputScale)
		om.MPxNode.attributeAffects(cls.aInputMatrix, cls.aOutputShear)
		om.MPxNode.attributeAffects(cls.aInputMatrix, cls.aOutputMatrix)

	def postConstructor(self):
		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		dependencyNode.setName("dynamicBevel#")

	def attrToPlug(self, attr):
		return om.MPlug(self.thisMObject(), attr)

	def changeConnections(self, _disconnectNodes, _connectNodes):
		#logging.info("changeConnections {0} {1}".format(_disconnectNodes, _connectNodes))
		startTime = time.time()
		time.sleep(0.04)
		while True:
			origShape = None

			# Fixes undos
			if len(_disconnectNodes) >= 2:
				# Turns undo/redo off without flushing the queue
				undoState = executeInMainThreadWithResult(cmds.undoInfo, query=True, state=True)
				if undoState:
					executeInMainThreadWithResult(cmds.undoInfo, stateWithoutFlush=False)
				#_disconnectNodes = [str(x) for x in _disconnectNodes]
				if isinstance(_disconnectNodes[0], om.MPlug):
					try:
						dagNode = om.MFnDagNode(_disconnectNodes[0].node())
						origShape = dagNode.fullPathName()
					except:
						origShape = next(iter(_disconnectNodes[0].name().split(".")))
				else:
					origShape = next(iter(str(_disconnectNodes[0]).split(".")))
				if origShape:
					executeInMainThreadWithResult(cmds.setAttr, origShape+".intermediateObject", False)
				# Turns undo/redo back on
				if undoState:
					executeInMainThreadWithResult(cmds.undoInfo, stateWithoutFlush=True)
			
			if len(_connectNodes) >= 2:
				'''
				global skipBevelPreviewCompute
				_skipBevelPreviewCompute = False
				if "skipBevelPreviewCompute" in globals() and skipBevelPreviewCompute:
					_skipBevelPreviewCompute = skipBevelPreviewCompute
					skipBevelPreviewCompute = False
				'''

				# Open undo chunk
				executeInMainThreadWithResult(cmds.undoInfo, openChunk=True, chunkName="NDB_ChangeConnections")
				#_connectNodes = [str(x) for x in _connectNodes]
				_connectNodes = getFullPathPlugs(_connectNodes)
				try:
					if origShape:
						executeInMainThreadWithResult(cmds.setAttr, origShape+".intermediateObject", True)
					#logging.info("change connections: {0} to {1}".format(_connectNodes[0], _connectNodes[1]))
					inputName = next(iter(_connectNodes[0].split(".")))
					outputName = next(iter(_connectNodes[1].split(".")))
					executeInMainThreadWithResult(safeConnect, _connectNodes[0], _connectNodes[1], force=True)
					executeInMainThreadWithResult(safeConnect, inputName+".intermediateObject", outputName+".intermediateObject", force=True)
					executeInMainThreadWithResult(safeConnect, inputName+".worldMatrix", outputName+".inputMatrix", force=True)
					objectTransform = next(iter(executeInMainThreadWithResult(cmds.listRelatives, inputName, fullPath=True, parent=True) or []), None)
					if objectTransform:
						executeInMainThreadWithResult(safeConnect, objectTransform+".message", outputName+".transformLink", force=True)
					# Trigger force compute
					outputPlug = self.attrToPlug(DynamicBevelNode.aOutput)
					outputPlugArray = outputPlug.connectedTo(False, True)
					if len(outputPlugArray) > 0:
						for p in outputPlugArray:
							dNode = om.MFnDependencyNode(p.node())
							if dNode.typeName == "gtGetHardEdges":
								# Force compute hard edges
								#logging.info("trigger force compute hard edges!")
								plugValue = executeInMainThreadWithResult(cmds.getAttr, dNode.name()+".forceCompute")
								executeInMainThreadWithResult(cmds.setAttr, dNode.name()+".forceCompute", not plugValue)
							if dNode.typeName in ["polyBevel", "polyBevel2", "polyBevel3"]:
								if objectTransform:
									executeInMainThreadWithResult(safeAddAttr, dNode.name(), longName="transformLink", attributeType="message", writable=True, readable=False, hidden=True)
									executeInMainThreadWithResult(safeConnect, objectTransform+".message", dNode.name()+".transformLink", force=True)

								'''
								if _skipBevelPreviewCompute:
									outputPlug = dNode.findPlug("output", False)
									outputPlugArray = outputPlug.connectedTo(False, True)
									if len(outputPlugArray) > 0:
										currentDependencyNode = om.MFnDependencyNode(outputPlugArray[0].node())
										if currentDependencyNode.typeName == "gtBevelPreview":
											# Force compute bevel preview
											#logging.info("trigger force compute bevel preview!")
											plugValue = executeInMainThreadWithResult(cmds.getAttr, currentDependencyNode.name()+".forceCompute")
											executeInMainThreadWithResult(cmds.setAttr, currentDependencyNode.name()+".forceCompute", not plugValue)
								'''

				except Exception as e:
					logging.exception(e)
				finally:
					# Close undo chunk
					executeInMainThreadWithResult(cmds.undoInfo, closeChunk=True)

				return

			if time.time() - startTime > 10:
				return
			
			time.sleep(0.04)

	def changeBevelDisplayFn(self, plug):
		#logging.info("changeBevelDisplayFn")
		if plug.isConnected and not plug.node().isNull():
			plugArray = plug.connectedTo(True, False)
			if len(plugArray) > 0:
				plug = plugArray[0]

		dagPath = self.getInputDag()[1]
		if dagPath:
			# Set visibility
			#plugValue = cmds.getAttr(self.name()+".enableBevelDisplay")
			
			dNode = self.getBevelPreviewNode()[1]
			if dNode:
				for attr in ["visibility", "lodVisibility"]:
					if dNode.hasAttribute(attr):
						p = dNode.findPlug(attr, False)
						#p.setBool(plug.asBool())
						cmds.evalDeferred(partial(changeAttr, str(p), str(plug)))
				
				cmds.evalDeferred(partial(changeBevelDisplay, self.thisMObject(), dagPath))

	def changeXRayFn(self, plug):
		#logging.info("changeXRayFn")
		# if Enable Bevel Display is turned off, ignore
		enableBevelDisplayPlug = self.attrToPlug(self.aEnableBevelDisplay)
		if not enableBevelDisplayPlug.asBool():
			return

		plugAttr = None
		if plug.isConnected and not plug.node().isNull():
			plugArray = plug.connectedTo(True, False)
			if len(plugArray) > 0:
				plugAttr = str(plugArray[0])

		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		inputMeshPlug = dependencyNode.findPlug("inputMesh", False)
		inputPlugArray = inputMeshPlug.connectedTo(True, False)
		if len(inputPlugArray) > 0:
			inputMObject = inputPlugArray[0].node()
			if inputMObject.hasFn(om.MFn.kMesh):
				dagNode = om.MFnDagNode(inputMObject)
				dagPath = dagNode.getPath()
				if not plugAttr:
					plugAttr = self.name()+".enableXRay"
				
				if not dagNode.isIntermediateObject:
					executeDeferred(partial(changeXRay, dagPath.fullPathName(), plugAttr))

	def changeShadingFn(self, plug):
		#logging.info("changeShadingFn")
		# if Enable Bevel Display is turned off, ignore
		enableBevelDisplayPlug = self.attrToPlug(self.aEnableBevelDisplay)
		if not enableBevelDisplayPlug.asBool():
			return

		plugSource = None
		if plug.isConnected and not plug.node().isNull():
			plugArray = plug.connectedTo(True, False)
			if len(plugArray) > 0:
				plugSource = str(plugArray[0])

		'''dependencyNode = om.MFnDependencyNode(self.thisMObject())
		inputMeshPlug = dependencyNode.findPlug("inputMesh", False)
		inputPlugArray = inputMeshPlug.connectedTo(True, False)
		if len(inputPlugArray) > 0:
			inputMObject = inputPlugArray[0].node()
			if inputMObject.hasFn(om.MFn.kMesh):
				dagNode = om.MFnDagNode(inputMObject)
				dagPath = dagNode.getPath()'''

		dagPath = self.getInputDag()[1]
		if dagPath:
			# Check if is in a displayLayer
			try:
				inputDependencyNode = om.MFnDependencyNode(dagPath.node())
				drawOverridePlug = inputDependencyNode.findPlug("drawOverride", False)
				drawOverridePlugArray = drawOverridePlug.connectedTo(True, False)
				if len(drawOverridePlugArray) > 0:
					# Disconnect from displayLayer
					mdgModifier = om.MDagModifier()
					mdgModifier.disconnect(drawOverridePlugArray[0], drawOverridePlug)
					mdgModifier.doIt()
			except Exception as e:
				logging.exception(e)
			
			# Set shading
			objectName = dagPath.fullPathName()
			if not plugSource:
				plugSource = self.name()+".enableShading"
			plugTarget = objectName+".overrideShading"
			cmds.evalDeferred(partial(changeAttr, plugTarget, plugSource))

			# Force override enabled
			forceSetAttr(objectName+".overrideEnabled", True)
			forceSetAttr(objectName+".overrideColor", 5)

	def getInputNode(self):
		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		inputMeshPlug = dependencyNode.findPlug("inputMesh", False)
		inputPlugArray = inputMeshPlug.connectedTo(True, False)
		if len(inputPlugArray) > 0:
			return inputPlugArray[0].node()
		return None

	def getInputDag(self):
		inputMObject = self.getInputNode()
		if inputMObject and inputMObject.hasFn(om.MFn.kMesh):
			dagNode = om.MFnDagNode(inputMObject)
			return dagNode, dagNode.getPath()
		
		return None, None

	'''
	def setInternalValueInContext(self, plug, dataHandle, ctx):
		if plug == DynamicBevelNode.aEnableXRay:
			self.changeXRayFn(plug)
		elif plug == DynamicBevelNode.aEnableShading:
			self.changeShadingFn(plug)

		return om.MPxNode.setInternalValueInContext(self, plug, dataHandle, ctx)
	'''

	def setDependentsDirty(self, plug, affect):
		#logging.info("dynamicBevel setDependentsDirty {0}".format(plug))
		if plug == DynamicBevelNode.aForceCompute:
			self.verifyInputMesh()
		elif plug == DynamicBevelNode.aForceComputeScale:
			for p in [DynamicBevelNode.aOutputScale, DynamicBevelNode.aOutputShear, DynamicBevelNode.aScaleMatrix, DynamicBevelNode.aReverseNormals]:
				affect.append(self.attrToPlug(p))
		elif plugMatch(plug, [DynamicBevelNode.aInputMesh, DynamicBevelNode.aIntermediateObject]):
			affect.append(self.attrToPlug(DynamicBevelNode.aOutput))
		elif plugMatch(plug, [DynamicBevelNode.aInputMatrix]):
			for p in [DynamicBevelNode.aOutputTranslate, DynamicBevelNode.aOutputRotate, DynamicBevelNode.aOutputScale, DynamicBevelNode.aOutputShear, DynamicBevelNode.aOutputMatrix]:
				affect.append(self.attrToPlug(p))
		elif plug == DynamicBevelNode.aEnableBevelDisplay:
			self.changeBevelDisplayFn(plug)
		elif plug == DynamicBevelNode.aEnableXRay:
			self.changeXRayFn(plug)
			#affect.append(self.attrToPlug(DynamicBevelNode.aInternalXray))
		elif plug == DynamicBevelNode.aEnableShading:
			self.changeShadingFn(plug)

	def connectionBroken(self, plug, otherPlug, isSrc):
		if plug == DynamicBevelNode.aInputMesh:
			#logging.info("input connection broken")
			#global skipBevelPreviewCompute
			#skipBevelPreviewCompute = True
			computeBevelPreviewPlug = self.attrToPlug(DynamicBevelNode.aComputeBevelPreview)
			computeBevelPreviewPlug.setBool(False)

			enableShading(otherPlug, deferred=True)
			disableXRay(otherPlug, deferred=True) # maybe needs to be deferred for scene close?

			# Always connect to a temporary node so it is not cleaned up by Maya
			undoState = cmds.undoInfo(query=True, state=True)
			if undoState:
				cmds.undoInfo(stateWithoutFlush=False)
			try:
				if cmds.objExists(self.name()):
					#logging.info("connect keepNodeAlive")
					knPlug = self.attrToPlug(DynamicBevelNode.aKeepNodeAlive)
					if not knPlug.isConnected:
						tmpNode = cmds.createNode("network", skipSelect=True)
						cmds.connectAttr(tmpNode+".affects[0]", self.name()+".keepNodeAlive", force=True)
						cmds.evalDeferred(partial(deleteUnconnectedNode, tmpNode, ".affects", source=False, destination=True, connections=False, plugs=False))
			except Exception as e:
				logging.exception(e)
			finally:
				if undoState:
					cmds.undoInfo(stateWithoutFlush=True)
			
			# trigger compute
			#forceComputePlugHandle = self.attrToPlug(DynamicBevelNode.aForceCompute)
			#forceComputePlugHandle.setBool(not forceComputePlugHandle.asBool())

			# Remove callback
			self.removeCallbacks()
		
		return om.MPxNode.connectionBroken(self, plug, otherPlug, isSrc)

	def connectionMade(self, plug, otherPlug, isSrc):
		if plug == DynamicBevelNode.aInputMesh:
			#logging.info("connection made")
			self._initNode = True

			#global skipBevelPreviewCompute
			#skipBevelPreviewCompute = False
			computeBevelPreviewPlug = self.attrToPlug(DynamicBevelNode.aComputeBevelPreview)
			computeBevelPreviewPlug.setBool(True)

			outputPlug = self.attrToPlug(DynamicBevelNode.aOutput)
			dependencyGraph = om.MItDependencyGraph(outputPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
			while not dependencyGraph.isDone():
				currentItem = dependencyGraph.currentNode()
				currentDependencyNode = om.MFnDependencyNode(currentItem)
				if currentDependencyNode.typeName == "gtBevelPreview":
					#logging.info("trigger force compute bevel preview!")
					forceComputePlug = currentDependencyNode.findPlug("forceCompute", False)
					forceComputePlug.setBool(not forceComputePlug.asBool())
					break

				dependencyGraph.next()
			
			# Create callback
			if not self._callbacks:
				self.createCallback()
		
		return om.MPxNode.connectionMade(self, plug, otherPlug, isSrc)

	def setLastObjectData(self, lastObjectName):
		self._lastObjectData = getDataFromObject(lastObjectName)

	def verifyInputMesh(self):
		#logging.info("verify input mesh")

		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		inputMeshPlug = dependencyNode.findPlug("inputMesh", False)
		inputPlugArray = inputMeshPlug.connectedTo(True, False)
		if len(inputPlugArray) > 0:
			inputMObject = inputPlugArray[0].node()
			if inputMObject.hasFn(om.MFn.kMesh):
				dagNode = om.MFnDagNode(inputMObject)
				dagPath = dagNode.getPath()
				#_lastShapeName = dagPath.fullPathName()
				dagPath.pop()
				_lastObjectName = dagPath.fullPathName()
				self._lastObject = [MayaNode(_lastObjectName), _lastObjectName]
				#self._lastObjectData = getDataFromObject(_lastObjectName)
				cmds.evalDeferred(partial(self.setLastObjectData, _lastObjectName))

				return True
		
		#else:
		#logging.info("try re-connect?")
		if len(self._lastObject) == 2 and not self._lastObject[0].name():
			# Disable cycle check
			cycleCheckEval = cmds.cycleCheck(query=True, evaluation=True)
			if cycleCheckEval:
				cmds.cycleCheck(evaluation=False)

			# if object still exists, reconnect
			if cmds.objExists(self._lastObject[1]):
				#logging.info("reconnecting from name")
				shapeName = next(iter(cmds.listRelatives(self._lastObject[1], fullPath=True, noIntermediate=True, shapes=True) or []), None)
				if shapeName:
					self._lastObject[0] = MayaNode(self._lastObject[1])
					_connectNodes = [shapeName+".outMesh", self.name()+".inputMesh"]
					changeConnectionsThread = threading.Thread(target=self.changeConnections, args=([], _connectNodes))
					changeConnectionsThread.daemon = True
					changeConnectionsThread.start()
			# otherwise, try to find the object by proximity
			elif self._lastObjectData:
				closestObject = findObjectFromData(self._lastObjectData["vertices"], self._lastObjectData["polygonCounts"], self._lastObjectData["polygonConnects"], self._lastObjectData["matrix"])
				if closestObject:
					if cmds.objectType(closestObject) == "transform":
						objectTransform = closestObject
						objectShape = next(iter(cmds.listRelatives(closestObject, fullPath=True, noIntermediate=True, shapes=True) or []), None)
					elif cmds.objectType(closestObject) == "mesh":
						objectTransform = next(iter(cmds.listRelatives(closestObject, fullPath=True, parent=True) or []), None)
						objectShape = closestObject
					if all([objectTransform, objectShape]):
						#logging.info("reconnecting from proximity")
						self._lastObject = [MayaNode(objectTransform), objectTransform]
						#self._lastObjectData = getDataFromObject(objectTransform)
						#cmds.evalDeferred(partial(self.setLastObjectData, objectTransform))
						_connectNodes = [objectShape+".outMesh", self.name()+".inputMesh"]
						#global skipBevelPreviewCompute
						#skipBevelPreviewCompute = True
						changeConnectionsThread = threading.Thread(target=self.changeConnections, args=([], _connectNodes))
						changeConnectionsThread.daemon = True
						changeConnectionsThread.start()
			
			# Enable cycle check
			if cycleCheckEval:
				cmds.cycleCheck(evaluation=True)
		
		return False

	def setInputMeshVisibility(self):
		#logging.info("setInputMeshVisibility")
		if cmds.optionVar(exists="BP_ContextSelectionCallback") and cmds.optionVar(query="BP_ContextSelectionCallback"):
			# Set source object visibility override
			sourceShapeDag = self.getInputDag()[1]
			if sourceShapeDag and sourceShapeDag.isValid():
				dgNode = om.MFnDependencyNode(sourceShapeDag.node())
				if dgNode.hasAttribute("overrideEnabled"):
					plug = dgNode.findPlug("overrideEnabled", False)
					if not plug.asBool():
						plug.setBool(True)
				if dgNode.hasAttribute("overrideVisibility"):
					plug = dgNode.findPlug("overrideVisibility", False)
					if plug.asBool():
						plug.setBool(False)
			
				# Select bevelPreview
				sourceDag = sourceShapeDag.getAPathTo(sourceShapeDag.transform())
				if any([om.MGlobal.getActiveSelectionList().hasItem(x) for x in [sourceDag, sourceShapeDag]]):
					bevelPreviewObj = self.getBevelPreviewNode()[0]
					bevelPreviewShapeDagNode = om.MFnDagNode(bevelPreviewObj)
					bevelPreviewShapeDag = bevelPreviewShapeDagNode.getPath()
					bevelPreviewDag = bevelPreviewShapeDag.getAPathTo(bevelPreviewShapeDag.transform())
					if not any([om.MGlobal.getActiveSelectionList().hasItem(x) for x in [bevelPreviewDag, bevelPreviewShapeDag]]):
						addList = om.MSelectionList()
						try:
							addList.add(bevelPreviewDag)
						except:
							pass
						if not addList.isEmpty():
							cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 0))
							om.MGlobal.setActiveSelectionList(addList, listAdjustment=om.MGlobal.kAddToList)
							#om.MGlobal.setActiveSelectionList(addList, listAdjustment=om.MGlobal.kAddToHeadOfList)
							cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))

	def compute(self, plug, data):
		#logging.info("dynamicBevel compute {0}".format(plug))
		if self._initNode:
			try:
				#xRayOverride.createOverride()
				#dependencyNode = om.MFnDependencyNode(self.thisMObject())
				bevelDisplayPlug = self.attrToPlug(DynamicBevelNode.aEnableBevelDisplay)
				cmds.evalDeferred(partial(self.changeBevelDisplayFn, bevelDisplayPlug))
				#xRayPlug = dependencyNode.findPlug("enableXRay", False)
				xRayPlug = self.attrToPlug(DynamicBevelNode.aEnableXRay)
				cmds.evalDeferred(partial(self.changeXRayFn, xRayPlug))
				#shadingPlug = dependencyNode.findPlug("enableShading", False)
				shadingPlug = self.attrToPlug(DynamicBevelNode.aEnableShading)
				cmds.evalDeferred(partial(self.changeShadingFn, shadingPlug))
				cmds.evalDeferred(self.setInputMeshVisibility) # needs to be deferred or when opening scene it is not working...

			except Exception as e:
				logging.exception(e)
			finally:
				self._initNode = False
		
		# Create callbacks
		if not self._callbacks:
			self.createCallback()

		if plug == DynamicBevelNode.aOutput:
			#logging.info("compute DynamicBevelNode output")
			self._disconnectNodes = []
			self._connectNodes = []
			
			inputMeshHandle = data.inputValue(DynamicBevelNode.aInputMesh)
			inputMesh = inputMeshHandle.asMesh()
			
			# If input object is not null
			if not inputMesh.isNull():
				inputMeshValid = self.verifyInputMesh()
				if not inputMeshValid:
					#logging.info("abort DynamicBevelNode output")
					return
				
				intermediateObectHandle = data.inputValue(DynamicBevelNode.aIntermediateObject)
				if intermediateObectHandle.asBool():
					# Get inputMesh MObject
					dependencyNode = om.MFnDependencyNode(self.thisMObject())

					inputMeshPlug = dependencyNode.findPlug("inputMesh", False)
					inputPlugArray = inputMeshPlug.connectedTo(True, False)
					if not len(inputPlugArray) == 0:
						inputMObject = inputPlugArray[0].node()
						# Find inputMesh connections
						if inputMObject.hasFn(om.MFn.kMesh):
							inputDependencyNode = om.MFnDependencyNode(inputMObject)
							outMeshPlug = inputDependencyNode.findPlug("outMesh", False)
							outMeshDependencyGraph = om.MItDependencyGraph(outMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kNodeLevel)
							while not outMeshDependencyGraph.isDone():
								currentItem = outMeshDependencyGraph.currentNode()
								currentDependencyNode = om.MFnDependencyNode(currentItem)

								# ignore dynamicBevel plugs
								if currentDependencyNode.typeName == "gtDynamicBevel":
									outMeshDependencyGraph.prune()

								elif currentDependencyNode.typeName == "mesh":
									outputPlug = currentDependencyNode.findPlug("outMesh", False)

									_disconnectNodes = [outMeshPlug, inputMeshPlug]
									_connectNodes = [outputPlug, inputMeshPlug]

									#global skipBevelPreviewCompute
									#skipBevelPreviewCompute = True
									computeBevelPreviewPlug = self.attrToPlug(DynamicBevelNode.aComputeBevelPreview)
									computeBevelPreviewPlug.setBool(False)

									#logging.info("thread: {0} to {1}".format(str(_connectNodes[0]), str(_connectNodes[1])))
									changeConnectionsThread = threading.Thread(target=self.changeConnections, args=(_disconnectNodes, _connectNodes))
									changeConnectionsThread.daemon = True
									changeConnectionsThread.start()
									
									break
								
								outMeshDependencyGraph.next()

				outputMeshHandle = data.outputValue(DynamicBevelNode.aOutput)
				outputMeshHandle.setMObject(inputMesh)
				outputMeshHandle.setClean()
		
		#elif plug in [DynamicBevelNode.aOutputTranslate, DynamicBevelNode.aOutputRotate]:
		#elif any([plug == x for x in [DynamicBevelNode.aOutputTranslate, DynamicBevelNode.aOutputRotate]]):	
		elif plugMatch(plug, [DynamicBevelNode.aOutputTranslate, DynamicBevelNode.aOutputRotate]):

			# Get matrix value from input
			matrixPlugHandle = data.inputValue(DynamicBevelNode.aInputMatrix)
			objectMatrix = matrixPlugHandle.asMatrix()

			if objectMatrix:
				# Create transformation matrix from input matrix
				trans_matrix = om.MTransformationMatrix(objectMatrix)

				# Set translation value
				if plug == DynamicBevelNode.aOutputTranslate:
					translation = trans_matrix.translation(om.MSpace.kWorld)
					outputTranslateHandle = data.outputValue(DynamicBevelNode.aOutputTranslate)
					outputTranslateHandle.set3Double(*translation)
					outputTranslateHandle.setClean()

				# Set rotation value
				elif plug == DynamicBevelNode.aOutputRotate:
					euler_rotation = trans_matrix.rotation(asQuaternion=False)
					outputRotateHandle = data.outputValue(DynamicBevelNode.aOutputRotate)
					outputRotateHandle.set3Double(*euler_rotation)
					outputRotateHandle.setClean()

		elif plugMatch(plug, [DynamicBevelNode.aOutputScale, DynamicBevelNode.aOutputShear]):

			# Get matrix value from input
			matrixPlugHandle = data.inputValue(DynamicBevelNode.aInputMatrix)
			objectMatrix = matrixPlugHandle.asMatrix()

			if objectMatrix:
				if self._compute_deferred != "action":
					#logging.info("set scale")

					# Create transformation matrix
					if not self._lastScaleMatrix:
						self._lastScaleMatrix = objectMatrix
					inverted_matrix = om.MTransformationMatrix(self._lastScaleMatrix.inverse() * objectMatrix)

					# Set scale value
					scale = inverted_matrix.scale(om.MSpace.kWorld)
					outputScaleHandle = data.outputValue(DynamicBevelNode.aOutputScale)
					outputScaleHandle.set3Double(*scale)
					outputScaleHandle.setClean()

					# Set shear value
					shear = inverted_matrix.shear(om.MSpace.kWorld)
					outputShearHandle = data.outputValue(DynamicBevelNode.aOutputShear)
					outputShearHandle.set3Double(*shear)
					outputShearHandle.setClean()

					self._compute_deferred = "bypass"
				
				else:
					#logging.info("set deferred scale")

					# Set scale value
					outputScaleHandle = data.outputValue(DynamicBevelNode.aOutputScale)
					outputScaleHandle.set3Double(1, 1, 1)
					outputScaleHandle.setClean()

					# Set shear value
					outputShearHandle = data.outputValue(DynamicBevelNode.aOutputShear)
					outputShearHandle.set3Double(0, 0, 0)
					outputShearHandle.setClean()

					self._compute_deferred = "sleep"
					self._lastScaleMatrix = None
					self._currentScaleMatrix = om.MTransformationMatrix(objectMatrix).asScaleMatrix()

		elif plug == DynamicBevelNode.aOutputMatrix:
			#logging.info("compute output matrix")

			matrixPlugHandle = data.inputValue(DynamicBevelNode.aInputMatrix)
			outputMatrixHandle = data.outputValue(DynamicBevelNode.aOutputMatrix)
			outputMatrixHandle.setMMatrix(matrixPlugHandle.asMatrix())
			outputMatrixHandle.setClean()
		
		elif plug == DynamicBevelNode.aScaleMatrix:
			#logging.info("compute scale matrix")

			matrixPlugHandle = data.inputValue(DynamicBevelNode.aInputMatrix)
			scaleMatrix = om.MTransformationMatrix(matrixPlugHandle.asMatrix()).asScaleMatrix()

			outputMatrixHandle = data.outputValue(DynamicBevelNode.aScaleMatrix)
			outputMatrixHandle.setMMatrix(scaleMatrix)
			outputMatrixHandle.setClean()
		
		elif plug == DynamicBevelNode.aReverseNormals:
			#logging.info("compute reverse normals")

			matrixPlugHandle = data.inputValue(DynamicBevelNode.aInputMatrix)
			scaleMatrix = om.MTransformationMatrix(matrixPlugHandle.asMatrix()).asScaleMatrix()

			reverseNormals = False
			if scaleMatrix and min(list(scaleMatrix)) < 0:
				reverseNormals = True

			reverseNormalsHandle = data.outputValue(DynamicBevelNode.aReverseNormals)
			reverseNormalsHandle.setBool(reverseNormals)
			reverseNormalsHandle.setClean()

	def getBevelPreviewNode(self):
		outputPlug = self.attrToPlug(DynamicBevelNode.aOutput)
		dependencyGraph = om.MItDependencyGraph(outputPlug, om.MItDependencyGraph.kDownstream, om.MItDependencyGraph.kNodeLevel)
		while not dependencyGraph.isDone():
			currentItem = dependencyGraph.currentNode()
			currentDependencyNode = om.MFnDependencyNode(currentItem)
			if currentDependencyNode.typeName == "gtBevelPreview":
				return currentItem, currentDependencyNode

			dependencyGraph.next()
		
		return None, None

	def createCallback(self, sourceObject=None):
		if not all([sourceObject, isinstance(sourceObject, om.MObject)]):
			sourceObject = self.getInputNode()
		
		if sourceObject:
			self._callbacks.append(om.MNodeMessage.addAttributeChangedCallback(sourceObject, self.propagateMaterial))
			self._callbacks.append(om.MEventMessage.addEventCallback("idleVeryLow", self.deferredCompute))
			self._callbacks.append(om.MNodeMessage.addNodeDestroyedCallback(self.thisMObject(), self.removeCallbacks))

	def removeCallbacks(self, *args):
		#logging.info("remove callbacks")
		for id in list(self._callbacks):
			try:
				om.MEventMessage.removeCallback(id)
			except:
				pass
			try:
				om.MNodeMessage.removeCallback(id)
			except:
				pass

			self._callbacks.remove(id)
		self._compute_deferred = "action"
	
	def propagateMaterial(self, msg, plug, otherPlug, *args):
		#logging.info("propagate material?")
		if msg & om.MNodeMessage.kConnectionMade:
			if plug.isCompound and plug.isElement:
				attr = om.MFnAttribute(plug.attribute())
				while True:
					attr_parent = attr.parent
					if not attr_parent.isNull():
						attr = om.MFnAttribute(attr_parent)
						continue
					break
				
				if attr.name == "instObjGroups":
					# Find the input object
					sourceDag = self.getInputDag()[1]
					sourceObjName = None
					if sourceDag and sourceDag.isValid():
						sourceDag.pop()
						sourceObjName = sourceDag.fullPathName()

						# Find the bevelPreview output object
						bevelPreviewNode, bevelPreviewDependency = self.getBevelPreviewNode()
						targetObjName = None
						if bevelPreviewNode and bevelPreviewDependency:
							outMeshPlug = bevelPreviewDependency.findPlug("outMesh", False)
							outMeshPlugArray = outMeshPlug.connectedTo(False, True)
							if len(outMeshPlugArray) > 0:
								targetMObject = outMeshPlugArray[0].node()
								if targetMObject.hasFn(om.MFn.kMesh):
									targetDag = om.MDagPath.getAPathTo(targetMObject)
									if targetDag.isValid():
										targetDag.pop()
										targetObjName = targetDag.fullPathName()
						
						# Assign input object material to bevelPreview object
						if all([sourceObjName, targetObjName]):
							# needs to defer the function to avoid errors
							cmds.evalDeferred(partial(propagateMaterial, sourceObjName, targetObjName))

	def deferredCompute(self, *args):
		if not om.MObjectHandle(self.thisMObject()).isValid():
			self.removeCallbacks()
		
		if self._compute_deferred == "bypass":
			#logging.info("compute now!")
			self._compute_deferred = "action"
			
			# Skip if scale matrix didnt change
			inputMatrixPlug = self.attrToPlug(DynamicBevelNode.aInputMatrix)
			inputMatrix = inputMatrixPlug.asMDataHandle().asMatrix()
			scaleMatrix = om.MTransformationMatrix(inputMatrix).asScaleMatrix()
			if self._currentScaleMatrix == scaleMatrix:
				self._compute_deferred = "sleep"
				return

			# trigger compute
			forceComputeScalePlug = self.attrToPlug(DynamicBevelNode.aForceComputeScale)
			forceComputeScalePlug.setBool(not forceComputeScalePlug.asBool())

class BevelPreviewNode(om.MPxSurfaceShape):
	kNodeName = "gtBevelPreview"
	kNodeId = om.MTypeId(0x00080029)
	drawDbClassification = "drawdb/geometry/gtBevelPreview"
	drawRegistrantId = "NonDestructiveBevel"

	# attributes
	aInMesh = None
	aSourceMesh = None
	aOutMesh = None
	aWireframeOpacity = None
	aRealTime = None
	aForceCompute = None
	aWeightedNormals = None

	def __init__(self):
		om.MPxSurfaceShape.__init__(self)
		self._initNode = False
		self._idle_callback = []
		self._compute_deferred = "action"
		self._transfer_normals = True
		self._polyBevelDict = None
		self._dagPath = om.MDagPath()
		self._nodeStateChange = False
		self._lastNormals = []
		self._tvnScriptJob = None
		self._weightedNormals = True
		self.displayColorsPlug = om.MPlug()
		self.wireColorRGBPlug = om.MPlug()

	@classmethod
	def creator(cls):
		return cls()

	@classmethod
	def initialize(cls):
		## -------------------------- INPUTS --------------------------- ##
		inMeshAttr = om.MFnTypedAttribute()
		cls.aInMesh = inMeshAttr.create("inMesh", "inm", om.MFnData.kMesh, om.MObject.kNullObj)
		inMeshAttr.readable = False
		inMeshAttr.writable = True
		inMeshAttr.hidden = True
		inMeshAttr.storable = False
		om.MPxNode.addAttribute(cls.aInMesh)

		srcTypeAttr = om.MFnTypedAttribute()
		cls.aSourceMesh = srcTypeAttr.create("sourceMesh", "src", om.MFnData.kMesh, om.MObject.kNullObj)
		srcTypeAttr.writable = True
		srcTypeAttr.readable = False
		srcTypeAttr.hidden = True
		srcTypeAttr.storable = False
		srcTypeAttr.disconnectBehavior = om.MFnAttribute.kReset
		om.MPxNode.addAttribute(cls.aSourceMesh)

		woAttr = om.MFnNumericAttribute()
		cls.aWireframeOpacity = woAttr.create("wireframeOpacity", "wo", om.MFnNumericData.kFloat, 0.2)
		woAttr.writable = True
		woAttr.readable = False
		woAttr.hidden = False
		woAttr.storable = False
		woAttr.keyable = True
		woAttr.setMin(0)
		woAttr.setMax(1)
		om.MPxNode.addAttribute(cls.aWireframeOpacity)

		rtAttr = om.MFnNumericAttribute()
		cls.aRealTime = rtAttr.create("realTime", "rtm", om.MFnNumericData.kBoolean, False)
		rtAttr.writable = True
		rtAttr.readable = False
		rtAttr.hidden = False
		rtAttr.storable = False
		rtAttr.keyable = True
		om.MPxNode.addAttribute(cls.aRealTime)

		wnAttr = om.MFnNumericAttribute()
		cls.aWeightedNormals = wnAttr.create("weightedNormals", "wn", om.MFnNumericData.kBoolean, True)
		wnAttr.writable = True
		wnAttr.readable = False
		wnAttr.hidden = False
		wnAttr.storable = False
		wnAttr.keyable = True
		wnAttr.affectsAppearance = True
		om.MPxNode.addAttribute(cls.aWeightedNormals)

		fcAttr = om.MFnNumericAttribute()
		cls.aForceCompute = fcAttr.create("forceCompute", "fc", om.MFnNumericData.kBoolean, False)
		fcAttr.writable = False
		fcAttr.readable = False
		fcAttr.hidden = True
		om.MPxNode.addAttribute(cls.aForceCompute)
		## -------------------------- OUTPUTS -------------------------- ## 
		outMeshAttr = om.MFnTypedAttribute()
		cls.aOutMesh = outMeshAttr.create("outMesh", "outm", om.MFnData.kMesh, om.MObject.kNullObj)
		outMeshAttr.readable = True
		outMeshAttr.writable = False
		outMeshAttr.hidden = True
		outMeshAttr.storable = False
		#outMeshAttr.disconnectBehavior = om.MFnAttribute.kReset
		om.MPxNode.addAttribute(cls.aOutMesh)

		## ---------- Specify what inputs affect the outputs ---------- ##
		om.MPxNode.attributeAffects(cls.aInMesh, cls.aOutMesh)
		om.MPxNode.attributeAffects(cls.aSourceMesh, cls.aOutMesh)
		om.MPxNode.attributeAffects(cls.aWeightedNormals, cls.aOutMesh)
		om.MPxNode.attributeAffects(cls.aForceCompute, cls.aOutMesh)

	def postConstructor(self):
		## This call allows the shape to have shading groups assigned
		self.isRenderable = True

		## Is the shape dirty? Used by VP2.0 sub-scene evaluator
		self.fShapeDirty = True
		self.fMaterialDirty = True

		dgNode = om.MFnDependencyNode(self.thisMObject())
		if dgNode.hasAttribute("displayColors"):
			self.displayColorsPlug = dgNode.findPlug("displayColors", False)
		#om.MFnNumericAttribute(self.displayColorsPlug.attribute()).keyable = True
		if dgNode.hasAttribute("wireColorRGB"):
			self.wireColorRGBPlug = dgNode.findPlug("wireColorRGB", False)
		self.wireOpacityPlug = om.MPlug(self.thisMObject(), BevelPreviewNode.aWireframeOpacity)

		dgNode.setName("bevelPreviewShape#")

	def attrToPlug(self, attr):
		return om.MPlug(self.thisMObject(), attr)

	def setIcon(self):
		objectName = om.MFnDependencyNode(self.thisMObject()).name()

		sel = OpenMaya.MSelectionList()
		sel.add(objectName)

		mobj = OpenMaya.MObject()
		sel.getDependNode(0, mobj)

		iconPath = os.path.join(os.path.dirname(ROOT_DIR), os.path.join("icons", "NDB_NonDestructiveBevel_Icon_20.png"))

		fn = OpenMaya.MFnDependencyNode(mobj)
		fn.setIcon(iconPath)

	def createCallback(self):
		#logging.info("create callback")
		self._idle_callback.append(om.MEventMessage.addEventCallback("idleVeryLow", self.deferredCompute))
		#self._idle_callback.append(om.MDGMessage.addNodeRemovedCallback(self.removeCallbacks, "dependNode"))
		self._idle_callback.append(om.MNodeMessage.addNodeDestroyedCallback(self.thisMObject(), self.removeCallbacks))
		#self._idle_callback.append(om.MNodeMessage.addNodePreRemovalCallback(self.thisMObject(), self.removeCallbacks))
		#self._idle_callback.append(om.MNodeMessage.addNodeAboutToDeleteCallback(self.thisMObject(), self.removeCallbacks))

	def removeCallbacks(self, *args):
		#logging.info("remove callbacks")
		for id in list(self._idle_callback):
			try:
				om.MEventMessage.removeCallback(id)
			except:
				pass
			try:
				om.MNodeMessage.removeCallback(id)
			except:
				pass
			try:
				om.MDGMessage.removeCallback(id)
			except:
				pass

			self._idle_callback.remove(id)
		self._compute_deferred = "action"
	
	def getDynamicBevelDependency(self):
		#logging.info("getDynamicBevelDependency")

		inMeshPlug = self.attrToPlug(BevelPreviewNode.aInMesh)
		dependencyGraph = om.MItDependencyGraph(inMeshPlug, om.MItDependencyGraph.kUpstream, om.MItDependencyGraph.kPlugLevel)
		while not dependencyGraph.isDone():
			currentItem = dependencyGraph.currentNode()
			currentDependencyNode = om.MFnDependencyNode(currentItem)
			if currentDependencyNode.typeName == "gtDynamicBevel":
				return currentDependencyNode
			dependencyGraph.next()
		
		return None

	def deferredCompute(self, *args):
		if not om.MObjectHandle(self.thisMObject()).isValid():
			self.removeCallbacks()
		
		if self._compute_deferred == "bypass":

			dynamicBevelDependency = self.getDynamicBevelDependency()
			if dynamicBevelDependency:
				computeBevelPreviewPlug = dynamicBevelDependency.findPlug("computeBevelPreview", False)
				if not computeBevelPreviewPlug.asBool():
					forceComputePlug = dynamicBevelDependency.findPlug("forceCompute", False)
					forceComputePlug.setBool(not forceComputePlug.asBool())
					self._compute_deferred = "sleep"
					return

			#logging.info("compute BevelPreviewNode now!")
			self._compute_deferred = "action"
			#self._transfer_normals = True
			# trigger compute
			#self.signalDirtyToViewport()
			forceComputePlugHandle = self.attrToPlug(BevelPreviewNode.aForceCompute)
			forceComputePlugHandle.setBool(not forceComputePlugHandle.asBool())

	def excludeAsPluginShape(self):
		return True

	def isBounded(self):
		return True

	def boundingBox(self):
		dagNode = self.getPlugDag("outMesh")[0]
		if dagNode:
			return dagNode.boundingBox
		
		return om.MBoundingBox()

	def getShapeSelectionMask(self):
		return om.MSelectionMask(om.MSelectionMask.kSelectMeshes)

	def getComponentSelectionMask(self):
		selMask = om.MSelectionMask(om.MSelectionMask.kSelectMeshVerts)
		selMask.addMask(om.MSelectionMask.kSelectMeshEdges)
		selMask.addMask(om.MSelectionMask.kSelectMeshFaces)
		selMask.addMask(om.MSelectionMask.kSelectMeshUVs)
		return selMask

	def transferNormalsDeferred(self, sourceMeshObj, inMeshObj, outMeshHandle):
		#logging.info("transfer vertex normals deferred")
		
		forceComputePlugHandle = self.attrToPlug(BevelPreviewNode.aForceCompute)
		forceComputePlugHandle.setBool(not forceComputePlugHandle.asBool())
	
	def compute(self, plug, datablock):
		#logging.info("compute BevelPreviewNode")
		if not self._initNode:
			# Set icon
			self.setIcon()
			
			# Set shading group
			#dgNode = om.MFnDependencyNode(self.thisMObject())
			#cmds.evalDeferred(partial(cmds.sets, dgNode.name(), edit=True, forceElement="initialShadingGroup"))
		
			# Create default polyBevelDict
			#self._polyBevelDict = self.getPolyBevelDict()
			cmds.evalDeferred(partial(self.getPolyBevelDict, setValue=True))

			self._initNode = True

		# Create callbacks
		if not self._idle_callback:
			self.createCallback()
		
		if plug != BevelPreviewNode.aOutMesh:
			#logging.info("stop compute BevelPreviewNode")
			return

		realTimeHandle = self.attrToPlug(BevelPreviewNode.aRealTime)
		attributeChange = False
		if not realTimeHandle.asBool():
			# Deferred compute
			if self._compute_deferred != "action":
				# verify if polyBevel attribute changed
				_polyBevelDict = self.getPolyBevelDict() # error Maya 2018
				if _polyBevelDict and _polyBevelDict != self._polyBevelDict:
					#logging.info("polyBevel attribute change!")
					self._polyBevelDict = dict(_polyBevelDict)
					attributeChange = True

				if not attributeChange:
					self._compute_deferred = "bypass"
					return

			self._compute_deferred = "sleep"

		#logging.info("compute BevelPreviewNode output")
		#inMeshHandle = datablock.inputValue(BevelPreviewNode.aInMesh)

		if self._nodeStateChange:
			self._nodeStateChange = False
			#executeDeferred(bevelPreviewViewportCallbackFn, forceDisplay=True)
			return
		
		inMeshHandle = datablock.inputValue(BevelPreviewNode.aInMesh)
		outMeshHandle = datablock.outputValue(BevelPreviewNode.aOutMesh)
		inMeshObj = inMeshHandle.asMesh()
		if not inMeshObj.isNull() and inMeshObj.hasFn(om.MFn.kMesh):

			# skip if nodeState set to blocking
			if inspect.isclass(CreatePrimitiveLive):
				if CreatePrimitiveLive.getCurrentState():
					inMeshPlug = self.attrToPlug(BevelPreviewNode.aInMesh)
					inMeshPlugArray = inMeshPlug.connectedTo(True, False)
					if not len(inMeshPlugArray) == 0:
						inputMObject = inMeshPlugArray[0].node()
						dgNode = om.MFnDependencyNode(inputMObject)
						nodeStatePlug = dgNode.findPlug("nodeState", False)
						if nodeStatePlug.asInt() == 2:
							#logging.info("skip BevelPreviewNode compute")
							self._nodeStateChange = True
							self._transfer_normals = True
							#executeDeferred(bevelPreviewViewportCallbackFn, forceDisplay=True)
							return

			# verify that a material is connected
			#executeDeferred(partial(self.connectDefaultMaterial))
			self.connectDefaultMaterial()

			dynamicBevelDependency = self.getDynamicBevelDependency()
			weightedNormalsHandle = self.attrToPlug(BevelPreviewNode.aWeightedNormals)
			weightedNormalsAttr = weightedNormalsHandle.asBool()

			if self._transfer_normals and weightedNormalsAttr and (dynamicBevelDependency and dynamicBevelDependency.findPlug("computeBevelPreview", False).asBool()):
				sourceMeshHandle = datablock.inputValue(BevelPreviewNode.aSourceMesh)
				sourceMeshObj = sourceMeshHandle.asMesh()

				# If source object exists
				if not sourceMeshObj.isNull() and sourceMeshObj.hasFn(om.MFn.kMesh):
					if not realTimeHandle.asBool() and (attributeChange or getMayaInputState()):
						if not (self._tvnScriptJob and cmds.scriptJob(exists=self._tvnScriptJob)):
							self._tvnScriptJob = cmds.scriptJob(event=("idleVeryLow", partial(self.transferNormalsDeferred, sourceMeshObj, inMeshObj, outMeshHandle)), runOnce=True)

					else:
						#logging.info("transfer vertex normals")
						
						# Get the source vertex normals
						sourceMeshFn = om.MFnMesh(sourceMeshObj)
						sourceNormals = sourceMeshFn.getNormals(om.MSpace.kObject)
						#if list(self._lastNormals) == list(sourceNormals):
							#return
						#self._lastNormals = sourceNormals

						# Transfer the vertex normals
						inMeshFn = om.MFnMesh(inMeshObj)
						inMeshFn.setNormals(sourceNormals[:inMeshFn.numNormals], om.MSpace.kObject)

						self._weightedNormals = True

						'''# Get bevel vertex positions
						inMeshFn = om.MFnMesh(inMeshObj)
						vertexPositions = inMeshFn.getPoints(om.MSpace.kObject)

						# Copy source object to output
						outMeshHandle.copy(sourceMeshHandle)
						outputMesh = outMeshHandle.asMesh()

						# Set the vertex positions of the output
						outputMeshFn = om.MFnMesh(outputMesh)
						#outputMeshFn.lockVertexNormals(range(outputMeshFn.numVertices))

						polygonVertCount, polygonVertIds = outputMeshFn.getVertices()
						faceIds, vertIds = [], []
						for faceId, x in enumerate(polygonVertCount):
							connectStart = sum(polygonVertCount[:faceId])
							connectEnd = connectStart + x
							faceVertexIds = polygonVertIds[connectStart:connectEnd]
							faceIds.extend([faceId for i in faceVertexIds])
							vertIds.extend(faceVertexIds)
						outputMeshFn.lockFaceVertexNormals(faceIds, vertIds)

						outputMeshFn.setPoints(vertexPositions, om.MSpace.kObject)

						# Set output object
						inMeshObj = outputMesh'''
			
			# If weighted normals gets disabled, make sure normals are reseted
			if self._weightedNormals and not weightedNormalsAttr:
				inMeshFn = om.MFnMesh(inMeshObj)
				inMeshFn.unlockVertexNormals(range(inMeshFn.numVertices))
				self._weightedNormals = False

			self._transfer_normals = True
			outMeshHandle.setMObject(inMeshObj)
			outMeshHandle.setClean()

	def setDependentsDirty(self, plug, affect):
		#if plug in [BevelPreviewNode.aInMesh, BevelPreviewNode.aSourceMesh, BevelPreviewNode.aWeightedNormals, self.displayColorsPlug, self.wireColorRGBPlug, BevelPreviewNode.aWireframeOpacity, BevelPreviewNode.aForceCompute]:
		if plugMatch(plug, [BevelPreviewNode.aInMesh, BevelPreviewNode.aSourceMesh, BevelPreviewNode.aWeightedNormals, self.displayColorsPlug, self.wireColorRGBPlug, BevelPreviewNode.aWireframeOpacity, BevelPreviewNode.aForceCompute]):
			self.signalDirtyToViewport()
			affect.append(om.MPlug(self.thisMObject(), BevelPreviewNode.aOutMesh))
			self._transfer_normals = True
			if plugMatch(plug, [self.displayColorsPlug, self.wireColorRGBPlug, BevelPreviewNode.aWireframeOpacity]):
				self._transfer_normals = False

	def connectDefaultMaterial(self):
		dgNode = om.MFnDependencyNode(self.thisMObject())
		instObjGroups = dgNode.findPlug("instObjGroups", True)
		if instObjGroups.isArray:
			plugIds = instObjGroups.getExistingArrayAttributeIndices()
			srcPlugsArray = [instObjGroups.elementByLogicalIndex(pid) for pid in plugIds]
			for srcp in srcPlugsArray:
				destPlugsArray = srcp.connectedTo(False, True)
				for destp in destPlugsArray:
					if destp.node().apiType() == om.MFn.kShadingEngine:
						return
		
		#logging.info("connecting initialShadingGroup")
		cmds.evalDeferred(partial(forceConnectMaterial, dgNode.name(), "initialShadingGroup"))

	def connectionMade(self, plug, otherPlug, asSrc):
		dgNode = om.MFnDependencyNode(self.thisMObject())
		instObjGroups = dgNode.findPlug("instObjGroups", True)
		if plug == instObjGroups:
			self.setMaterialDirty(True)
		elif plug == BevelPreviewNode.aOutMesh:
			self.signalDirtyToViewport()

		return om.MPxNode.connectionMade(self, plug, otherPlug, asSrc)

	def connectionBroken(self, plug, otherPlug, asSrc):		
		dgNode = om.MFnDependencyNode(self.thisMObject())
		instObjGroups = dgNode.findPlug("instObjGroups", True)
		if plug == instObjGroups:
			self.setMaterialDirty(True)
		elif plug == BevelPreviewNode.aOutMesh:
			self.signalDirtyToViewport()

		return om.MPxNode.connectionBroken(self, plug, otherPlug, asSrc)

	def shapeDirty(self):
		return self.fShapeDirty

	def resetShapeDirty(self):
		self.fShapeDirty = False

	def materialDirty(self):
		return self.fMaterialDirty

	def setMaterialDirty(self, dirty):
		self.fMaterialDirty = dirty
	
	def signalDirtyToViewport(self):
		self.fShapeDirty = True
		omr.MRenderer.setGeometryDrawDirty(self.thisMObject())

	#@deferred_thread_safe
	def getPolyBevelDict(self, setValue=False):
		#logging.info("getPolyBevelDict")
		_polyBevelDict = defaultdict(dict)
		inputPlug = self.attrToPlug(BevelPreviewNode.aInMesh)
		if inputPlug.isConnected:
			inputPlugArray = inputPlug.connectedTo(True, False)
			for p in inputPlugArray:
				if p.node().apiType() in [om.MFn.kPolyBevel, om.MFn.kPolyBevel2, om.MFn.kPolyBevel3]:
					nodeName = p.name().split(".")[0]
					#attributeList = cmds.listAttr(nodeName, write=True, settable=True, keyable=True)
					#for attr in attributeList:
						#_polyBevelDict[nodeName][attr] = cmds.getAttr(nodeName+"."+attr)
					
					dNode = om.MFnDependencyNode(p.node())
					for attrId in range(dNode.attributeCount()):
						attrMobj = dNode.attribute(attrId)
						attr = om.MFnAttribute(attrMobj)
						plug = dNode.findPlug(attrMobj, False)
						if all([attr.writable, attr.storable, not attr.hidden]):
							_polyBevelDict[nodeName][attr.name] = getPlugValue(plug, attrMobj)

		if setValue:
			self._polyBevelDict = _polyBevelDict
		return _polyBevelDict

	def getDagPath(self):
		if not self._dagPath.isValid():
			self._dagPath = om.MDagPath()

		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		inMeshPlug = dependencyNode.findPlug("outMesh", False)
		inMeshPlugArray = inMeshPlug.connectedTo(False, True)
		if len(inMeshPlugArray) > 0:
			inMeshMObject = inMeshPlugArray[0].node()
			if inMeshMObject.hasFn(om.MFn.kMesh):
				self._dagPath = om.MDagPath.getAPathTo(inMeshMObject)

		return self._dagPath
	
	def getPlugDag(self, plugName):
		dagNode = None
		dagPath = None
		dependencyNode = om.MFnDependencyNode(self.thisMObject())
		if dependencyNode.hasAttribute(plugName):
			inputMeshPlug = dependencyNode.findPlug(plugName, False)
			inputPlugArray = []
			if inputMeshPlug.isDestination:
				inputPlugArray = inputMeshPlug.connectedTo(True, False)
			elif inputMeshPlug.isSource:
				inputPlugArray = inputMeshPlug.connectedTo(False, True)
			if len(inputPlugArray) > 0:
				inputMObject = inputPlugArray[0].node()
				if inputMObject.hasFn(om.MFn.kMesh):
					dagNode = om.MFnDagNode(inputMObject)
					dagPath = dagNode.getPath()
		return dagNode, dagPath
	
	def displayColorsState(self):
		state = False

		if not self.displayColorsPlug.isNull:
			state = self.displayColorsPlug.asBool()
		
		return state
	
	def wireColorRGBAState(self):
		state = [0, 0, 0, 0.2]

		if not self.wireColorRGBPlug.isNull:
			state = self.wireColorRGBPlug.asMDataHandle().asFloat3()
			state.append(0.2)
		
		if not self.wireOpacityPlug.isNull:
			opacity = self.wireOpacityPlug.asFloat()
			state[3] = max(0, min(1, opacity))
		
		return state
	
	def wireColorAState(self):
		opacity = 0.2

		if not self.wireOpacityPlug.isNull:
			opacity = self.wireOpacityPlug.asFloat()
		
		return opacity

class BevelPreviewShapeUI(omui.MPxSurfaceShapeUI):
	def __init__(self):
		omui.MPxSurfaceShapeUI.__init__(self)

	@staticmethod
	def creator():
		return BevelPreviewShapeUI()

class BevelPreviewGeometryOverride(omr.MPxGeometryOverride):
	## Render item names
	sWireframeItemName = "BevelPreviewWireframe"
	sSelectedWireframeItemName = "BevelPreviewSelectedWireFrame"

	def __init__(self, obj):
		omr.MPxGeometryOverride.__init__(self, obj)
		self.fThisNode = om.MObject(obj)
		self.fType = om.MFn.kInvalid # the type of the associated object.
		self.fPath = om.MDagPath() # the associated object path.
		self.fMesh = om.MFnDependencyNode(obj).userNode()
		self.fProxyShader = omr.MShaderManager.k3dDashLineShader # When no shader node is assigned to the object
		self._componentMode = False
		self._initNode = False

	def __del__(self):
		self.fMesh = None
	
	@staticmethod
	def creator(obj):
		return BevelPreviewGeometryOverride(obj)

	def supportedDrawAPIs(self):
		return (omr.MRenderer.kOpenGL | omr.MRenderer.kDirectX11 | omr.MRenderer.kOpenGLCoreProfile)

	def updateDG(self):
		if self.fMesh:
			self.fPath = self.fMesh.getDagPath()
			if self.fPath.isValid():
				self.fType = self.fPath.apiType()
			else:
				self.fType = om.MFn.kInvalid

	def updateRenderItems(self, path, itemsList):
		if not self.fPath.isValid():
			return
		
		shaderManager = omr.MRenderer.getShaderManager()
		if not shaderManager:
			return
		
		if self.fType == om.MFn.kMesh:
			if not self._initNode:
				self._initNode = True

				if cmds.optionVar(exists="BP_ContextSelectionCallback") and cmds.optionVar(query="BP_ContextSelectionCallback"):
					self.hideSourceObjects(path)
				else:
					self.showSourceObjects(path)
			
			else:
				# set source objects visibility
				if cmds.optionVar(exists="BP_ContextSelectionCallback") and cmds.optionVar(query="BP_ContextSelectionCallback"):
					self.setSourceObjectDisplay(path)

			## update wireframe render items
			self.updateDormantAndTemplateWireframeItems(path, itemsList, shaderManager)
			self.updateActiveWireframeItem(path, itemsList, shaderManager)
			
			## disable StandardShadedItem if CPV is shown.
			showCPV = self.fMesh.displayColorsState()
			index = itemsList.indexOf("StandardShadedItem", omr.MGeometry.kTriangles, omr.MGeometry.kShaded)
			if index >= 0:
				shadedItem = itemsList[index]
				if shadedItem is not None:
					shadedItem.enable(not showCPV)

			index = itemsList.indexOf("StandardShadedItem", omr.MGeometry.kTriangles, omr.MGeometry.kTextured)
			if index >= 0:
				shadedItem = itemsList[index]
				if shadedItem is not None:
					shadedItem.enable(not showCPV)

			## add item for CPV.
			index = itemsList.indexOf("BevelPreviewCPV")
			if index >= 0:
				cpvItem = itemsList[index]
				if cpvItem is not None:
					cpvItem.enable(showCPV)

			else:
				## if no cpv item and showCPV is true, created the cpv item.
				if showCPV:
					cpvItem = omr.MRenderItem.create("BevelPreviewCPV", omr.MRenderItem.MaterialSceneItem, omr.MGeometry.kTriangles)
					cpvItem.setDrawMode(omr.MGeometry.kShaded | omr.MGeometry.kTextured)
					itemsList.append(cpvItem)

					shader = shaderManager.getStockShader(omr.MShaderManager.k3dCPVSolidShader)
					if shader is not None:
						cpvItem.setShader(shader)
						cpvItem.enable(True)
						shaderManager.releaseShader(shader)

	def populateGeometry(self, requirements, renderItems, data):
		if not self.fPath.isValid():
			return

		## here, fPath is the path of the linked object instead of the plugin node; it
		## is used to determine the right type of the geometry shape, e.g., polygon
		## or NURBS surface.
		## The sharing flag (true here) is just for the polygon shape.
		options = omr.MGeometryExtractor.kPolyGeom_Normal
		options = options | omr.MGeometryExtractor.kPolyGeom_BaseMesh

		try:
			extractor = omr.MGeometryExtractor(requirements, self.fPath, options)
		except:
			extractor = None
		if extractor is None:
			return

		## fill vertex buffer
		descList = requirements.vertexRequirements()
		for desc in descList:
			if desc.semantic == omr.MGeometry.kPosition or desc.semantic == omr.MGeometry.kShaded or desc.semantic == omr.MGeometry.kTexture or desc.semantic == omr.MGeometry.kNormal or desc.semantic == omr.MGeometry.kTangent or desc.semantic == omr.MGeometry.kBitangent or desc.semantic == omr.MGeometry.kColor:
				#if desc.semantic == omr.MGeometry.kTexture:
					#continue

				vertexBuffer = data.createVertexBuffer(desc)
				if vertexBuffer:
					## MGeometryExtractor.vertexCount and MGeometryExtractor.populateVertexBuffer.
					## since the plugin node has the same vertex data as its linked scene object,
					## call vertexCount to allocate vertex buffer of the same size, and then call
					## populateVertexBuffer to copy the data.
					vertexCount = extractor.vertexCount()
					vertices = vertexBuffer.acquire(vertexCount, True) ## writeOnly - we don't need the current buffer values
					if vertices:
						try:
							extractor.populateVertexBuffer(vertices, vertexCount, desc)
						except Exception as e:
							pass
						vertexBuffer.commit(vertices)

		## fill index buffer
		for item in renderItems:
			indexBuffer = data.createIndexBuffer(omr.MGeometry.kUnsignedInt32)
			if not indexBuffer:
				continue

			## MGeometryExtractor.primitiveCount and MGeometryExtractor.populateIndexBuffer.
			## since the plugin node has the same index data as its linked scene object,
			## call primitiveCount to allocate index buffer of the same size, and then call
			## populateIndexBuffer to copy the data.
			if item.primitive() == omr.MGeometry.kTriangles:
				triangleDesc = omr.MIndexBufferDescriptor(omr.MIndexBufferDescriptor.kTriangle, "", omr.MGeometry.kTriangles, 3)
				numTriangles = extractor.primitiveCount(triangleDesc)

				indices = indexBuffer.acquire(3 * numTriangles, True) ## writeOnly - we don't need the current buffer values
				extractor.populateIndexBuffer(indices, numTriangles, triangleDesc)
				indexBuffer.commit(indices)

			elif item.primitive() == omr.MGeometry.kLines:
				edgeDesc = omr.MIndexBufferDescriptor(omr.MIndexBufferDescriptor.kEdgeLine, "", omr.MGeometry.kLines, 2)
				numEdges = extractor.primitiveCount(edgeDesc)

				indices = indexBuffer.acquire(2 * numEdges, True) ## writeOnly - we don't need the current buffer values
				extractor.populateIndexBuffer(indices, numEdges, edgeDesc)
				indexBuffer.commit(indices)

			item.associateWithIndexBuffer(indexBuffer)
	
	def cleanUp(self):
		# no-op
		pass

	## Render item handling methods
	def updateDormantAndTemplateWireframeItems(self, path, itemsList, shaderMgr):
		wireframeItem = None
		index = itemsList.indexOf(self.sWireframeItemName)
		if index < 0:
			wireframeItem = omr.MRenderItem.create(self.sWireframeItemName, omr.MRenderItem.DecorationItem, omr.MGeometry.kLines)
			wireframeItem.setDrawMode(omr.MGeometry.kWireframe)

			## Set dormant wireframe with appropriate priority to not clash with
			## any active wireframe which may overlap in depth.
			wireframeItem.setDepthPriority(omr.MRenderItem.sDormantWireDepthPriority)

			itemsList.append(wireframeItem)

			shader = shaderMgr.getStockShader(omr.MShaderManager.k3dSolidShader, None, None)
			if shader:
				## assign shader
				wireframeItem.setShader(shader)

				## once assigned, no need to hold on to shader instance
				shaderMgr.releaseShader(shader)
		else:
			wireframeItem = itemsList[index]

		#displayStatus = omr.MGeometryUtilities.displayStatus(path)
		#wireColor = omr.MGeometryUtilities.wireframeColor(path)
		
		## Enable / disable wireframe item and update the shader parameters
		if wireframeItem:
			shader = wireframeItem.getShader()

			wireColor = self.fMesh.wireColorRGBAState()
			self.setSolidColor(shader, wireColor)
			wireframeItem.enable(True)

			'''
			if displayStatus == omr.MGeometryUtilities.kTemplate:
				wireframeItem.enable(True)

			elif displayStatus == omr.MGeometryUtilities.kActiveTemplate:
				wireframeItem.enable(True)

			elif displayStatus == omr.MGeometryUtilities.kDormant:
				#colorIndex = cmds.displayColor("polymesh", query=True, dormant=True)
				#wireColor = cmds.colorIndex(colorIndex, query=True)
				#wireColor.append(0.2)
				#self.setSolidColor(shader, wireColor)
				wireframeItem.enable(True)

			elif displayStatus == omr.MGeometryUtilities.kActiveAffected:
				wireframeItem.enable(True)

			else:
				#wireframeItem.enable(False)
				wireframeItem.enable(True)
			'''

	def updateActiveWireframeItem(self, path, itemsList, shaderMgr):
		## Create a render item for active wireframe if it does not exist. Updating
		## shading parameters as necessary.

		selectItem = None
		index = itemsList.indexOf(self.sSelectedWireframeItemName)
		if index < 0:
			selectItem = omr.MRenderItem.create(self.sSelectedWireframeItemName, omr.MRenderItem.DecorationItem, omr.MGeometry.kLines)
			selectItem.setDrawMode(omr.MGeometry.kAll)
			selectItem.setDepthPriority(omr.MRenderItem.sActiveWireDepthPriority)
			itemsList.append(selectItem)

			## For active wireframe we will use a shader which allows us to draw thick lines
			drawThick = False
			shaderId = omr.MShaderManager.k3dSolidShader
			if drawThick:
				shaderId = omr.MShaderManager.k3dThickLineShader

			shader = shaderMgr.getStockShader(shaderId)
			if shader:
				## assign shader
				selectItem.setShader(shader)
				## once assigned, no need to hold on to shader instance
				shaderMgr.releaseShader(shader)
		else:
			selectItem = itemsList[index]

		shader = None
		if selectItem:
			shader = selectItem.getShader()

		displayStatus = omr.MGeometryUtilities.displayStatus(path)
		#wireColor = omr.MGeometryUtilities.wireframeColor(path)
		wireColor = [1, 1, 1, 0.2]
		wireColor[3] = self.fMesh.wireColorAState()

		self.setSolidColor(shader, wireColor)
		selectItem.enable(True)

		if displayStatus not in [omr.MGeometryUtilities.kLead, omr.MGeometryUtilities.kActive, omr.MGeometryUtilities.kHilite, omr.MGeometryUtilities.kActiveComponent]:
			selectItem.enable(False)

		'''
		if displayStatus == omr.MGeometryUtilities.kLead:
			self.setSolidColor(shader, wireColor)
			selectItem.enable(True)

		elif displayStatus == omr.MGeometryUtilities.kActive:
			self.setSolidColor(shader, wireColor)
			selectItem.enable(True)

		elif displayStatus == omr.MGeometryUtilities.kHilite or displayStatus == omr.MGeometryUtilities.kActiveComponent:
			self.setSolidColor(shader, wireColor)
			selectItem.enable(True)

		else:
			selectItem.enable(False)
		'''

	def setSolidColor(self, shaderInstance, defaultColor):
		## Set the solid color for solid color shaders
		if shaderInstance:
			color = defaultColor
			try:
				shaderInstance.setParameter("solidColor", color)
			except:
				pass

	@make_undoable
	def showSourceObjects(self, path):
		#logging.info("showSourceObjects")
		sourceObjects = getBevelPreviewSourceObject(path.fullPathName())
		sourceShapes = cmds.listRelatives(sourceObjects, fullPath=True, noIntermediate=True, shapes=True) or []
		selList = om.MSelectionList()
		for obj in sourceShapes:
			try:
				selList.add(obj)
			except:
				pass
		
		for i in range(selList.length()):
			mObj = selList.getDependNode(i)
			dagPath = selList.getDagPath(i)
			dgNode = om.MFnDependencyNode(mObj)
			if dgNode.hasAttribute("overrideVisibility"):
				plug = dgNode.findPlug("overrideVisibility", False)
				if not plug.asBool():
					plug.setBool(True)

					# Make sure xRay is enabled if attribute is enabled
					dynamicBevel = getDynamicBevelFromObject(dagPath.node())
					if dynamicBevel and dynamicBevel.hasAttribute("enableXRay"):
						p = dynamicBevel.findPlug("enableXRay", False)
						xRayState = next(iter(cmds.displaySurface(dagPath.fullPathName(), query=True, xRay=True) or []))
						if p.asBool() and not xRayState:
							setDisplaySurface(dagPath.fullPathName(), xRay=True)
		
		dgNode = om.MFnDependencyNode(path.node())
		if dgNode.hasAttribute("overrideEnabled"):
			plug = dgNode.findPlug("overrideEnabled", False)
			if not plug.asBool():
				plug.setBool(True)
		if dgNode.hasAttribute("overrideDisplayType"):
			plug = dgNode.findPlug("overrideDisplayType", False)
			if plug.asInt() != 2:
				plug.setInt(2)
	
	@make_undoable
	def hideSourceObjects(self, path):
		#logging.info("hideSourceObjects")
		sourceObjects = getBevelPreviewSourceObject(path.fullPathName())
		sourceShapes = cmds.listRelatives(sourceObjects, fullPath=True, noIntermediate=True, shapes=True) or []
		selList = om.MSelectionList()
		for obj in sourceShapes:
			try:
				selList.add(obj)
			except:
				pass
		
		for i in range(selList.length()):
			mObj = selList.getDependNode(i)
			dgNode = om.MFnDependencyNode(mObj)
			if dgNode.hasAttribute("overrideEnabled"):
				plug = dgNode.findPlug("overrideEnabled", False)
				if not plug.asBool():
					plug.setBool(True)
			if dgNode.hasAttribute("overrideVisibility"):
				plug = dgNode.findPlug("overrideVisibility", False)
				if plug.asBool():
					plug.setBool(False)
		
		dgNode = om.MFnDependencyNode(path.node())
		if dgNode.hasAttribute("overrideDisplayType"):
			plug = dgNode.findPlug("overrideDisplayType", False)
			if plug.asInt() != 0:
				plug.setInt(0)

	@make_undoable
	def setSourceObjectDisplay(self, path):
		#logging.info("setSourceObjectDisplay")
		#componentMode = cmds.selectMode(query=True, component=True)
		currentHl = cmds.ls(hilite=True, long=True, objectsOnly=True)
		if all([self._componentMode, currentHl]):
			sourceObjects = getBevelPreviewSourceObject(path.fullPathName())
			for srcObj in sourceObjects:
				if srcObj in currentHl:
					return
		elif all([not self._componentMode, not currentHl]):
			return

		hiliteMode, sourceObjects = self.enableActiveComponentDisplay(path)
		if hiliteMode:
			#logging.info("Hilited {0}".format(path.fullPathName()))

			# Force remove bevelPreview from activeSelectionList
			bevelPreview = path.getAPathTo(path.transform())
			removeList = om.MSelectionList()
			for obj in [path, bevelPreview]:
				try:
					removeList.add(obj)
				except:
					pass
			
			cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 0))
			om.MGlobal.setActiveSelectionList(removeList, listAdjustment=om.MGlobal.kAddToList)
			om.MGlobal.setActiveSelectionList(removeList, listAdjustment=om.MGlobal.kRemoveFromList)
			cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))

			cmds.hilite(sourceObjects)
			bevelPreviewSelectionChangedCallback()

			sourceShapes = cmds.listRelatives(sourceObjects, fullPath=True, noIntermediate=True, shapes=True) or []
			selList = om.MSelectionList()
			for obj in sourceShapes:
				try:
					selList.add(obj)
				except:
					pass
			
			for i in range(selList.length()):
				mObj = selList.getDependNode(i)
				dagPath = selList.getDagPath(i)
				dgNode = om.MFnDependencyNode(mObj)
				if dgNode.hasAttribute("overrideVisibility"):
					plug = dgNode.findPlug("overrideVisibility", False)
					if not plug.asBool():
						plug.setBool(True)

						# Make sure xRay is enabled if attribute is enabled
						dynamicBevel = getDynamicBevelFromObject(dagPath.node())
						if dynamicBevel and dynamicBevel.hasAttribute("enableXRay"):
							p = dynamicBevel.findPlug("enableXRay", False)
							xRayState = next(iter(cmds.displaySurface(dagPath.fullPathName(), query=True, xRay=True) or []))
							if p.asBool() and not xRayState:
								setDisplaySurface(dagPath.fullPathName(), xRay=True)
			
			self._componentMode = True

		elif not hiliteMode:
			#logging.info("Not hilited {0}".format(path.fullPathName()))

			sourceObjects = getBevelPreviewSourceObject(path.fullPathName())
			sourceShapes = cmds.listRelatives(sourceObjects, fullPath=True, noIntermediate=True, shapes=True) or []
			selList = om.MSelectionList()
			for obj in sourceShapes:
				try:
					selList.add(obj)
				except:
					pass
			
			for i in range(selList.length()):
				mObj = selList.getDependNode(i)
				dgNode = om.MFnDependencyNode(mObj)
				if dgNode.hasAttribute("overrideEnabled"):
					plug = dgNode.findPlug("overrideEnabled", False)
					if not plug.asBool():
						plug.setBool(True)
				if dgNode.hasAttribute("overrideVisibility"):
					plug = dgNode.findPlug("overrideVisibility", False)
					if plug.asBool():
						plug.setBool(False)

			# Make sure the object is in the activeSelectionList
			if not currentHl:
				bevelPreview = path.getAPathTo(path.transform())
				if not om.MGlobal.getActiveSelectionList().hasItem(bevelPreview):
					changeSelection = False
					sourceObjectsList = om.MSelectionList()
					for obj in sourceObjects:
						try:
							sourceObjectsList.add(obj)
						except:
							pass
					for i in range(sourceObjectsList.length()):
						mObj = sourceObjectsList.getDependNode(i)
						if om.MGlobal.getActiveSelectionList().hasItem(mObj):
							changeSelection = True

					if changeSelection:
						addList = om.MSelectionList()
						try:
							addList.add(bevelPreview)
						except:
							pass
						cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 0))
						om.MGlobal.setActiveSelectionList(addList, listAdjustment=om.MGlobal.kAddToList)
						cmds.optionVar(intValue=("NDB_SelectionChangedCallback", 1))

			self._componentMode = False

	def enableActiveComponentDisplay(self, path):
		## Test to see if active components should be enabled.
		## Based on active vertices + non-template state
		enable = False
		sourceObjects = []

		displayStatus = omr.MGeometryUtilities.displayStatus(path)
		if displayStatus & omr.MGeometryUtilities.kHilite:
			enable = True
			sourceObjects = getBevelPreviewSourceObject(path.fullPathName())
			#if path.isTemplated():
		else:
			currentHl = cmds.ls(hilite=True, long=True)
			#componentMode = cmds.selectMode(query=True, component=True)
			#if all([currentHl, not componentMode]):
			if currentHl:
				sourceObjects = getBevelPreviewSourceObject(path.fullPathName())
				sourceObjects = [x for x in sourceObjects if x in currentHl]
				if sourceObjects:
					enable = True

		return enable, sourceObjects

class GetBevelPreviewSourceObject(om.MPxCommand):
	kCommandName = "getBevelPreviewSourceObject"

	def __init__(self):
		om.MPxCommand.__init__(self)

	@staticmethod
	def creator():
		return GetBevelPreviewSourceObject()

	@staticmethod
	def createSyntax():
		syntax = om.MSyntax()
		syntax.setObjectType(om.MSyntax.kSelectionList)
		syntax.useSelectionAsDefault(True)
		return syntax

	def doIt(self, args):
		try:
			argdb = om.MArgDatabase(self.syntax(), args)
		except RuntimeError:
			#om.MGlobal.displayError("Error while parsing arguments, make sure that the object name(s) exist in scene.")
			#raise
			return

		selList = argdb.getObjectList()
		currentSel = selList.getSelectionStrings()
		sourceObjects = getBevelPreviewSourceObject(currentSel)

		if sourceObjects:
			self.setResult(sourceObjects)

class HiliteOverride(om.MPxCommand):
	kCommandName = "hilite"
	kReplaceFlag = "-r"
	kReplaceFlagLong = "-replace"
	kToggleFlag = "-tgl"
	kToggleFlagLong = "-toggle"
	kUnHiliteFlag = "-u"
	kUnHiliteFlagLong = "-unHilite"

	def __init__(self):
		om.MPxCommand.__init__(self)

	@staticmethod
	def creator():
		return HiliteOverride()

	@staticmethod
	def createSyntax():
		syntax = om.MSyntax()
		syntax.setObjectType(om.MSyntax.kSelectionList)
		syntax.useSelectionAsDefault(True)

		syntax.addFlag(HiliteOverride.kReplaceFlag, HiliteOverride.kReplaceFlagLong)
		syntax.addFlag(HiliteOverride.kToggleFlag, HiliteOverride.kToggleFlagLong, om.MSyntax.kBoolean)
		syntax.addFlag(HiliteOverride.kUnHiliteFlag, HiliteOverride.kUnHiliteFlagLong, om.MSyntax.kBoolean)

		return syntax

	def doIt(self, args):
		try:
			argdb = om.MArgDatabase(self.syntax(), args)
		except RuntimeError:
			#om.MGlobal.displayError("Error while parsing arguments, make sure that the object name(s) exist in scene.")
			#raise
			return

		selList = argdb.getObjectList()
		currentSel = selList.getSelectionStrings()
		
		selList = OpenMaya.MSelectionList()
		for sel in currentSel:
			try:
				selList.add(sel)
			except:
				pass

		OpenMaya.MGlobal.setHiliteList(selList)

def NDB_CompressUndo():
	try:
		# If undo is turned off, ignore
		undoState = cmds.undoInfo(query=True, state=True)
		if not undoState:
			return

		redoName = cmds.undoInfo(query=True, redoName=True)
		undoName = cmds.undoInfo(query=True, undoName=True)
		if redoName in ["NDB_ChangeConnections", "NDB_ForceConnectMaterial"]:
			cmds.undo()

			# If last undo is "undefined", need to undo again otherwise nothing gets undone
			lastUndo = cmds.undoInfo(query=True, redoName=True)
			undoName = cmds.undoInfo(query=True, undoName=True)
			if not lastUndo and undoName:
				cmds.undo()
		
		elif undoName in ["NDB_Create", "createDynamicBevel"] and not redoName:
			cmds.undo()
		
	except Exception as e:
		logging.exception(e)

def initializePlugin(obj):
	mplugin = om.MFnPlugin(obj, "GENtools", "1.0.0.0")
	nodeName = None

	try:
		for n in [DynamicBevelNode, TransferVertexNormalsNode, GetHardEdgesNode]:
			nodeName = n.kNodeName
			mplugin.registerNode(nodeName, n.kNodeId, n.creator, n.initialize)
	except:
		raise Exception("Failed to register node: {0}".format(nodeName))
	
	try:
		nodeName = BevelPreviewNode.kNodeName
		mplugin.registerShape(nodeName, BevelPreviewNode.kNodeId, BevelPreviewNode.creator, BevelPreviewNode.initialize, BevelPreviewShapeUI.creator, BevelPreviewNode.drawDbClassification)
	except:
		raise Exception("Failed to register shape: {0}".format(nodeName))

	try:
		omr.MDrawRegistry.registerGeometryOverrideCreator(BevelPreviewNode.drawDbClassification, BevelPreviewNode.drawRegistrantId, BevelPreviewGeometryOverride.creator)
	except:
		raise Exception("Failed to register override: {0}".format(BevelPreviewNode.drawDbClassification))
	
	try:
		for n in [GetBevelPreviewSourceObject]:
			commandName = n.kCommandName
			mplugin.registerCommand(commandName, n.creator, n.createSyntax)
	except Exception as e:
		raise Exception("Failed to register command: {0}".format(commandName))

	# Create NDB_CompressUndo scriptJob
	global NDB_CompressUndo_ScriptJob
	NDB_CompressUndo_ScriptJob = cmds.scriptJob(event=("Undo", NDB_CompressUndo), parent="MayaWindow", protected=True)

	createViewportCallback(startup=True)
	createSelectionCallback(startup=True)

def uninitializePlugin(obj):
	mplugin = om.MFnPlugin(obj)
	nodeName = None

	try:
		for n in [DynamicBevelNode, TransferVertexNormalsNode, GetHardEdgesNode]:
			nodeName = n.kNodeName
			mplugin.deregisterNode(n.kNodeId)
	except:
		raise Exception("Failed to deregister node: {0}".format(nodeName))

	try:
		omr.MDrawRegistry.deregisterGeometryOverrideCreator(BevelPreviewNode.drawDbClassification, BevelPreviewNode.drawRegistrantId)
	except:
		raise Exception("Failed to deregister override: {0}".format(BevelPreviewNode.drawDbClassification))

	try:
		mplugin.deregisterNode(BevelPreviewNode.kNodeId)
	except:
		raise Exception("Failed to deregister shape: {0}".format(BevelPreviewNode.kNodeName))
	
	try:
		for n in [GetBevelPreviewSourceObject]:
			commandName = n.kCommandName
			mplugin.deregisterCommand(commandName)
	except Exception as e:
		raise Exception("Failed to deregister command: {0}".format(commandName))

	# Remove NDB_ChangeConnectionsUndo scriptJob
	global NDB_CompressUndo_ScriptJob
	if "NDB_CompressUndo_ScriptJob" in globals():
		if cmds.scriptJob(exists=NDB_CompressUndo_ScriptJob):
			cmds.scriptJob(kill=NDB_CompressUndo_ScriptJob, force=True)
	
	removeViewportCallback()
	removeSelectionCallback()