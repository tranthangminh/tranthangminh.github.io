#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import maya.mel as mel

from .core.config.infos import GENtools_Root

mel_source_file = r"{0}\GENtools.mel".format(GENtools_Root).replace(os.sep, "/")
mel.eval(r'catchQuiet(eval("source \"{0}\";"));'.format(mel_source_file))
mel.eval(r'evalDeferred("catchQuiet(GENtools_Startup());");')