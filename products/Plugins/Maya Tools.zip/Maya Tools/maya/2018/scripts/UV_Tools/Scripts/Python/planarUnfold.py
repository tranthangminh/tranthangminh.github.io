import maya.cmds as cmds

def planar_unfold():
    mesh = cmds.ls(sl = True)
    cmds.ConvertSelectionToFaces(mesh)
    cmds.polyProjection( ch = True, t='Planar', kir=True,ibd = True,  md='b', )
    cmds.u3dUnfold (ite=5, p=0, bi=1, tf=1, ms=1024, rs=0)
    return
