import maya.cmds as cmds
import maya.mel as mel

def autoUVFromHardEdges(faceList, selectEdge = None):
    mel.eval('DeleteAllHistory;')
    cmds.polyProjection(faceList, ch = 1, type = "Planar", ibd = 1, icx = 0.5, icy = 0.5, ra = 0, isu = 1, isv = 1, md = 'bestPlane')
    if selectEdge:
        cmds.polyMapCut(selectEdge)
    else:
        edgeCut = list()
        edgesList = cmds.filterExpand(cmds.polyListComponentConversion(faceList, te = True), sm = 32 )
        for e in edgesList:
            edgeInfo = cmds.polyInfo(e, ev = True)
            if 'Hard' in edgeInfo[0]:
                edgeCut.append(e)
        if edgeCut:
            cmds.polyMapCut(edgeCut)

    cmds.select(faceList)
    mel.eval("ConvertSelectionToUVs")
    uvList = cmds.ls(sl = True, fl = True)

    while len(uvList) > 0:
        cmds.select(uvList[0])
        mel.eval("SelectUVShell;")
        mel.eval("PolySelectConvert 4;")
        # cmds.unfold(i = 10000, ss = 0.001, gb = 0, gmb = 0.5, pub = 0, ps = 0, oa = 0, us = 0)
        try:
            mel.eval("u3dUnfold -ite 1 -p 1 -bi 1 -tf 1 -ms 1024 -rs 0;")
        except: pass
        temp_shell = cmds.ls(sl=True,fl=True)
        for j in range(0,len(temp_shell)):
            if temp_shell[j] in uvList:
                uvList.remove(temp_shell[j])
    cmds.polyLayoutUV(faceList, lm = 0, sc = 1, se = 0, rbf = 0, fr = 1, ps = 0.2, l = 2, ch = 1)
    mel.eval('DeleteAllHistory;')
    cmds.select(faceList, r = True)
    
def process():
    selected = cmds.ls(sl = True, fl = True, l = True)
    edge = cmds.filterExpand(selected, sm = 32, fp = True)
    face = cmds.filterExpand(selected, sm = 34, fp = True)
    mesh = cmds.filterExpand(selected, sm = 12, fp = True)
    if edge: 
        faceList = cmds.polyListComponentConversion(edge, tf = True)
        cmds.select(faceList)
        mel.eval("SelectUVShell;")
        faceList = cmds.ls(sl = True, fl = True, l = True)
        autoUVFromHardEdges(faceList, edge)
    if face:autoUVFromHardEdges(face)
    if mesh:
        for m in mesh:
            faceList = cmds.polyListComponentConversion(m, tf = True)
            autoUVFromHardEdges(faceList)