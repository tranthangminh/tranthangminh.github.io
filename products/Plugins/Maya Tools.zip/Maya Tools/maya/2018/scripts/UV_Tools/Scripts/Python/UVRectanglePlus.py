'''
Coded by Masaharu Ijichi
Layout Rectangle with keeping scale and Position of UV shell
'''

import pymel.core as pm
import maya.mel as mel

def ezLayoutRectanglePlus():
	selUV = pm.selected()
	mel.eval('polySelectBorderShell 0;')
	uvList = pm.filterExpand(sm=35)
	selVtx = pm.polyListComponentConversion(pm.selected(),fuv=1,tv=1,internal=1)
	
	sumi = []
	pm.select(cl=1)
	for i in uvList:
		eComp = pm.polyListComponentConversion(i,fuv=1,te=1)
		if len( pm.filterExpand( eComp,sm=32 ) ) == 2:
			sumi.append(i)
	sumiU = []
	sumiV = []
	for i in sumi:
		uv = pm.polyEditUV(i,q=1,r=0)
		sumiU.append(uv[0])
		sumiV.append(uv[1])

	uScl = abs( max(sumiU)-min(sumiU) )
	vScl = abs( max(sumiV)-min(sumiV) )
	center = ( min(sumiU),min(sumiV) )
	pm.select(selUV,r=1)
	mel.eval('polyPerformAction polyUVRectangle v 0;')
	newUV = pm.polyListComponentConversion(selVtx,fv=1,tuv=1)
	pm.select(newUV,r=1)
	mel.eval('polySelectBorderShell 0;')
	pm.polyEditUV(su=uScl,sv=vScl,r=1)
	pm.polyEditUV(u=center[0],v=center[1],r=1)