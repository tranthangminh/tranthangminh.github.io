import maya.cmds as cmds
import maya.mel as mel
import os
from functools import partial
import subprocess
import json
import tempfile
import shutil

try:
	dict.iteritems
except AttributeError:
	# Python 3
	from importlib import reload
	def itervalues(d):
		return iter(d.values())
	def iteritems(d):
		return iter(d.items())
	def iterkeys(d):
		return iter(d)

else:
	# Python 2
	def itervalues(d):
		return d.itervalues()
	def iteritems(d):
		return d.iteritems()
	def iterkeys(d):
		return d.iterkeys()

LOCAL_PATH = os.path.expanduser("~").replace("\\", "/") + "/maya/" + str(cmds.about(version=True)) + "/scripts"
LOCAL_PREF_PATH = os.path.expanduser("~").replace("\\", "/") + "/maya/" + str(cmds.about(version=True)) + "/prefs"
if int(cmds.about(version=True)) >= 2023:
	LOCAL_PATH = os.path.expanduser("~").replace("\\", "/") + "/Documents/maya/" + str(cmds.about(version=True)) + "/scripts"
	LOCAL_PREF_PATH = os.path.expanduser("~").replace("\\", "/") + "/Documents/maya/" + str(cmds.about(version=True)) + "/prefs"

SERVER_SOURCE_PATH = "//virtuosgames.com/geh/TOOLS/Technical_Script/Projects/Hard_Surface/General_Tool/Source"

SERVER_DATABASE_PATH = "//virtuosgames.com/geh/TOOLS/Technical_Script/Projects/Hard_Surface/General_Tool/Database"

# SETTING PATH
LOCAL_SETTING_PATH = tempfile.gettempdir() + "/HardSurfaceTool_Setting.json"
SERVER_SETTING_PATH = SERVER_DATABASE_PATH + "/HardSurfaceTool_Setting.json"
# RUNTIME COMMAND PATH
LOCAL_RUNTIME_COMMAND_PATH = LOCAL_PREF_PATH + "/userRunTimeCommands.mel" 
SERVER_RUNTIME_COMMAND_PATH = SERVER_DATABASE_PATH + "/userRunTimeCommands.mel"
LOCAL_NAMED_COMMAND_PATH = LOCAL_PREF_PATH + "/userNamedCommands.mel" 
SERVER_NAMED_COMMAND_PATH = SERVER_DATABASE_PATH + "/userNamedCommands.mel"
# IMPORT/EXPORT FILE PATH
LOCAL_IMPORT_EXPORT_FILE_PATH = tempfile.gettempdir() + "/HardSurfaceTool_ImportExportFile.json"
SERVER_IMPORT_EXPORT_FILE_PATH = SERVER_DATABASE_PATH + "/HardSurfaceTool_ImportExportFile.json"

# WINDOW NAME
WINDOW_NAME = "hardsurface_tool_window"
# TOOL VERSION
TOOL_VERSION = "2024"
# WINDOW TITLE
WINDOW_TITLE = "HardSurface Tool " + TOOL_VERSION +  " - Maya " + cmds.about(version=True)
# WINDOW SIZE
WINDOW_HEIGHT = 840
WINDOW_WIDTH = 320

# TEMPLATE UI
TEMPLATE_NAME = "HSTemplate"

# TAB LIST
DEFAULT_TAB_LIST = [1,2,3,4,5,6]

from Check_Tools import CheckTool
reload(CheckTool)

from Model_Tools import ModelTool
reload(ModelTool)

from Mirror_Tools import MirrorTool
reload(MirrorTool)

from UV_Tools import UVToolsMain
reload(UVToolsMain)

from Normal_Tools import NormalTools_Main
reload(NormalTools_Main)

from BakeSet_Tools import BakeSetTool
reload(BakeSetTool)

#region SAVE PARAMETERS
if not cmds.optionVar(ex='straightenLine_even'):
	cmds.optionVar(iv=['straightenLine_even', 0])
if not cmds.optionVar(ex='averageLine_even'):
	cmds.optionVar(iv=['averageLine_even', 0])
if not cmds.optionVar(ex='averageLine_keepshape'):
	cmds.optionVar(iv=['averageLine_keepshape', 1])
if not cmds.optionVar(ex='averageLine_smooth'):
	cmds.optionVar(iv=['averageLine_smooth', 0])
if not cmds.optionVar(ex='averageLine_align'):
	cmds.optionVar(iv=['averageLine_align', 4])
if not cmds.optionVar(ex='averageLine_step'):
	cmds.optionVar(iv=['averageLine_step', 1])
if not cmds.optionVar(ex='connect_div'):
	cmds.optionVar(iv=['connect_div', 1])
if not cmds.optionVar(ex='ari_circle_clear_btn'):
	cmds.optionVar(iv=['ari_circle_clear_btn', False])
if not cmds.optionVar(ex='mirror_uv'):
	cmds.optionVar(iv=['mirror_uv', 0])
if not cmds.optionVar(q='mirror_space'):
	cmds.optionVar(iv=['mirror_space', 1])
if not cmds.optionVar(q='merge_tolerance'):
	cmds.optionVar(fv=['merge_tolerance', 0.1])
if not cmds.optionVar(q='revolve_instance'):
	cmds.optionVar(iv=['revolve_instance', 0])
if not cmds.optionVar(q='revolve_count'):
	cmds.optionVar(iv=['revolve_count', 8])
if not cmds.optionVar(ex='export_bakeset_mode'):
	cmds.optionVar(iv=['export_bakeset_mode', 2])
if not cmds.optionVar(q='dot_loop_value'):
	cmds.optionVar(iv=['dot_loop_value', 1])
if not cmds.optionVar(q='dot_ring_value'):
	cmds.optionVar(iv=['dot_ring_value', 1])
if not cmds.optionVar(q='bakeset_lock_normal'):
	cmds.optionVar(iv=['bakeset_lock_normal', 1])

# Tab Layout
if not cmds.optionVar(ex='select_tab'):
	cmds.optionVar(iv=['select_tab', 2])

# Frame Layout
if not cmds.optionVar(ex='scene_cl'):
	cmds.optionVar(iv=['scene_cl', True])
if not cmds.optionVar(ex='modify_object_cl'):
	cmds.optionVar(iv=['modify_object_cl', True])
if not cmds.optionVar(ex='ari_circle_cl'):
	cmds.optionVar(iv=['ari_circle_cl', True])
if not cmds.optionVar(ex='select_component_cl'):
	cmds.optionVar(iv=['select_component_cl', True])
if not cmds.optionVar(ex='instance_object_cl'):
	cmds.optionVar(iv=['instance_object_cl', True])
if not cmds.optionVar(ex='fix_cl'):
	cmds.optionVar(iv=['fix_cl', True])
if not cmds.optionVar(ex='maya_blender_cl'):
	cmds.optionVar(iv=['maya_blender_cl', True])
if not cmds.optionVar(ex='import_export_cl'):
	cmds.optionVar(iv=['import_export_cl', True])
if not cmds.optionVar(ex='support_tool_cl'):
	cmds.optionVar(iv=['supprot_tool_cl', True])

#endregion

def GUI():
	#region Update newest version
	f = open("//virtuosgames.com/geh/TOOLS/Technical_Script/Projects/Hard_Surface/General_Tool/Source/HS_TOOL_VERSION.txt", "r")
	hs_tool_version = f.read()
	f.close()

	if TOOL_VERSION != hs_tool_version:
		new_message = 'HardSurface Tool ' + hs_tool_version + ' is available. Install now?'
		confirm = cmds.confirmDialog(title='Confirm', message=new_message, button=['Yes','No'], defaultButton='Yes', cancelButton='No', dismissString='No' )
		if confirm == 'Yes':
			update_tool_for_this_maya()
			return
	
	#endregion
	
	global tab_list
	tab_list = DEFAULT_TAB_LIST

	# Clear old UI
	clear_old_ui()

	# Get setting json file
	if not os.path.exists(LOCAL_SETTING_PATH):
		shutil.copy(SERVER_SETTING_PATH, LOCAL_SETTING_PATH)
	data = read_data_from_json(LOCAL_SETTING_PATH)
	frame_bgc = data['ui']['frame_color']
	button_bgc = data['ui']['button_color']

	# Main Window
	main_window = cmds.window(WINDOW_NAME, title=WINDOW_TITLE, menuBar=True, rtf=True, mnb=False, mxb=False)

	# Create uiTemplate
	cmds.uiTemplate(TEMPLATE_NAME)
	cmds.frameLayout(defineTemplate=TEMPLATE_NAME, bgc=frame_bgc)
	cmds.button(defineTemplate=TEMPLATE_NAME, bgc=button_bgc)

	# Apply UI Template
	cmds.setUITemplate(TEMPLATE_NAME, pushTemplate=True)

	# Menu
	cmds.menu(l='Update', tearOff=False)
	cmds.menuItem(l='This Maya', c=update_tool_for_this_maya)
	cmds.menuItem(l='All Maya', c=update_tool_for_all_maya)
	cmds.menu(l='UI', tearOff=False)
	cmds.menuItem(l='Frame Color', c=change_frame_color)
	cmds.menuItem(l='Button Color', c=change_button_color)
	cmds.menuItem(l='Reset Color', c=reset_tool_color)
	cmds.menu(l='Hotkey', tearOff=False)
	cmds.menuItem(l='Get Hotkey Command', c=change_user_command_file)
	cmds.menuItem(l='Open Hotkey Editor', c=open_hotkey_editor)
	cmds.menu(l='Help', tearOff=False)
	cmds.menuItem(l='Document', c=open_hs_tool_document)

	# Main Layout
	button_form = cmds.formLayout('button_form')
	main_tab = cmds.tabLayout('main_tablayout', parent = button_form, width=WINDOW_WIDTH+5, cr=True)
	
	check_layout = cmds.rowColumnLayout('Check', parent = main_tab, nc = 1, cw = [(1, WINDOW_WIDTH)])
	model_layout = cmds.rowColumnLayout('Model', parent = main_tab, nc = 1, cw = [(1, WINDOW_WIDTH)])
	mirror_layout = cmds.rowColumnLayout('Mirror', parent = main_tab, nc = 1, cw = [(1, WINDOW_WIDTH)])
	normal_layout = cmds.rowColumnLayout('Normal', parent = main_tab, nc = 1, cw = [(1, WINDOW_WIDTH)])
	uv_layout = cmds.rowColumnLayout('UV', parent = main_tab, nc = 1, cw = [(1, WINDOW_WIDTH)])
	bake_layout = cmds.rowColumnLayout('Bake', parent = main_tab, nc = 1, cw = [(1, WINDOW_WIDTH)])

	cmds.tabLayout('main_tablayout', e=True, sti = cmds.optionVar(q='select_tab'), sc='cmds.optionVar(iv=[\'select_tab\', cmds.tabLayout(\'main_tablayout\', q=True, sti=True)])', dcc=detach_tab_to_window)

	create_check_tab(check_layout)
	create_model_tab(model_layout)
	create_mirror_tab(mirror_layout)
	create_normal_tab(normal_layout)
	create_uv_tab(uv_layout)
	create_bake_tab(bake_layout)

	# Resize
	cmds.window(main_window, e=True, w=WINDOW_WIDTH, h=WINDOW_HEIGHT)
	cmds.window(main_window, e=True, s=False)
	# Show
	cmds.showWindow(main_window)
	cmds.scriptJob(e=['SceneOpened', GUI], parent=main_window)

def create_check_tab(check_layout):
	#region Check Tab
	check_function = CheckTool.getAllCheckFunction(CheckTool)
	fix_function = CheckTool.getAllFixFunction(CheckTool)

	all_frame = list(set([v[0] for k,v in iteritems(check_function) if v[0] != None]))
	checking_main_frame = cmds.formLayout('checking_main_frame', p=check_layout)
	checking_main_layout = cmds.columnLayout('checking_main_layout', p=checking_main_frame, adj=True, rs=5)
	cmds.formLayout(checking_main_frame, e=True, af=[(checking_main_layout, 'left', 5), (checking_main_layout, 'right', 5), (checking_main_layout, 'top', 5), (checking_main_layout, 'bottom', 5)])

	for frame in all_frame:
		frame_layout = cmds.frameLayout(frame, l=frame, p=checking_main_layout, cll=False)
		col_frame = cmds.columnLayout('column_' + frame, p=frame_layout, adj=True, rs=5)
		# Button FormLayout
		main_button = cmds.formLayout('main_button', p=col_frame)
		button_layout_position = 0
		for k,v in iteritems(check_function):
			if v[0] != None and v[0] == frame:
				button_layout = cmds.rowColumnLayout(k.replace("Check", "") + "_layout", p=main_button, nc=2, cw=[(1, 230), (2,60)], adj=2, cs=[(2,5)])
				
				# Set button_layout
				cmds.formLayout(main_button, e=True, af=[(button_layout, 'left', 5), (button_layout, 'right', 5), (button_layout, 'top', button_layout_position + 5)])
				button_layout_position += cmds.rowColumnLayout(button_layout, q=True, h=True)
				
				# Check & Fix Button
				check_name = k
				fix_name = k.replace("Check", "Fix")

				# Check Button
				cmds.button(check_name, l=CheckTool.camelToSpaces(check_name).replace("Check", ""), h=30, p=button_layout, c=partial(CheckTool.executeSelectedFunction, [v[1]]), bgc=[0.2,0.2,0.2])

				# Fix Button
				for fk, fv in iteritems(fix_function):
					if fk == fix_name:
						cmds.button(fix_name, l="Fix", p=button_layout, h=30, c=fv[1], bgc=[0.2,0.2,0.2])
						break		
	#endregion

def create_model_tab(model_layout):
	model_scroll = cmds.scrollLayout('model_scroll',p=model_layout, cr = True, hst=0, vst=0, h=WINDOW_HEIGHT)
	main_model_layout = cmds.columnLayout('frame_column_layout', p=model_scroll, adj=True)

	#region AriCircleVertex
	cmds.frameLayout('ari_circle_frame_layout', p = main_model_layout, l = 'AriCircle', collapsable = True, ann = 'AriCircle', cl=cmds.optionVar(q='ari_circle_cl'), w=300, cc=lambda *args: get_current_frame_status('ari_circle_frame_layout', 'ari_circle_cl'), ec=lambda *args: get_current_frame_status('ari_circle_frame_layout', 'ari_circle_cl'))
	
	cmds.rowColumnLayout(nc=3, cw=[(1, 120), (2, 90), (3, 80)], adj=3, cs=[(2,5), (3,5)])
	cmds.checkBox('ari_diameter_cb', l = 'Diameter Input', ofc='cmds.floatField(\'ari_diameter_fl\', e=True, en=False)', onc='cmds.floatField(\'ari_diameter_fl\', e=True, en=True)')
	cmds.floatField('ari_diameter_fl', v=1.0, en=False)
	cmds.button(l = 'Get', c=ModelTool.get_ari_diameter_input)
	cmds.setParent('..')

	cmds.rowColumnLayout(nc=3, cw=[(1, 120), (2, 90), (3, 80)], adj=3, cs=[(2,5), (3,5)])
	cmds.checkBox('ari_angle_cb', l = 'Angle Input', ofc='cmds.floatField(\'ari_angle_fl\', e=True, en=False)', onc='cmds.floatField(\'ari_angle_fl\', e=True, en=True)')
	cmds.floatField('ari_angle_fl', v=180.0, en=False)
	cmds.button(l = 'Get', c=ModelTool.get_ari_angle_input)
	cmds.setParent('..')

	cmds.rowColumnLayout(nc=3, cw=[(1, 120), (2, 70), (3, 100)], adj=3, cs=[(2,5), (3,5)])
	cmds.textField('ari_circle_tf', ed=False, tx='')
	cmds.button('air_clear_btn', l = 'Clear', en=cmds.optionVar(q='ari_circle_clear_btn'), c= lambda *args: ModelTool.get_priority_vertex(0))
	cmds.button(l = 'Get Priority', c= lambda *args: ModelTool.get_priority_vertex(1))
	cmds.setParent('..')

	cmds.rowColumnLayout(nc = 2, cw = [(1, 190), (2,100)], adj = 2, cs = [(2,5), (3,5)])
	cmds.button(l = 'Alignment', bgc = (0.2, 0.8, 0.5), h=50, c=ModelTool.alignment_ari_circle)
	cmds.columnLayout(columnAttach=('both', 0), rs=5, adj=True)
	cmds.button(l = 'Contiguous', c=ModelTool.select_contiguous_edges)
	cmds.button(l = 'Ring', c=ModelTool.select_edge_ring)
	cmds.setParent('..')

	cmds.setParent('..')
	#endregion

	#region Select
	cmds.frameLayout('select_component_frame_layout', p = main_model_layout, l = 'Select', collapsable = True, ann = 'Select Component', cl=cmds.optionVar(q='select_component_cl'), w=300, cc=lambda *args: get_current_frame_status('select_component_frame_layout', 'select_component_cl'), ec=lambda *args: get_current_frame_status('select_component_frame_layout', 'select_component_cl'))
	cmds.rowColumnLayout(nc=4, cw=[(1, 35), (2, 110), (3, 35), (4, 110)], adj=4, cs=[(2,5), (3,5), (4,5)])
	cmds.intField('dot_loop_if', v=cmds.optionVar(q='dot_loop_value'), cc='cmds.optionVar(iv=[\'dot_loop_value\', cmds.intField(\'dot_loop_if\', q=True, v=True)])')
	cmds.button(l='Dot Loop', h = 25, c = ModelTool.select_dot_loop)
	cmds.intField('dot_ring_if', v=cmds.optionVar(q='dot_ring_value'), cc='cmds.optionVar(iv=[\'dot_ring_value\', cmds.intField(\'dot_ring_if\', q=True, v=True)])')
	cmds.button(l='Dot Ring', h = 25, c = ModelTool.select_dot_ring)
	cmds.setParent('..')

	cmds.separator(st='in')

	cmds.rowColumnLayout(nc=2, cw=[(1, 230), (2,70)], adj=2)
	cmds.intSliderGrp('angle_selection_isg', label='Co-planar Angle:', field=True, cw3 = [90,50,90], minValue=0, maxValue=180, fieldMinValue=0, fieldMaxValue=180, value=5, cc=ModelTool.update_selection_by_normal_angle)
	cmds.button('angle_selection_btn', l='Select', c=ModelTool.grow_selection_by_normal_angle)
	cmds.setParent('..')

	cmds.separator(st='in')

	cmds.rowColumnLayout(nc=2, cw=[(1, 150), (2, 150)], adj=2, cs=[(2,5)])
	cmds.button(l='Select Similar Object', h = 25, ann='Select Object To Find Similar Objects', c = ModelTool.select_similar)
	cmds.button(l='Selection Set', h = 25, ann='Save Selection And Re-Selection', c = lambda *args: ModelTool.open_selection_set_tool(WINDOW_NAME))
	cmds.setParent('..')

	cmds.setParent('..')
	#endregion

	#region Modify Object
	cmds.frameLayout('modify_object_frame_layout', p = main_model_layout, l = 'Modify Object', collapsable = True, ann = 'Modify Object', cl=cmds.optionVar(q='modify_object_cl'), w=300, cc=lambda *args: get_current_frame_status('modify_object_frame_layout', 'modify_object_cl'), ec=lambda *args: get_current_frame_status('modify_object_frame_layout', 'modify_object_cl'))

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)
	cmds.iconTextButton("combine_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/combine.png", l="Combine", ann = "Combine", c=ModelTool.combine_object)
	cmds.iconTextButton("detach_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/detach.png", l="Detach", ann = "Detach", c=ModelTool.detach_object)
	cmds.iconTextButton("clone_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/clone.png", l="Clone", ann = "Clone", c=ModelTool.clone_object)
	cmds.iconTextButton("detach_by_material_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/detach_by_material.png", l="Detach By Mat", ann = "Detach By Material", c=ModelTool.detach_by_material)
	cmds.setParent('..')

	cmds.separator(st='in')

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)
	cmds.iconTextButton("CP_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/center_pivot.png", l="Center Pivot", ann = "Center Pivot", c = ModelTool.center_pivot)
	cmds.iconTextButton("RT_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/reset_pivot.png", l="Reset Pivot", ann = "Reset Transforms", c = ModelTool.reset_transforms)
	cmds.iconTextButton("set_pivot_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/set_pivot.png", l="Set Pivot", ann = "Set Pivot Position", c = ModelTool.set_pivot)
	cmds.iconTextButton("maxmin_pivot_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/pivot.png", l="Object Pivot", ann = "Max/Min X/Y/Z Pivot", c = ModelTool.show_set_maxmin_pivot_window)
	cmds.setParent('..')

	cmds.setParent('..')
	#endregion   

	#region Scene
	cmds.frameLayout('scene_frame_layout', p = main_model_layout, l = 'Scene', collapsable = True, ann = 'Clean Scene', cl=cmds.optionVar(q='scene_cl'), w=300, cc=lambda *args: get_current_frame_status('scene_frame_layout', 'scene_cl'), ec=lambda *args: get_current_frame_status('scene_frame_layout', 'scene_cl'))
	
	cmds.rowColumnLayout(nc=3, cw=[(1, 100), (2, 100), (3, 100)], adj=3)
	cmds.iconTextButton("unhide_all_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/unhide_all.png", l="Unhide All", ann = "Y or Z", c = ModelTool.unhide_all)
	cmds.iconTextButton("FT_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/FT.png", l="Freeze Transforms", ann = "Freeze Transform", c = ModelTool.freeze_transforms)
	cmds.iconTextButton("YorZ_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/YorZ.png", l="Y/Z", ann = "Y or Z", c = ModelTool.changeYZ)
	cmds.setParent('..')
	
	cmds.rowColumnLayout(nc=3, cw=[(1, 100), (2, 100), (3, 100)], adj=3)
	cmds.iconTextButton("fcc_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/FCC.png", l="FCC", ann = "Force Clean Combine", c = ModelTool.FCC)
	cmds.iconTextButton("delete_history_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/history.png", l="History", ann = "Delete History", c = ModelTool.delete_history)
	cmds.iconTextButton("rename_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/rename.png", l="Rename", ann = "Rename Objects", c = ModelTool.rename_objects)
	cmds.setParent('..')

	cmds.setParent('..')
	#endregion

	#region Instance
	cmds.frameLayout('instance_object_frame_layout', p = main_model_layout, l = 'Instance', collapsable = True, ann = 'Instance', cl=cmds.optionVar(q='instance_object_cl'), w=300, cc=lambda *args: get_current_frame_status('instance_object_frame_layout', 'instance_object_cl'), ec=lambda *args: get_current_frame_status('instance_object_frame_layout', 'instance_object_cl'))
	cmds.rowColumnLayout(nc=2, cw=[(1, 150), (2, 150)], adj=2)
	cmds.iconTextButton("set_instance_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/set_instance.png", l="Set Instance", ann = "Set Instance", c = ModelTool.instance_objects)
	cmds.iconTextButton("uninstance_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/uninstance.png", l="Un-Instance", ann = "Un-Instance", c = ModelTool.uninstance_objects)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

	#region Support Tool
	cmds.frameLayout('support_tool_frame_layout', p = main_model_layout, l = 'Speed Tool', collapsable = True, ann = 'Speed Tool', cl=cmds.optionVar(q='support_tool_cl'), w=300, cc=lambda *args: get_current_frame_status('support_tool_frame_layout', 'support_tool_cl'), ec=lambda *args: get_current_frame_status('support_tool_frame_layout', 'support_tool_cl'))

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)
	cmds.iconTextButton("edge_length_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/edge_length.png", l="Edge Length", ann = "Open Edge Length Tool", c = lambda *args: ModelTool.open_edge_length_tool(WINDOW_NAME))
	cmds.iconTextButton("straighten_line_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/straighten_line.png", l="Straighten", ann = "Open Straighten Line Tool", c = lambda *args: ModelTool.open_straighten_line_tool(WINDOW_NAME))
	cmds.iconTextButton("average_line_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/average_line.png", l="Average", ann = "Open Average Line Tool", c = lambda *args: ModelTool.open_average_line_tool(WINDOW_NAME))
	cmds.iconTextButton("shrinkwrap_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/shrinkwrap.png", l="ShrinkWrap", ann = "Open ShrinkWrap Tool", c = lambda *args: ModelTool.open_shrinkwrap_tool(WINDOW_NAME))
	cmds.setParent('..')

	cmds.separator(st='in')

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)
	cmds.iconTextButton("unbevel_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/unbevel.png", l="Unbevel", ann = "Open Unbevel Tool", c = lambda *args: ModelTool.open_unbevel_tool(WINDOW_NAME))
	cmds.iconTextButton("snap_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/snap.png", l="Snap", ann = "Open Snap Tool", c = lambda *args: ModelTool.open_snap_tool(WINDOW_NAME))
	cmds.iconTextButton("inflate_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/inflate.png", l="Inflate", ann = "Open Inflate Tool", c = lambda *args: ModelTool.open_inflate_tool(WINDOW_NAME))
	cmds.iconTextButton("split_polygon_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/split_polygon.png", l="Split", ann = "Select 2 Vertices / Couple Edges", c=ModelTool.split_polygon)
	cmds.setParent('..')

	cmds.separator(st='in')

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)
	
	cmds.iconTextButton("extend_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/extend_face.png", l="Extend", ann = "Select 1 Vertex / 1 Edge", c=ModelTool.smart_extend)
	cmds.iconTextButton("file_hole_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/fill_hole.png", l="Fill Hole", ann = "Select 2 Vertices", c=ModelTool.smart_fill_hole)
	cmds.iconTextButton("clean_mesh_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/clean_mesh.png", l="Clean Mesh", ann = "Select Mesh", c=lambda *args: ModelTool.open_clean_mesh_tool(WINDOW_NAME))
	cmds.iconTextButton("reset_object_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/reset_object.png", l="Reset Object", ann = "Select 3 Points / 2 Edges / 1 Face", c=ModelTool.reset_object_rotation)
	cmds.setParent('..')

	cmds.separator(st='in')

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)
	cmds.iconTextButton("bridge_pipe_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/bridge.png", l="Bridge Pipe", ann = "Select 2 edge ring from 2 Pipe", c=ModelTool.smart_bridge)
	cmds.iconTextButton("bend_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/bend.png", l="Bend", ann = "Open Speed Bend Tool", c = lambda *args: ModelTool.open_bend_tool(WINDOW_NAME))	
	cmds.iconTextButton("create_decal_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/decal.png", l="Decal", ann = "Open Create Decal Tool", c=lambda *args: ModelTool.open_create_decal_tool(WINDOW_NAME))
	cmds.iconTextButton("swap_lod_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/LOD.png", l="Swap LOD", ann = "Open LOD Tool", c= lambda *args: ModelTool.open_lod_tool(WINDOW_NAME))
	cmds.setParent('..')
	
	cmds.separator(st='in')

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)
	cmds.iconTextButton("cable_tool_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/cable.png", l="Cable", ann = "Open Cable Tool", c = lambda *args: ModelTool.open_cable_tool(WINDOW_NAME))	
	cmds.iconTextButton("image_camera_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/image_camera.png", l="Image Camera", ann = "Open Image Camera Tool", c=lambda *args: ModelTool.open_image_camera_tool(WINDOW_NAME))
	cmds.iconTextButton("shader_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/shader.png", l="Shader", ann = "Open Shader Manager", c = lambda *args: ModelTool.open_shader(WINDOW_NAME))
	cmds.iconTextButton("library_button", style = "iconAndTextVertical", image1 = LOCAL_PATH + "/Model_Tools/Icons/library.png", l="Library", ann = "Open Library", c = lambda *args: ModelTool.open_library_tool(WINDOW_NAME, SERVER_DATABASE_PATH))
	cmds.setParent('..')

	cmds.rowColumnLayout(nc=4, cw=[(1, 75), (2, 75), (3, 75), (4, 75)], adj=4)

	cmds.setParent('..')

	cmds.setParent('..')
	#endregion

	#region Fix Frame
	cmds.frameLayout('fix_layout', p = main_model_layout, l = 'Fix Maya', collapsable = True, ann = 'Fix any maya error', cl=cmds.optionVar(q='fix_cl'), w=300, cc=lambda *args: get_current_frame_status('fix_layout', 'fix_cl'), ec=lambda *args: get_current_frame_status('fix_layout', 'fix_cl'))
	cmds.rowColumnLayout(nc=2, cw=[(1, 150), (2, 150)], adj=2, cs=[(2,5)])
	cmds.button("fix_cant_create_mesh_btn", h = 25, l = "Fix Can't Create Mesh", c = ModelTool.fix_cant_create_mesh)
	cmds.button("fix_error_maya_file_btn", h = 25, l = "Fix Green/Missing Object", c = ModelTool.fix_error_maya_file)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion	


	#region Blender <-> Maya
	cmds.frameLayout('maya_blender_frame_layout', p = main_model_layout, l = 'Maya - Blender', collapsable = True, ann = 'Maya - Blender', cl=cmds.optionVar(q='maya_blender_cl'), w=300, cc=lambda *args: get_current_frame_status('maya_blender_frame_layout', 'maya_blender_cl'), ec=lambda *args: get_current_frame_status('maya_blender_frame_layout', 'maya_blender_cl'))
	cmds.rowColumnLayout("maya_blender_btn_layout", nc = 2, cw = [(1, 150), (2,150)], adj = 2, cs = [(2,5)])
	cmds.button("import_blender_btn", l = "Import From Blender", h = 25, bgc = (0.2, 0.2, 0.2), c = ModelTool.import_from_blender)
	cmds.button("export_blender_btn" , l = "Export To Blender", h = 25, bgc = (0.8, 0.8, 0.8), c = ModelTool.export_to_blender)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

	#region Import Export
	if not os.path.exists(LOCAL_IMPORT_EXPORT_FILE_PATH):
		ModelTool.create_json_file(LOCAL_IMPORT_EXPORT_FILE_PATH)
		
	default_import_export_path = read_data_from_json(LOCAL_IMPORT_EXPORT_FILE_PATH)["default_path"]

	if default_import_export_path == '':
		ModelTool.create_json_file(LOCAL_IMPORT_EXPORT_FILE_PATH)

	cmds.frameLayout('import_export_frame_layout', p = main_model_layout, l = 'Import/Export', collapsable = True, ann = 'Import/Export', cl=cmds.optionVar(q='import_export_cl'), w=300, cc=lambda *args: get_current_frame_status('import_export_frame_layout', 'import_export_cl'), ec=lambda *args: get_current_frame_status('import_export_frame_layout', 'import_export_cl'))
	cmds.rowColumnLayout('import_export_file_path_layout', nc = 3, cw = [(1,65), (2,195), (3,45)], adj=3, cs = [(2,5), (3,5)])
	cmds.text('File Path:')
	cmds.textField('import_export_path_tf', tx = default_import_export_path)
	cmds.button('get_import_export_btn', l='...', h = 25, c=lambda *args: ModelTool.get_import_export_file_path(default_import_export_path, LOCAL_IMPORT_EXPORT_FILE_PATH))
	cmds.setParent('..')
	cmds.rowColumnLayout("import_export_btn_layout", nc = 2, cw = [(1, 150), (2,150)], adj = 2, cs = [(2,5)])
	cmds.button("import_btn", l = "Import Source To Current", h = 25, bgc = (0.2, 0.8, 0.5), c = ModelTool.import_current_file)
	cmds.button("export_btn" , l = "Export Current To Source", h = 25, bgc = (0.8, 0.5, 0), c = ModelTool.export_current_file)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

def create_mirror_tab(mirror_layout):
	#region Mirror Tab
	cmds.columnLayout('mirror_setting_layout', p = mirror_layout, cw = 315, columnAttach=('both', 0), rowSpacing= 5)

	cmds.rowColumnLayout(nc=2, cw=[(1, 200), (2, 80)], cat=[2, 'left', 5])
	cmds.radioButtonGrp('mirror_setting_rbg', h=30, nrb=2, l=' Space:', la2=['World', 'Local'], sl=cmds.optionVar(q='mirror_space'), cw3=[45, 60, 45], cal=[1, 'left'], on1='cmds.optionVar(iv=[\'mirror_space\', 1])', on2='cmds.optionVar(iv=[\'mirror_space\', 2])')
	cmds.checkBox('mirror_uv_cb', l='UV', h=30, v=cmds.optionVar(q='mirror_uv'), cc='cmds.optionVar(iv=[\'mirror_uv\', cmds.checkBox(\'mirror_uv_cb\', q=True, v=True)])')
	cmds.setParent('..')

	#region BAKE PIVOT
	cmds.rowColumnLayout('pivot_setting_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.button('bake_pivot_button', l='Bake Pivot', h=40, c=MirrorTool.bake_pivot)
	cmds.button('freeze_tranformations_button', l='Freeze Transforms', h=40, c=MirrorTool.freeze_transforms)
	cmds.button('reset_pivot_button', l='Reset Pivot', h=40, c=MirrorTool.reset_pivot)
	cmds.setParent('..')
	#endregion

	#region MIRROR FLIP
	cmds.frameLayout('mirror_flip_frame_layout', p = mirror_layout, l = 'FLIP', collapsable = False, ann = 'FLIP')
	cmds.rowColumnLayout('mirror_flip_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.button(l = 'Flip X', bgc=(0.8, 0.27, 0.2), h=30, c = MirrorTool.flip_X)
	cmds.button(l = 'Flip Y', bgc = (0.2, 0.8, 0.5), h=30, c = MirrorTool.flip_Y)
	cmds.button(l = 'Flip Z', bgc=(0.2, 0.43, 0.8), h=30, c = MirrorTool.flip_Z)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

	#region MIRROR SELECTION
	cmds.frameLayout('mirror_selection_frame_layout', p = mirror_layout, l = 'MIRROR', collapsable = False, ann = 'MIRROR')
	cmds.rowColumnLayout('mirror_selection_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.button(l = 'Mirror X', bgc=(0.8, 0.27, 0.2), h=30, c = MirrorTool.mirror_X)
	cmds.button(l = 'Mirror Y', bgc = (0.2, 0.8, 0.5), h=30, c = MirrorTool.mirror_Y)
	cmds.button(l = 'Mirror Z', bgc=(0.2, 0.43, 0.8), h=30, c = MirrorTool.mirror_Z)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

	#region MIRROR INSTANCE
	cmds.frameLayout('instance_frame_layout', p = mirror_layout, l = 'INSTANCE', collapsable = False, ann = 'INSTANCE')
	cmds.rowColumnLayout('instance_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.button(l = 'Instance X', bgc=(0.8, 0.27, 0.2), h=30, c=MirrorTool.mirror_instance_X)
	cmds.button(l = 'Instance Y', bgc = (0.2, 0.8, 0.5), h=30, c=MirrorTool.mirror_instance_Y)
	cmds.button(l = 'Instance Z', bgc=(0.2, 0.43, 0.8), h=30, c=MirrorTool.mirror_instance_Z)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

	#region MIRROR MERGE
	cmds.frameLayout('merge_frame_layout', p = mirror_layout, l = 'MERGE', collapsable = False, ann = 'MERGE')

	cmds.rowColumnLayout('merge_tolerance_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.text(l = 'Merge Tolerance:', h=30)
	cmds.floatField('merge_tolerance_ff', h=30 , v = cmds.optionVar(q='merge_tolerance'), cc='cmds.optionVar(iv=[\'merge_tolerance\', cmds.floatField(\'merge_tolerance_ff\', q=True, v=True)])')
	cmds.setParent('..')

	cmds.rowColumnLayout('merge_up_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.button(l = 'Merge +X', bgc=(0.8, 0.27, 0.2), h=30, c = MirrorTool.mirror_merge_X_pos)
	cmds.button(l = 'Merge +Y', bgc = (0.2, 0.8, 0.5), h=30, c = MirrorTool.mirror_merge_Y_pos)
	cmds.button(l = 'Merge +Z', bgc=(0.2, 0.43, 0.8), h=30, c = MirrorTool.mirror_merge_Z_pos)
	cmds.setParent('..')

	cmds.rowColumnLayout('merge_down_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.button(l = 'Merge -X', bgc=(0.8, 0.27, 0.2), h=30, c = MirrorTool.mirror_merge_X_neg)
	cmds.button(l = 'Merge -Y', bgc = (0.2, 0.8, 0.5), h=30, c = MirrorTool.mirror_merge_Y_neg)
	cmds.button(l = 'Merge -Z', bgc=(0.2, 0.43, 0.8), h=30, c = MirrorTool.mirror_merge_Z_neg)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

	#region MIRROR CUT
	cmds.frameLayout('mirror_cut_frame_layout', p = mirror_layout, l = 'CUT', collapsable = False, ann = 'CUT')
	cmds.rowColumnLayout('mirror_cut_layout', nc = 1, cw = [(1,315)], adj=1)
	cmds.button('mirror_cut_button', l='Mirror Cut', h=40, c = MirrorTool.mirror_cut)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

	#region MIRROR REVOLVE
	cmds.frameLayout('mirror_revolve_frame_layout', p = mirror_layout, l = 'REVOLVE', collapsable = False, ann = 'REVOLVE')
	cmds.rowColumnLayout('mirror_revolve_setting_layout', nc = 3, cw = [(1,155), (1,105), (3,55)], adj=3, cs = [(2,5), (3,25)])
	cmds.text('Revolve Count:')
	cmds.intField('revolve_count_if', h=30, v=cmds.optionVar(q='revolve_count_value'), cc='cmds.optionVar(iv=[\'revolve_count_value\', cmds.intField(\'revolve_count_if\', q=True, v=True)])')
	cmds.checkBox('revolve_instance_cb', h=30, l='Instance', v=cmds.optionVar(q='revolve_instance'), cc='cmds.optionVar(iv=[\'revolve_instance\', cmds.checkBox(\'revolve_instance_cb\', q=True, v=True)])')
	cmds.setParent('..')

	cmds.rowColumnLayout('mirror_revolve_layout', nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5),(3,5)])
	cmds.button(l = 'Revolve X', bgc=(0.8, 0.27, 0.2), h=30, c=MirrorTool.revolve_X)
	cmds.button(l = 'Revolve Y', bgc = (0.2, 0.8, 0.5), h=30, c=MirrorTool.revolve_Y)
	cmds.button(l = 'Revolve Z', bgc=(0.2, 0.43, 0.8), h=30, c=MirrorTool.revolve_Z)
	cmds.setParent('..')

	cmds.setParent('..')
	#endregion

	cmds.setParent('..')
	#endregion

def create_normal_tab(normal_layout):
	#region Normal Tab
	display_vertex_normal_frame_layout = cmds.frameLayout('display_vertex_normal_frame_layout', p = normal_layout, l = 'Display Vertex Normal', collapsable = False, ann = 'Display Vertex Normal')
	cmds.rowColumnLayout('normal_size_layout', p = display_vertex_normal_frame_layout, nc = 2, cw = [(1,115), (2,195)], adj=2, cs = [(2,5)])
	cmds.text(l = 'Normal Size:', h=30)
	cmds.floatField('normal_size_textfield', h=30, v = 2, min = 0, max = 100, step = 0.1)
	cmds.setParent('..')

	cmds.rowColumnLayout('toggle_normal_layout', p = display_vertex_normal_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('toggle_selected_button', l = 'Toggle Selected', h=30, c = NormalTools_Main.toggle_selected_normal)
	cmds.button('toggle_everything_button', l = 'Toggle Everything', h=30, c = NormalTools_Main.toggle_everything_normal)
	cmds.setParent('..')

	copy_paste_normal_frame_layout = cmds.frameLayout('copy_paste_normal_frame_layout', p = normal_layout, l = 'Copy/Paste Normal', collapsable = False, ann = 'Copy/Paste Normal')
	
	cmds.rowColumnLayout(p = copy_paste_normal_frame_layout, nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5), (3,5)])
	cmds.button('copy_normal_button', l = 'Copy', h=30, c = NormalTools_Main.copy_vertex_normal)
	cmds.button('copy_average_button', l = 'Copy Average', h=30, c = NormalTools_Main.copy_average_normal)
	cmds.button('paste_normal_button', l = 'Paste', h=30, c = NormalTools_Main.paste_vertex_normal)
	cmds.setParent('..')

	cmds.rowColumnLayout(p = copy_paste_normal_frame_layout, nc = 1, cw = [(1,315)])
	cmds.button('copy_average_paste_3_vertices_button', l = 'Copy Paste Average 3 Vertex Normals', h=30, c = NormalTools_Main.copy_paste_average_3_vetices_normals)
	cmds.setParent('..')
	cmds.rowColumnLayout(p = copy_paste_normal_frame_layout, nc = 1, cw = [(1,315)])
	cmds.button('paste_average_normals_button', l = 'Copy Paste Average Normals', h=30, c = NormalTools_Main.copy_paste_average_normals)
	cmds.setParent('..')
	cmds.rowColumnLayout(p = copy_paste_normal_frame_layout, nc = 1, cw = [(1,315)])
	cmds.button('inverse_selected_vertex_normals_button', l = 'Inverse Selected Vertex Normals', h=30, c = NormalTools_Main.inverse_selected_vertex_normals)
	cmds.setParent('..')


	lock_normal_frame_layout = cmds.frameLayout('lock_normal_frame_layout', p = normal_layout, l = 'Lock Normal', collapsable = False, ann = 'Lock Normal')

	cmds.rowColumnLayout(p = lock_normal_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('lock_button', l = 'Lock', h=30, c = NormalTools_Main.lock_normals)
	cmds.button('unlock_soft_display_button', l = 'Unlock', h=30, c = NormalTools_Main.unlock_normals)
	cmds.setParent('..')

	cmds.rowColumnLayout(p = lock_normal_frame_layout, nc = 2, cw = [(1,315)], adj=1)
	cmds.button('unlock_normals_with_hard_soft_edges_button', l = 'Unlock Normals With Hard/Soft Edges', h=30, c = NormalTools_Main.unlock_normals_with_hard_soft_edges)
	cmds.setParent('..')

	cmds.rowColumnLayout(p = lock_normal_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('lock_follow_small_face_button', l = 'Lock follow SMALL face', h=30, c = NormalTools_Main.lock_follow_small_face)
	cmds.button('lock_follow_large_face_button', l = 'Lock follow LARGE face', h=30, c = NormalTools_Main.lock_follow_large_face)
	cmds.setParent('..')

	cmds.rowColumnLayout(p = lock_normal_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('smooth_bevelled_faces_button', l = 'Smooth Bevelled Faces', h=30, c = NormalTools_Main.smooth_bevelled_faces)
	cmds.button('smooth_flatten_face_button', l = 'Smooth Flatten Faces', h=30, c = NormalTools_Main.smooth_flatten_faces)
	cmds.setParent('..')	

	cmds.rowColumnLayout(p = lock_normal_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('lock_face_90_button', l = 'Lock Face 90 Angle', h=30, c = NormalTools_Main.lock_face_90_angle)
	cmds.button('lock_hard_face_button', l = 'Lock Hard Face', h=30, c = NormalTools_Main.lock_hard_face)
	cmds.setParent('..')

	transfer_normal_frame_layout = cmds.frameLayout('transfer_normal_normal_frame_layout', p = normal_layout, l = 'Transfer Normal', collapsable = False, ann = 'Transfer Normal')
	cmds.rowColumnLayout(p = transfer_normal_frame_layout, nc = 2, cw = [(1,115), (2,195)], adj=2, cs = [(2,5)])
	cmds.button('pick_source_button', l = 'Pick SOURCE:', h=30, c = NormalTools_Main.pick_source_for_transfer)
	cmds.textField('source_normal_textfield', h=30)
	cmds.setParent('..')

	cmds.rowColumnLayout(p = transfer_normal_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('transfer_to_mesh_button', l = 'Transfer To MESH', h=30, c = NormalTools_Main.transfer_normals_to_object)
	cmds.button('transfer_to_vertex_button', l = 'Transfer To VERTEX', h=30, c = NormalTools_Main.transfer_normals_to_selected_vertices)
	cmds.setParent('..')
	
	cmds.separator(h=1, p = transfer_normal_frame_layout)

	cmds.rowColumnLayout(p = transfer_normal_frame_layout, nc = 1, cw = [(1,315)], adj=1)
	cmds.button('transfer_vertices_select_target_then_source_button', l = 'Transfer VERTICES - Select TARGET(s) Then SOURCE', h=30, c = NormalTools_Main.transfer_normal)
	cmds.setParent('..')
	
	connect_normal_frame_layout = cmds.frameLayout('connect_normal_frame_layout', p = normal_layout, l = 'Connect Normal', collapsable = False, ann = 'Connect Normal')
	cmds.rowColumnLayout(p = connect_normal_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('connect_with_flow_button', l = 'Connect With Flow', h=30, c = NormalTools_Main.connect_with_follow)
	cmds.button('connect_without_flow_button', l = 'Connect Without Flow', h=30, c = NormalTools_Main.connect_without_follow)
	cmds.setParent('..')
	#endregion 

def create_uv_tab(uv_layout):
	#region UV Tab
	UVToolsMain.config_for_rizom()
	#region Select & Set Frame
	select_frame_layout = cmds.frameLayout("select_frame_layout", p = uv_layout, l = "Select & Set", collapsable = False, ann = "Select") 
	select_row_column_layout = cmds.rowColumnLayout("select_row_column_layout", p = select_frame_layout, nc = 2, cw = [(1,155), (2,155)], cs = [(2,5)])
	cmds.button("HE_button", p = select_row_column_layout, l = "Hard Edge", h=30, c = UVToolsMain.selectHardEdge)
	cmds.button("HENB_button", p = select_row_column_layout, l = "Hard Edge (Not Border)", h=30, c = UVToolsMain.get_hard_edges_without_uv_border)
	set_row_column_layout = cmds.rowColumnLayout("set_row_column_layout", p = select_frame_layout, nc = 2, cw = [(1,155), (2,155)], cs = [(2,5)])
	cmds.button("BE_button", p = set_row_column_layout, l = "Open Edge", h=30, c = UVToolsMain.selectBorderEdge)
	cmds.button("UB_button", p = set_row_column_layout, l = "Set UV Border", h=30, c = UVToolsMain.selectUVBorder)
	#endregion

	#region Unwarp Frame
	unwrap_frame_layout = cmds.frameLayout("unwrap_frame_layout", p = uv_layout, l = "Unwrap", collapsable = False, ann = "Unwrap") 
	
	# Unwarp button
	UW1_column_layout = cmds.rowColumnLayout("UW1_column_layout", p = unwrap_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.iconTextButton("UW_select_button", p = UW1_column_layout, style = "iconAndTextHorizontal", image1 = LOCAL_PATH + "/UV_Tools/Icons/US.png", l = "UW Select Edge", c = UVToolsMain.unwrapSelectEdge)
	cmds.iconTextButton("UW_hard_edge_button", p = UW1_column_layout, style = "iconAndTextHorizontal", image1 = LOCAL_PATH + "/UV_Tools/Icons/UH.png", l = "UW Hard Edge", c = UVToolsMain.unwrapHardEdge)

	#endregion

	#region Edit Frame
	edit_frame_layout = cmds.frameLayout("edit_frame_layout", p = uv_layout, l = "Edit", collapsable = False, collapse = False, ann = "Edit")

	# Edit UVs button
	edit1_column_layout = cmds.rowColumnLayout("edit1_column_layout", p = edit_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button("UF_smart_button", p = edit1_column_layout, l = "Unfold", h=30, c = UVToolsMain.smartUnfold)
	cmds.button("UV_straight_button", p = edit1_column_layout, l = "UV Straight", h=30, c = UVToolsMain.UVStraight)

	edit2_column_layout = cmds.rowColumnLayout("edit2_column_layout", p = edit_frame_layout, nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button("UV_grid_button", p = edit2_column_layout, l = "UV Grid", h=30, c = UVToolsMain.UVGridding)
	cmds.button("radio_uv_button", p = edit2_column_layout, l = "Ratio UV", h=30, c = UVToolsMain.UV_ratio)

	edit_uf_layout = cmds.rowColumnLayout("edit_uf_layout", p = edit_frame_layout, nc = 2, cw = [(1,155), (2,155)], cs = [(2,5)])
	cmds.button("transfer_uv_button", p = edit_uf_layout, l = "Transfer UV", h=30, c = UVToolsMain.transferUV)
	cmds.button("match_uv_button", p = edit_uf_layout, l = "Match UV", h=30, c = UVToolsMain.matchUV)

	cmds.separator(st='in', p=edit_frame_layout)
	scale_uv_layout = cmds.rowColumnLayout("scale_uv_layout", p = edit_frame_layout, nc = 5, cw = [(1,75), (2,55), (3,55), (4,55), (5,55)], cs = [(2,5), (3,5), (4,5), (5,5)])
	cmds.text('Texel Density: ')
	cmds.floatField("texel_density_ff", min=0, max=10000, pre=2, v=0)
	cmds.text('Size Map: ')
	cmds.intField("size_map_tf", min=1, max=10000, v=2048)
	cmds.button("get_texel_density_button", p = scale_uv_layout, l = "Get", h=30, c = UVToolsMain.show_texel_density)
	scale2_uv_layout = cmds.rowColumnLayout("scale2_uv_layout", p = edit_frame_layout, nc = 2, cw = [(1,155), (2,155)], cs = [(2,5)])
	cmds.button("scale_center_element_button", p = scale2_uv_layout, l = "Scale", h=30, c = UVToolsMain.scale_by_center_element)
	cmds.button("scale_center_group_button", p = scale2_uv_layout, l = "Group Scale", h=30, c = UVToolsMain.scale_by_center_group)
	cmds.separator(st='in', p=edit_frame_layout)
	#endregion

	#region Photoshop Frame
	pts_frame_layout = cmds.frameLayout("pts_frame_layout", p = uv_layout, l = "Photoshop", collapsable = False, ann = "UV To Photoshop") 
	pts_layout = cmds.columnLayout("pts_layout", p = pts_frame_layout, cw = 315, columnAttach=('both', 0), rowSpacing= 5)
	cmds.button("uv_to_pts_button", p = pts_layout, l = "UV To PTS", h=40, c = UVToolsMain.UVtoPSD)
	#endregion

	#region rizom Frame
	rizom_frame_layout = cmds.frameLayout("rizom_frame_layout", p = uv_layout, l = "Rizom", collapsable = False, collapse = False, ann = "Rizom")
	rizom_layout = cmds.rowColumnLayout("rizom_layout", p = rizom_frame_layout, nc = 3, cw = [(1,105), (2,105), (3,105)], adj=3, cs = [(2,5), (3,5)])
	cmds.button("run_rizom_button,", p = rizom_layout, l = "Run RizomUV", h=40, c = UVToolsMain.open_rizom)
	cmds.button("export_to_rizom_button", p = rizom_layout, l = "Export To Rizom", h=40, c = UVToolsMain.export_to_rizom)
	cmds.button("import_to_maya_button", p = rizom_layout, l = "Import To Maya", h=40, c = UVToolsMain.import_to_maya)
	#endregion

	#region Checker Frame
	checker_frame_layout = cmds.frameLayout("checker_frame_layout", p = uv_layout, l = "Checker", collapsable = False, collapse = False, ann = "Checker")
	checker_layout = cmds.columnLayout("checker_layout", p = checker_frame_layout, cw = 315, columnAttach=('both', 0), rowSpacing= 5)
	cmds.button("checker_button", p = checker_layout, l = "UV Checker", h=40, c = UVToolsMain.UVChecker)
	#endregion

	#region UVSet Frame
	uvset_frame_layout = cmds.frameLayout("uvset_frame_layout", p = uv_layout, l = "UVSet", collapsable = False, ann = "UVSet") 
	uvset_layout = cmds.rowColumnLayout("uvset_layout", p = uvset_frame_layout, nc = 2, cw = [(1,210), (2,115)], adj=2, cs = [(1,5)])
	cmds.textScrollList("uvset_list_textscroll", p = uvset_layout, ams = True, vcc=UVToolsMain.reloadUVSetTextScroll, dcc=UVToolsMain.selectUVSet)
	uvset_event_btn_layout = cmds.columnLayout("uvset_event_btn_layout", p = uvset_layout, columnAttach=('both', 1), rowSpacing=1)
	cmds.button("new_uvset_button", p = uvset_event_btn_layout, l = "New", h=30, c = UVToolsMain.createUVSet)
	cmds.button("delete_button", p = uvset_event_btn_layout, l = "Delete", h=30, c = UVToolsMain.deleteUVSet)
	cmds.button("copy_button", p = uvset_event_btn_layout, l = "Copy", h=30, c = UVToolsMain.copyUVSet)
	cmds.separator(st='in', p = uvset_event_btn_layout)
	cmds.button("select_object_by_uvset_button", p = uvset_event_btn_layout, l = "Select Object(s)", h=30, c = UVToolsMain.selectObjectByUVSet)
	cmds.separator(st='in', p = uvset_event_btn_layout)
	cmds.textField('rename_textbox', p = uvset_event_btn_layout, h=30)
	cmds.button("rename_button", p = uvset_event_btn_layout, l = "Rename", h=30, c = UVToolsMain.renameUVSet)
	#endregion

	#region UV Editor
	editor_button_layout = cmds.rowColumnLayout("editor_button_layout", p = uv_layout, nc = 1, cw = [(1,315)])
	cmds.button("editor_button", p = editor_button_layout, label = "Editor", bgc = (0.2, 0.8, 0.5), c = UVToolsMain.OpenUVEditor, h=50)
	#endregion

	cmds.scriptJob(ct=["SomethingSelected", UVToolsMain.reloadUVSetTextScroll], parent=WINDOW_NAME)
	cmds.scriptJob(e=["SelectionChanged", UVToolsMain.reloadUVSetTextScroll], parent=WINDOW_NAME)
	cmds.scriptJob(e=["PolyUVSetChanged", UVToolsMain.reloadUVSetTextScroll], parent=WINDOW_NAME)
	cmds.scriptJob(e=["PolyUVSetDeleted", UVToolsMain.reloadUVSetTextScroll], parent=WINDOW_NAME)
	#endregion

def create_bake_tab(bake_layout):
	#region BakeSet Tab
	normal_path = BakeSetTool.auto_fill_normal_path()
	export_path = BakeSetTool.auto_fill_export_path()

	cmds.frameLayout('apply_normal_map_frame_layout', p = bake_layout, l = 'Apply Normal Map', collapsable = False, ann = 'Apply Normal Map')
	cmds.rowColumnLayout('set_normal_map_layout', nc = 3, cw = [(1,65), (2,205), (3,35)], adj=3, cs = [(2,5), (3,5)])
	cmds.text('Map Path:', h=30)
	cmds.textField('normal_map_path_tf', h=30, tx=normal_path)
	cmds.button('get_normal_path_btn', h=30, l='...', c=BakeSetTool.get_normal_map_path)
	cmds.setParent('..')
	cmds.rowColumnLayout('apply_normal_button_layout', nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button('replace_apply_normal_map_btn', l='Replace + Apply Material', h=40, c=lambda *args: BakeSetTool.apply_normal_map(0))
	cmds.button('create_apply_normal_map_btn', l='Create + Apply Material', h=40, c=lambda *args: BakeSetTool.apply_normal_map(1))
	cmds.setParent('..')
	cmds.setParent('..')

	cmds.frameLayout('tangent_space_frame_layout', p = bake_layout, l = 'Tangent Space', collapsable = False, ann = 'Tangent Space')
	cmds.rowColumnLayout('tangent_space_layout', nc = 2, cw = [(1,155), (2,155)], adj=2, cs = [(2,5)])
	cmds.button("right_handed_btn", l = "Right Handed", h=40, c = BakeSetTool.set_right_handed)
	cmds.button("left_handed_btn", l = "Left Handed", h=40, c = BakeSetTool.set_left_handed)
	cmds.setParent('..')
	cmds.setParent('..')

	cmds.frameLayout('setup_scene_frame_layout', p = bake_layout, l = 'Setup Bake Scene', collapsable = False, ann = 'Setup Bake Scene')
	cmds.columnLayout("setup_scene_layout", columnAttach=('both', 0), rowSpacing= 5, cw=315)
	cmds.rowColumnLayout('bakeset_name_layout', nc = 4, cw = [(1,85), (2,105), (3, 65), (4,45)], adj= 4, cs = [(2,5), (3,5)])
	cmds.text('BakeSet Name:', h=30)
	cmds.textField('bakeset_name_tf', h=30, tx="BakeSet_")
	cmds.text('Threshold:', h=30)
	cmds.floatField('bakeset_auto_threshold_ff', h=30, v=0.01)
	cmds.setParent('..')
	cmds.button("rename_highpoly_btn", l = "Rename Highpoly", h=40, c = BakeSetTool.rename_highpoly)
	cmds.button("create_bakeset_group_manual_btn", l = "Create BakeSet (Select High+Low)", h=40, c = BakeSetTool.create_bakeset_group_manual)
	cmds.button("create_bakeset_group_auto_btn", l = "Auto Create BakeSet (Select All High+Low)", h=40, c = BakeSetTool.create_bakeset_group_auto)
	cmds.button("create_highlow_layer_btn", l = "Create HighLow Layer", h=40, c = BakeSetTool.create_highlow_layer)
	cmds.setParent('..')
	cmds.setParent('..')

	cmds.frameLayout('export_fbx_frame_layout', p = bake_layout, l = 'Export FBX', collapsable = False, ann = 'Export FBX')
	cmds.rowColumnLayout('set_export_fbx_path_layout', nc = 3, cw = [(1,60), (2,205), (3,35)], adj=3, cs = [(2,5), (3,5)])
	cmds.text('FBX Path:', h=30)
	cmds.textField('export_fbx_path_tf', h=30, tx=export_path)
	cmds.button('export_fbx_path_btn', h=30, l='...', c=BakeSetTool.get_export_fbx_path)
	cmds.setParent('..')
	cmds.columnLayout("export_fbx_layout", columnAttach=('both', 0), rowSpacing= 5, cw=315)
	cmds.radioButtonGrp('export_bakeset_mode_rbg', l='Export Mode:', h=40, nrb=2, la2=['1 File','Multiple Files'], cw3=[100,100,100], cl3=['left'] * 3, sl=cmds.optionVar(q='export_bakeset_mode'), cc="cmds.optionVar(iv=['export_bakeset_mode', cmds.radioButtonGrp(\'export_bakeset_mode_rbg\',q=True,sl=True)])")
	cmds.rowColumnLayout('bakeset_name_layout', nc = 2, cw = [(1,75), (2,105)], adj= 2, cs = [(2,35),(3,105)])
	cmds.text('Lock Normal:')
	cmds.checkBox('bakeset_lock_normal_cb', l='Keep', v=cmds.optionVar(q='bakeset_lock_normal'), cc="cmds.optionVar(iv=[\'bakeset_lock_normal\', cmds.checkBox(\'bakeset_lock_normal_cb\', q=True, v=True)])")
	cmds.setParent('..')
	cmds.button("export_selected_btn", l = "Export Selected High/Low Objects", h=40, c = BakeSetTool.export_selected_objects)
	cmds.button("export_bakeset_btn", l = "Export All BakeSet", h=40, c = BakeSetTool.export_bakeset)
	cmds.setParent('..')
	cmds.setParent('..')
	#endregion

#region SUPPORT FUNCTION

#region UI FUNCTION
def clear_old_ui():
	if cmds.window(WINDOW_NAME, ex = True):
		cmds.deleteUI(WINDOW_NAME, window = True)

	if cmds.window('check_tool_window', ex=True):
		cmds.deleteUI('check_tool_window', window = True)
	if cmds.window('model_tool_window', ex=True):
		cmds.deleteUI('model_tool_window', window = True)
	if cmds.window('mirror_tool_window', ex=True):
		cmds.deleteUI('mirror_tool_window', window = True)
	if cmds.window('normal_tool_window', ex=True):
		cmds.deleteUI('normal_tool_window', window = True)
	if cmds.window('uv_tool_window', ex=True):
		cmds.deleteUI('uv_tool_window', window = True)
	if cmds.window('bake_tool_window', ex=True):
		cmds.deleteUI('bake_tool_window', window = True)

	if cmds.uiTemplate(TEMPLATE_NAME, ex=True):
		cmds.deleteUI(TEMPLATE_NAME, uiTemplate=True)

def create_tab(tab_name, layout):
	cmds.setUITemplate(TEMPLATE_NAME, pushTemplate=True)
	if tab_name == 'Check':
		create_check_tab(layout)
	elif tab_name == 'Model':
		create_model_tab(layout)
	elif tab_name == 'Mirror':
		create_mirror_tab(layout)
	elif tab_name == 'Normal':
		create_normal_tab(layout)
	elif tab_name == 'UV':
		create_uv_tab(layout)
	elif tab_name == 'Bake':
		create_bake_tab(layout)

def get_index_from_tab_name(tab_name):
	if tab_name == 'Check':
		return 1
	elif tab_name == 'Model':
		return 2
	elif tab_name == 'Mirror':
		return 3
	elif tab_name == 'Normal':
		return 4
	elif tab_name == 'UV':
		return 5
	elif tab_name == 'Bake':
		return 6

def get_current_frame_status(frame_layout, option_var):
	cmds.optionVar(iv=[option_var, cmds.frameLayout(frame_layout,q=True,cl=True)])

def return_to_tool_window(tab_name, tab_index):
	try:
		global tab_list
		# Create layout
		layout = cmds.rowColumnLayout(tab_name, parent = 'main_tablayout', nc = 1, cw = [(1, WINDOW_WIDTH)])
		# Create Tab
		create_tab(tab_name, layout)

		# Change tab order
		num_of_tab = cmds.tabLayout('main_tablayout', q=True, nch=True)
		
		tab_list.append(tab_index)
		tab_list = list(set(tab_list))

		for index in range(0, len(tab_list)):
			if tab_list[index] == tab_index:
				cmds.tabLayout('main_tablayout', e=True, mt=[num_of_tab, index+1])
				break
		# Select Tab
		cmds.tabLayout('main_tablayout', e=True, sti=index+1)
	except:
		pass

def detach_tab_to_window(*arg):
	global tab_list
	current_tab_name = cmds.tabLayout('main_tablayout', q=True, st=True)
	current_tab_index = get_index_from_tab_name(current_tab_name)
	tab_list.remove(current_tab_index)

	# Delete current tabLayout
	if cmds.rowColumnLayout(current_tab_name, ex=True):
		cmds.deleteUI(current_tab_name, layout = True)
	
	# Create child window
	child_window_name = current_tab_name.lower() + '_tool_window'
	child_window_tittle = current_tab_name + ' Tool'
	child_window = cmds.window(child_window_name, title = child_window_tittle, rtf=True, mnb=False, mxb=False, cc=partial(return_to_tool_window, current_tab_name, current_tab_index))
	child_layout = cmds.columnLayout(current_tab_name, p=child_window, adj=True, rs = 5, w=WINDOW_WIDTH)
	create_tab(current_tab_name, child_layout)
	cmds.showWindow(child_window)

def change_user_runtime_command_file():
	# Read server user command data
	server_runtime_command_file  = open(SERVER_RUNTIME_COMMAND_PATH, "r")
	server_runtime_command_content = server_runtime_command_file.read()
	server_runtime_command_file.close()

	# Check and update user command file
	local_runtime_command_file  = open(LOCAL_RUNTIME_COMMAND_PATH, "r+")
	local_runtime_command_content = local_runtime_command_file.read()

	# Get diff list
	local_runtime_command_list = local_runtime_command_content.split("runTimeCommand")
	server_runtime_command_list = server_runtime_command_content.split("runTimeCommand")
	different_runtime_command_list = list(set(server_runtime_command_list) - set(local_runtime_command_content))
	# Check server commmand in local file
	if server_runtime_command_content not in local_runtime_command_content:
		if len(different_runtime_command_list) != len(server_runtime_command_list):
			# Get HardSurfaceTool command in local File
			same_runtime_command_list = [command for command in server_runtime_command_list if command in local_runtime_command_list]
			# Delete old HardSurfaceTool command in local File 
			delete_part = "".join(same_runtime_command_list)
			local_runtime_command_content = local_runtime_command_content.replace(delete_part, "")
			local_runtime_command_file.seek(0)
			local_runtime_command_file.write(local_runtime_command_content)
			local_runtime_command_file.truncate()
		# Write server command in local File
		local_runtime_command_file.write(server_runtime_command_content)

	local_runtime_command_file.close()

def change_user_named_command_file():
	# Read server user command data
	server_named_command_file  = open(SERVER_NAMED_COMMAND_PATH, "r")
	server_named_command_content = server_named_command_file.read()
	server_named_command_file.close()

	# Check and update user command file
	local_named_command_file  = open(LOCAL_NAMED_COMMAND_PATH, "r+")
	local_named_command_content = local_named_command_file.read()

	# Get diff list
	local_named_command_list = local_named_command_content.split("nameCommand")
	server_named_command_list = server_named_command_content.split("nameCommand")
	different_named_command_list = list(set(server_named_command_list) - set(local_named_command_content))
	# Check server commmand in local file
	if server_named_command_content not in local_named_command_content:
		if len(different_named_command_list) != len(server_named_command_list):
			# Get HardSurfaceTool command in local File
			same_named_command_list = [command for command in server_named_command_list if command in local_named_command_list]
			# Delete old HardSurfaceTool command in local File 
			delete_part = "".join(same_named_command_list)
			local_named_command_content = local_named_command_content.replace(delete_part, "")
			local_named_command_file.seek(0)
			local_named_command_file.write(local_named_command_content)
			local_named_command_file.truncate()
		# Write server command in local File
		local_named_command_file.write(server_named_command_content)

	local_named_command_file.close()

def change_user_command_file(*arg):
	change_user_runtime_command_file()
	change_user_named_command_file()
	mel.eval("savePrefs -hk;")
	cmds.confirmDialog(icn="information", m = "Hotkeys has been updated! Please re-open Maya!")

def open_hotkey_editor(*arg):
	mel.eval("hotkeyEditorWindow;")

#endregion

#region SETTING FUNCTION
def read_data_from_json(path):
	json_data = {}
	try:
		with open(path, 'r') as file:
			json_data = json.load(file)
			file.close()
	except:
		pass
	return json_data

def save_ui_setting_to_json(json_path, key_name, value):
	data_json = read_data_from_json(json_path)
	for key in data_json['ui'].keys():
		if key == key_name:
			data_json['ui'][key] = value

	with open(json_path, 'w') as json_file:
		json.dump(data_json, json_file)

def change_frame_color(*arg):
	cmds.colorEditor(p=WINDOW_NAME)
	if cmds.colorEditor(q=True, r=True):
		values = cmds.colorEditor(q=True, rgb=True)
		save_ui_setting_to_json(LOCAL_SETTING_PATH, 'frame_color', values)
		cmds.frameLayout(defineTemplate=TEMPLATE_NAME, bgc=values)
		cmds.confirmDialog(icn="information", m = "Frame color has been changed! Please re-open Tool!")

def change_window_color(*arg):
	cmds.colorEditor(p=WINDOW_NAME)
	if cmds.colorEditor(q=True, r=True):
		values = cmds.colorEditor(q=True, rgb=True)
		save_ui_setting_to_json(LOCAL_SETTING_PATH,'window_color', values)
		cmds.window(defineTemplate=TEMPLATE_NAME, bgc=values)
		cmds.confirmDialog(icn="information", m = "Window color has been changed! Please re-open Tool!")

def change_button_color(*arg):
	cmds.colorEditor(p=WINDOW_NAME)
	if cmds.colorEditor(q=True, r=True):
		values = cmds.colorEditor(q=True, rgb=True)
		save_ui_setting_to_json(LOCAL_SETTING_PATH,'button_color', values)
		cmds.button(defineTemplate=TEMPLATE_NAME, bgc=values)
		cmds.confirmDialog(icn="information", m = "Button color has been changed! Please re-open Tool!")

def reset_tool_color(*arg):
	default_button_color = [0.4, 0.4, 0.4]
	default_frame_color = [0.7, 0.3, 0.0]
	default_window_color = [0.25, 0.25, 0.25]
	cmds.button(defineTemplate=TEMPLATE_NAME, bgc=default_button_color)
	save_ui_setting_to_json(LOCAL_SETTING_PATH,'button_color', default_button_color)
	cmds.frameLayout(defineTemplate=TEMPLATE_NAME, bgc=default_frame_color)
	save_ui_setting_to_json(LOCAL_SETTING_PATH,'frame_color', default_frame_color)
	cmds.window(defineTemplate=TEMPLATE_NAME, bgc=default_window_color)
	save_ui_setting_to_json(LOCAL_SETTING_PATH,'window_color', default_window_color)
	cmds.confirmDialog(icn="information", m = "Reset Color: Done! Please re-open Tool!")

def update_tool_for_this_maya(*arg):
	shutil.copy(SERVER_SETTING_PATH, LOCAL_SETTING_PATH)
	SOURCE_PATH_LIST = [SERVER_SOURCE_PATH + "/HardSurface_Tool",
						SERVER_SOURCE_PATH + "/Check_Tools",
						SERVER_SOURCE_PATH + "/Model_Tools",
						SERVER_SOURCE_PATH + "/Mirror_Tools",
						SERVER_SOURCE_PATH + "/Normal_Tools",
						SERVER_SOURCE_PATH + "/UV_Tools",
						SERVER_SOURCE_PATH + "/BakeSet_Tools"]
	robocopy(SOURCE_PATH_LIST, LOCAL_PATH)
	cmds.confirmDialog(icn="information", m = "Tool has been updated! Please re-open Tool!")

def update_tool_for_all_maya(*arg):
	shutil.copy(SERVER_SETTING_PATH, LOCAL_SETTING_PATH)
	SOURCE_PATH_LIST = [SERVER_SOURCE_PATH + "/HardSurface_Tool",
						SERVER_SOURCE_PATH + "/Check_Tools",
						SERVER_SOURCE_PATH + "/Model_Tools",
						SERVER_SOURCE_PATH + "/Mirror_Tools",
						SERVER_SOURCE_PATH + "/Normal_Tools",
						SERVER_SOURCE_PATH + "/UV_Tools",
						SERVER_SOURCE_PATH + "/BakeSet_Tools"]
	robocopy(SOURCE_PATH_LIST, os.path.expanduser("~") + "/maya/2018/scripts")
	robocopy(SOURCE_PATH_LIST, os.path.expanduser("~") + "/maya/2019/scripts")
	robocopy(SOURCE_PATH_LIST, os.path.expanduser("~") + "/maya/2020/scripts")
	robocopy(SOURCE_PATH_LIST, os.path.expanduser("~") + "/maya/2022/scripts")
	robocopy(SOURCE_PATH_LIST, os.path.expanduser("~") + "/maya/2023/scripts")
	cmds.confirmDialog(icn="information", m = "Tool has been updated! Please re-open Tool!")

def open_hs_tool_document(*arg):
	shutil.copy(SERVER_DATABASE_PATH + '/HardSurfaceTool_Document.html', tempfile.gettempdir() + '/HardSurfaceTool_Document.html')
	os.system('start ' + tempfile.gettempdir() + '/HardSurfaceTool_Document.html')

def robocopy(source, des):
	#source is list full file name or folder
	#des is full folder path destination
	file = {}
	folder = []
	for f in source:
		if os.path.isfile(f):
			file[os.path.split(f)[1]] = os.path.split(f)[0]
		else:
			folder.append(f)
	folder_from_file = {}
	
	for key, value in iteritems(file):
		if value not in folder_from_file:
			folder_from_file[value] = [key]
		else:
			folder_from_file[value].append(key)
	cmd =  r"C:\Windows\System32\Robocopy.exe "
	if file:
		for k, v in iteritems(folder_from_file):
			cmd += '"' + k + '" "' + des + '" '
			for f in v:
				cmd += '"' + f + '" '
			cmd += "/Z" + " /MT"
			out = subprocess.call(cmd, shell = False)
			cmd = r"C:\Windows\System32\Robocopy.exe "
	if folder:
		for f in folder:
			cmd += '"' + f + '" "' + des + '/' + os.path.split(f)[1] + '"' + " /S" + " /Z" + " /MT"
			subprocess.call(cmd, shell = False)
			cmd = r"C:\Windows\System32\Robocopy.exe "
	return True

#endregion

#endregion