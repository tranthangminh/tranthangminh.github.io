import maya.cmds as cmds
import maya.mel as mel
import math
import os
import site

try:
	from importlib import reload
except:
	pass

# VARIABLES

LOCAL_PATH = os.path.expanduser("~").replace("\\", "/") + "/maya/" + str(cmds.about(version=True)) + "/scripts"
if int(cmds.about(version=True)) >= 2023:
	LOCAL_PATH = os.path.expanduser("~").replace("\\", "/") + "/Documents/maya/" + str(cmds.about(version=True)) + "/scripts"

#region SUPPORT
site.addsitedir(LOCAL_PATH + '/Normal_Tools/Scripts/Python')
mel.eval('source ' + '"' + LOCAL_PATH + '/Normal_Tools/Scripts/Mel/' + 'NormalTools_SupportFunction.mel";')

def normalize_vector(vector):
	vector_length = math.sqrt(sum([e**2 for e in vector]))
	normalize_vector = [e/vector_length for e in vector]
	return normalize_vector

def toggle_selected_normal(*arg):
	normal_size = cmds.floatField('normal_size_textfield', v=True, q=True)
	is_display_normals = cmds.polyOptions(activeObjects=True, displayNormal=True, query=True)
	if (is_display_normals):
		toggle_normals = not is_display_normals[0]
		cmds.polyOptions(activeObjects=True, displayNormal=toggle_normals, point=True, sizeNormal= normal_size)

def toggle_everything_normal(*arg):
	normal_size = cmds.floatField('normal_size_textfield', v=True, q=True)
	is_display_normals = cmds.polyOptions(activeObjects=True, displayNormal=True, query=True)
	if (is_display_normals):
		toggle_normals = not is_display_normals[0]
	cmds.polyOptions(gl=True, displayNormal=toggle_normals, point=True, sizeNormal=normal_size)

#endregion

#region COPY/PASTE NORMAL

def copy_vertex_normal(*arg):
	mel.eval('GE_CopyVertexNormals(\"x\");')

def paste_vertex_normal(*arg):
	# Get soft edges
	selected = cmds.ls(sl=True, fl=True)
	get_soft_edges()
	soft_edges = cmds.ls(sl=True, fl=True)

	# Paste normal
	cmds.select(selected)
	mel.eval('GE_PasteVertexNormals(\"x\");')
	
	# Set soft edge
	cmds.select(soft_edges)
	mel.eval('polyPerformAction "polySoftEdge -a 180" e 0;')
	cmds.polySoftEdge(soft_edges, ch=True, angle=180)

	# Reset select
	cmds.ConvertSelectionToVertices()
	cmds.select(selected)

def copy_average_normal(*arg):
	mel.eval('GE_CopyAverageVertexNormal();')

def copy_paste_average_3_vetices_normals(*arg):
	# Get soft edges
	selected = cmds.ls(sl=True, fl=True)
	get_soft_edges()
	soft_edges = cmds.ls(sl=True, fl=True)

	# Paste normal
	cmds.select(selected)
	mel.eval('GE_PasteVertexNormals3Verts();')
	
	# Set soft edge
	cmds.select(soft_edges)
	mel.eval('polyPerformAction "polySoftEdge -a 180" e 0;')
	cmds.polySoftEdge(soft_edges, ch=True, angle=180)
	
	# Reset select
	cmds.ConvertSelectionToVertices()
	cmds.select(selected)

def copy_paste_average_normals(*arg):
	# Get soft edges
	selected = cmds.ls(sl=True, fl=True)
	get_soft_edges()
	soft_edges = cmds.ls(sl=True, fl=True)

	# Paste normal
	cmds.select(selected)
	mel.eval('GE_CopyPasteAverageVertexNormal();')
	
	# Set soft edge
	cmds.select(soft_edges)
	mel.eval('polyPerformAction "polySoftEdge -a 180" e 0;')
	cmds.polySoftEdge(soft_edges, ch=True, angle=180)
	
	# Reset select
	cmds.ConvertSelectionToVertices()
	cmds.select(selected)

def inverse_selected_vertex_normals(*arg):
    selected = cmds.ls(sl=True, fl=True, l=True)
    for i in selected:
        cmds.select(d=True)
        cmds.select(i)
        list = cmds.polyNormalPerVertex(q=True, xyz=True)
        result = [0,0,0]
        while len(list):
            result = [result[0] + list.pop(0), result[1] + list.pop(0), result[2] + list.pop(0)]
        result = (-result[0], -result[1], -result[2])
        cmds.polyNormalPerVertex(xyz=result)
    cmds.select(selected)

#endregion

#region TRANSFER NORMAL
def pick_source_for_transfer(*arg):
	selected_mesh = cmds.ls(long=True, selection=True)

	if(len(selected_mesh)==1):
		cmds.textField('source_normal_textfield', e = True, tx = selected_mesh[0])
	else:
		cmds.confirmDialog(title='Confirm', message='Please select ONE mesh', button=['Confirm'], defaultButton='Confirm', cancelButton='Confirm', dismissString='No')

def copy_vertex_normal_for_transfer(source_vertices=None, destination_vertices=None):
	closest_vertex = None
	for destination_vertex in destination_vertices:

		min_distance = 1000000
		for source_vertex in source_vertices:

			source_vertex_coordinate = cmds.xform(source_vertex,
												query=True,
												worldSpace=True,
												translation=True)
			destination_vertex_coordinate = cmds.xform(destination_vertex,
												query=True,
												worldSpace=True,
												translation=True)

			distance_vertices = sum([(src - des)**2 for src, des in zip(source_vertex_coordinate, destination_vertex_coordinate)])

			if(distance_vertices < min_distance):
				min_distance = distance_vertices
				closest_vertex = source_vertex

		closest_vertex_normal = cmds.polyNormalPerVertex(closest_vertex, query=True, normalXYZ=True)

		for k in range(0, len(closest_vertex_normal), 3):
			cmds.polyNormalPerVertex(destination_vertex,
									normalXYZ=[closest_vertex_normal[k],
											closest_vertex_normal[k+1],
											closest_vertex_normal[k+2]])

def transfer_normals_to_selected_vertices(*arg):
	source_mesh = cmds.textField('source_normal_textfield', tx = True, q = True)
	selected_vertex = cmds.ls(long=True, selection=True, flatten=True)
	if(source_mesh and selected_vertex):
		if('.vtx' in selected_vertex[0]):
			transfer_normals_to_selected_vertices_function(source_object=source_mesh, selected_vertices=selected_vertex)

		else:
			infor = 'Please Pick source MESH, then select destination VERTEX'
			cmds.confirmDialog(title='Confirm', message=infor, button=['Confirm'], defaultButton='Confirm', cancelButton='Confirm', dismissString='No')

	else:
		infor = 'Please Pick source MESH, then select destination VERTEX'
		cmds.confirmDialog(title='Confirm', message=infor, button=['Confirm'], defaultButton='Confirm', cancelButton='Confirm', dismissString='No')

def transfer_normals_to_selected_vertices_function(source_object=None, selected_vertices=None):

	source_object_to_vertex = cmds.polyListComponentConversion(source_object, toVertex=True)
	source_object_vertex = cmds.ls(source_object_to_vertex, flatten=True)

	copy_vertex_normal_for_transfer(source_vertices=source_object_vertex, destination_vertices=selected_vertices)

def transfer_normals_to_object(*arg):
	source_mesh = cmds.textField('source_normal_textfield', tx = True, q = True)
	selected_mesh = cmds.ls(long=True, selection=True)

	if(source_mesh and selected_mesh):
		for e_mesh in selected_mesh:
			transfer_normals_to_object_function(source_object=source_mesh, destination_object=e_mesh)
	else:
		cmds.confirmDialog(title='Confirm', message='Please Pick source mesh, then select destination mesh', button=['Confirm'], defaultButton='Confirm', cancelButton='Confirm', dismissString='No')

def transfer_normals_to_object_function(source_object=None, destination_object=None):
	# Get source_object's path, destination_object's path
	source_object_path = cmds.listRelatives(source_object, fullPath=True, parent=True)
	detination_object_path = cmds.listRelatives(destination_object, fullPath=True, parent=True)

	# UNparent object(parent to WORLD)
	if(source_object_path):
		unparent_object = cmds.parent(source_object, world=True)
		source_object = unparent_object[0]

	if(detination_object_path):
		unparent_object = cmds.parent(destination_object, world=True)
		destination_object = unparent_object[0]

	# Clean UP (makeIdentity & DeleteHistory)
	cmds.makeIdentity(source_object,
					apply=True,
					translate=True,
					rotate=True,
					scale=True,
					normal=0)
	cmds.delete(source_object , constructionHistory=True)
	cmds.makeIdentity(destination_object,
					apply=True,
					translate=True,
					rotate=True,
					scale=True,
					normal=0)
	cmds.delete(destination_object , constructionHistory=True)

	# transfer Normals object by [cmds.transferAttributes]
	cmds.transferAttributes(source_object, destination_object,
							transferPositions=0,
							transferNormals=1,
							transferUVs=0,
							transferColors=0,
							sampleSpace=0,
							searchMethod=3,
							flipUVs=0,
							colorBorders=1)
	cmds.delete(destination_object , constructionHistory=True)

	# REparent object(parent to the original path)
	if(source_object_path):
		cmds.parent(source_object, source_object_path)

	if(detination_object_path):
		unparent_object = cmds.parent(destination_object, detination_object_path)

	cmds.select(destination_object)
	cmds.makeIdentity(destination_object,
					apply=True,
					translate=True,
					rotate=True,
					scale=True,
					normal=0)

	cmds.select(source_object)
	cmds.makeIdentity(source_object,
					apply=True,
					translate=True,
					rotate=True,
					scale=True,
					normal=0)

#endregion

#region LOCK/UNLOCK NORMAL
def get_current_selection_mode():
	selected = cmds.ls(sl=True, fl=True)
	mode = selected[0].split("[", 1)[0].rsplit(".", 1)[-1]
	if mode == 'vtx' or mode == 'f' or mode == 'vtxFace' or mode == 'e':
		return mode
	else:
		return 'obj'

def return_selection_mode(mode):
	if mode == 'vtx':
		cmds.ConvertSelectionToVertices()
	elif mode == 'vtxFace':
		cmds.ConvertSelectionToVertexFaces()
	elif mode == 'f':
		cmds.ConvertSelectionToFaces()
	elif mode == 'e':
		cmds.ConvertSelectionToEdges()

def get_soft_edges():
	cmds.ConvertSelectionToEdges()
	mel.eval("resetPolySelectConstraint();")
	cmds.polySelectConstraint(m=0, dis=True)
	cmds.polySelectConstraint(m=3, t=0x8000, sm=2)
	cmds.polySelectConstraint(m=0, dis=True)
	mel.eval("resetPolySelectConstraint();")

def lock_normals(*arg):
	mode = get_current_selection_mode()
	# Get infor selected
	selected = cmds.ls(sl=True, fl=True)
	get_soft_edges()
	soft_edges = cmds.ls(sl=True, fl=True)
	# Lock normal
	cmds.select(selected)
	if mode != 'vtxFace':
		selected_vt = cmds.ls(cmds.polyListComponentConversion(selected, tv=True), fl=True)
		for vt in selected_vt:
			if not cmds.polyNormalPerVertex(vt, q=True, al=True)[0]:
				cmds.polyNormalPerVertex(vt, freezeNormal=True)
	else:
		cmds.polyNormalPerVertex(freezeNormal=True)

	# Set soft edge
	cmds.select(soft_edges)
	mel.eval('polyPerformAction "polySoftEdge -a 180" e 0;')
	cmds.polySoftEdge(soft_edges, ch=True, angle=180)
	# Reset select
	return_selection_mode(mode)
	cmds.select(selected)

def unlock_normals(*arg):
	mode = get_current_selection_mode()
	# Get infor selected
	selected = cmds.ls(sl=True, fl=True)
	get_soft_edges()
	soft_edges = cmds.ls(sl=True, fl=True)

	# Unlock normal
	cmds.select(selected)
	selected_vt = cmds.ls(cmds.polyListComponentConversion(selected, tv=True), fl=True)
	cmds.polyNormalPerVertex(selected_vt, unFreezeNormal=True)

	# Set soft edge
	cmds.select(soft_edges)
	mel.eval('polyPerformAction "polySoftEdge -a 180" e 0;')
	cmds.polySoftEdge(soft_edges, ch=True, angle=180)
	# Reset select
	return_selection_mode(mode)
	cmds.select(selected)

def unlock_normals_with_hard_soft_edges(*arg):
	import lockNormals_toHS as lockNormals_toHS
	reload(lockNormals_toHS)

def lock_follow_small_face(*arg):
	mel.eval('GE_LockEdgeNormalsByRelatedFaceAreas(0)')

def lock_follow_large_face(*arg):
	mel.eval('GE_LockEdgeNormalsByRelatedFaceAreas(1)')

def smooth_bevelled_faces(*arg):
	mel.eval('boltNorms.SmoothBevel(0)')

def smooth_flatten_faces(*arg):
	mel.eval('boltNorms.SmoothFaces()')

def transfer_normal(*arg):
	mel.eval('GE_transfer_normal();')

def lock_face_90_angle(*arg):
	mode = get_current_selection_mode()
	current_object = cmds.ls(sl=True, fl=True)[0].rsplit("[", 1)[0].rsplit(".", 1)[0]

	# Get border edges
	selected_faces = cmds.ls(sl=True, fl=True)

	cmds.ConvertSelectionToEdgePerimeter()
	border_edges = cmds.ls(sl=True, fl=True)

	# Get hard edges
	cmds.polySelectConstraint(m=3, t=0x8000, sm=1)
	mel.eval('resetPolySelectConstraint;')
	hard_edges = cmds.ls(sl=True, fl=True)

	# Get soft border edges
	soft_border_edges = list(set(border_edges) - set(hard_edges))
	soft_border_edge_num = len(soft_border_edges)

	# Get side vertices
	side_vertices = []

	soft_border_vertices = cmds.ls(cmds.polyListComponentConversion(soft_border_edges, tv=True), fl=True)

	for v in soft_border_vertices:
		edges = cmds.ls(cmds.polyListComponentConversion(v, fv=True, te=True), fl=True)
		edge_in_list_num = len(list(set(soft_border_edges) - set(edges)))
		if edge_in_list_num == soft_border_edge_num - 1:
			side_vertices.append(v)

	inside_vertices = list(set(soft_border_vertices) - set(side_vertices))

	# Get vertex faces
	selected_edge_vertex_faces = cmds.ls(cmds.polyListComponentConversion(soft_border_edges, tvf=True), fl=True)
	selected_vertices_vertex_faces = cmds.ls(cmds.polyListComponentConversion(inside_vertices, tvf=True), fl=True)

	hard_edge_vertex_faces = cmds.ls(cmds.polyListComponentConversion(selected_faces, tvf=True), fl=True)

	selected_vertex_faces = list(set(selected_edge_vertex_faces + selected_vertices_vertex_faces + hard_edge_vertex_faces))

	# Get true normal
	cmds.select(selected_faces)
	mel.eval("source \"" + LOCAL_PATH + "/Model_Tools/Scripts/Mel/Clone.mel\"")
	new_object = cmds.ls(sl=True, l=True)
	true_vertex = cmds.ls(cmds.polyListComponentConversion(new_object, tv=True), fl=True)[0]
	cmds.select(true_vertex)
	copy_vertex_normal()

	# Apply true normal to all vertex faces
	cmds.delete(new_object)
	cmds.select(selected_vertex_faces)
	paste_vertex_normal()

	# Soft edge
	cmds.select(selected_faces)
	cmds.ConvertSelectionToContainedEdges()
	contained_edges = cmds.ls(sl=True, fl=True)
	
	# Check contained_edges
	if selected_faces == contained_edges:
		contained_edges = []
	final_edges = contained_edges + cmds.ls(cmds.polyListComponentConversion(inside_vertices, te=True), fl=True)
	final_edges = list(set(final_edges) - set(hard_edges))
	cmds.select(final_edges)
	mel.eval('polyPerformAction "polySoftEdge -a 180" e 0;')
	if len(soft_border_edges) != 0:
		cmds.polySoftEdge(soft_border_edges, ch=True, angle=180)

	# Return Selection
	cmds.select(current_object)
	return_selection_mode(mode)
	cmds.select(selected_faces)

def lock_hard_face(*arg):
	cmds.polySetToFaceNormal()
	cmds.ConvertSelectionToVertexFaces()
	lock_normals()
	cmds.ConvertSelectionToFaces()


#endregion

#region CONNECT NORMAL

def connect_with_follow(*arg):
	sel = cmds.ls(sl=True, fl=True, l=True)
	storeVertex = []
	newVertex = []

	for edge in sel:
		converVertex = cmds.polyListComponentConversion(edge, fromEdge=True, toVertex=True)
		cmds.select(converVertex)
		converVertex = cmds.ls(sl=True, fl=True, l=True)
		storeVertex.append(converVertex)
	
	edgeConnection = cmds.polyConnectComponents(sel, ch=True, insertWithEdgeFlow=True, adjustEdgeFlow=True)
	for vertex in storeVertex:
		cmds.select(vertex)
		sel_ver = cmds.ls(sl=True, fl=True, l=True)
		firstIndex = sel_ver[0][(sel_ver[0].index("[")+1):-1]
		secondIndex = sel_ver[1][(sel_ver[1].index("[")+1):-1]
		cmds.polySelect(shortestEdgePath=[int(firstIndex),int(secondIndex)])
		converVertex = cmds.polyListComponentConversion(fromEdge=True, toVertex=True)
		cmds.select(converVertex)
		converVertex = cmds.ls(sl=True, fl=True, l=True)
		newVertex.extend([i for i in converVertex if i not in sel_ver])
		cmds.select(converVertex)
		mel.eval("GE_PasteVertexNormals3Verts;")

	cmds.select(newVertex)
	mel.eval("ConvertSelectionToContainedEdges;")
	cmds.polySoftEdge(ch=True, a=180)

def connect_without_follow(*arg):
	sel = cmds.ls(sl=True, fl=True, l=True)
	storeVertex = []
	newVertex = []

	for edge in sel:
		converVertex = cmds.polyListComponentConversion(edge, fromEdge=True, toVertex=True)
		cmds.select(converVertex)
		converVertex = cmds.ls(sl=True, fl=True, l=True)
		storeVertex.append(converVertex)
	
	edgeConnection = cmds.polyConnectComponents(sel, ch=True, insertWithEdgeFlow=False, adjustEdgeFlow=True)
	for vertex in storeVertex:
		cmds.select(vertex)
		sel_ver = cmds.ls(sl=True, fl=True, l=True)
		firstIndex = sel_ver[0][(sel_ver[0].index("[")+1):-1]
		secondIndex = sel_ver[1][(sel_ver[1].index("[")+1):-1]
		cmds.polySelect(shortestEdgePath=[int(firstIndex),int(secondIndex)])
		converVertex = cmds.polyListComponentConversion(fromEdge=True, toVertex=True)
		cmds.select(converVertex)
		converVertex = cmds.ls(sl=True, fl=True, l=True)
		newVertex.extend([i for i in converVertex if i not in sel_ver])
		cmds.select(converVertex)
		mel.eval("GE_PasteVertexNormals3Verts;")
		cmds.select(newVertex)
		cmds.polyNormalPerVertex(ufn=True)

	cmds.select(newVertex)
	mel.eval("ConvertSelectionToContainedEdges;")
	cmds.polySoftEdge(ch=True, a=180)

#endregion
