try:
    from importlib import reload
except:
    pass
from HardSurface_Tool import HardSurfaceTool
reload(HardSurfaceTool)
HardSurfaceTool.GUI()