import maya.cmds as cmds
import pymel.core as pm
import math

def lineIntersect(A, B, C, D):
    '''

    Description:
        Find an intersect point between two line (AB, CD)
        
    Args:
         A, B ,C ,D: (Vector3) present for point in R3 space
         
    Returns:
        Intersect point: (Vector3) if two lines are crossed to each other. 
        
    Raises:
        TypeError: if two line aren't crossed.
    '''
    a = B - A
    b = D - C
    c = C - A
    cross1 = a.cross(b)
    cross2 = c.cross(b)
    intersectPoint = A + a* cross2.dot(cross1)/math.pow(cross1.length(),2)
    return intersectPoint

def getConnectedEdges():
    #if not cmds.selectType(q = True, e = True):   
    selectedEdges = cmds.ls(sl = True, fl = True)
    unconnectedSelectedEdges = list()
    #currentEdge = selectedEdges[0]
    while len(selectedEdges) > 0:
        unconnectedSelectedEdges.append(list())
        unconnectedSelectedEdges[len(unconnectedSelectedEdges) - 1].append(selectedEdges[0])
        selectedEdges.remove(selectedEdges[0])
        i = 0
        while i < len(unconnectedSelectedEdges[len(unconnectedSelectedEdges) - 1]):
            i += 1
            verts = cmds.polyListComponentConversion(unconnectedSelectedEdges[len(unconnectedSelectedEdges) - 1], tv = True)
            neigborEdges = cmds.polyListComponentConversion(verts, te = True)
            cmds.select(neigborEdges)
            neigborEdges = cmds.ls(sl= True, fl = True)
            for e in neigborEdges:
                if e in selectedEdges:
                    selectedEdges.remove(e)
                    unconnectedSelectedEdges[len(unconnectedSelectedEdges) - 1].append(e)
    return unconnectedSelectedEdges   

def smartCollapsing():          
    print('--execute ---')
    edgeSets = getConnectedEdges()
    for set in edgeSets:
        #try:
            verts = list()
            endVerts = list()
            midleVerts = list()
            for e in set:
                for vertStr in cmds.polyListComponentConversion(e, tv = True):
                    cmds.select(vertStr)
                    for v in cmds.ls(sl = True, fl = True):
                        verts.append(v)
                        # filter verts to separate endverts and midle
            
            for v in verts:
                if verts.count(v) > 1:
                    midleVerts.append(v)
                else:
                    endVerts.append(v)
                            
            # get end edges
            edges = cmds.polyListComponentConversion(endVerts, te = True)
            execEdges = list()
            cmds.select(edges)
            for e in cmds.ls(sl = True, fl = True):
                if e in set:
                    execEdges.append(e)
            cmds.select(execEdges)
            # there are only two edges at the end
            # get two point on the first edges
            vertSet = cmds.polyListComponentConversion(execEdges[0], tv = True)
            cmds.select(vertSet)
            vertSet = cmds.ls(sl = True, fl = True)
            pointA = pm.pointPosition(vertSet[0])
            pointB = pm.pointPosition(vertSet[1])
            # get two point on the second edges
            vertSet = cmds.polyListComponentConversion(execEdges[1], tv = True)
            cmds.select(vertSet)
            vertSet = cmds.ls(sl = True, fl = True)
            pointC = pm.pointPosition(vertSet[0])
            pointD = pm.pointPosition(vertSet[1])
            # get the intersect Point base on 4 point
            intersectPoint = lineIntersect(pointA, pointB, pointC, pointD)
            for v in midleVerts:
                pm.move(v, intersectPoint)
        #except:
        #   continue 
    polybase = cmds.ls(hl = True)
    cmds.select(polybase) 
    cmds.polyMergeVertex( d = 0.001)  
    
cmds.undoInfo(openChunk = True)
smartCollapsing()
cmds.undoInfo(closeChunk = True)