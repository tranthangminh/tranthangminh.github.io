import sys
envRoot = r'\\virtuosgames.com\geh\TOOLS\Technical_Deployment\ReleaseLine\GE_ToolSet\plugin\GhostStory_Replay_HS_22\maya'
if envRoot not in sys.path:
    sys.path.append(envRoot)
    
import CheckingTools_GhostStory_Replay_HS_22

try:
    from importLib import reload
except:
    pass
    
reload(CheckingTools_GhostStory_Replay_HS_22)

CheckingTools_GhostStory_Replay_HS_22.GUI(CheckingTools_GhostStory_Replay_HS_22)