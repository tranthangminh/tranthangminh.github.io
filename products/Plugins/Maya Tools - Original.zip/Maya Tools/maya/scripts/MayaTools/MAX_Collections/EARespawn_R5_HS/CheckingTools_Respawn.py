import site
site.addsitedir(r'//virtuosgames.com/geh/TOOLS/TECHNICAL_SCRIPT/Projects/Hard_Surface/Respawn')

import CheckingTools_Respawn
reload(CheckingTools_Respawn)
CheckingTools_Respawn.GUI(CheckingTools_Respawn)