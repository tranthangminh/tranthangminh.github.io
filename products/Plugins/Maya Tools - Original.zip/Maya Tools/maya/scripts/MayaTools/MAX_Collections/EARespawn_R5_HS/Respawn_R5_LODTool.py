import site 
site.addsitedir(r'\\virtuosgames.com\geh\TOOLS\TECHNICAL_SCRIPT\Projects\Hard_Surface\Respawn')
import Respawn_R5_LODTool
reload(Respawn_R5_LODTool)
Respawn_R5_LODTool.GUI()